import os,sys,json,time,subprocess,tempfile,pathlib
BASE=pathlib.Path(__file__).parent
S=BASE/'source'
R=BASE/(sys.argv[1] if len(sys.argv)>1 else '.')
R.mkdir(exist_ok=True)
tmp=pathlib.Path(tempfile.mkdtemp(prefix='zaratustra-review-d-scoped-'))
env=os.environ.copy()
for k in ['ZARATUSTRA_SQLITE_DLL','PYTHONPATH','PYTEST_ADDOPTS','ZARA_RESTART_EVIDENCE','ZARA_RESTART_NEGATIVES']: env.pop(k,None)
env['PYTHONPATH']=os.pathsep.join(str(S/p) for p in ['packages/core/src','packages/app/src','src'])
env['TEMP']=env['TMP']=str(tmp)
env['PYTEST_ADDOPTS']='--basetemp='+(tmp/'pytest').as_posix()
env['ZARA_RESTART_EVIDENCE']=str(R/'scoped-traces')
env['ZARA_RESTART_NEGATIVES']=str(R/'scoped-negatives')
(R/'scoped-traces').mkdir(exist_ok=True)
cmd=[sys.executable,'-m','pytest',sys.argv[2] if len(sys.argv)>2 else 'tests/restart','-q']
(R/'scoped-invocation.json').write_text(json.dumps(dict(command=cmd,cwd=str(S),env={k:env[k] for k in ['PYTHONPATH','TEMP','PYTEST_ADDOPTS','ZARA_RESTART_EVIDENCE','ZARA_RESTART_NEGATIVES']},source='11ebf956bafc2bbca4a3685e37d117474f11c151'),indent=2))
start=time.time()
with (R/'scoped.stdout.bin').open('xb') as out,(R/'scoped.stderr.bin').open('xb') as err:
 p=subprocess.run(cmd,cwd=S,env=env,stdout=out,stderr=err)
(R/'scoped-exit.json').write_text(json.dumps(dict(returncode=p.returncode,seconds=time.time()-start)))
print(p.returncode)
