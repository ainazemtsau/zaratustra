import hashlib,json,zipfile,tarfile,pathlib,subprocess,sys,tomllib
R=pathlib.Path(__file__).parent
W=R.parents[2]
E=W/'evidence/package-d/final-11ebf95'
S=R/'source'
def h(b): return hashlib.sha256(b).hexdigest()
def write(n,o): (R/n).write_text(json.dumps(o,indent=2),encoding='utf-8')
report={'checks':[]}
def ck(name,ok,**kw):
 report['checks'].append(dict(name=name,pass_=bool(ok),**kw))
 assert ok,(name,kw)
pins={'source-11ebf95.zip':'2b58def9e487d57d71fe8cde3febcea66d5ef7c702db1af666bf2876973037ac','zaratustra-next-d-11ebf95-windows-x64.zip':'5efe5b0c9b92f0c458740171691d0aa09c49abf8c99f05f6d847bcad206d65ee','install-11ebf95/manifest.json':'8f77ca685cde73e82e243c810b6f6560982c74820cfaae639065c8bc60a8e7f5','SOURCE-MANIFEST.json':'5090e396549ccf7c4d910cbc1f551381ecd9bd4141b3fdc48f4717982f2a4d24'}
try:
 for p,v in pins.items(): ck('pin:'+p,h((E/p).read_bytes())==v,sha256=h((E/p).read_bytes()))
 manifest=json.loads((E/'SOURCE-MANIFEST.json').read_bytes())
 with zipfile.ZipFile(E/'source-11ebf95.zip') as z:
  for f in manifest['files']:
   raw=(S/f['path']).read_bytes()
   ck('source:'+f['path'],len(raw)==f['bytes'] and h(raw)==f['sha256'] and z.read(f['path'])==raw)
 build=E/'install-11ebf95/physical-builds'
 installed=pathlib.Path('C:/Users/Anton/AppData/Local/Temp/zaratustra-d-11ebf95-kfg90fay/runtime/env/Lib/site-packages')
 installed_owner=pathlib.Path('C:/Users/Anton/AppData/Local/Temp/zaratustra-d-owner-11ebf95-g6wg1szb/runtime/env/Lib/site-packages')
 prod=[]
 for pkg,mod,dist in [('core','zaratustra_core','zaratustra_core'),('app','zaratustra_app','zaratustra_next')]:
  with zipfile.ZipFile(build/(dist+'-0.1.0-py3-none-any.whl')) as z,tarfile.open(build/(dist+'-0.1.0.tar.gz')) as t:
   for p in (S/'packages'/pkg/'src'/mod).rglob('*'):
    if p.suffix not in {'.py','.ts','.mjs'}: continue
    rel=p.relative_to(S/'packages'/pkg/'src').as_posix()
    raw=p.read_bytes()
    ck('distribution:'+rel,z.read(rel)==raw and t.extractfile(dist+'-0.1.0/src/'+rel).read()==raw and (installed/rel).read_bytes()==raw and (installed_owner/rel).read_bytes()==raw,sha256=h(raw),bytes=len(raw))
    prod.append(rel)
 lock=(S/'uv.lock').read_text(encoding='utf-8')
 for wh in (E/'owner-bundle/wheels').glob('*.whl'):
  if wh.name.startswith(('zaratustra_core','zaratustra_next')): continue
  ck('dependency-lock:'+wh.name,h(wh.read_bytes()) in lock,sha256=h(wh.read_bytes()))
  with zipfile.ZipFile(wh) as z:
   for name in z.namelist():
    if name.endswith('/') or '.dist-info/' in name: continue
    ck('installed-dependency:'+name,(installed_owner/name).read_bytes()==z.read(name))
 report.update(production_files=len(prod),source_files=len(manifest['files']),archive_note='Own git archive zip container differs from author custom zip; all 400 scope file contents compared exactly, no LF normalization.')
finally: write('byte-verification.json',report)
print(json.dumps({'checks':len(report['checks']),'production_files':len(prod),'all_pass':all(c['pass_'] for c in report['checks'])}))
