import pathlib,json,tempfile,time,subprocess,io,sys
from urllib.error import HTTPError
from zaratustra_core import Core,CoreError
from zaratustra_app import Conversation,Pi,LiveProfile
from zaratustra_app.adapters.pi import bridge
R=pathlib.Path(__file__).parent
old='--expect-old' in sys.argv
B=pathlib.Path(tempfile.mkdtemp(prefix='zaratustra-native-capability-',dir='C:/Users/Anton/AppData/Local/Temp'))
auth=B/'fictional-auth.json';auth.write_text(json.dumps({'openai':dict(type='oauth',access='FICTIONAL_NATIVE_ACCESS',refresh='FICTIONAL_NATIVE_REFRESH',expires=int(time.time()*1000)+3600000)}),encoding='utf-8')
preload=B/'local-only.mjs';preload.write_text("const f=globalThis.fetch;globalThis.fetch=(u,...a)=>{if(!String(u).startsWith('http://127.0.0.1:'))throw Error('unexpected_external_network');return f(u,...a);};",encoding='utf-8')
def sse(text):
 m={'id':'m-cap','type':'message','role':'assistant','status':'completed','content':[{'type':'output_text','text':text,'annotations':[]}]};r={'id':'r-cap','object':'response','status':'completed','model':'gpt-6-luna','output':[m],'usage':{'input_tokens':1,'output_tokens':1,'total_tokens':2}}
 ev=[{'type':'response.created','response':r|{'output':[],'status':'in_progress'}},{'type':'response.output_item.added','output_index':0,'item':m|{'content':[],'status':'in_progress'}},{'type':'response.content_part.added','item_id':m['id'],'output_index':0,'content_index':0,'part':{'type':'output_text','text':'','annotations':[]}},{'type':'response.output_text.delta','item_id':m['id'],'output_index':0,'content_index':0,'delta':text},{'type':'response.output_text.done','item_id':m['id'],'output_index':0,'content_index':0,'text':text},{'type':'response.output_item.done','output_index':0,'item':m},{'type':'response.completed','response':r}]
 return ''.join('event: '+e['type']+'\ndata: '+json.dumps(e)+'\n\n' for e in ev).encode()
original_pop=subprocess.Popen;original_opener=bridge.build_opener
packets=[];failure=None;result=None
def pop(cmd,**kwargs):return original_pop([cmd[0],'--import',preload.as_uri(),*cmd[1:]],**kwargs)
class Response(io.BytesIO):status=200;headers={'Content-Type':'text/event-stream'}
class Controlled:
 def open(self,req,timeout):
  payload=json.loads(req.data);packets.append(payload)
  assert req.full_url=='https://api.openai.com/v1/responses'
  assert payload['model']=='gpt-6-luna' and payload['max_output_tokens']==64 and payload['stream'] and not payload['store']
  if any(x.get('type')=='configuration_update' for x in payload['input']):
   raw=json.dumps({'error':{'type':'invalid_request_error','code':'subscription_sharing_unsupported_capability','param':'input','message':'configuration_update is unsupported by the selected subscription route'}}).encode()
   raise HTTPError(req.full_url,400,'controlled subscription capability refusal',{},io.BytesIO(raw))
  return Response(sse(json.dumps({'state':'completed','text':'controlled supported request','changes':[],'expected_heads':{}})))
try:
 subprocess.Popen=pop;bridge.build_opener=lambda *_:Controlled()
 core,t=Core.initialize(B/'data');s=Conversation(core,t);s.submit('Fictional transport test only, no semantic G14 claim.')
 live=LiveProfile(endpoint='https://api.openai.com/v1',model='gpt-6-luna',auth_mode='pi-chatgpt',auth_path=str(auth),max_tokens=64,context_window=128000,timeout=15)
 pi=Pi(pathlib.Path('C:/Users/Anton/AppData/Roaming/npm/node_modules/@earendil-works/pi-coding-agent/dist/bundle/cli.js'),B/'pi',live.endpoint,live=live)
 try:result=s.run(pi,{'fixture':'independent-capability-admission'},4)
 except CoreError as e:failure=e.as_dict()
 assert len(packets)==pi.provider_sends==1
 has_update=any(x.get('type')=='configuration_update' for x in packets[0]['input'])
 assert has_update==old and bool(result)==(not old),(has_update,result,failure)
 if not old:
  assert result['text']=='controlled supported request'
  assert packets[0]['reasoning']['effort']=='medium','Keep the agent effective effort in request-level reasoning; do not silently drop it.'
 for p in (B/'pi').rglob('*'):
  if p.is_file() and p.suffix in {'.bin','.jsonl'}:
   raw=p.read_bytes();assert b'FICTIONAL_NATIVE_ACCESS' not in raw and b'FICTIONAL_NATIVE_REFRESH' not in raw
   dest=R/('capability-old-raw' if old else 'capability-raw')/p.relative_to(B/'pi');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
finally:
 subprocess.Popen=original_pop;bridge.build_opener=original_opener
 (R/('native-capability-old.json' if old else 'native-capability.json')).write_text(json.dumps(dict(base=str(B),request_count=len(packets),request=packets[0] if packets else None,result=result,failure=failure,expected_old=old),indent=2),encoding='utf-8')
print(json.dumps(dict(expected_old=old,requests=1,all_pass=True)))
