# F-D-05 — Native SDK silently raises accepted profile token caps below16

Importance: required resource-boundary defect. Source `11ebf956bafc2bbca4a3685e37d117474f11c151`. Exact responsibility: `packages/app/src/zaratustra_app/executor_port.py:LiveProfile.__post_init__`, native model override and `Pi.run`; installed Pi SDK `openai-responses.js` applies its documented minimum output limit16.

Independent actual-SDK controlled probes on the exact installed build measured:

| Selected profile max_tokens | Actual forwarded max_output_tokens | Physical sends |
| --- | --- | --- |
|1|16|1|
|15|16|1|
|16|16|1|
|64|64|1|

The profile accepts1 and15; the actual native request widens each to16 before forwarding. Therefore the selected cap is not honored even though the physical send cap and the positive16/64 cases remain correct. No claim is made that a real provider generated excess tokens: these are fictional credentials and controlled local responses, with all external network disabled. The evidence is the actual emitted request, not a scanner/constant check or an inferred tuning effect.

Reproduction is `native_token_cap_probe.py`, one isolated fixture per argument1/15/16/64, run by the exact installed Python. `token-cap-summary.json`, `token-cap-*/native-capability.json` and raw host/native/provider files preserve inputs, actual translated request and results. The baseline64 passes the existing native compatibility check; all injections are valid accepted profiles, not broken imports or builds. No real credentials were read or copied.

The first G14 on this source selected4096 and forwarded4096, so this boundary defect is separate from its missing-Activity failure. It does not relabel the substantive text result. A bounded correction must reject an unsupported too-small profile before inference or otherwise honor its exact cap; it must not silently increase the owner's limit or substitute access/model/endpoint. Preserve positive16/64, other API-mode contracts and the existing physical cap, and verify the actual generated request. A new production source/build needs the usual independent reconciliation.
