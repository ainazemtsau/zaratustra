import pathlib,json
from zaratustra_core import Core
R=pathlib.Path(__file__).parent
execution=json.loads((R/'g14-installed/execution.json').read_bytes())
root=pathlib.Path(execution['data_root'])
# Generated disposable Core credential only; never output or export its value.
client=Core(root).connect((root/'owner.credential').read_text(encoding='utf-8'))
s=client.call('read_snapshot',{},'independent-new-process-read')
activity=[x for x in s['heads'] if x['kind']=='activity']
out=dict(new_process_public_core_read=True,activity_count=len(activity),activity_heads=activity,work_statuses=[x['status'] for x in s['works']],conversations=s['conversations'],record_kinds=[x['kind'] for x in s['heads']])
(R/'g14-fresh-read.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out))
