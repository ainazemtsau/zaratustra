# G14 — frozen fourth substantive trace, f80180a

**PASS, limited single trace. Source READY is not yet declared.** Required final native gate and separate source/candidate reconciliation remain. Owner has not accepted D or Work.

Independent request/rubric were chosen only after final source/build freeze and own byte/runtime checks. Root executed the unchanged script once through ordinary approval under the concrete owner-selected calls-only contract. Actual client exits: init0, request0, correction0, reopen0. Previous3/3 failed substantive series and earlier technical/account/system/reboot evidence remain unchanged; this is a separately admitted fourth, not a relabeled old outcome. No fifth or preflight repeat occurred.

Human reading, not a semantic validator: first response supplies a usable40-minute character-writing meeting for6teens, two concrete exercises, facilitator lines and take-away. Correction supplies25minutes/eightadults/no facilitator with ready cards and correct total timing. New client supplies25minutes/sixadults/threepairs with an in-exercise quiet variant, no added time/stage or return to the old format. One Activity keeps six revisions with actual updated constraints/results; full useful texts are Activity-scoped results. Six completed Work/Attempt/actions/results, messages3/cursor3, acceptance0.

Non-blocking clarity observations are retained rather than hidden: correction card1label3–11 while timetable explicitly continues the same exercise11–14; final subject JSON has one extra value nesting, with actual current content still present/readable. Free subject bodies have no mandated field schema. These notes do not claim perfect presentation or sustained reliability.

All7actual request bodies use JSON-object mode and omit max_output_tokens. Calls-only profile is exact across six pins; no guaranteed token/money ceiling is inferred from localSDK sizing4096. Work roots8/children6, reserve2perAttempt,4reservedperchain; physical counts2/2/3, eachAttempt≤2 andtotal7≤24.

The seventh request is fully accounted: native zara_change intent_json={} received ordinary.changes validation refusal before reserve/effect; normal function_call_output feedback then produced the final response inside the same Attempt. Coretool_calls0 is expected. There was no accepted tool effect, unknown send, provider retry or hidden new G14. Model owns the final new response; host did not repair old bytes.

Usage includes all seven provider responses and all seven SDKassistant message_end events, including the toolUse response:52896input+5701output=58597tokens; reasoning514 is within output. SDKestimate0.0081401 is not an actual bill/quota debit, which is unknown. Counting only six Core terminals would incorrectly omit the first toolUse response; it is included here.

Exact visible texts, native/provider bodies, original raw input, Core export, usage and tool events are retained. No credential-file contents are copied. Inventory is written last and checkpoint stays immutable. Full native final evidence will be reported separately; no partial gate is called PASS.
