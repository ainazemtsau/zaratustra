import os,sys,json,time,subprocess,tempfile,pathlib
R=pathlib.Path(__file__).parent
S=R/'source'
O=R/'own-affected';O.mkdir(exist_ok=False)
tmp=pathlib.Path(tempfile.mkdtemp(prefix='zaratustra-final-profile-review-'))
env=os.environ.copy()
for k in ['ZARATUSTRA_SQLITE_DLL','PYTHONPATH','PYTEST_ADDOPTS','ZARA_RESTART_EVIDENCE','ZARA_RESTART_NEGATIVES']:env.pop(k,None)
env['PYTHONPATH']=os.pathsep.join(str(S/p) for p in ['packages/core/src','packages/app/src','src'])
env['TEMP']=env['TMP']=str(tmp)
env['PYTEST_ADDOPTS']='--basetemp='+(tmp/'tests').as_posix()
env['ZARA_RESTART_NEGATIVES']=str(O/'negatives')
cmd=[sys.executable,'-m','pytest','tests/restart/test_native_resource_profile.py','tests/restart/test_sleep_profile.py','tests/restart/test_conversation.py','tests/restart/test_delivery_controls.py','-q','-k','native_resource or api_key or sleep_profile or native_pi_oauth_launcher_controlled or native_auth_errors or D-native']
(O/'invocation.json').write_text(json.dumps({'source':'f80180a950ce7a3e21d30c86e610ae4a935320e3','command':cmd,'cwd':str(S),'temp':str(tmp),'scope':'own affected focused actual native SDK/local fictional profile checks; not full native/scoped gate','no_live':True},indent=2))
start=time.time()
with (O/'stdout.bin').open('xb') as out,(O/'stderr.bin').open('xb') as err:p=subprocess.run(cmd,cwd=S,env=env,stdout=out,stderr=err)
(O/'exit.json').write_text(json.dumps({'returncode':p.returncode,'seconds':time.time()-start},indent=2))
print(p.returncode)
