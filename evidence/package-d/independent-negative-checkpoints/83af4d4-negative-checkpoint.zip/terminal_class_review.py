"""Offline classes only. Never alters or retries the real G14 instance."""
import base64,json,pathlib,tempfile
from zaratustra_core import Core,CoreError
from zaratustra_app import Coordinator
R=pathlib.Path(__file__).parent
B=pathlib.Path(tempfile.mkdtemp(prefix='zaratustra-terminal-classes-'))
actual=(R/'g14-installed/correction-retained-terminal.bin').read_bytes()
valid={'state':'completed','text':'Mechanical fixture response','outputs':[{'id':'activity','revision':1}]}
def envelope(text,stop='stop'):
    return json.dumps({'type':'message_end','message':{'role':'assistant','content':[{'type':'text','text':text}],'stopReason':stop}}).encode()
cases=[('valid',envelope(json.dumps(valid)),None,4),('actual-extra-brace',actual,'retained_outcome_format',4),('empty-text',envelope(''),'retained_outcome_format',4),('markdown-fence',envelope('```json\n'+json.dumps(valid)+'\n```'),'retained_outcome_format',4),('array-json',envelope('[]'),'ordinary.outcome_shape',4),('missing-state',envelope('{"text":"fixture"}'),'ordinary.outcome_shape',4),('missing-activity-output',envelope('{"state":"completed","text":"fixture"}'),'ordinary.activity_output',4),('cutoff-json',envelope('{"state":"completed","text":"unfinished','length'),'retained_outcome_format',4),('known-format-no-budget',actual,'retained_outcome_format',2),('unknown-transport',None,'retained_claim',4)]
report=[]
for name,raw,field,limit in cases:
    core,t=Core.initialize(B/name);c=core.connect(t);co=Coordinator(c)
    c.call('apply_changes',{'changes':[{'id':'conversation-execution-method','kind':'method','key':'fixture','body':'Mechanical fixture only'},{'id':'profile','kind':'profile','key':'fixture','body':{'resource_unit':'calls'}},{'id':'activity','kind':'activity','key':'fixture','body':'Fictional'}]},'fixture',expected_heads={'conversation-execution-method':0,'profile':0,'activity':0})
    c.call('ingest_message',{'conversation':'c','event_id':'e','raw_base64':base64.b64encode(b'Fictional pending input').decode()},'input')
    co.open_work({'id':'w','conversation':'c','goal':'Check technical terminal class','method_ref':{'id':'conversation-execution-method','revision':1},'inputs':[{'id':'activity','revision':1}],'call_limit':limit,'continuation_policy':'durable'},scope='activity')
    co.prepare('w','a',{'id':'profile','revision':1})
    class Held:
        resource_upper=2
        def run(self,context,action):
            if raw is None:raise RuntimeError('Fictional transport lost; no terminal')
            return raw
    try:co.dispatch('a',1,Held())
    except RuntimeError:assert raw is None
    errors=[];results=[]
    for _ in range(2):
        try:results.append(co.recover('a',pi=True,ordinary=True))
        except CoreError as e:errors.append(e.as_dict());assert e.field==field,(name,e)
    s=co.snapshot()
    assert len(s['actions'])==1 and s['works'][0]['reserved']==2
    assert len(s['results'])==(1 if field is None else 0)
    assert s['conversations'][0]['cursor']==(1 if field is None else 0)
    if raw is not None:
        held=json.loads(s['observations'][0]['body']);assert base64.b64decode(held['raw_base64'])==raw
    row={'class':name,'errors':errors,'result_replays_equal':len(results)==2 and results[0]==results[1],'actions':1,'reserved':2,'cursor':s['conversations'][0]['cursor'],'known_terminal':raw is not None,'model_calls':0,'subject_head':next(h['revision'] for h in s['heads'] if h['id']=='activity')}
    if name in {'actual-extra-brace','known-format-no-budget','unknown-transport'}:
        # Probe an existing public admission primitive only; no new send follows.
        work=s['works'][0]
        try:
            c.call('control_work',{'work_id':'w','revision':work['revision'],'action':'refresh'},'offline-primitive-check')
        except CoreError as e:
            row['refresh_admission_error']=e.as_dict()
            assert (e.code,e.field)==(('resource_exhausted','calls') if limit==2 else ('outcome_unknown','refresh.claim'))
        else:
            assert name=='actual-extra-brace'
            fresh=co.snapshot();assert fresh['works'][0]['reserved']==2 and fresh['works'][0]['generation']==2 and len(fresh['actions'])==1
            assert fresh['observations']==s['observations']
            row['existing_refresh_primitive']='admits known terminal within remaining budget, preserves reserve and exact original observation; no prepare or send performed'
    report.append(row)
result={'source':'83af4d4a529ca73d06d566db62a3586f2a432af9','fixture':str(B),'cases':report,'real_G14_unchanged':True,'real_provider_requests':0,'original_G14_not_retried':True,'scope':'Current refusal/replay/resource behavior only. No claimed successful repair or new product implementation.'}
(R/'terminal-class-review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'classes':len(report),'all_pass':True,'real_provider_requests':0}))
