import json,pathlib,tempfile
from zaratustra_core import Core,CoreError
R=pathlib.Path(__file__).parent
B=pathlib.Path(tempfile.mkdtemp(prefix='zaratustra-resource-contract-'))
core,t=Core.initialize(B/'fixture');c=core.connect(t)
contract=c.call('describe_contract',{},'describe')
assert contract['resource_units']==['calls']
c.call('apply_changes',{'changes':[{'id':'m','kind':'method','key':'fixture','body':'Fictional contract check'}]},'fixture',expected_heads={'m':0})
base={'conversation':'c','goal':'Fictional resource admission','method_ref':{'id':'m','revision':1},'inputs':[],'call_limit':4,'continuation_policy':'durable'}
results=[]
for field,value in [('token_limit',4096),('money_limit','1.00')]:
    try:c.call('open_work',base|{'id':field,field:value},'open:'+field)
    except CoreError as e:
        assert (e.code,e.field)==('unsupported_capability','resource_unit')
        results.append({'limit':field,'error':e.as_dict()})
    else:raise AssertionError('Unsupported resource admitted')
assert not c.call('read_snapshot',{},'after')['works']
c.call('open_work',base|{'id':'calls-only'},'open:calls')
s=c.call('read_snapshot',{},'last');assert len(s['works'])==1 and s['works'][0]['reserved']==0
out={'installed_source':'83af4d4a529ca73d06d566db62a3586f2a432af9','public_describe_contract':contract,'unsupported_limit_admission':results,'calls_only_work_admitted':True,'no_effects_from_refusals':True,'external_or_model_calls':0,'fixture':str(B)}
(R/'resource-contract-probe.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({'resource_units':contract['resource_units'],'token_money_refused':True,'calls_only_admitted':True,'model_calls':0}))
