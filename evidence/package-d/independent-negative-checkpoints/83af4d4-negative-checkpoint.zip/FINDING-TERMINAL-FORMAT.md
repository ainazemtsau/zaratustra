# F-D-08 — known malformed terminal blocks the ordinary correction

**NOT_READY / G14 FAIL**, source `83af4d4a529ca73d06d566db62a3586f2a432af9`. Third and last agreed substantive trial; no further live inference.

The first visible lesson is useful and mathematically correct:1+3=4 refutes the both-even conclusion, same parity is a true replacement, and the analogous even-product exercise has a valid counterexample and solution. One real Activity retains the agreement and lesson in revisions1/2.

On correction, routing selects the same Activity and opens a scoped child. The fourth physical response is a completed native assistant message (`stopReason=stop`, raw stop `completed`), with851 output tokens against maximum4096. Its visible terminal has2189 characters, SHA256 `6e3680bb69f936f0fc6c8dc286ea588c1970d79116be07bad83a6e28723686bf`. JSON parsing stops at offset2067: an extra closing brace precedes `expected_heads`. There is no observed truncation, unknown send, account failure or repeated goal273/240 failure.

`Pi.decode` parses free terminal text as JSON. `Coordinator.recover` reports `invalid_request/retained_outcome_format`; the corrected CLI returns structured JSON stderr and exit1 without traceback or retry. C7 retains exact bytes; C8 is not admitted. Retained mathematical text is sound (2×3 counterexample for6, true distributed2/3 factor condition, analogous2×5 example for10), but it was not delivered to the user or committed. It is not counted as a successful correction. No brace was removed, answer rewritten or rubric changed. Reopen was not run.

Retained final state: Activity head2, four Work, three results, two human messages, cursor1; latest scoped Work running, its action terminal, proposed Activity revision3 absent. Correction input stays pending; acceptance0. Exact script/rubric, native/provider bodies and exported state are under `g14-installed`; human assessment and usage are in `G14-ASSESSMENT.json`.

The boundary correctly fails closed, but the ordinary usefulness gate fails. Current `zara_change` has a structured outer tool argument containing an opaque `intent_json` string; final responses remain free text. A repeated JSON instruction alone does not establish reliable structured terminal admission.

Own offline installed-build `terminal_class_review.py` passed10 classes: valid replay, exact malformed terminal, empty/fenced/list/missing-state JSON, missing Activity output, cutoff-shaped invalid JSON, no-budget malformed terminal and unknown transport. Failure cases preserve observation/pending cursor without another action. Existing C9 refresh admits a known terminal with remaining budget, refuses unknown transport/exhaustion, and preserves reserve. This is an admission-primitive probe, not a repair implementation or another real G14 attempt.

Four sends completed, one per Attempt. Usage19,935 input +1,855 output =21,790 tokens;306 reasoning tokens are included in output. SDK estimate0.002921 is not actual billing/quota debit, which is unknown. Root8/child6 chains reserved4 each; physical resource remained, but the independent substantive-trial allowance is exhausted3/3. Current NOT_READY is not a request for more tokens or another lucky retry. See `NEXT-MECHANISM-PROPOSAL.md`.

This file is restored after reboot. Its pre-reboot combined write/fresh-reader operation did not execute because approval review failed HTTP403. No fresh83af public-reader claim is made; the original script's retained Core export is the state evidence. See `REBOOT-RECOVERY.json`.
