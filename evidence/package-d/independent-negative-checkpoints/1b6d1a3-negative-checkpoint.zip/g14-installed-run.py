"""Root may execute this unchanged with normal approval and direct owner grant.
All G14 messages/rubric belong to independent reviewer; no output validator.
Runs only the actual installed entrypoint. No product imports or successful stub.
"""
import pathlib,subprocess,os,sys,json,tempfile,hashlib,sqlite3,time
R=pathlib.Path(__file__).parent
ENTRY=pathlib.Path('C:/Users/Anton/AppData/Local/Temp/zaratustra-independent-d-ch5ibt4p/runtime/env/Scripts/zaratustra-next.exe')
PIN='1b6d1a3946348a18d90cbb1a4e8d36208e242285'
RUBRIC_HASH='7bc557be9e82307285106d856b18e39d5f2860f567f0a045f0aae43666d47d27'
rubric_raw=(R/'g14-rubric.json').read_bytes()
assert hashlib.sha256(rubric_raw).hexdigest()==RUBRIC_HASH
rubric=json.loads(rubric_raw)
preflight=json.loads((R.parent/'account-preflight.stdout.json').read_bytes())
assert preflight['account_specific_inference'] and preflight['model']=='gpt-6-luna' and preflight['sends']<=2
proof=R/'g14-installed';proof.mkdir(exist_ok=False)
base=pathlib.Path(tempfile.mkdtemp(prefix='zaratustra-g14-independent-',dir='C:/Users/Anton/AppData/Local/Temp'))
root=base/'data';home=base/'home';home.mkdir()
profile=base/'profile.json'
profile.write_text(json.dumps(dict(pi_cli='C:/Users/Anton/AppData/Roaming/npm/node_modules/@earendil-works/pi-coding-agent/dist/bundle/cli.js',endpoint='https://api.openai.com/v1',model='gpt-6-luna',auth_mode='pi-chatgpt',auth_path='C:/Users/Anton/.pi/agent/auth.json',max_tokens=4096,context_window=128000,timeout=180)),encoding='utf-8')
env={k:v for k,v in os.environ.items() if k.upper() in {'PATH','PATHEXT','SYSTEMROOT','WINDIR','COMSPEC','TEMP','TMP'}}
env.update(HOME=str(home),USERPROFILE=str(home),APPDATA=str(home/'AppData'),LOCALAPPDATA=str(home/'LocalAppData'),PYTHONUTF8='1')
manifest=dict(source_commit=PIN,entry=str(ENTRY),base=str(base),data_root=str(root),rubric_sha256=RUBRIC_HASH,transport='Main-chat leader executes unchanged independent reviewer script with normal approval and direct owner grant; reviewer evaluates raw outputs.',calls=[])
def save(): (proof/'execution.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
def run(label,args,input=None):
 cmd=[str(ENTRY),'--data-root',str(root),*args]
 (proof/(label+'.input.bin')).write_bytes(input or b'')
 start=time.time();out=b'';err=b'';code=None
 try:
  p=subprocess.run(cmd,input=input,cwd=base,env=env,capture_output=True,timeout=215)
  out,err,code=p.stdout,p.stderr,p.returncode
 except subprocess.TimeoutExpired as e:
  out,err=e.stdout or b'',e.stderr or b'';code='timeout'
 finally:
  (proof/(label+'.stdout.bin')).write_bytes(out);(proof/(label+'.stderr.bin')).write_bytes(err)
  manifest['calls'].append(dict(label=label,command=cmd,returncode=code,seconds=time.time()-start));save()
 if code!=0:raise RuntimeError('Entry failure; stop without blind model retry: '+label)
 return out
try:
 run('init',['init'])
 # First real interactive session: request, correction, /exit. No JSON required from user.
 first='\n'.join([rubric['request'],rubric['correction'],'/exit','']).encode('utf-8')
 run('request-and-correction',['chat','--profile-file',str(profile),'--call-limit','8'],first)
 # A new physical client and fresh Pi session; all authoritative context must come from Core.
 reopened=(rubric['reopen_request']+'\n/exit\n').encode('utf-8')
 run('reopen',['chat','--profile-file',str(profile),'--call-limit','8'],reopened)
 manifest['mechanical_processes_completed']=True
finally:
 # Preserve exact native input/output/provider bodies; no credential-file contents are copied.
 if (root/'pi').exists():
  for p in (root/'pi').rglob('*'):
   if p.is_file() and (p.suffix in {'.bin','.jsonl'} or p.name.endswith('.redaction.json')):
    target=proof/'native'/p.relative_to(root/'pi');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
 if (root/'core.sqlite3').exists():
  with sqlite3.connect('file:'+str(root/'core.sqlite3').replace('\\','/')+'?mode=ro',uri=True) as db:
   db.row_factory=sqlite3.Row
   state={table:[dict(x) for x in db.execute('SELECT * FROM '+table)] for table in ['works','attempts','actions','results','observations','messages','heads','records','acceptance','intents','conversations']}
  (proof/'retained-state.json').write_text(json.dumps(state,indent=2,ensure_ascii=False),encoding='utf-8')
  manifest['physical_provider_requests']=len(list((proof/'native').rglob('*-request.bin')))
 save()
print(json.dumps({'proof':str(proof),'calls':manifest['calls'],'evaluation':'independent human rubric review required'},ensure_ascii=False))
