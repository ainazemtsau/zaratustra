import pathlib,tempfile,json,sqlite3
from zaratustra_core import Core,CoreError
from zaratustra_app import Coordinator
R=pathlib.Path(__file__).parent
B=pathlib.Path(tempfile.mkdtemp(prefix='zaratustra-independent-c7-',dir='C:/Users/Anton/AppData/Local/Temp'))
report=[]
def state(core):
 with sqlite3.connect(core.path) as db:
  names=[r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
  return {x:db.execute('SELECT * FROM '+x).fetchall() for x in names}
try:
 for kind in ['terminal','progress','unknown','reconcile']:
  core,t=Core.initialize(B/kind);c=core.connect(t)
  c.call('apply_changes',{'changes':[dict(id='m',kind='method',key='m',body='generic'),dict(id='p',kind='profile',key='p',body={})]},'setup',expected_heads={'m':0,'p':0})
  host=core.connect(core.grant(t,'host',['read','claim_dispatch','observe_attempt'],origin='host'))
  for w in ['own','other']:
   c.call('open_work',dict(id=w,conversation=w,goal='fictional C7',method_ref={'id':'m','revision':1},inputs=[],call_limit=4,continuation_policy='durable'),'open-'+w)
   Coordinator(c).prepare(w,w+'-attempt',{'id':'p','revision':1})
   host.call('claim_dispatch',dict(attempt_id=w+'-attempt',generation=1),'claim-'+w,action_id=w+'-action')
  payload=dict(attempt_id='own-attempt',event_id='bad',kind=kind,evidence=dict(action_id='other-action',state='running',receiver_ref='opaque receiver ref without local target'))
  if kind=='terminal':payload['raw_base64']='e30='
  before=state(core);error=None
  try:host.call('observe_attempt',payload,'wrong-action')
  except CoreError as e:error=e.as_dict()
  assert error and error['code']==('denied' if kind=='reconcile' else 'invalid_request') and state(core)==before
  report.append(dict(kind=kind,case='foreign existing action identity refused atomically',error=error,pass_=True))
  payload['evidence']['action_id']='own-action';payload['event_id']='good'
  observed=host.call('observe_attempt',payload,'own-action')
  assert observed.get('verified',False)==(kind=='reconcile') and observed['evidence']['receiver_ref']==payload['evidence']['receiver_ref']
  report.append(dict(kind=kind,case='own action + opaque receiver allowed; verification origin kept',pass_=True))
finally:(R/'c7-identity-checks.json').write_text(json.dumps(dict(base=str(B),checks=report),indent=2),encoding='utf-8')
print(json.dumps(dict(cases=len(report),all_pass=True)))
