import hashlib,json,zipfile,tarfile,pathlib,subprocess,sys,tomllib
R=pathlib.Path(__file__).parent
W=R.parents[2]
E=W/'evidence/package-d/final-1b6d1a3'
S=R/'source'
def h(b): return hashlib.sha256(b).hexdigest()
def write(n,o): (R/n).write_text(json.dumps(o,indent=2),encoding='utf-8')
report={'checks':[]}
def ck(name,ok,**kw):
 report['checks'].append(dict(name=name,pass_=bool(ok),**kw))
 assert ok,(name,kw)
pins={'source-1b6d1a3.zip':'0321aa6b1fa5e5af75f39e88bb2aa6375469ada079a3233fd706181357c4df38','zaratustra-next-d-1b6d1a3-windows-x64.zip':'c16e1925762c0228e0bec04403cdc2da088181d29b62ddd4262421b2cb1c8bef','install-1b6d1a3/manifest.json':'f2185dc9970e2e1ea99fc92b8f5f7bebf9d95c0ceddadc906c532c2d5d1f3c99','SOURCE-MANIFEST.json':'2255c1119cf244af6ec22a08d9015677d6b6f58ce327f39e8388b9589d4ce28e'}
try:
 for p,v in pins.items(): ck('pin:'+p,h((E/p).read_bytes())==v,sha256=h((E/p).read_bytes()))
 manifest=json.loads((E/'SOURCE-MANIFEST.json').read_bytes())
 with zipfile.ZipFile(E/'source-1b6d1a3.zip') as z:
  for f in manifest['files']:
   raw=(S/f['path']).read_bytes()
   ck('source:'+f['path'],len(raw)==f['bytes'] and h(raw)==f['sha256'] and z.read(f['path'])==raw)
 build=E/'install-1b6d1a3/physical-builds'
 installed=pathlib.Path('C:/Users/Anton/AppData/Local/Temp/zaratustra-d-1b6d1a3-hqfgwtbu/runtime/env/Lib/site-packages')
 installed_owner=pathlib.Path('C:/Users/Anton/AppData/Local/Temp/zaratustra-d-owner-1b6d1a3-tb49hv6l/runtime/env/Lib/site-packages')
 prod=[]
 for pkg,mod,dist in [('core','zaratustra_core','zaratustra_core'),('app','zaratustra_app','zaratustra_next')]:
  with zipfile.ZipFile(build/(dist+'-0.1.0-py3-none-any.whl')) as z,tarfile.open(build/(dist+'-0.1.0.tar.gz')) as t:
   for p in (S/'packages'/pkg/'src'/mod).rglob('*'):
    if p.suffix not in {'.py','.ts','.mjs'}: continue
    rel=p.relative_to(S/'packages'/pkg/'src').as_posix()
    raw=p.read_bytes()
    ck('distribution:'+rel,z.read(rel)==raw and t.extractfile(dist+'-0.1.0/src/'+rel).read()==raw and (installed/rel).read_bytes()==raw and (installed_owner/rel).read_bytes()==raw,sha256=h(raw),bytes=len(raw))
    prod.append(rel)
 lock=(S/'uv.lock').read_text(encoding='utf-8')
 for wh in (E/'owner-bundle/wheels').glob('*.whl'):
  if wh.name.startswith(('zaratustra_core','zaratustra_next')): continue
  ck('dependency-lock:'+wh.name,h(wh.read_bytes()) in lock,sha256=h(wh.read_bytes()))
  with zipfile.ZipFile(wh) as z:
   for name in z.namelist():
    if name.endswith('/') or '.dist-info/' in name: continue
    ck('installed-dependency:'+name,(installed_owner/name).read_bytes()==z.read(name))
 report.update(production_files=len(prod),source_files=len(manifest['files']),archive_note='Own git archive zip container differs from author custom zip; all 400 scope file contents compared exactly, no LF normalization.')
finally: write('byte-verification.json',report)
print(json.dumps({'checks':len(report['checks']),'production_files':len(prod),'all_pass':all(c['pass_'] for c in report['checks'])}))
