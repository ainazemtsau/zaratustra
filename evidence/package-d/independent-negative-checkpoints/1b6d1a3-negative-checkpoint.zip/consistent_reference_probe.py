"""Internal receipt consistency is not a substitute for actual reference closure.
Run only using the selected corrected installed Python -I.
"""
import pathlib,json,tempfile,sqlite3,hashlib,shutil
from zaratustra_core import Core,CoreError
R=pathlib.Path(__file__).parent
BASELINE=R.parent/'f072-negative-checkpoint/reference-corruption-evidence/baseline'
B=pathlib.Path(tempfile.mkdtemp(prefix='zaratustra-consistent-corruption-',dir='C:/Users/Anton/AppData/Local/Temp'))
OUT=R/'consistent-reference-evidence';OUT.mkdir(exist_ok=True)
REPORT=[]
try:
 Core.restore_quarantined(BASELINE,B/'valid-baseline')
 for mode in ['profile-ref','method-bytes','manifest-hash']:
  bad=B/mode;shutil.copytree(BASELINE,bad)
  with sqlite3.connect(bad/'core.sqlite3') as db:
   before=json.loads(db.execute('SELECT body FROM attempts').fetchone()[0]);changed=json.loads(json.dumps(before))
   if mode=='profile-ref':changed['profile_ref']={'id':'missing','revision':999}
   elif mode=='method-bytes':changed['method']['body']['value']='tampered exact Method bytes'
   else:changed['manifest'][0]['sha256']='0'*64
   db.execute('UPDATE attempts SET body=?',(json.dumps(changed),))
   # Deliberately keep all redundant prepare/claim pinned copies and receipt/event
   # results mutually equal, preserving any claim's separate resource_state.
   updated=[]
   for seq,subject,raw in db.execute("SELECT seq,subject,body FROM events WHERE kind IN ('prepare_attempt','claim_dispatch')").fetchall():
    value=json.loads(raw);oldpin=value['pinned'];value['pinned']=json.loads(json.dumps(changed))
    if 'resource_state' in oldpin:value['pinned']['resource_state']=oldpin['resource_state']
    db.execute('UPDATE events SET body=? WHERE seq=?',(json.dumps(value),seq))
    receipt=json.loads(db.execute('SELECT response FROM receipts WHERE command=?',(subject,)).fetchone()[0]);receipt['result']=value
    db.execute('UPDATE receipts SET response=? WHERE command=?',(json.dumps(receipt),subject));updated.append(subject)
   assert updated
   assert db.execute('PRAGMA integrity_check').fetchall()==[('ok',)] and not db.execute('PRAGMA foreign_key_check').fetchall()
  m=json.loads((bad/'manifest.json').read_bytes());raw=(bad/'core.sqlite3').read_bytes();m.update(database_sha256=hashlib.sha256(raw).hexdigest(),database_size=len(raw));(bad/'manifest.json').write_text(json.dumps(m),encoding='utf-8')
  dest=OUT/mode;shutil.copytree(bad,dest)
  (dest/'mutant-diff.json').write_text(json.dumps(dict(before=before,after=changed,also_synchronized_event_receipts=updated),indent=2),encoding='utf-8')
  result=dict(case=mode,injection_reached=before!=changed,outer_hash_valid=True,internal_pinned_copies_synchronized=True)
  try:Core.restore_quarantined(bad,B/('restore-'+mode))
  except CoreError as e:result.update(rejected=True,error=e.as_dict())
  else:result.update(rejected=False)
  REPORT.append(result)
 assert all(x['rejected'] for x in REPORT),REPORT
finally:(R/'consistent-reference-checks.json').write_text(json.dumps(dict(base=str(B),checks=REPORT),indent=2),encoding='utf-8')
print(json.dumps(dict(cases=len(REPORT),all_rejected=True)))
