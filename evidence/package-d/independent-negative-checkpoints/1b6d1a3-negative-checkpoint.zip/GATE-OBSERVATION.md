# Corrected-source gate observation

Pinned source `1b6d1a3946348a18d90cbb1a4e8d36208e242285`.

Independent scoped gate currently records a failure in `D-database-hash-ignored` (raw report under `scoped/scoped-negatives/D-database-hash-ignored.json`). Mutated restore hash guard returns an underlying successful test run (`returncode:0`, `1 passed`), so the mutation is not killed. The original corruption fixture changes `events.body`; the new reference-closure verifier also rejects that corruption, even with database checksum verification removed. Therefore this control no longer distinguishes the promised checksum guard. This is a gate/control regression, not evidence that corrected product accepts the broken reference graph.

The behavioral control needs a valid, internally coherent SQLite byte change that the checksum guard alone rejects, with unchanged source/build baseline and reached mutation evidence. Reviewer does not modify product/tests. Final native/scoped outcomes are still pending, and no complete PASS is claimed.

The independent G15 fixture rerun, consistent-corruption checks, declared-ref C3/C8 rollback and historical/Sleep positives already pass. One C7 probe harness initially used a different observer principal from the claimant and was denied by the pre-existing executor guard; preserved separately and corrected by claiming with the same host principal.
