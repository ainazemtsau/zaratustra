"""Run with corrected installed Python -I after new source/build pins.
Uses exact frozen negative fixtures; never rewrites the original checkpoint.
"""
import pathlib,json,tempfile,sys
from zaratustra_core import Core,CoreError
R=pathlib.Path(__file__).parent
out=R/(sys.argv[1] if len(sys.argv)>1 else 'corrected-fixture-recheck')
out.mkdir(exist_ok=False)
fixture=R/'f072-negative-checkpoint'
base=pathlib.Path(tempfile.mkdtemp(prefix='zaratustra-corrected-recheck-',dir='C:/Users/Anton/AppData/Local/Temp'))
checks=[]
sources=[('baseline',fixture/'reference-corruption-evidence/baseline',True)]
sources.extend((p.name,p,False) for p in sorted((fixture/'reference-corruption-evidence').glob('bad-*')) if p.is_dir())
sources.extend((p.name,p,False) for p in sorted((fixture/'closure-sweep-evidence').iterdir()) if p.is_dir())
try:
 for name,source,should_restore in sources:
  item=dict(case=name,fixture=str(source),expected_restore=should_restore)
  try:core,token=Core.restore_quarantined(source,base/name)
  except CoreError as e:item.update(restored=False,error=e.as_dict())
  else:item.update(restored=True,mode=core.connect(token).call('export_diagnostics',{},'diagnostics')['mode'])
  item['pass_']=item['restored']==should_restore;checks.append(item)
 # Continue through all cases, then issue the concrete aggregate assertion.
 assert all(c['pass_'] for c in checks),[c for c in checks if not c['pass_']]
finally:(out/'checks.json').write_text(json.dumps(dict(base=str(base),checks=checks),indent=2),encoding='utf-8')
print(json.dumps(dict(cases=len(checks),all_pass=True)))
