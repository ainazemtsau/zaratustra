import pathlib,subprocess,json,tempfile,os
R=pathlib.Path(__file__).parent
B=pathlib.Path('C:/Users/Anton/AppData/Local/Temp/zaratustra-independent-d-j7s92asp')
entry=B/'runtime/env/Scripts/zaratustra-next.exe';python=B/'runtime/env/Scripts/python.exe'
temp=pathlib.Path(tempfile.mkdtemp(prefix='zaratustra-review-diagnostic-',dir='C:/Users/Anton/AppData/Local/Temp'))
guard=temp/'guard';guard.mkdir()
(guard/'sitecustomize.py').write_text("import sys,os,pathlib,json\nlog=pathlib.Path(os.environ['REVIEW_NETWORK_LOG'])\nwith log.open('a',encoding='utf-8') as f:f.write('audit-hook-loaded\\n')\ndef audit(event,args):\n if event.startswith('socket.') or event in {'subprocess.Popen','os.system','os.exec','os.posix_spawn'}:\n  with log.open('a',encoding='utf-8') as f:f.write(event+'\\n')\n  raise RuntimeError('review network/process denial')\nsys.addaudithook(audit)\n",encoding='utf-8')
env=os.environ.copy()
for key in ['PYTHONPATH','ZARATUSTRA_SQLITE_DLL','OPENAI_API_KEY','PI_CODING_AGENT_DIR']:env.pop(key,None)
env['PYTHONPATH']=str(guard);env['REVIEW_NETWORK_LOG']=str(temp/'injection.log')
# Reached behavioral control: genuine socket construction must be stopped by the guard.
p=subprocess.run([str(python),'-c','import socket;socket.socket()'],env=env,capture_output=True,timeout=10)
assert p.returncode!=0 and 'socket.__new__' in (temp/'injection.log').read_text()
checks=[dict(case='guard positive control',reached=True,returncode=p.returncode)]
for label,more in [('preview',[]),('explicit-export',['--destination',str(temp/'export.json')])]:
 log=temp/(label+'.network.log');env['REVIEW_NETWORK_LOG']=str(log)
 p=subprocess.run([str(entry),'--data-root',str(B/'data'),'diagnostics',*more],env=env,cwd=temp,capture_output=True,timeout=15)
 (R/('diagnostic-'+label+'.stdout.bin')).write_bytes(p.stdout);(R/('diagnostic-'+label+'.stderr.bin')).write_bytes(p.stderr)
 assert p.returncode==0,(p.stdout,p.stderr)
 assert log.read_text()=='audit-hook-loaded\n',log.read_text()
 assert b'PRIVATE_SENTINEL' not in p.stdout and b'PRIVATE_RAW_SENTINEL' not in p.stdout
 checks.append(dict(case=label,returncode=p.returncode,loaded_and_no_network_process_attempts=True,network_log=log.read_text()))
assert json.loads((R/'diagnostic-explicit-export.stdout.bin').read_bytes())==json.loads((temp/'export.json').read_bytes())
(R/'diagnostic-boundary-checks.json').write_text(json.dumps(dict(base=str(temp),checks=checks),indent=2),encoding='utf-8')
print(json.dumps(dict(checks=len(checks),all_pass=True)))
