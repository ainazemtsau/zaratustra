import sys,os,json,pathlib,tempfile,time,subprocess,io,hashlib,base64
from concurrent.futures import ThreadPoolExecutor
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from threading import Thread
from zaratustra_core import Core,CoreError
from zaratustra_app import Conversation,Pi,LiveProfile
from zaratustra_app.adapters.pi import bridge
R=pathlib.Path(__file__).parent
base=pathlib.Path(tempfile.mkdtemp(prefix='zaratustra-independent-native-',dir='C:/Users/Anton/AppData/Local/Temp'))
SDK='C:/Users/Anton/AppData/Roaming/npm/node_modules/@earendil-works/pi-coding-agent/dist/'
CLI=pathlib.Path(SDK+'bundle/cli.js')
REPORT=[]
def save(): (R/'native-auth-checks.json').write_text(json.dumps({'base':str(base),'cases':REPORT},indent=2),encoding='utf-8')
def sse(text):
 m={'id':'m-independent','type':'message','role':'assistant','status':'completed','content':[{'type':'output_text','text':text,'annotations':[]}]}
 response={'id':'r-independent','object':'response','status':'completed','model':'gpt-6-luna','output':[m],'usage':{'input_tokens':1,'output_tokens':1,'total_tokens':2}}
 events=[{'type':'response.created','response':dict(response,output=[],status='in_progress')},{'type':'response.output_item.added','output_index':0,'item':dict(m,content=[],status='in_progress')},{'type':'response.content_part.added','item_id':m['id'],'output_index':0,'content_index':0,'part':{'type':'output_text','text':'','annotations':[]}},{'type':'response.output_text.delta','item_id':m['id'],'output_index':0,'content_index':0,'delta':text},{'type':'response.output_text.done','item_id':m['id'],'output_index':0,'content_index':0,'text':text},{'type':'response.output_item.done','output_index':0,'item':m},{'type':'response.completed','response':response}]
 return ''.join('event: '+e['type']+'\ndata: '+json.dumps(e)+'\n\n' for e in events).encode()
ORIGINAL_POPEN=subprocess.Popen
ORIGINAL_OPENER=bridge.build_opener
try:
 for mode in ['baseline','concurrent-oauth-noop','concurrent-api-key','refresh-error','absent-selected-path','server-error']:
  home=base/mode;home.mkdir();auth=home/'fictional-auth.json';marker=home/'refresh-marker.json'
  credential={'type':'oauth','access':'SYNTHETIC_ACCESS_ONLY','refresh':'SYNTHETIC_REFRESH_ONLY','expires':int(time.time()*1000)+3600000}
  if mode in ['concurrent-oauth-noop','concurrent-api-key','refresh-error']:credential['expires']=0
  if mode!='absent-selected-path':auth.write_text(json.dumps({'openai':credential}),encoding='utf-8')
  preload=home/'controlled.mjs'
  replacement=credential|{'access':'SYNTHETIC_CONCURRENT_ACCESS','expires':int(time.time()*1000)+3600000}
  if mode=='concurrent-api-key':replacement={'type':'api_key','key':'SYNTHETIC_API_KEY_ONLY'}
  preload.write_text("import {writeFileSync} from 'node:fs';\nimport {pathToFileURL} from 'node:url';\n"+
   "const {AuthStorage}=await import(pathToFileURL("+json.dumps(SDK+'core/auth-storage.js')+"));\n"+
   "const original=AuthStorage.prototype.modify;\n"+
   ("AuthStorage.prototype.modify=async function(p,fn,o){writeFileSync("+json.dumps(str(marker))+",'concurrent replacement reached');writeFileSync("+json.dumps(str(auth))+",JSON.stringify({openai:"+json.dumps(replacement)+"}));return original.call(this,p,fn,o);};\n" if mode.startswith('concurrent-') else '')+
   "const nativeFetch=globalThis.fetch;globalThis.fetch=async(url,...args)=>{if(String(url).startsWith('http://127.0.0.1:'))return nativeFetch(url,...args);if(String(url)!=='https://auth.openai.com/api/accounts/oauth/token')throw Error('unexpected_external_network');writeFileSync("+json.dumps(str(marker))+",'refresh reached');return new Response('SYNTHETIC_ACCESS_ONLY SYNTHETIC_REFRESH_ONLY',{status:400});};\n",encoding='utf-8')
  def controlled_popen(command,**kwargs):
   kwargs['env']['OPENAI_API_KEY']='AMBIENT_KEY_MUST_NOT_BE_USED'
   return ORIGINAL_POPEN([command[0],'--import',preload.as_uri(),*command[1:]],**kwargs)
  subprocess.Popen=controlled_popen
  packets=[]
  class Response(io.BytesIO):
   status=200;headers={'Content-Type':'text/event-stream'}
  class Transport:
   def open(self,req,timeout):
    payload=json.loads(req.data)
    assert req.full_url=='https://api.openai.com/v1/responses'
    assert req.get_header('Authorization') in ['Bearer SYNTHETIC_ACCESS_ONLY','Bearer SYNTHETIC_CONCURRENT_ACCESS']
    assert payload['model']=='gpt-6-luna' and payload['max_output_tokens']==64 and payload['stream'] and not payload['store']
    packets.append(payload)
    if mode=='server-error':raise HTTPError(req.full_url,500,'controlled failure',{},io.BytesIO(b'SYNTHETIC_ACCESS_ONLY'))
    return Response(sse(json.dumps({'state':'completed','text':'independent controlled result','changes':[],'expected_heads':{}})))
  bridge.build_opener=lambda *_:Transport()
  core,token=Core.initialize(home/'data');session=Conversation(core,token);session.submit('Fictional mechanical probe; semantic G14 is separate.')
  live=LiveProfile(endpoint='https://api.openai.com/v1',model='gpt-6-luna',auth_mode='pi-chatgpt',auth_path=str(auth),max_tokens=64,context_window=128000,timeout=20)
  pi=Pi(CLI,home/'pi',live.endpoint,live=live)
  failure=None;result=None
  try: result=session.run(pi,{'case':mode},4)
  except CoreError as e:failure=e.as_dict()
  expected_success=mode in ['baseline','concurrent-oauth-noop']
  assert bool(result)==expected_success,(mode,result,failure)
  assert pi.provider_sends==len(packets)<=2
  if expected_success:assert result['text']=='independent controlled result' and len(packets)==1
  if mode in ['refresh-error','concurrent-api-key','absent-selected-path']:assert len(packets)==0
  if mode.startswith('concurrent-') or mode=='refresh-error':assert marker.exists()
  captured=[p.read_bytes() for p in (home/'pi').rglob('*') if p.is_file()]
  secrets=[b'SYNTHETIC_ACCESS_ONLY',b'SYNTHETIC_REFRESH_ONLY',b'SYNTHETIC_CONCURRENT_ACCESS',b'SYNTHETIC_API_KEY_ONLY',b'AMBIENT_KEY_MUST_NOT_BE_USED']
  assert all(s not in b''.join(captured) for s in secrets)
  for p in (home/'pi').rglob('*'):
   if p.is_file() and p.suffix in {'.bin','.jsonl'}:
    dest=R/'native-raw'/mode/p.relative_to(home/'pi');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
  REPORT.append(dict(mode=mode,expected_success=expected_success,result=result,failure=failure,sends=pi.provider_sends,packets=len(packets),injection_reached=marker.exists(),secret_free=True))
  save()
 # Concurrent physical forwarding cap, including unsuccessful requests.
 subprocess.Popen=ORIGINAL_POPEN
 class Rejecting:
  def open(self,req,timeout):raise HTTPError(req.full_url,503,'synthetic',{},io.BytesIO(b'not a secret'))
 bridge.build_opener=lambda *_:Rejecting()
 proxy=bridge.Bridge('https://api.openai.com/v1',None,2,native_auth=True)
 thread=Thread(target=proxy.serve_forever,daemon=True);thread.start()
 def post(i):
  req=Request(f'http://127.0.0.1:{proxy.server_port}/provider/v1/responses',b'{}',{'Authorization':'Bearer FICTIONAL'})
  try:urlopen(req,timeout=5).read();return 200
  except HTTPError as e:return e.code
 with ThreadPoolExecutor(max_workers=8) as pool:statuses=list(pool.map(post,range(8)))
 proxy.shutdown();proxy.server_close();thread.join()
 assert sorted(statuses)==[429]*6+[503]*2 and proxy.sends==2
 REPORT.append(dict(mode='concurrent-physical-cap',statuses=statuses,sends=proxy.sends))
finally:
 subprocess.Popen=ORIGINAL_POPEN;bridge.build_opener=ORIGINAL_OPENER;save()
print(json.dumps({'cases':len(REPORT),'passed':True}))
