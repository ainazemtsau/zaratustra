import pathlib,json,hashlib,shutil,zipfile
R=pathlib.Path(__file__).parent
B=pathlib.Path('C:/Users/Anton/AppData/Local/Temp/zaratustra-independent-d-j7s92asp')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False),encoding='utf-8')
# Complete exact corrupted backup fixtures with all baseline held bytes.
P=R/'reference-corruption-evidence'
for dest in list(P.iterdir()):
 if dest.is_dir() and not (dest/'artifacts').exists():shutil.copytree(B/'backup/artifacts',dest/'artifacts')
dest=P/'baseline';dest.mkdir(exist_ok=True)
for name in ['core.sqlite3','manifest.json']:(dest/name).write_bytes((B/'backup'/name).read_bytes())
if not (dest/'artifacts').exists():shutil.copytree(B/'backup/artifacts',dest/'artifacts')
# Retain both failed native harness attempts before copying successful third output.
for version,home in [('first','zaratustra-independent-native-1bqdu6k0'),('second','zaratustra-independent-native-98pfeny_')]:
 origin=B.parent/home
 if origin.exists():
  for p in origin.rglob('*'):
   if p.is_file() and 'pi' in p.parts and p.suffix in {'.bin','.jsonl'}:
    target=R/('native-failed-'+version)/p.relative_to(origin);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
checkpoint=R/'f072-negative-checkpoint';checkpoint.mkdir(exist_ok=False)
for p in R.iterdir():
 if p.is_file() and p.suffix in {'.py','.mjs','.json','.bin','.md'} and p.name not in {'LOCAL-ONLY-credentials.json'}:
  shutil.copyfile(p,checkpoint/p.name)
for folder in ['scoped-approved','scoped-build-followup','reference-corruption-evidence','closure-sweep-evidence','native-raw','native-failed-first','native-failed-second']:
 if (R/folder).exists():shutil.copytree(R/folder,checkpoint/folder)
source_evidence=R.parent.parent/'evidence/package-d/final-f072509'
for folder in ['scoped-f072509','native-f072509']:
 dest=checkpoint/'studied-author-gates'/folder;dest.mkdir(parents=True)
 for name in ['invocation.json','exit.json','stdout.bin','stderr.bin']:
  if (source_evidence/folder/name).exists():shutil.copyfile(source_evidence/folder/name,dest/name)
write(checkpoint/'EXPORT-EXCLUSIONS.json',{
 'excluded_files':['LOCAL-ONLY-credentials.json','**/LOCAL-ONLY-credentials.json','**/owner.credential','**/auth.json','**/*fictional-auth.json'],
 'forbidden_contents':'No real credential values or real auth-file contents were read, copied, or exported. Disposable generated credential files are not exported either.',
 'not_copied':['source/ (execution snapshot; source artifact referenced below)','source-f072509.zip (unscoped own archive)','source-scoped-f072509.zip (indexed exact source is separately retained)','OS temp runtime/data/credential directories'],
 'source_artifact':{'path':str(source_evidence/'source-f072509.zip'),'sha256':'3f366a11f1360cce9102ace8ef260c23fc52af9bc82efae4e9456267fa0a43cf'},
 'notes':'SQLite fixtures contain only invented subject data and one-way hashes of disposable generated Core credentials; no raw credential files. Native captures contain fictional prompts only.'})
report='''# Независимый отрицательный checkpoint D — f072509

Вердикт: **NOT READY**. Обязательный G15 опровергнут независимым установленным probe; G14 ещё не выполнен. Это сохранённый checkpoint перед исправлением, не прекращение review CALL и не принятие продукта владельцем.

Проверялся source `f07250996d861404728c5892fa1f3b0a6a07bba4` поверх принятого C `7d211480d1dd5067bf52c3a654cc1a713368310d`. Candidate commit пока не объявлен. Все продуктовые проверки выполнялись по архивным либо установленным байтам; рабочий product source не менялся проверяющим. Принятые plan/review hashes совпали буквально. PROBA36, local-only; никаких требований v37/OPORA, публикации или миграции не добавлялось.

**Outcome.** F-D-01: `packages/core/src/zaratustra_core/maintenance.py:24` проверяет лишь часть JSON-связей backup. При исправном baseline и заново верном внешнем SHA256 restore принимает несуществующий profile_ref Attempt, подменённый Method pin, отсутствующую message sequence manifest, а также broken Method/analysis/source refs типизированного Sleep progress. SQLite integrity/FK при этом проходят. Битые outer record refs и Work inputs отказываются. Новый Core client видит broken Attempt pin, exact read отсутствующего материала отказывает. Quarantine продолжает блокировать исполнение; execution escape не заявляется. Нарушена обязательная целостность C12/G15. Полное воспроизведение, exact refs, mutant diffs и родственные случаи — в `FINDINGS-f072509.md` и соответствующих JSON/raw fixture directories.

**Evidence.** Независимая сверка: 397 source files, 18 production Python/TS/MJS source↔wheel↔sdist↔две установки; dependency wheel hashes в uv.lock и фактические installed bytes; 545 успешных проверок. Исходные CRLF/LF не нормализовались. Точный owner archive отдельно установлен offline в настоящем OS temp вне всех Git checkout, в чистом вымышленном профиле. Настоящий installed .exe прошёл diagnostics/artifact/backup/restore; физическое прерывание и новый процесс проверили durable artifact bytes. Раздельно проверены old token, old epoch/new token и fully-new valid quarantine envelope; unknown actions/observations, reservations и fences сохранены. Diagnostics actual preview/export bytes не содержат private/secret sentinels; достигнутый audit hook запретил socket/process, оба запуска настоящего .exe прошли без попыток передачи.

Свой scoped запуск: 279 PASS и 1 harness failure (не был создан log directory); ровно упавшая unchanged wheel-проверка затем дала 1 PASS. Это составной результат, не один зелёный scoped gate. Его 59 mutation controls достигли injections и поведенческих отказов. Первоначальный sandbox-denied pytest setup сохранён отдельно. Авторский текущий scoped изучен по raw evidence: 280 PASS / 59 reached controls; это исполнение автора. Авторский full native остановлен INCOMPLETE после воспроизведения G15; его exit1 и pytest exit4294967295 не являются full-gate PASS. Повторного full native проверяющий не запускал.

Семь независимых native SDK сценариев на fictional credentials/control responses прошли, включая concurrent OAuth no-op refresh, concurrent API-key refusal, refresh-error sanitation, выбранный отсутствующий auth path при ambient key, upstream failure и физический cap2 при восьми конкурирующих запросах. Две ошибки собственного harness сохранены; только третий исправленный запуск засчитан. Девять физических Windows sharing/fence checks прошли: transient release, permanent denial, no destination, existing sentinel preservation, primary cleanup error, grant/revoke/accept/artifact/input writers между inventory и snapshot. Предыдущий ошибочный fence harness сохранён.

**Assumptions.** Принятые A–C остаются базой. Positive historical test подтверждает сохранение exact revision1 после продвижения heads до2; исправление closure не должно требовать current heads. Отдельный evaluator smoke был bounded read-only и не подменяет эту проверку.

**Cuts.** G14 не исполнен. Rubric f072 сохранена неизменной, но не будет использована для исправленной сборки: после её freeze независимый проверяющий выберет новый запрос/рубрику. Для f072 нет окончательного candidate reconciliation. Проверка исправления и final review продолжаются в этом же CALL. Никаких source fixes, merge/push/publication, старых пользовательских данных и реальных auth-файлов проверяющий не менял.

**Cost.** Reviewer-side preflight auto-review отклонил до создания процесса; точная команда, script SHA и полный отказ сохранены. Root в основном чате затем выполнил неизменённый bounded SDK script через обычное согласование с прямым owner grant. Один Luna public Responses send, HTTP200, OK, input10/output5, refresh0. Reported SDK estimate0.0000035 не является фактическим billing evidence; реальное списание неизвестно. Reviewer был автором script/rubric и оценки, root — раскрытым транспортом. G14 calls0. Авторизация не обходилась.

**Manual-acceptance.** D и полезность продукта владельцем не приняты. Независимый положительный модельный опыт, если появится, не будет называться устойчивостью или личной полезностью владельцу.

**Next: solmax.** Удержать этот неизменяемый отрицательный bundle. После explicit corrected source/build pins сверить изменённые байты, повторить исправленные/родственные G15 случаи, затем выбрать новый G14 и сверить окончательный evidence-only candidate. После двух неудачных исправлений одного пункта — checkpoint для свежего чата.

Inventory перечисляет каждый экспортируемый файл кроме самого inventory. `EXPORT-EXCLUSIONS.json` явно исключает `LOCAL-ONLY-credentials.json` и credential files. Exact source artifact отдельно указан по пути/SHA; этот checkpoint не дублирует весь архив. Скрипты сохранены исходными bytes; их исходный review-root указан в invocation JSON и path-константах. Для воспроизведения доступны закреплённый source artifact, wheels и self-contained fictional corrupt-backup fixtures.
'''
(checkpoint/'report.md').write_text(report,encoding='utf-8')
write(checkpoint/'verification.json',{
 'source_commit':'f07250996d861404728c5892fa1f3b0a6a07bba4','candidate_commit':None,'verdict':'NOT_READY','status':'frozen_negative_checkpoint_review_continues',
 'criteria':{'plan_review_exact':'PASS','source_distribution_installed_mapping':'PASS','outside_installation':'PASS','A_C_scoped':'279 PASS + 1 harness failure then 1 focused PASS; author 280 PASS separately','native_full':'INCOMPLETE_AUTHOR_STOPPED; not reviewer PASS','G15':'FAIL','diagnostics_actual_bytes_and_no_network':'PASS','G14':'PENDING corrected source/build and fresh independent rubric','owner_acceptance':'NOT_GIVEN'},
 'findings':[{'id':'F-D-01','importance':'release-blocking required G15','exact_ref':'packages/core/src/zaratustra_core/maintenance.py:24@f07250996d861404728c5892fa1f3b0a6a07bba4','reproduction':['installed_probe.py','reference_class_sweep.py','history_sleep_sweep.py'],'violated_guarantee':'C12/G15 complete JSON/exact-reference closure before restored publication','related_cases':['outer record source ref rejected','Work input rejected','historical pins with newer heads accepted','Attempt profile/method/manifest accepted broken','typed Sleep Method/analysis/source refs accepted broken']}],
 'limitations':['G14 pending','final candidate pending','full native author run incomplete','own scoped combined rerun result disclosed','no owner acceptance'],
 'preflight':{'reviewer_attempt':'auto-review rejection before process creation','root_transport':'same script hash with direct owner grant via ordinary approval','script_sha256':'59cded1fea4d08bb24d081dfc8130ffc028a8f09e531cd616d42b6394ab4a237','result_sha256':'e205605df4be5781ad0d5c072bbed4ee7e309523e00337a027435da5adb8945d','sends':1,'input_tokens':10,'output_tokens':5,'refreshes':0},
 'exports_exclusions':'EXPORT-EXCLUSIONS.json','acceptance_authority':'owner only'})
files=[]
for p in sorted(checkpoint.rglob('*')):
 if p.is_file() and p.name!='inventory.json':
  raw=p.read_bytes();files.append(dict(path=p.relative_to(checkpoint).as_posix(),bytes=len(raw),sha256=sha(raw)))
write(checkpoint/'inventory.json',{'format':'inventory/v1','files':files,'frozen_after_write':True})
# No checkpoint files are written beyond this point.
bundle=R/'f072-negative-checkpoint.zip'
with zipfile.ZipFile(bundle,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted(checkpoint.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(checkpoint).as_posix())
result=dict(path=str(checkpoint),files=len(files)+1,inventory_sha256=sha((checkpoint/'inventory.json').read_bytes()),bundle=str(bundle),bundle_bytes=bundle.stat().st_size,bundle_sha256=sha(bundle.read_bytes()))
write(R/'f072-checkpoint-retention.json',result)
print(json.dumps(result,indent=2))
