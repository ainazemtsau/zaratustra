import hashlib,json,zipfile,tarfile,pathlib,subprocess,sys,tomllib
R=pathlib.Path(__file__).parent
W=R.parent.parent
E=W/'evidence/package-d/final-f072509'
S=R/'source'
def h(b): return hashlib.sha256(b).hexdigest()
def write(n,o): (R/n).write_text(json.dumps(o,indent=2),encoding='utf-8')
report={'checks':[]}
def ck(name,ok,**kw):
 report['checks'].append(dict(name=name,pass_=bool(ok),**kw))
 assert ok,(name,kw)
pins={'source-f072509.zip':'3f366a11f1360cce9102ace8ef260c23fc52af9bc82efae4e9456267fa0a43cf','zaratustra-next-d-f072509-windows-x64.zip':'d030bd88d028474ff51d3f2b5f73df4b02ef9cd36bb9e9f1adcc3c158589393f','install-f072509/manifest.json':'1e9f85e1a6eb98b9253b3dd67d166c8fafd9f0de1c457279fb308e1374953d6c','SOURCE-MANIFEST.json':'3df7914257761fbce2e3e1aadd23ddd22a0d2f6d63f65464d27c22351c49d6e9'}
try:
 for p,v in pins.items(): ck('pin:'+p,h((E/p).read_bytes())==v,sha256=h((E/p).read_bytes()))
 manifest=json.loads((E/'SOURCE-MANIFEST.json').read_bytes())
 with zipfile.ZipFile(E/'source-f072509.zip') as z:
  for f in manifest['files']:
   raw=(S/f['path']).read_bytes()
   ck('source:'+f['path'],len(raw)==f['bytes'] and h(raw)==f['sha256'] and z.read(f['path'])==raw)
 build=E/'install-f072509/physical-builds'
 installed=pathlib.Path('C:/Users/Anton/AppData/Local/Temp/zaratustra-d-f072509-_mypkhfk/runtime/env/Lib/site-packages')
 installed_owner=pathlib.Path('C:/Users/Anton/AppData/Local/Temp/zaratustra-d-owner-f072509-veu34hei/runtime/env/Lib/site-packages')
 prod=[]
 for pkg,mod,dist in [('core','zaratustra_core','zaratustra_core'),('app','zaratustra_app','zaratustra_next')]:
  with zipfile.ZipFile(build/(dist+'-0.1.0-py3-none-any.whl')) as z,tarfile.open(build/(dist+'-0.1.0.tar.gz')) as t:
   for p in (S/'packages'/pkg/'src'/mod).rglob('*'):
    if p.suffix not in {'.py','.ts','.mjs'}: continue
    rel=p.relative_to(S/'packages'/pkg/'src').as_posix()
    raw=p.read_bytes()
    ck('distribution:'+rel,z.read(rel)==raw and t.extractfile(dist+'-0.1.0/src/'+rel).read()==raw and (installed/rel).read_bytes()==raw and (installed_owner/rel).read_bytes()==raw,sha256=h(raw),bytes=len(raw))
    prod.append(rel)
 lock=(S/'uv.lock').read_text(encoding='utf-8')
 for wh in (E/'owner-bundle/wheels').glob('*.whl'):
  if wh.name.startswith(('zaratustra_core','zaratustra_next')): continue
  ck('dependency-lock:'+wh.name,h(wh.read_bytes()) in lock,sha256=h(wh.read_bytes()))
  with zipfile.ZipFile(wh) as z:
   for name in z.namelist():
    if name.endswith('/') or '.dist-info/' in name: continue
    ck('installed-dependency:'+name,(installed_owner/name).read_bytes()==z.read(name))
 report.update(production_files=len(prod),source_files=len(manifest['files']),archive_note='Own git archive zip container differs from author custom zip; all 397 scope file contents compared exactly, no LF normalization.')
finally: write('byte-verification.json',report)
print(json.dumps({'checks':len(report['checks']),'production_files':len(prod),'all_pass':all(c['pass_'] for c in report['checks'])}))
