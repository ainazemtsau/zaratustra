import pathlib,sys,os,time,json,tempfile,threading,ctypes,subprocess,base64
from zaratustra_core import Core,CoreError,storage,maintenance
R=pathlib.Path(__file__).parent
BASE=pathlib.Path('C:/Users/Anton/AppData/Local/Temp/zaratustra-independent-d-j7s92asp')
root=BASE/'data'
def own():return Core(root),(root/'owner.credential').read_text(encoding='utf-8')
if len(sys.argv)>1:
 core,token=own();c=core.connect(token);kind=sys.argv[1]
 try:
  if kind=='grant':core.grant(token,'blocked', ['read'],origin='host')
  elif kind=='revoke':core.revoke(token,'blocked')
  elif kind=='accept':core.accept_result(token,'attempt','0'*64)
  elif kind=='artifact':c.call('stage_artifact',dict(sha256=__import__('hashlib').sha256(b'x').hexdigest(),raw_base64='eA==',content_type='application/octet-stream'),'blocked-artifact')
  else:c.call('ingest_message',dict(conversation='c',event_id='blocked',raw_base64='eA=='),'blocked-input')
 except CoreError as e: print(json.dumps(e.as_dict()));sys.exit(0 if e.field=='maintenance' else 2)
 raise AssertionError('writer entered backup window')
REPORT=[]
tmp=pathlib.Path(tempfile.mkdtemp(prefix='zaratustra-review-sharing-',dir='C:/Users/Anton/AppData/Local/Temp'))
raw=b'complete independent bytes\x00\xff'*10001
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.CreateFileW.restype=ctypes.c_void_p
kernel.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p]
kernel.CloseHandle.argtypes=[ctypes.c_void_p]
for transient in [True,False]:
 staging=tmp/('stage-'+str(transient));dest=tmp/('published-'+str(transient));staging.mkdir();f=staging/'held.bin';f.write_bytes(raw)
 handle=kernel.CreateFileW(str(f),0x80000000,3,None,3,0,None)
 assert handle!=ctypes.c_void_p(-1).value
 try:
  try:os.replace(staging,dest)
  except OSError as e:assert e.winerror in {5,32,33};injected=e.winerror
  else:raise AssertionError('sharing fault not reached')
  if transient:
   closer=threading.Timer(0.25,lambda:kernel.CloseHandle(handle));closer.start()
  start=time.monotonic();err=None
  try:storage.publish_directory(staging,dest)
  except OSError as e:err=e.winerror
  seconds=time.monotonic()-start
  if transient:
   closer.join();assert dest.is_dir() and (dest/'held.bin').read_bytes()==raw and not staging.exists() and err is None
  else:assert err in {5,32,33} and seconds>=2 and not dest.exists() and f.read_bytes()==raw
  REPORT.append(dict(case='actual Windows sharing',transient=transient,injected_winerror=injected,result_winerror=err,seconds=seconds,pass_=True))
 finally:
  if not transient:assert kernel.CloseHandle(handle)
staging=tmp/'existing-stage';dest=tmp/'existing';staging.mkdir();dest.mkdir();(staging/'new').write_bytes(raw);(dest/'sentinel').write_bytes(b'old')
try:storage.publish_directory(staging,dest)
except OSError:pass
else:raise AssertionError('existing destination overwritten')
assert (dest/'sentinel').read_bytes()==b'old' and not (dest/'new').exists() and (staging/'new').read_bytes()==raw
REPORT.append(dict(case='existing destination preserved',pass_=True))
# Keep the publication failure as the primary error while cleanup cannot remove its tree.
core,token=own();publish=maintenance.publish_directory;rmtree=maintenance.shutil.rmtree
primary=PermissionError('independent publication denied')
def fail(*args):raise primary
maintenance.publish_directory=fail
maintenance.shutil.rmtree=lambda path,ignore_errors=False:None
try:
 try:core.backup(token,tmp/'failed-backup')
 except OSError as e:assert e is primary
 else:raise AssertionError('backup wrongly returned')
 assert not (tmp/'failed-backup').exists() and len(list(tmp.glob('failed-backup.partial-*')))==1
 REPORT.append(dict(case='cleanup keeps primary failure and no destination',pass_=True))
finally:maintenance.publish_directory=publish;maintenance.shutil.rmtree=rmtree
# Target() is called after inventory and before SQLite snapshot while maintenance fence is held.
target=maintenance.target;ready=threading.Event();release=threading.Event();result=[]
def held_target(*args):ready.set();assert release.wait(20);return target(*args)
maintenance.target=held_target
def do_backup():
 try:result.append(core.backup(token,tmp/'fenced-backup'))
 except BaseException as e:result.append(str(e))
backup_thread=threading.Thread(target=do_backup);backup_thread.start();assert ready.wait(10)
try:
 workers=[(kind,subprocess.Popen([sys.executable,'-I','-X','utf8',str(__file__),kind],stdout=subprocess.PIPE,stderr=subprocess.PIPE)) for kind in ['grant','revoke','accept','artifact','input']]
 for kind,p in workers:
  out,err=p.communicate(timeout=15)
  assert p.returncode==0,(kind,p.returncode,out,err)
  REPORT.append(dict(case='inventory-to-snapshot fence:'+kind,pass_=True,refusal=json.loads(out)))
finally:
 release.set();backup_thread.join(20);maintenance.target=target
assert len(result)==1 and isinstance(result[0],dict)
(R/'sharing-fence-checks.json').write_text(json.dumps(dict(base=str(tmp),checks=REPORT),indent=2),encoding='utf-8')
print(json.dumps(dict(checks=len(REPORT),all_pass=True)))
