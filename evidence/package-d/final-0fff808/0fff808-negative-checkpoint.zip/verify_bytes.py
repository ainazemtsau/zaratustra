import hashlib,json,zipfile,tarfile,pathlib,subprocess,sys,tomllib
R=pathlib.Path(__file__).parent
W=R.parents[2]
E=W/'evidence/package-d/final-0fff808'
S=R/'source'
def h(b): return hashlib.sha256(b).hexdigest()
def write(n,o): (R/n).write_text(json.dumps(o,indent=2),encoding='utf-8')
report={'checks':[]}
def ck(name,ok,**kw):
 report['checks'].append(dict(name=name,pass_=bool(ok),**kw))
 assert ok,(name,kw)
pins={'source-0fff808.zip': '66e4652092ed03cc8e59a252565aad7e10e7fb08c18282aaec31ef82c180a43f', 'zaratustra-next-d-0fff808-windows-x64.zip': 'a5828d17ccc55902e128c4535463679be358999c237d01ffb5bba6948a9de802', 'install-0fff808/manifest.json': 'b3f00a4713940ef06104b303a1ddb6941c405a7a8666a42e0b97aca93a00d466', 'SOURCE-MANIFEST.json': '312bfe12c3aeb7e501c89b9921916cba86a46e89d4505c8f97904a42e58691e6'}
try:
 for p,v in pins.items(): ck('pin:'+p,h((E/p).read_bytes())==v,sha256=h((E/p).read_bytes()))
 manifest=json.loads((E/'SOURCE-MANIFEST.json').read_bytes())
 with zipfile.ZipFile(E/'source-0fff808.zip') as z:
  for f in manifest['files']:
   raw=(S/f['path']).read_bytes()
   ck('source:'+f['path'],len(raw)==f['bytes'] and h(raw)==f['sha256'] and z.read(f['path'])==raw)
 build=E/'install-0fff808/physical-builds'
 installed=pathlib.Path('C:/Users/Anton/AppData/Local/Temp/zaratustra-d-0fff808-04geqcqn/runtime/env/Lib/site-packages')
 installed_owner=pathlib.Path('C:/Users/Anton/AppData/Local/Temp/zaratustra-d-owner-0fff808-q992x0tg/runtime/env/Lib/site-packages')
 prod=[]
 for pkg,mod,dist in [('core','zaratustra_core','zaratustra_core'),('app','zaratustra_app','zaratustra_next')]:
  with zipfile.ZipFile(build/(dist+'-0.1.0-py3-none-any.whl')) as z,tarfile.open(build/(dist+'-0.1.0.tar.gz')) as t:
   for p in (S/'packages'/pkg/'src'/mod).rglob('*'):
    if p.suffix not in {'.py','.ts','.mjs'}: continue
    rel=p.relative_to(S/'packages'/pkg/'src').as_posix()
    raw=p.read_bytes()
    ck('distribution:'+rel,z.read(rel)==raw and t.extractfile(dist+'-0.1.0/src/'+rel).read()==raw and (installed/rel).read_bytes()==raw and (installed_owner/rel).read_bytes()==raw,sha256=h(raw),bytes=len(raw))
    prod.append(rel)
 lock=(S/'uv.lock').read_text(encoding='utf-8')
 for wh in (E/'owner-bundle/wheels').glob('*.whl'):
  if wh.name.startswith(('zaratustra_core','zaratustra_next')): continue
  ck('dependency-lock:'+wh.name,h(wh.read_bytes()) in lock,sha256=h(wh.read_bytes()))
  with zipfile.ZipFile(wh) as z:
   for name in z.namelist():
    if name.endswith('/') or '.dist-info/' in name: continue
    ck('installed-dependency:'+name,(installed_owner/name).read_bytes()==z.read(name))
 report.update(production_files=len(prod),source_files=len(manifest['files']),archive_note='Own git archive zip container differs from author custom zip; all 400 scope file contents compared exactly, no LF normalization.')
finally: write('byte-verification.json',report)
print(json.dumps({'checks':len(report['checks']),'production_files':len(prod),'all_pass':all(c['pass_'] for c in report['checks'])}))
