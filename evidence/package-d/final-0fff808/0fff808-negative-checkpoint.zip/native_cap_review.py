import json, pathlib, subprocess, sys
from zaratustra_app import LiveProfile
from zaratustra_core import CoreError

R=pathlib.Path(__file__).parent
checks=[]
for cap in [1,15]:
    try:
        LiveProfile(endpoint='https://api.openai.com/v1',model='gpt-6-luna',auth_mode='pi-chatgpt',auth_path=str(R/'absent-fictional-auth.json'),max_tokens=cap)
    except CoreError as e:
        assert (e.code,e.field)==('unsupported_capability','native.max_output_tokens.minimum16')
        checks.append(dict(cap=cap,refused_before_runtime=True,error=e.as_dict(),physical_calls=0))
    else:
        raise AssertionError('Unsupported native cap admitted')
for cap in [16,64]:
    p=subprocess.run([sys.executable,'-I','-X','utf8',str(R/'native_token_cap_probe.py'),str(cap)],capture_output=True,timeout=90)
    (R/f'token-cap-{cap}.stdout.bin').write_bytes(p.stdout)
    (R/f'token-cap-{cap}.stderr.bin').write_bytes(p.stderr)
    assert p.returncode==0,p.stderr.decode(errors='replace')
    raw=json.loads((R/f'token-cap-{cap}/native-capability.json').read_bytes())
    assert raw['request_count']==1 and raw['request']['max_output_tokens']==cap
    checks.append(dict(cap=cap,exact_cap=True,physical_local_requests=1,external_requests=0))
(R/'token-cap-review.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
print(json.dumps(checks))
