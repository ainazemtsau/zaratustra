"""Independent fictional normal-operation cases, no provider or test helpers."""
import json,pathlib,subprocess,sys,tempfile
from zaratustra_core import Core,CoreError
from zaratustra_app import Conversation,Driver

R=pathlib.Path(__file__).parent
def dump(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
if len(sys.argv)>1:
    root=pathlib.Path(sys.argv[1]);core=Core(root)
    c=core.connect((root/'owner.credential').read_text(encoding='utf-8'))
    s=c.call('read_snapshot',{},'fresh-process-review')
    print(json.dumps({k:s[k] for k in ['works','results','conversations','heads','actions','acceptance']},ensure_ascii=False))
    sys.exit()

B=pathlib.Path(tempfile.mkdtemp(prefix='zaratustra-normal-continuation-review-'))
checks=[]
for limit in [2,4]:
    core,token=Core.initialize(B/str(limit));calls=[]
    (core.root/'owner.credential').write_text(token,encoding='utf-8')
    def receive(context,action):
        calls.append(context)
        phase=context['response_contract']['version']
        if phase=='ordinary-routing/1':
            result={'state':'completed','text':'not presented','changes':[{'id':'fictional-act','kind':'activity','key':'review','body':{'agreement':'Fictional local fixture'}}],'expected_heads':{'fictional-act':0},'outputs':[{'id':'fictional-act','revision':1}],'next_work':{'scope':'fictional-act','goal':'Perform fictional fixture','inputs':[]}}
        else:
            assert context['work']['scope']=='fictional-act'
            assert context['raw_messages']==['original exact fictional input']
            assert any(r['id']=='fictional-act' for r in context['inputs'])
            result={'state':'completed','text':'Fictional useful fixture result','changes':[{'id':'fixture-result','kind':'data','key':'result','scope':'fictional-act','body':'A retained fixture result'}],'expected_heads':{'fixture-result':0},'outputs':[{'id':'fictional-act','revision':1},{'id':'fixture-result','revision':1}]}
        return json.dumps(result).encode()
    driver=Driver(receive);session=Conversation(core,token)
    session.submit('original exact fictional input')
    try:result=session.run(driver,{'fixture':'review'},limit)
    except CoreError as e:
        assert limit==2 and (e.code,e.field)==('resource_exhausted','work.paused')
        result={'state':'paused','error':e.as_dict()}
    snapshot=session.owner.call('read_snapshot',{},'independent-snapshot')
    parent=next(w for w in snapshot['works'] if json.loads(w['body'])['scope']=='space')
    child=next(w for w in snapshot['works'] if w['id']!=parent['id'])
    parent_body,child_body=map(lambda w:json.loads(w['body']),[parent,child])
    assert child_body['call_limit']==limit-parent['reserved']
    assert len(snapshot['works'])==2 and not snapshot['acceptance']
    assert sum(w['reserved'] for w in snapshot['works'])<=limit
    original=session.coordinator.recover(next(a['id'] for a in snapshot['attempts'] if a['work']==parent['id']),ordinary=True)
    assert original['next_work_id']==child['id'] and original['text']==''
    try:reopened=Conversation(Core(core.root),token).run(driver,{'fixture':'review'},limit)
    except CoreError as e:
        assert limit==2 and (e.code,e.field)==('resource_exhausted','work.paused')
        reopened={'state':'paused','error':e.as_dict()}
    assert len(calls)==(1 if limit==2 else 2)
    if limit==2:
        assert child['status']=='paused' and result['state']==reopened['state']=='paused'
        assert snapshot['conversations'][0]['cursor']==0
    else:
        assert result['text']=='Fictional useful fixture result' and reopened['state']=='idle'
        assert snapshot['conversations'][0]['cursor']==1
    p=subprocess.run([sys.executable,'-I','-X','utf8',str(__file__),str(core.root)],capture_output=True,timeout=20)
    (R/f'continuation-{limit}-fresh.stdout.bin').write_bytes(p.stdout)
    (R/f'continuation-{limit}-fresh.stderr.bin').write_bytes(p.stderr)
    assert p.returncode==0,p.stderr
    fresh=json.loads(p.stdout);assert fresh['works']==snapshot['works']
    backup=B/f'backup-{limit}';core.backup(token,backup)
    restored=B/f'restored-{limit}';Core.restore_quarantined(backup,restored)
    dump(R/f'continuation-{limit}-state.json',{k:snapshot[k] for k in ['works','attempts','results','conversations','heads','actions','acceptance']})
    checks.append({'limit':limit,'calls':len(calls),'reserved':sum(w['reserved'] for w in snapshot['works']),'result':result,'reopened':reopened,'fresh_process_and_restore':True})
dump(R/'continuation-review.json',{'base':str(B),'checks':checks})
print(json.dumps(checks))
