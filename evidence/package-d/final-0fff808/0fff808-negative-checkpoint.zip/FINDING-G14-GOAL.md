# F-D-07 — ordinary reopen ends on an undisclosed handoff goal limit

Source `0fff8088f092a8ba6b32451ed5c1e03e844c233a`; real installed owner archive SHA256 `a5828d17ccc55902e128c4535463679be358999c237d01ffb5bba6948a9de802`.

**Release blocker: G14 FAIL.** The independently chosen request and correction produced useful draft games and four meaningful immutable revisions of the same Activity. A third fresh installed client received a successful provider terminal, then exited 1 with a traceback before showing any requested continuation. `next_work.goal` contains 273 Unicode characters; `shapes.Work.goal` uses `Id`, whose maximum is 240. Core correctly refused that shape. The routing Method/response contract describes `goal` as text without exposing that bound, and the ordinary path provides no successful handling of this known invalid terminal.

Exact evidence: immutable `g14-rubric.json`, `g14-installed-run.py`, `g14-installed/reopen.stderr.bin`, `g14-installed/reopen-decoded-outcome.json`, `g14-installed/reopen-retained-terminal.bin`, the fifth exact provider request/response and `G14-ASSESSMENT.json`. The initial request is not overlong user-supplied Work metadata; the adapter asks the model to derive the handoff goal from an ordinary human continuation.

The third routing terminal proposes Activity revision 5 with the correct current coin/three-minute agreement and a second-level goal. Atomic rejection preserved head revision 4, four prior results, and conversation cursor 2; message 3 remains pending. There is no fifth revision, second-level scoped Work or useful third answer. The latest Work remains running with its exact terminal retained and action terminal. This is a typed handoff/application failure, not an account, unknown-send or provider refusal. No retry was performed.

The first two responses are limited positive usefulness evidence, and actual Activity creation/persistence now works for those turns. They do not satisfy the required reopen criterion. The coin rules also have a smaller quality ambiguity: checking for exactly three signals only after both flips leaves an overshoot to four unclear. That observation does not explain or replace the application failure.

Five physical requests completed, one per Attempt. Native reserve was two each, the first two root chains used four each and the unfinished third used two. Reported usage: 27,076 input + 3,251 output = 30,327 tokens, including 459 reasoning tokens within output. SDK estimated cost is 0.0043331; actual billing/quota debit is unknown. No owner acceptance was made. Source, rubric and script remain unchanged.

This is a new failure point. Earlier Activity-absent and native-cap findings are not erased or recast as a successful overall G14 trial. A correction must preserve exact original input and retained terminal evidence; a new source/build and another live trial require their own explicit bounded review handling.
