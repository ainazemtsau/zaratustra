"""Launch one ordinary interactive Pi with an epoch-bound local Core bridge."""

from __future__ import annotations

import argparse
import getpass
import os
import subprocess
import sys
import threading
from contextlib import ExitStack
from importlib.resources import files
from pathlib import Path
from urllib.parse import urlsplit
from uuid import UUID, uuid4

from zaratustra.foundation import (
    BootstrapRequest,
    FoundationError,
    LocalAuthority,
    apply_operation,
    authorize_local,
    initialize_space,
    inspect_space,
    managed_pi_session_lock,
    managed_pi_sessions,
    read_space,
    upgrade_activity_setup_space,
    upgrade_binding_space,
    upgrade_change_package_space,
    upgrade_child_execution_space,
    upgrade_composition_space,
    upgrade_continuation_space,
    upgrade_conversation_space,
    upgrade_delivery_correlation_space,
    upgrade_development_space,
    upgrade_execution_space,
    upgrade_knowledge_space,
    upgrade_memory_space,
    upgrade_parent_execution_space,
    upgrade_plan_revision_space,
    upgrade_space,
    upgrade_structures_space,
    upgrade_workflow_space,
)
from zaratustra.workspace import read_config

from .bridge import Bridge, BridgeServer
from .skills import activity_setup_skill, external_workflow_skill

INTERACTIVE_ZARA_TOOLS = (
    "zara_activity",
    "zara_binding",
    "zara_memory",
    "zara_data",
    "zara_grant",
    "zara_sleep",
    "zara_development",
    "zara_result",
    "zara_transfer",
    "zara_integration",
    "zara_workspace",
    "zara_workflow",
    "zara_conversation",
)


def _prepare_space(
    path: Path, actor: str, *, create: bool, upgrade_existing: bool = False
) -> LocalAuthority:
    if create:
        initialize_space(path)
    info = read_space(path)
    if not create and not upgrade_existing and info.schema_version < 18:
        raise FoundationError(
            "upgrade_required", "Run zaratustra upgrade explicitly before opening Pi"
        )
    authority = authorize_local(path, actor=actor, source_ref=f"local-console:{actor}:{uuid4()}")
    if info.state_revision == 0:
        apply_operation(
            path,
            BootstrapRequest(
                operation_id=uuid4(),
                space_id=info.space_id,
                actor=actor,
                decision_id=uuid4(),
                grant_id=uuid4(),
            ),
            authority,
        )
    if read_space(path).schema_version == 1:
        upgrade_space(path, authority)
    if read_space(path).schema_version == 2:
        upgrade_execution_space(path, authority)
    for version, upgrade in (
        (4, upgrade_continuation_space),
        (5, upgrade_composition_space),
        (6, upgrade_child_execution_space),
        (7, upgrade_plan_revision_space),
        (8, upgrade_parent_execution_space),
        (9, upgrade_binding_space),
        (10, upgrade_knowledge_space),
        (11, upgrade_development_space),
        (12, upgrade_change_package_space),
        (13, upgrade_memory_space),
        (14, upgrade_activity_setup_space),
        (15, upgrade_structures_space),
        (16, upgrade_workflow_space),
        (17, upgrade_conversation_space),
        (18, upgrade_delivery_correlation_space),
    ):
        if read_space(path).schema_version < version:
            upgrade(path, authority)
    return authority


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--space", required=True, type=Path)
    parser.add_argument("--workspace", required=True, type=Path)
    parser.add_argument("--workspace-config", type=Path)
    parser.add_argument("--pi-cli", required=True, type=Path)
    parser.add_argument(
        "--pi-runtime",
        required=True,
        type=Path,
        help="Directory with node_modules for the selected upstream Pi",
    )
    parser.add_argument("--node", default="node")
    parser.add_argument("--new-space", action="store_true")
    parser.add_argument("--limit-units", type=int)
    parser.add_argument("--reserve-units", type=int, required=True)
    parser.add_argument("--free-conversation-limit-units", type=int)
    parser.add_argument("--context-max-bytes", type=int)
    parser.add_argument(
        "--provider-profile", choices=("codex-sse", "local-completions"), default="codex-sse"
    )
    parser.add_argument("--provider-base-url", help="Selected Pi Provider endpoint")
    parser.add_argument("--local-provider-id")
    parser.add_argument("--local-model-id")
    parser.add_argument("--local-context-window", type=int)
    parser.add_argument("--local-max-tokens", type=int)
    parser.add_argument("--model", help="Provider/model selected by Pi; no product default")
    parser.add_argument("--thinking", help="Pi reasoning level")
    parser.add_argument("--remember-selection", action="store_true")
    parser.add_argument("--subscription-agent-dir", type=Path)
    parser.add_argument("--pi-tools", help="Optional comma-separated native Pi tool allowlist")
    parser.add_argument("--session-dir", type=Path)
    parser.add_argument("--activity-id", type=UUID)
    parser.add_argument("--work-id", type=UUID)
    args = parser.parse_args(argv)
    if args.workspace_config:
        config = read_config(args.workspace_config)
        preferred = config.preferred_model
        if preferred is not None and preferred.provider_profile == args.provider_profile:
            args.model = args.model or preferred.model_id
            args.thinking = args.thinking or preferred.thinking
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        parser.error("Start from an interactive local console for trusted setup")
    space = args.space.expanduser().resolve()
    workspace = args.workspace.expanduser().resolve()
    pi_cli = args.pi_cli.expanduser().resolve()
    runtime = args.pi_runtime.expanduser().resolve()
    expected_sessions = space / ".zara-core" / "pi-sessions"
    if args.session_dir and args.session_dir.expanduser().resolve() != expected_sessions:
        parser.error(f"Pi sessions must use the managed Core directory: {expected_sessions}")
    if not workspace.is_dir() or not pi_cli.is_file() or not (runtime / "node_modules").is_dir():
        parser.error("Workspace, Pi CLI or Pi runtime is unavailable")
    if (
        args.reserve_units < 1
        or (args.limit_units is not None and args.limit_units < 1)
        or (
            args.free_conversation_limit_units is not None
            and args.free_conversation_limit_units < 1
        )
        or (args.context_max_bytes is not None and args.context_max_bytes < 1)
    ):
        parser.error("Model resource limits must be positive")
    base_url = args.provider_base_url or (
        "https://chatgpt.com/backend-api" if args.provider_profile == "codex-sse" else None
    )
    if not base_url:
        parser.error("Local Provider needs an explicit base URL")
    parsed_url = urlsplit(base_url)
    if parsed_url.scheme not in ("https", "http") or not parsed_url.hostname:
        parser.error("Provider base URL must be an absolute HTTP URL")
    if args.provider_profile == "local-completions" and (
        not args.local_provider_id
        or not args.local_model_id
        or not args.local_context_window
        or not args.local_max_tokens
    ):
        parser.error("Local Provider needs id, model and context/output bounds")
    if (args.activity_id is None) != (args.work_id is None):
        parser.error("Initial Activity and Work must be selected together")
    native_tools = (
        [item.strip() for item in args.pi_tools.split(",") if item.strip()]
        if args.pi_tools
        else ["read", "write", "edit", "bash"]
    )
    active_tools = ",".join(dict.fromkeys([*native_tools, *INTERACTIVE_ZARA_TOOLS]))
    workflow_skill = external_workflow_skill()
    actor = getpass.getuser()
    print(f"Core space: {space}\nWorking directory: {workspace}\nLocal user: {actor}")
    usage_line = (
        "Local model usage: recorded without a spending stop"
        if args.limit_units is None and args.free_conversation_limit_units is None
        else f"Work limit: {args.limit_units or 'none'}; "
        f"free conversation limit: {args.free_conversation_limit_units or 'none'}"
    )
    print(
        f"Provider profile: {args.provider_profile}\n"
        f"Pi model: {args.model or 'Pi selection'}\n"
        f"Pi tools: {active_tools}\n"
        f"{usage_line}"
    )
    if args.activity_id:
        print(f"Activity: {args.activity_id}\nWork: {args.work_id}")
    if input("Type CONNECT to use these paths and local identity: ").strip() != "CONNECT":
        return 1
    current_schema = 0 if args.new_space else read_space(space).schema_version
    if not args.new_space and current_schema < 18:
        parser.error("Run zaratustra upgrade explicitly; Pi does not migrate an existing Core")
    if args.new_space:
        print(f"Selected Core schema: {current_schema}; new Core target: 18")
        if input("Type UPGRADE to initialize or upgrade this space: ").strip() != "UPGRADE":
            return 1
    authority = _prepare_space(space, actor, create=args.new_space)
    with managed_pi_session_lock(space):
        if inspect_space(space, authority).pending_deletions:
            parser.error("Complete pending Core deletions before opening Pi")
        session_dir = managed_pi_sessions(space, authority.space_id, create=True)
        bridge = Bridge(
            space,
            authority,
            workspace,
            args.limit_units,
            context_max_bytes=args.context_max_bytes,
            free_conversation_limit_units=args.free_conversation_limit_units,
            workspace_config=args.workspace_config,
        )
        executor_store = space / ".zara-core" / "executor.sqlite3"
        if executor_store.is_file():
            from .assigned import deliver_outbox

            bridge.deliver_answer = lambda outbox_id: deliver_outbox(space, authority, outbox_id)
        from .activity_setup import SetupCoordinator
        from .assigned import AssignedConfig
        from .procedures import ProcedureCoordinator
        from .workflows import WorkflowCoordinator

        bridge.setup_controller = SetupCoordinator(
            bridge,
            AssignedConfig(
                space=space,
                workspace=workspace,
                pi_cli=pi_cli,
                pi_runtime=runtime,
                node=args.node,
                provider_profile=args.provider_profile,
                provider_base_url=base_url,
                provider_id="openai-codex"
                if args.provider_profile == "codex-sse"
                else args.local_provider_id,
                model_id=args.model or args.local_model_id or "",
                thinking=args.thinking,
                context_window=args.local_context_window,
                max_tokens=args.local_max_tokens,
                reserve_units=args.reserve_units,
                limit_units=args.limit_units,
                offline=args.provider_profile == "local-completions",
                disable_tools=True,
                subscription_agent_dir=args.subscription_agent_dir,
                workspace_config=args.workspace_config,
            ),
        )
        bridge.procedure_controller = ProcedureCoordinator(bridge, bridge.setup_controller.config)
        bridge.workflow_controller = WorkflowCoordinator(bridge, bridge.setup_controller.config)
        with ExitStack() as cleanup:
            server = BridgeServer(bridge)
            cleanup.callback(server.server_close)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            cleanup.callback(thread.join, timeout=5)
            cleanup.callback(server.shutdown)
            cleanup.callback(bridge.workflow_controller.close)
            cleanup.callback(bridge.procedure_controller.close)
            cleanup.callback(bridge.setup_controller.close)
            extension = Path(str(files("zaratustra.pi_adapter").joinpath("extension.ts")))
            environment = os.environ.copy()
            environment["ZARA_CORE_ENDPOINT"] = f"http://127.0.0.1:{server.server_port}"
            environment["ZARA_CORE_TOKEN"] = bridge.token
            environment["ZARA_RESERVE_UNITS"] = str(args.reserve_units)
            environment["ZARA_PROVIDER_PROFILE"] = args.provider_profile
            environment["ZARA_PROVIDER_BASE_URL"] = base_url
            if args.remember_selection:
                environment["ZARA_REMEMBER_SELECTION"] = "1"
            environment["ZARA_PROVIDER_ORIGIN"] = f"{parsed_url.scheme}://{parsed_url.netloc}"
            environment["PI_SKIP_VERSION_CHECK"] = "1"
            environment["PI_TELEMETRY"] = "0"
            if args.subscription_agent_dir:
                environment["PI_CODING_AGENT_DIR"] = str(args.subscription_agent_dir.resolve())
            if args.provider_profile == "local-completions":
                environment["PI_OFFLINE"] = "1"
            if args.activity_id:
                environment["ZARA_INITIAL_ACTIVITY_ID"] = str(args.activity_id)
                environment["ZARA_INITIAL_WORK_ID"] = str(args.work_id)
            if args.provider_profile == "local-completions":
                environment["ZARA_LOCAL_PROVIDER_ID"] = args.local_provider_id
                environment["ZARA_LOCAL_MODEL_ID"] = args.local_model_id
                environment["ZARA_LOCAL_CONTEXT_WINDOW"] = str(args.local_context_window)
                environment["ZARA_LOCAL_MAX_TOKENS"] = str(args.local_max_tokens)
            command = [
                args.node,
                str(pi_cli),
                "--provider",
                "openai-codex" if args.provider_profile == "codex-sse" else args.local_provider_id,
                "--extension",
                str(extension),
                "--no-extensions",
                "--no-context-files",
                "--skill",
                str(workflow_skill),
                "--skill",
                str(activity_setup_skill()),
            ]
            if args.model:
                command.extend(["--model", args.model])
            if args.thinking:
                command.extend(["--thinking", args.thinking])
            command.extend(["--tools", active_tools])
            command.extend(["--session-dir", str(session_dir)])
            return subprocess.run(command, cwd=workspace, env=environment, check=False).returncode


if __name__ == "__main__":
    raise SystemExit(main())
