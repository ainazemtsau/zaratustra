# Interactive Pi adapter

Ordinary material reads use exact common Artifact/knowledge windows and runtime
selectors without definition-local aliases. Only returned bytes become exposed;
navigation and index coverage cannot claim full originals were read. Native
transport guards preserve the original context refusal through SDK hook error
handling. After unknown delivery the same native origin cannot retry silently;
recheck the exact durable invocation/manifest. A new owner request can explain
saved effects without changing the old unknown outcome or accepting Work.

`selection.py` is the shared native transition for ordinary Work/project selection
and assigned process entry. Retain actual native choice/entry/invocation evidence,
then hold Bridge's admission RLock from host validation through the exact Core
stop receipt and selection commit. No executor launch, observation or cleanup wait
belongs inside that lock. Keep old pins in native pending entries until the
receipt resolves; startup/tree restoration is passive and a fresh owner request
chooses continue or cancel. Preserve no-op Attempts only with their actual current
resource pin/root. Recheck the exact target after the stop receipt before local
commit; later Core context/effect pins remain authoritative. A pre-stop cancel
retains the surviving old Attempt as an addressed recovery obstacle, restored
passively from the native committed choice after reopening. It never reselects or
interrupts that Attempt. Sequential native tools require fresh context after a change.
Assigned entry detaches ordinary selection before waking or launching a worker.
Read-only command focus is a separate exact Work reference in ContextManifest;
it never owns a resource or creates an Attempt. Addressed answers use the same
guarded transition before their outbox can wake assigned execution.

Configured procedure selection persists its Core resource before dispatch. Read
the committed snapshot after selection, then pin that resource's actual ID and
revision. Never create a fallback from the earlier empty snapshot. Legacy setup
also selects one actual active resource; historical entries cannot supply its
identity or revision. Keep multiple-resource refusals and owner acceptance intact.

0.25.1 BridgeServer owns the checked idle Core client until native HTTP handlers
have drained. Keep request threads joinable and inactive socket reads bounded; release
the client/fence after native server cleanup, including constructor failure and
repeated close. Ordinary/assigned hosts share this same server boundary. No
domain transaction, snapshot, write lock or alternate execution authority is
retained. SQLite's default FULL/checkpoint policy and Core schema 18 stay intact.
Persist setup/workflow pause through the existing atomic Core domain operation
before signalling local teardown. Do not precede it with snapshot-based duplicate
assignment stops. Propagate admission refusals and drain every owned resource even
if one coordinator's close refuses; native cleanup uses standard ExitStack.

Setup, workflow and procedure use one public completed-response recovery before
fresh dispatch. Native message_end retains raw assigned bytes before accounting;
turn_end retains the actual persisted entry/protocol before interpretation.
Never invent an entry ID for early capture. Missing terminal proof or unknown
sends stop with addressed diagnostics. Recovery precedes new model admission;
the existing domain validators still decide whether the retained output works.

Current 0.25.0 has one ordinary conversational owner. Lifecycle tools await a
typed transient ProcessBoundary; observers receive exact target/session/branch/
generation leases, native AbortSignal and progress. Never inject a completion
turn from status/executor callbacks. Startup discovers saved state without
automatic executor/model launch. Native lifecycle tools are sequential; worker
nodes keep their existing concurrency. Questions return without joining live
RPC. Abort requests addressed pause/stop without waiting for cleanup joins.
Empty final recovery stays in the same native run: exact public terminal proof,
at most two reservations in persisted custom entries and native context edits.
Response-only admission blocks mutations/answers/acceptance at both host and tool
gates while preserving each provider request's actual Work/Attempt correlation.
Its native request exposes no model tools; it formulates an explanation from the
checked context and completed run. Retained derived selections and Git checks are
effects, not permitted repair reads.
New actual owner input restores normal authority. Legacy wake history is filtered;
fresh legacy/unsupported custom messages cannot initiate another conversation.
The schema-17 delivery contracts below remain compatibility/history, not new
completion scheduling authority. The current plan is docs/single-conversation-owner-plan.md.

New ordinary Pi spaces explicitly initialize through schema 18; existing spaces
need the owner-approved public upgrade before launch. Durable delivery correlation
pins Work/Attempt/session without scanning unrelated old manifests. Schema 17
conversation records retain their legacy reading and response protocols; automatic
no-send cleanup requires schema 18 and otherwise reports upgrade_required.

Schema 17 conversation continuation derives current actions from Core. Native
terminal observations preserve exact visible UTF-8 bytes, including empty bytes,
before Core classifies the response. Thinking is excluded. A checked host task
appears in actual provider instructions. Core permits at most two repairs of known
empty completed responses per logical delivery; native BoundaryResult commits an
empty checked custom wake before continuation. Repair manifests pin the prior
Source and manifest. Unknown sends, capture failures and stale rights never cause
a blind resend. Current context and UI retain Core-derived delivery obstacles.
followUp wakes carry empty, checked-address custom entries filtered from provider
and compaction input; exact ContextManifest, observed invocation and persisted
final assistant entry prove delivery. Tool-use answers are not final delivery.
Closed/switch/fork/tree generations fence callbacks; only proven unsent claims
can be abandoned. Actual owner requests recover current facts after notices were
delivered. Selecting the existing first Work neither duplicates nor accepts it.

Native received input is not consumed input. Schema-17 origin uses newly delivered
persisted native user entries, preserving raw receipt separately. Extension-origin
user input is retained without owner authority and refused at ingress; extensions
must use checked Core events. No text marker or natural-language intent parser.
Multiple consumed entries need an exact source choice for addressed answers; a
source predating a question cannot answer it. Host/history turns have Core-reader
and scoped file-reader authority; writable tools and unknown extension tools are
not admitted. Ordinary owner turns restore their selected loadout. Pin invocation
Work/Attempt/session independently of later selection changes.
Ordinary successful finals retain exact native entry and pinned manifest proof at
turn_end. After abrupt loss, Core atomically rechecks that proof on completed
StopAttempt; absent or unknown proof preserves execution and restores a free
conversation with an addressed obstacle. Explicit interruption requires a real
owner Source and native confirmation. Never replay a send or accept Work during
recovery. Model memory cannot create or revise the reserved final-proof flag.
Native failure/shutdown cleanup uses the same saved proof; only an exact Attempt
with Core-proven absence of sends may be interrupted automatically. A terminal
unknown delivery cannot inject its old host task into a fresh owner conversation.

`workflows.py` coordinates schema-16 workflow nodes through ordinary assigned Pi/DBOS.
WorkPlan is the actual graph; Work/Attempt and committed receipts own progress.
Node model/profile/reasoning is pinned before launch. At most two read-only model
nodes run together. No additional queue, execution-status copy or model engine.
Host questions retain original user Sources and can wait without a live Pi process.
Internal validation permits only an addressed next step, never owner acceptance.
Setup nodes expose only admitted Core readers; changes remain host-owned.

`procedures.py` coordinates saved procedure Work through existing RPC/DBOS while
Pi is open, using the selected admitted provider/model. Intent precedes input
selection; Work acceptance stays separate. `zara_data` uses the public installed
Core/integration contract. Setup v2 has separate full preparation/review/correction
sessions without file/command tools. Old Work context retains its exact or legacy pin.

Config v2 workspace/project operations use public `zaratustra.workspace`.
Native Pi factories receive both the selected root and that root in their tool
context; persisted transcript cwd never changes Core resources on resume.
Add workspace guidance as structured prompt sections, never a forced prompt that
overwrites the request-local ContextManifest. Git UI confirms one exact packet.

Activity setup uses a window-owned finite coordinator in `activity_setup.py`.
New stages pin setup_json in Core; ordinary/legacy assigned Work keep the envelope.
Retain raw completed stage text before JSON validation. Core rejection decides
same-kind bounded correction; never retry unknown sends or stored-state failures.
Every stage is the existing assigned ordinary Pi/DBOS path in a separate session,
with arbitrary tools disabled. Core holds all progress and review counts.
No real-provider fallback, no background service, and no automatic Work acceptance.
The packaged setup skill drives small substantive question groups.

Schema 13 `zara_memory` catalog/read_batch/history/open_selection/prepare_cache/export
uses the shared public Core. Method requirements resolve current Activity in the
host, then pin the checked selection in ContextManifest; large reference text
has explicit continuation instead of unlimited automatic context. Conversation
caches refresh before sends. Export stays inside the selected resource and never
overwrites. Existing composite execution still uses assigned ordinary Pi RPC.

`manual_exchange.py` is a compatibility import from `zaratustra.integrations`.
The shared adapter owns manual operations over public Core, not Pi or release state.
`zara_integration` exposes installed catalog/contract/apply; actor and operation identity
come from the host session. Assigned RPC cannot use this interactive setup path.
It propagates only exact references whose content was actually exposed, not import
acknowledgements. Read windows are bounded; instance settings and sources remain Core
data. Do not infer sending, matching or acceptance from preparation or source import.
The interactive launcher explicitly passes the installed `zaratustra-external` skill
via Pi's native --skill path; never substitute a cwd profile or copy personal settings
into package resources. Synthetic tools.probe_external_pi checks actual delivery and
retention/reopening, not autonomous instruction quality or a real external connection.

This package hosts the loopback HTTP bridge for ordinary upstream Pi.
Resolve the ordinary Pi from PATH for the selected system runtime on each launch,
including assigned Work. Do not freeze a second Pi installation or copy the extension
into npm-owned files. The wheel supplies extension bytes; the extension resolves its
dependencies from the actual Pi CLI. Preserve explicit-runtime configurations as an
opt-in and keep subscription-agent-dir separate from managed Pi sessions. Pi 1.0.4
has scoped interactive, compaction and assigned localhost evidence; future updates
still pass the existing provider observation and Core admission checks.
It establishes local authority in the host process, never from model or request text.
It composes public foundation operations and owns no model loop or subject store.
The TypeScript extension runs inside ordinary upstream Pi and observes supported
Provider HTTP/SSE traffic. Keep the model/provider selection configurable; reject
unobservable transport instead of sending an unrecorded request. New data and Pi
sessions belong to a user-selected workspace, not the installed package.

The assigned RPC path uses only ordinary upstream Pi and pinned DBOS queue,
workflow and message APIs. Its DBOS input/output contains addresses and outcomes,
not Work prose or provider payload. The interactive bridge may show and answer a
saved question while RPC is waiting. Keep assigned child bridge access bound to
one Attempt/session. The assigned Pi home and DBOS SQLite are managed under the
chosen Core space; backup, epoch fencing and addressed deletion must cover them.
Do not add a second dispatcher, queue or replay ledger here.
A composite child runs only through that same assigned path: Core's launch claim
and effect gate decide plan, pin and dependency admission. A subject refusal
before launch records an observed stop without starting Pi; technical refusals
leave the assignment for maintenance. Pi context and `/zara-status` carry Core
state, plan addresses and pinned versions, never a copy of the plan.
Part 3.10 shows addressed status reasons, Choice/Exception applicability,
revalidation, node decisions, pins/transfers and immediate nested children.
New DBOS workflows have Attempt-specific queues and app versions so another
runner cannot recover them under the wrong workspace. Repeated delivery keeps
the recorded workflow ID. A legacy shared-route workflow is moved by public
DBOS resume to its Attempt-specific queue before its runner starts; that runner
listens only to the selected queue and has an Attempt-specific executor ID.
An already addressed PENDING workflow recorded by the earlier local executor
is resumed by its own runner through the same public DBOS operation. Core's
committed launch claim still makes a second execution unknown without new HTTP.
An unrelated legacy workflow stays queued for its own runner. A cancelled launch
with no claim is an observed prelaunch stop without Pi or HTTP.
Concurrent cold runners in one Core space serialize the short DBOS SQLite
lookup/migration/launch window with `managed_executor_start_lock`. Their
Attempt-specific queues and Pi sessions remain independent after launch.
An interrupted first DBOS migration can leave only the executor SQLite file.
Under the same startup lock, use DBOS's public migration entry point before
DBOSClient queries an existing file; preserve its workflow IDs, versions and
post-claim unknown fence. Never replace that file as a recovery shortcut.
Schema 8 lets the same assigned path run a root or nested composite Work's own
Attempt. Its Core plan pin and output proof are visible by address in the assigned
context and `/zara-status`, with roleless obligations labelled as own Work.
No plan text, confirmation basis or new authority is copied into DBOS or Pi status.
Interactive ordinary Pi exposes `zara_binding`: catalog, a generated typed Core
contract for one operation kind, and confirmed apply. Core assigns actor and
space, checks every request and owns the receipt; assigned RPC cannot manage
Bindings. `/zara-binding` shows current addresses and offers. No model or
semantic judge runs in the foundation. The development-only localhost synthetic
model probe is `tools.probe_binding_pi --pi-runtime <path>`.
Interactive Pi captures admitted conversation text and exposes `zara_memory`
for typed sources, Claim and handoff mutations plus exact retrieval. Core stores
the original, not the extension. Memory creation and revision use the current Core
rights without per-record owner prompts; interactive deletion still requires exact
confirmation and assigned Attempts cannot delete knowledge. A ContextManifest is prepared from current Core
rights, Work/Method/plan and scoped evidence for each request; the actual provider
body is observed separately and must contain its marker. Free conversation has
separate durable usage accounting. Spending/context caps are optional and must
be explicitly configured; absence means no local spending stop. Ordinary Work
delivers complete results through `zara_result` and Core's atomic Attempt
publication. Routine conversation never replaces a linked output. The local synthetic multi-process trace is
`tools.probe_knowledge_pi --pi-runtime <path>`.
Native split compaction can send history and turn-prefix summaries separately.
Keep its purpose through the whole lifecycle, prepare the current manifest for
each HTTP, and finish each provider stream's own usage before closing its Attempt.
The aggregate compaction entry is not per-request usage. The focused synthetic
trace is `tools.probe_knowledge_pi --split-compaction-only --pi-runtime <path>`;
`--fail-prefix` preserves an unknown second send without erasing the first usage.
Compact must also work immediately after reopening a saved Pi session, before any
new prompt or Work selection. Restore only the last original user message on the
actual branch, label it as saved history, and use native session/entry identity
for idempotent capture. Do not capture a generated summary as user input or infer
Work selection/authority from history. `--resume-compaction-only` checks native
startup and switch_session with fresh Bridge processes and no intervening prompt.
Routine `zara_development` preparation and evidence writes do not ask per-operation
owner confirmation: new Work/Artifact/resource, Method registration already admitted
by Core, composite preparation/child issue, output linking, Sleep/Candidate revisions
and change outcome observations. All other development mutations stay confirmed,
including acceptance, Decisions, deletion, obligations and application/stop/restore.
This UI policy grants no Core rights and does not admit a reusable Method or Candidate.
Keep assigned RPC's narrower operation allowlist. The ordinary localhost trace is
`tools.probe_development_autonomy_pi`; it fails on any routine confirmation, then checks
reopening, cancelled owner actions and explicit acceptance/deletion.
