"""Durable, bounded setup of one new Activity; no model or executor in Core."""

from __future__ import annotations

import hashlib
import json
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast
from uuid import UUID, uuid4, uuid5

from pydantic import ValidationError

from .capabilities import procedure_operation_catalog
from .models import (
    ActivityActivationManifest,
    ActivitySetupDraft,
    ActivitySetupDraftV2,
    ActivitySetupRequest,
    ActivitySetupReview,
    ActivitySetupReviewV2,
    ActivitySetupRevision,
    ActivitySetupState,
    ActivityState,
    ApplyCandidateRequest,
    ArtifactRef,
    ChangeCandidateState,
    ChangeDecisionState,
    ClaimState,
    CompositeChange,
    CreateActivityRequest,
    CreateArtifactRequest,
    CreateCompositeWorkRequest,
    CreateDecisionRequest,
    CreateDevelopmentRequest,
    CreateKnowledgeRequest,
    CreateWorkRequest,
    DomainRequest,
    KnowledgeRef,
    MemoryMetadata,
    MemoryRequirement,
    MethodChange,
    MethodRef,
    OutputContract,
    PlanChild,
    RequestAttemptStopRequest,
    ReviseActivityRequest,
    SetupInteraction,
    SetupResultRejection,
    SetupStage,
    SetupValidationIssue,
    SourceState,
    SpaceInfo,
    ValidationCriterion,
    ValidationPlanState,
    ValidationResultState,
    WorkflowChange,
    WorkState,
)
from .operations import LocalAuthority, _authorize, _local_space
from .setup_validation import SetupResultError, validation_issues
from .storage import (
    SETUP_SCHEMA_NAME,
    SETUP_SCHEMA_SHA256,
    SETUP_SCHEMA_STATEMENTS,
    FoundationError,
    canonical_json,
    read_space,
    space_connection,
    utc_now,
)
from .structure_setup import (
    compile_structure,
    draft_from_bytes,
    review_component_catalog,
    review_from_bytes,
    review_result_schema,
    validate_review_components,
)

AREAS = ("goal", "workflow", "history", "continuation", "extension", "capabilities", "consistency")


@dataclass(frozen=True)
class _StageExecution:
    pending_outcome: bool
    stopped: bool


def _stage_execution(connection: sqlite3.Connection, stage: SetupStage) -> _StageExecution:
    """Read execution evidence; a saved pause is not an observed process stop."""
    work = str(stage.work_id)
    assignments = tuple(
        row[0]
        for row in connection.execute(
            "SELECT status FROM execution_assignments WHERE work_id=?", (work,)
        )
    )
    active = (
        connection.execute(
            "SELECT 1 FROM execution_attempts WHERE work_id=? AND status='active' LIMIT 1",
            (work,),
        ).fetchone()
        is not None
    )
    invocation_states = tuple(
        row[0]
        for row in connection.execute(
            "SELECT status FROM execution_invocations WHERE work_id=?", (work,)
        )
    )
    in_flight = any(status in ("admitted", "sent") for status in invocation_states)
    return _StageExecution(
        pending_outcome=in_flight or "unknown" in invocation_states or "unknown" in assignments,
        stopped=not active and not in_flight and all(status == "stopped" for status in assignments),
    )


def _unfinished_stages(state: ActivitySetupState) -> tuple[SetupStage, ...]:
    return tuple(stage for stage in state.stages if stage.output is None and not stage.retired)


def _require_known_stage_outcomes(
    connection: sqlite3.Connection, state: ActivitySetupState
) -> None:
    if any(
        _stage_execution(connection, stage).pending_outcome for stage in _unfinished_stages(state)
    ):
        raise FoundationError(
            "unknown_effect",
            "An earlier setup request has a pending or unknown outcome. Inputs may be saved "
            "while paused; a fresh stage requires explicit retry after observed local stop "
            "and changed inputs. The earlier request will not be replayed.",
        )


def read_setup_stage(path: Path, work_id: UUID, authority: LocalAuthority) -> SetupStage | None:
    """Resolve a trusted protocol from the saved setup, never from model flags."""
    with space_connection(path) as (connection, info):
        _local_space(authority, info)
        stage, state = _stage_for_work(connection, work_id)
        if state is not None:
            _readable(connection, state, authority.actor, info.execution_epoch)
        return stage


def _stage_for_work(
    connection: sqlite3.Connection, work_id: UUID
) -> tuple[SetupStage | None, ActivitySetupState | None]:
    if int(connection.execute("PRAGMA user_version").fetchone()[0]) < 14:
        return None, None
    row = connection.execute(
        "SELECT e.setup_id FROM activity_setup_edges e JOIN activity_setups s "
        "ON s.setup_id=e.setup_id AND s.current_revision=e.revision "
        "WHERE e.target_id=? AND e.role='work' AND s.status='active' LIMIT 1",
        (str(work_id),),
    ).fetchone()
    if row is None:
        return None, None
    state = _current(connection, UUID(row[0])).state
    return next((stage for stage in state.stages if stage.work_id == work_id), None), state


def _rejected_result(
    state: ActivitySetupState,
    stage: SetupStage,
    output: ArtifactRef,
    issues: tuple[SetupValidationIssue, ...],
) -> dict[str, Any]:
    identity = sorted((item.code, canonical_json(item.path)) for item in issues)
    fingerprint = hashlib.sha256(canonical_json(identity).encode("utf-8")).hexdigest()
    series = stage.repair_series or stage.work_id
    previous = next((item for item in state.stages if item.work_id == stage.repair_of), None)
    repeated = bool(
        previous
        and previous.rejection
        and previous.rejection.series_id == series
        and previous.rejection.fingerprint == fingerprint
    )
    stopped = (
        repeated
        or stage.repair_number >= 2
        or (stage.kind == "review" and state.reviews_started - state.pass_boundary >= 5)
    )
    rejected = stage.model_copy(
        update={
            "retired": True,
            "rejection": SetupResultRejection(
                artifact=output, issues=issues, fingerprint=fingerprint, series_id=series
            ),
        }
    )
    reason = (
        "Повторилась та же ошибка результата"
        if repeated
        else "Исчерпаны исправления результата"
        if stopped
        else "Исправляется результат этапа"
    )
    details = "; ".join(
        f"{item.code} ({'.'.join(map(str, item.path)) or '$'}): {item.message}" for item in issues
    )
    return {
        "stages": state.stages[:-1] + (rejected,),
        "phase": "needs_attention"
        if stopped
        else {"draft": "drafting", "correction": "correcting", "review": "reviewing"}[stage.kind],
        "result": (reason + ". Ответы сохранены. " + details)[:4096],
        "auto_resume": False,
    }


def upgrade_activity_setup_space(path: Path, authority: LocalAuthority) -> SpaceInfo:
    """Explicit additive 13 to 14 upgrade; no reinterpretation of old records."""
    with space_connection(path, writable=True) as (connection, info):
        _local_space(authority, info)
        if info.recovery_state != "active" or info.schema_version < 13:
            raise FoundationError("unsupported_schema", "Activity setup needs active schema 13")
        _authorize(
            connection,
            actor=authority.actor,
            action="maintenance.backup",
            epoch=info.execution_epoch,
        )
        if info.schema_version == 13:
            for statement in SETUP_SCHEMA_STATEMENTS:
                connection.execute(statement)
            now = utc_now().isoformat()
            connection.execute(
                "INSERT INTO schema_migrations VALUES (14,?,?,?)",
                (SETUP_SCHEMA_NAME, SETUP_SCHEMA_SHA256, now),
            )
            connection.execute("PRAGMA user_version=14")
            connection.execute(
                "UPDATE spaces SET state_revision=state_revision+1 WHERE singleton=1"
            )
            connection.execute(
                "INSERT INTO maintenance_events VALUES (?,'schema_upgrade',?,?)",
                (str(uuid4()), now, canonical_json({"from": 13, "to": 14})),
            )
    return read_space(path)


def _current(
    connection: sqlite3.Connection, setup_id: UUID, revision: int | None = None
) -> ActivitySetupRevision:
    row = connection.execute(
        "SELECT s.current_revision,s.status,r.payload,r.sha256 FROM activity_setups s JOIN "
        "activity_setup_revisions r ON r.setup_id=s.setup_id "
        "AND r.revision=COALESCE(?,s.current_revision) WHERE s.setup_id=?",
        (revision, str(setup_id)),
    ).fetchone()
    if row is None:
        raise FoundationError("setup_unavailable", f"Activity setup {setup_id} is absent")
    if row[1] != "active" or row[2] is None:
        raise FoundationError("content_unavailable", f"Activity setup {setup_id} lost its basis")
    if hashlib.sha256(bytes(row[2])).hexdigest().upper() != row[3]:
        raise FoundationError("corrupt_content", "Activity setup revision checksum differs")
    state = ActivitySetupState.model_validate_json(row[2])
    if revision is None and state.root_work_id:
        # Historical setup JSON stays exact. Current coordination is read from its one
        # workflow event/control stream; revisions retain snapshots for audit only.
        event = connection.execute(
            "SELECT detail FROM workflow_events WHERE root_work_id=? AND kind LIKE 'setup:%' "
            "ORDER BY revision DESC LIMIT 1",
            (str(state.root_work_id),),
        ).fetchone()
        if event and event[0]:
            status = json.loads(event[0])
            state = state.model_copy(
                update={"phase": status["phase"], "question": status.get("question")}
            )
        control = connection.execute(
            "SELECT control FROM workflow_runs WHERE root_work_id=?", (str(state.root_work_id),)
        ).fetchone()
        if control and control[0] in ("paused", "cancelled"):
            state = state.model_copy(
                update={"phase": "paused" if control[0] == "paused" else "cancelled"}
            )
    return ActivitySetupRevision(
        setup_id=setup_id,
        revision=revision or row[0],
        state=state,
    )


def _basis(
    connection: sqlite3.Connection,
    ref: KnowledgeRef,
    actor: str,
    epoch: int,
    *,
    current: bool = True,
) -> dict[str, Any]:
    from .knowledge import _require_ref

    _require_ref(connection, ref, actor, epoch)
    row = connection.execute(
        "SELECT r.current_revision,v.payload,r.received_at FROM knowledge_records r "
        "JOIN knowledge_revisions v "
        "ON v.record_id=r.record_id AND v.revision=? WHERE r.record_id=?",
        (ref.revision, str(ref.record_id)),
    ).fetchone()
    if row is None or (current and row[0] != ref.revision):
        raise FoundationError("stale_basis", f"Setup basis {ref.record_id} changed")
    state = json.loads(row[1])
    if state.get("kind") == "source":
        source = SourceState.model_validate_json(row[1])
        state = source.model_dump(mode="json", exclude={"content"})
        state["received_at"] = row[2]
        content = source.content
    elif ref.start is not None:
        from .knowledge import BODY_ADAPTER
        from .models import HandoffState, MemoryViewState

        body = BODY_ADAPTER.validate_json(row[1])
        content = (
            body.document
            if isinstance(body, HandoffState)
            else body.text.encode("utf-8")
            if isinstance(body, MemoryViewState)
            else None
        )
        state = {"kind": state["kind"]}
    else:
        content = None
    if content is not None:
        selected = content[ref.start : ref.end] if ref.start is not None else content
        try:
            state["text"] = selected.decode("utf-8")
        except UnicodeDecodeError as error:
            raise FoundationError(
                "invalid_fragment", "Selected bytes split UTF-8 characters"
            ) from error
    elif state.get("kind") == "source":
        state["text"] = None
    return {"ref": ref.model_dump(mode="json"), "state": state}


def _artifact(
    connection: sqlite3.Connection,
    ref: ArtifactRef,
    actor: str,
    epoch: int,
    *,
    current: bool = True,
) -> bytes:
    from .operations import _authorize_artifact_ref

    _authorize_artifact_ref(connection, ref, actor=actor, epoch=epoch, grants=[], decisions=[])
    row = connection.execute(
        "SELECT r.current_revision,c.payload,c.sha256 FROM records r JOIN managed_content c "
        "ON c.record_id=r.record_id AND c.revision=? WHERE r.record_id=?",
        (ref.revision, str(ref.artifact_id)),
    ).fetchone()
    if row is None or (current and row[0] != ref.revision) or row[1] is None:
        raise FoundationError("stale_basis", f"Setup Artifact {ref.artifact_id} changed")
    content = bytes(row[1])
    if hashlib.sha256(content).hexdigest().upper() != row[2]:
        raise FoundationError("corrupt_content", "Setup Artifact checksum differs")
    return content


def _readable(
    connection: sqlite3.Connection, state: ActivitySetupState, actor: str, epoch: int
) -> None:
    _authorize(
        connection,
        actor=actor,
        action="record.read",
        epoch=epoch,
        resource_type="activity",
        resource_id=state.activity_id,
    )
    for ref in state.sources:
        _basis(connection, ref, actor, epoch, current=False)


def read_activity_setup(
    path: Path, setup_id: UUID, authority: LocalAuthority, *, revision: int | None = None
) -> ActivitySetupRevision:
    with space_connection(path) as (connection, info):
        _local_space(authority, info)
        if info.schema_version < 14:
            raise FoundationError("upgrade_required", "Activity setup needs schema 14")
        item = _current(connection, setup_id, revision)
        _readable(connection, item.state, authority.actor, info.execution_epoch)
        return item


def list_activity_setups(
    path: Path,
    authority: LocalAuthority,
    *,
    activity_id: UUID | None = None,
    limit: int = 50,
    pending_only: bool = False,
) -> tuple[ActivitySetupRevision, ...]:
    if not 1 <= limit <= 100:
        raise FoundationError("invalid_request", "Setup page must contain 1 to 100 records")
    with space_connection(path) as (connection, info):
        _local_space(authority, info)
        if info.schema_version < 14:
            return ()
        result = []
        for (identifier,) in connection.execute(
            (
                "SELECT a.setup_id FROM activity_setups a JOIN activity_setup_revisions r "
                "ON r.setup_id=a.setup_id AND r.revision=a.current_revision "
                "WHERE a.status='active' AND (? IS NULL OR a.activity_id=?) "
                "AND (?=0 OR json_extract(CAST(r.payload AS TEXT),'$.phase') "
                "NOT IN ('ready','cancelled')) ORDER BY a.setup_id"
            ),
            (str(activity_id) if activity_id else None,) * 2 + (int(pending_only),),
        ):
            item = _current(connection, UUID(identifier))
            try:
                _readable(connection, item.state, authority.actor, info.execution_epoch)
            except FoundationError as error:
                if error.code in (
                    "permission_denied",
                    "decision_denied",
                    "content_unavailable",
                    "stale_basis",
                ):
                    continue
                raise
            result.append(item)
            if len(result) == limit:
                break
        return tuple(result)


def check_setup_execution(
    connection: sqlite3.Connection, work_id: UUID, actor: str, epoch: int
) -> None:
    """Old Activities are untouched; unfinished new setups admit only their stages."""
    if int(connection.execute("PRAGMA user_version").fetchone()[0]) < 14:
        return
    row = connection.execute(
        (
            "SELECT a.setup_id FROM activity_setups a JOIN subject_records w ON "
            "w.parent_id=a.activity_id WHERE w.record_id=?"
            + (
                " AND a.mode='create'"
                if int(connection.execute("PRAGMA user_version").fetchone()[0]) >= 15
                else ""
            )
        ),
        (str(work_id),),
    ).fetchone()
    if row is None:
        return
    state = _current(connection, UUID(row[0])).state
    if state.phase == "ready":
        return
    for ref in state.sources:
        _basis(connection, ref, actor, epoch)
    stage = next((item for item in state.stages if item.work_id == work_id), None)
    if stage is not None and (stage.retired or stage.input_version != state.input_version):
        raise FoundationError("setup_pending", "The setup stage was retired or its inputs changed")
    if state.root_work_id and state.phase not in ("paused", "cancelled", "needs_attention"):
        from .workflows import _run

        if _run(connection, state.root_work_id)[2] == "running" and (
            work_id == state.root_work_id
            or connection.execute(
                "SELECT 1 FROM workflow_nodes WHERE root_work_id=? AND work_id=?",
                (str(state.root_work_id), str(work_id)),
            ).fetchone()
        ):
            return
    if state.phase not in ("paused", "cancelled", "needs_attention") and any(
        stage.work_id == work_id
        and stage.output is None
        and not stage.retired
        and stage.input_version == state.input_version
        for stage in state.stages
    ):
        return
    raise FoundationError("setup_pending", f"Activity setup {row[0]} is {state.phase}")


def check_setup_record_access(
    connection: sqlite3.Connection, record_id: UUID, actor: str, epoch: int
) -> None:
    if int(connection.execute("PRAGMA user_version").fetchone()[0]) < 14:
        return
    for (identifier,) in connection.execute(
        "SELECT DISTINCT setup_id FROM activity_setup_edges WHERE target_id=? "
        "AND role IN ('derived_artifact','derived_knowledge','method','work','activity')",
        (str(record_id),),
    ):
        row = connection.execute(
            "SELECT status FROM activity_setups WHERE setup_id=?", (identifier,)
        ).fetchone()
        if row[0] != "active":
            continue
        state = _current(connection, UUID(identifier)).state
        for ref in state.sources:
            _basis(connection, ref, actor, epoch, current=False)


def activity_setup_memory(
    path: Path, activity_id: UUID, authority: LocalAuthority, *, work_id: UUID | None = None
) -> tuple[MemoryRequirement, ...]:
    """Exact ready setup requirements, also for subsequent plain Work."""
    from .data import describe_structure

    with space_connection(path) as (_, info):
        schema = info.schema_version
    if schema >= 15:
        structure = describe_structure(path, activity_id, authority, work_id=work_id)
        if not structure["legacy"]:
            return tuple(
                MemoryRequirement.model_validate(item)
                for item in structure["state"]["memory_requirements"]
            )
        if work_id is not None:
            # A pre-structure Work keeps its previous context contract.
            pass
    entries = list_activity_setups(path, authority, activity_id=activity_id, limit=100)
    entries = tuple(
        item for item in entries if item.state.mode == "create" and item.state.contract_version == 1
    )
    if not entries or entries[0].state.phase != "ready" or not entries[0].state.draft:
        return ()
    with space_connection(path) as (connection, info):
        draft = draft_from_bytes(
            _artifact(
                connection,
                entries[0].state.draft,
                authority.actor,
                info.execution_epoch,
                current=False,
            ),
            entries[0].state.contract_version,
        )
        return draft.memory


def _save(
    connection: sqlite3.Connection,
    request: ActivitySetupRequest,
    state: ActivitySetupState,
    revision: int,
    now: str,
) -> None:
    if state.root_work_id:
        run_revision = (
            connection.execute(
                "SELECT revision FROM workflow_runs WHERE root_work_id=?",
                (str(state.root_work_id),),
            ).fetchone()[0]
            + 1
        )
        connection.execute(
            "UPDATE workflow_runs SET revision=? WHERE root_work_id=?",
            (run_revision, str(state.root_work_id)),
        )
        connection.execute(
            "INSERT INTO workflow_events VALUES (?,?,?,?,?,?)",
            (
                str(state.root_work_id),
                run_revision,
                str(request.operation_id),
                "setup:" + request.action,
                canonical_json(
                    {"phase": state.phase, "question": state.question, "setup_revision": revision}
                ),
                now,
            ),
        )
    if revision == 1:
        if int(connection.execute("PRAGMA user_version").fetchone()[0]) >= 15:
            connection.execute(
                "INSERT INTO activity_setups (setup_id,activity_id,current_revision,status,mode) "
                "VALUES (?,?,1,'active',?)",
                (str(request.setup_id), str(state.activity_id), state.mode),
            )
        else:
            connection.execute(
                "INSERT INTO activity_setups VALUES (?,?,1,'active')",
                (str(request.setup_id), str(state.activity_id)),
            )
    else:
        connection.execute(
            "UPDATE activity_setups SET current_revision=? WHERE setup_id=?",
            (revision, str(request.setup_id)),
        )
    data = state.model_dump_json().encode("utf-8")
    connection.execute(
        "INSERT INTO activity_setup_revisions VALUES (?,?,?,?,?)",
        (
            str(request.setup_id),
            revision,
            str(request.operation_id),
            data,
            hashlib.sha256(data).hexdigest().upper(),
        ),
    )
    refs: list[tuple[str, UUID, int]] = [
        ("basis", ref.record_id, ref.revision) for ref in state.sources
    ]
    for ref in state.sources:
        row = connection.execute(
            "SELECT payload FROM knowledge_revisions WHERE record_id=? AND revision=?",
            (str(ref.record_id), ref.revision),
        ).fetchone()
        if row and row[0]:
            original = json.loads(row[0])
            if original.get("connection") == "activity-setup" and original.get(
                "scope_activity_id"
            ) == str(state.activity_id):
                refs.append(("owned_source", ref.record_id, ref.revision))
    refs.append(
        ("activity" if state.mode == "create" else "referenced_activity", state.activity_id, 1)
    )
    if state.root_work_id:
        refs.append(("work", state.root_work_id, 1))
        refs.extend(
            ("work", UUID(row[0]), 1)
            for row in connection.execute(
                "SELECT work_id FROM workflow_nodes WHERE root_work_id=?",
                (str(state.root_work_id),),
            )
        )
    if state.manifest:
        refs.append(("derived_artifact", state.manifest.artifact_id, state.manifest.revision))
    for stage in state.stages:
        refs.extend(
            (
                ("work", stage.work_id, 1),
                ("derived_artifact", stage.packet.artifact_id, stage.packet.revision),
            )
        )
        if stage.output:
            refs.append(("derived_artifact", stage.output.artifact_id, stage.output.revision))
        if stage.rejection:
            refs.append(
                (
                    "derived_artifact",
                    stage.rejection.artifact.artifact_id,
                    stage.rejection.artifact.revision,
                )
            )
    refs.extend(("work", ref, 1) for ref in state.activated_works)
    refs.extend(("method", ref.method_id, ref.version) for ref in state.activated_methods)
    if state.repair_work:
        refs.append(("work", state.repair_work, 1))
    if state.phase == "ready" and state.contract_version == 1:
        refs.append(("derived_knowledge", uuid5(request.setup_id, "instructions"), 1))
    if state.phase == "ready" and state.contract_version == 2 and state.manifest:
        manifest = ActivityActivationManifest.model_validate_json(
            _artifact(
                connection,
                state.manifest,
                request.actor,
                connection.execute("SELECT execution_epoch FROM spaces").fetchone()[0],
                current=False,
            )
        )
        refs.append(
            ("derived_knowledge", manifest.structure_ref.record_id, manifest.structure_ref.revision)
        )
        refs.extend(
            ("derived_format", item.ref.record_id, item.ref.revision)
            for item in manifest.formats
            if item.create
        )
    for ordinal, (role, identifier, version) in enumerate(refs):
        connection.execute(
            "INSERT INTO activity_setup_edges VALUES (?,?,?,?,?,?)",
            (str(request.setup_id), revision, ordinal, str(identifier), version, role),
        )


def apply_setup_change(
    connection: sqlite3.Connection,
    request: ActivitySetupRequest,
    *,
    now: str,
    epoch: int,
    authority: LocalAuthority,
    grants: list[dict[str, object]],
    decisions: list[dict[str, object]],
) -> tuple[dict[str, Any], list[dict[str, object]]]:
    from .operations import _apply_change, _operation_action

    if int(connection.execute("PRAGMA user_version").fetchone()[0]) < 14:
        raise FoundationError("upgrade_required", "Activity setup needs explicit schema 14")
    targets: list[dict[str, object]] = []

    def effect(kind: type[Any], **fields: Any) -> dict[str, Any]:
        nested = kind(
            operation_id=request.operation_id,
            space_id=request.space_id,
            actor=request.actor,
            **fields,
        )
        action, resource_type, resource_id = _operation_action(nested)
        added_grants, added_decisions = _authorize(
            connection,
            actor=request.actor,
            action=action,
            epoch=epoch,
            resource_type=resource_type,
            resource_id=resource_id,
        )
        grants.extend(added_grants)
        decisions.extend(added_decisions)
        answer, refs = _apply_change(
            connection,
            cast(DomainRequest, nested),
            now=now,
            epoch=epoch,
            authority=authority,
            grants=grants,
            decisions=decisions,
        )
        targets.extend(refs)
        return answer

    def source(text: str) -> KnowledgeRef:
        settings = (
            _current(connection, request.setup_id).state if request.action != "begin" else request
        )
        identifier = uuid5(request.operation_id, "user-source")
        effect(
            CreateKnowledgeRequest,
            record_id=identifier,
            state=SourceState(
                channel="conversation_user",
                connection="activity-setup",
                profile_revision=1,
                source_event_id=str(request.operation_id),
                scope_activity_id=settings.activity_id,
                sender=request.actor,
                media_type="text/plain",
                capture="full",
                content=text.encode("utf-8"),
                memory=MemoryMetadata(
                    title="Activity setup request or answer",
                    activity_id=settings.activity_id,
                    material_role="basis",
                )
                if settings.contract_version == 2 or settings.mode == "change_structure"
                else None,
            ),
        )
        return KnowledgeRef(record_id=identifier, revision=1)

    def retire_stage_nodes(state: ActivitySetupState, stages: tuple[SetupStage, ...]) -> None:
        """Retire unfinished host stages in the actual native plan, retaining its history."""
        if state.root_work_id is None or not stages:
            return
        from .composition import _plan
        from .models import NodeClosure, PlanNodeDecision, ReviseActivePlanRequest
        from .operations import _subject_current

        parent = state.root_work_id
        current = _plan(connection, parent)
        departing = {stage.work_id for stage in stages}
        nodes = tuple(
            PlanNodeDecision(
                role=child.role,
                work_id=child.work_id,
                decision="cancel" if child.work_id in departing else "keep",
                closure=NodeClosure(
                    expected_revision=_subject_current(connection, child.work_id, "work")[0],
                    outcome="cancelled",
                    basis="Unfinished setup preparation superseded by new owner inputs",
                )
                if child.work_id in departing
                else None,
            )
            for child in current.plan.children
        )
        if not any(child.work_id in departing for child in current.plan.children):
            return
        effect(
            ReviseActivePlanRequest,
            work_id=parent,
            expected_work_revision=_subject_current(connection, parent, "work")[0],
            expected_plan_revision=current.revision,
            plan=current.plan.model_copy(
                update={
                    "children": tuple(
                        child for child in current.plan.children if child.work_id not in departing
                    )
                }
            ),
            nodes=nodes,
        )

    if request.action == "begin":
        if not request.title or not request.text or request.expected_revision is not None:
            raise FoundationError("invalid_request", "Begin needs a title and original request")
        schema = int(connection.execute("PRAGMA user_version").fetchone()[0])
        if (request.contract_version == 2 or request.mode == "change_structure") and schema < 15:
            raise FoundationError("upgrade_required", "Structure setup needs explicit schema 15")
        previous_structure = None
        if request.mode == "create":
            effect(
                CreateActivityRequest,
                activity_id=request.activity_id,
                state=ActivityState(title=request.title, goal=request.text[:4096]),
            )
        else:
            from .data_store import head_ref
            from .operations import _subject_state

            row = connection.execute(
                "SELECT current_revision FROM subject_records WHERE record_id=? "
                "AND kind='activity'",
                (str(request.activity_id),),
            ).fetchone()
            if row is None:
                raise FoundationError("not_found", "Activity to change does not exist")
            _subject_state(connection, request.activity_id, row[0])
            previous_structure = head_ref(connection, request.activity_id)
            for (identifier,) in connection.execute(
                "SELECT setup_id FROM activity_setups WHERE activity_id=? "
                "AND mode='change_structure' AND status='active'",
                (str(request.activity_id),),
            ):
                if _current(connection, UUID(identifier)).state.phase not in ("ready", "cancelled"):
                    raise FoundationError("setup_running", "Continue the existing structure change")
        refs = (source(request.text),) + request.source_refs
        for ref in refs:
            _basis(connection, ref, request.actor, epoch)
        state = ActivitySetupState(
            activity_id=request.activity_id,
            owner=request.actor,
            phase="collecting",
            sources=refs,
            mode=request.mode,
            contract_version=request.contract_version,
            previous_structure=previous_structure,
            authorization_scope="activity_structure_change"
            if request.mode == "change_structure"
            else "new_activity_setup",
        )
        if schema >= 16:
            from .workflows import setup_workflow_begin

            workflow, root_work_id = setup_workflow_begin(
                connection,
                request,
                refs,
                now=now,
                epoch=epoch,
                authority=authority,
                grants=grants,
                decisions=decisions,
            )
            state = state.model_copy(update={"workflow": workflow, "root_work_id": root_work_id})
        revision = 1
    else:
        current = _current(connection, request.setup_id)
        if (
            current.revision != request.expected_revision
            or current.state.activity_id != request.activity_id
        ):
            raise FoundationError("stale_setup", "Setup revision or Activity differs")
        state, revision = current.state, current.revision + 1
        if state.owner != request.actor:
            raise FoundationError(
                "permission_denied", "Only the initiating local owner controls setup"
            )
        _readable(connection, state, request.actor, epoch)
        if state.phase in ("ready", "cancelled"):
            raise FoundationError("setup_closed", "Setup is already ready or cancelled")
        updates: dict[str, Any] = {}
        if request.action == "bind_model":
            if not request.stage_model or not state.stages:
                raise FoundationError("invalid_request", "Model pin needs the current stage")
            stage = state.stages[-1]
            if stage.model is not None and stage.model != request.stage_model:
                raise FoundationError("stale_node_model", "Started stage keeps its selected model")
            updates["stages"] = state.stages[:-1] + (
                stage.model_copy(update={"model": request.stage_model}),
            )
            if state.root_work_id:
                connection.execute(
                    "UPDATE workflow_nodes SET model=? WHERE work_id=?",
                    (request.stage_model.model_dump_json(), str(stage.work_id)),
                )
        elif request.action == "attach_sources":
            refs = tuple(dict.fromkeys(state.sources + request.source_refs))
            for ref in refs:
                _basis(connection, ref, request.actor, epoch)
            if refs != state.sources:
                unfinished = _unfinished_stages(state)
                pending = any(
                    _stage_execution(connection, stage).pending_outcome for stage in unfinished
                )
                if unfinished and state.phase != "paused":
                    raise FoundationError(
                        "setup_running", "Pause the active stage before adding inputs"
                    )
                if not pending and any(
                    not _stage_execution(connection, stage).stopped for stage in unfinished
                ):
                    raise FoundationError(
                        "setup_stopping", "The setup executor has not yet confirmed its local stop"
                    )
                if not pending:
                    retire_stage_nodes(state, unfinished)
                updates = dict(
                    sources=refs,
                    input_version=state.input_version + 1,
                    draft=None,
                    review=None,
                    manifest=None,
                    phase="paused"
                    if state.phase == "paused"
                    else "needs_input"
                    if state.question
                    else "collecting",
                    stages=state.stages
                    if pending
                    else tuple(
                        stage.model_copy(update={"retired": True}) if stage in unfinished else stage
                        for stage in state.stages
                    ),
                    result=(
                        "New inputs are saved. An earlier setup request has a pending or unknown "
                        "outcome; execution remains paused. After observed local stop, explicit "
                        "retry can prepare a fresh stage from these inputs without replaying "
                        "the earlier request."
                    )
                    if pending
                    else None,
                    auto_resume=False,
                )
        elif request.action == "answer":
            if not request.text:
                raise FoundationError("invalid_request", "Answer must retain original text")
            saving_pending_answer = bool(
                state.phase == "paused"
                and state.question
                and any(
                    _stage_execution(connection, stage).pending_outcome
                    for stage in _unfinished_stages(state)
                )
            )
            if not saving_pending_answer:
                _require_known_stage_outcomes(connection, state)
            answering_wait = False
            restart_wait = False
            retired = state.stages
            if (
                not saving_pending_answer
                and state.stages
                and state.stages[-1].output is None
                and not state.stages[-1].retired
            ):
                waiting_work_id = str(state.stages[-1].work_id)
                answering_wait = (
                    state.phase == "needs_input"
                    and connection.execute(
                        "SELECT 1 FROM execution_waits "
                        "WHERE work_id=? AND status='answered' LIMIT 1",
                        (waiting_work_id,),
                    ).fetchone()
                    is not None
                )
                live = connection.execute(
                    (
                        "SELECT 1 FROM execution_assignments WHERE work_id=? AND status IN "
                        "('assigned','waiting','ready','stop_requested','unknown') LIMIT 1"
                    ),
                    (waiting_work_id,),
                ).fetchone()
                if not answering_wait and live:
                    raise FoundationError(
                        "setup_running", "Pause the active stage before changing its inputs"
                    )
                if not live and state.phase in ("needs_input", "paused") and state.question:
                    restart_wait = (
                        connection.execute(
                            "SELECT 1 FROM execution_waits WHERE work_id=? AND status='closed' "
                            "AND question=? LIMIT 1",
                            (waiting_work_id, state.question.encode("utf-8")),
                        ).fetchone()
                        is not None
                    )
                    answering_wait = restart_wait
                if not answering_wait:
                    retire_stage_nodes(state, (state.stages[-1],))
                    retired = state.stages[:-1] + (
                        state.stages[-1].model_copy(update={"retired": True}),
                    )
            answer_ref = source(request.text)
            answered_interactions = tuple(
                interaction.model_copy(update={"answer": answer_ref})
                if interaction.answer is None and interaction.question == state.question
                else interaction
                for interaction in state.interactions
            )
            refs = tuple(dict.fromkeys(state.sources + (answer_ref,) + request.source_refs))
            for ref in refs:
                _basis(connection, ref, request.actor, epoch)
            if state.root_work_id and state.question:
                from .models import WorkflowRequest
                from .workflows import _run, _waits, apply_workflow_change

                wait = next(
                    (
                        item
                        for item in _waits(connection, state.root_work_id)
                        if item.question == state.question
                    ),
                    None,
                )
                if wait:
                    apply_workflow_change(
                        connection,
                        WorkflowRequest(
                            operation_id=request.operation_id,
                            space_id=request.space_id,
                            actor=request.actor,
                            action="answer",
                            root_work_id=state.root_work_id,
                            expected_revision=_run(connection, state.root_work_id)[1],
                            wait_id=wait.wait_id,
                            expected_wait_revision=wait.revision,
                            answer=answer_ref,
                            source_refs=request.source_refs,
                        ),
                        now=now,
                        epoch=epoch,
                        authority=authority,
                        grants=grants,
                        decisions=decisions,
                    )
            if restart_wait:
                stage = state.stages[-1]
                continuation_packet = json.loads(
                    _artifact(connection, stage.packet, request.actor, epoch)
                )
                continuation_packet["sources"] = [
                    _basis(connection, ref, request.actor, epoch) for ref in refs
                ]
                continuation_packet["interactions"] = [
                    {
                        "question": item.question,
                        "input_version": item.input_version,
                        "answer": _basis(connection, item.answer, request.actor, epoch)
                        if item.answer
                        else None,
                    }
                    for item in answered_interactions
                ]
                packet_id = uuid5(request.operation_id, "continuation-packet")
                effect(
                    CreateArtifactRequest,
                    artifact_id=packet_id,
                    media_type="application/json",
                    content=canonical_json(continuation_packet).encode("utf-8"),
                )
                from .operations import _subject_state, _write_subject

                work_revision = connection.execute(
                    "SELECT current_revision FROM subject_records WHERE record_id=?",
                    (str(stage.work_id),),
                ).fetchone()[0]
                current_work = WorkState.model_validate(
                    _subject_state(connection, stage.work_id, work_revision)
                )
                new_packet = ArtifactRef(artifact_id=packet_id, revision=1)
                added_grants, added_decisions = _authorize(
                    connection,
                    actor=request.actor,
                    action="work.write",
                    epoch=epoch,
                    resource_type="work",
                    resource_id=stage.work_id,
                )
                grants.extend(added_grants)
                decisions.extend(added_decisions)
                _write_subject(
                    connection,
                    record_id=stage.work_id,
                    kind="work",
                    parent_id=state.activity_id,
                    operation_id=request.operation_id,
                    actor=request.actor,
                    now=now,
                    status=current_work.status,
                    state=current_work.model_copy(
                        update={
                            "inputs": tuple(
                                new_packet if ref == stage.packet else ref
                                for ref in current_work.inputs
                            )
                        }
                    ),
                    revision=work_revision + 1,
                )
                targets.append({"record_id": str(stage.work_id), "revision": work_revision + 1})
                retired = state.stages[:-1] + (stage.model_copy(update={"packet": new_packet}),)
            updates = dict(
                sources=refs,
                input_version=state.input_version + int(not answering_wait),
                phase="paused"
                if saving_pending_answer
                else {"draft": "drafting", "correction": "correcting", "review": "reviewing"}[
                    state.stages[-1].kind
                ]
                if answering_wait
                else "collecting",
                question=None,
                draft=state.draft if answering_wait else None,
                review=state.review if answering_wait else None,
                manifest=state.manifest if answering_wait else None,
                stages=retired,
                recovery_boundary=state.recovery_boundary
                if saving_pending_answer or answering_wait
                else len(retired),
                interactions=answered_interactions,
            )
            if saving_pending_answer:
                updates.update(
                    result="The original answer is saved. Execution remains paused because an "
                    "earlier setup request has a pending or unknown outcome. After observed "
                    "local stop, explicit retry can use the new inputs without replaying it.",
                    auto_resume=False,
                )
        elif request.action == "question":
            if not request.text:
                raise FoundationError("invalid_request", "Question text is required")
            updates = dict(
                question=request.text,
                phase="needs_input",
                interactions=state.interactions
                + (
                    SetupInteraction(
                        interaction_id=uuid5(request.operation_id, "question"),
                        question=request.text,
                        input_version=state.input_version,
                        sources=state.sources,
                    ),
                ),
            )
            if state.root_work_id:
                from .models import WorkflowRequest
                from .workflows import _run, apply_workflow_change

                apply_workflow_change(
                    connection,
                    WorkflowRequest(
                        operation_id=request.operation_id,
                        space_id=request.space_id,
                        actor=request.actor,
                        action="ask",
                        root_work_id=state.root_work_id,
                        expected_revision=_run(connection, state.root_work_id)[1],
                        node_key="interview",
                        question=request.text,
                        purpose="Obtain the missing owner decision for Activity setup",
                        source_refs=state.sources,
                    ),
                    now=now,
                    epoch=epoch,
                    authority=authority,
                    grants=grants,
                    decisions=decisions,
                )
        elif request.action in ("pause", "cancel", "attention"):
            for stage in state.stages:
                for attempt_id, session_id, assignment_revision in connection.execute(
                    "SELECT a.attempt_id,t.session_id,a.revision FROM execution_assignments a "
                    "JOIN execution_attempts t ON t.attempt_id=a.attempt_id "
                    "WHERE a.work_id=? AND a.status IN ('assigned','waiting','ready')",
                    (str(stage.work_id),),
                ):
                    effect(
                        RequestAttemptStopRequest,
                        work_id=stage.work_id,
                        attempt_id=UUID(attempt_id),
                        session_id=UUID(session_id),
                        expected_assignment_revision=assignment_revision,
                        reason="Activity setup stopped by its saved state",
                    )
            updates = dict(
                phase={"pause": "paused", "cancel": "cancelled", "attention": "needs_attention"}[
                    request.action
                ],
                result=request.text,
                auto_resume=request.auto_resume if request.action == "pause" else False,
            )
            if state.root_work_id:
                connection.execute(
                    "UPDATE workflow_runs SET control=? WHERE root_work_id=?",
                    (
                        "cancelled"
                        if request.action == "cancel"
                        else "paused"
                        if request.action == "pause"
                        else "running",
                        str(state.root_work_id),
                    ),
                )
            if request.action == "attention" and state.repair_work is None:
                repair_id = uuid5(request.setup_id, "technical-repair")
                effect(
                    CreateWorkRequest,
                    work_id=repair_id,
                    state=WorkState(
                        activity_id=state.activity_id,
                        goal="Diagnose the saved technical obstacle to Activity setup",
                        constraints=(request.text or "Read the exact interrupted setup history",),
                        inputs=(state.stages[-1].packet,) if state.stages else (),
                        expected_outputs=(OutputContract(slot="report", media_type="text/plain"),),
                    ),
                )
                updates["repair_work"] = repair_id
        elif request.action == "migrate_workflow":
            if state.root_work_id is not None:
                raise FoundationError("workflow_exists", "Setup already uses its workflow")
            if state.phase in ("activating", "ready"):
                raise FoundationError(
                    "setup_result_pending",
                    "Finish the exact saved successful review before switching execution; "
                    "a ready Activity needs no setup migration",
                )
            for stage in state.stages:
                assignment = connection.execute(
                    "SELECT status FROM execution_assignments WHERE work_id=? ORDER BY rowid "
                    "DESC LIMIT 1",
                    (str(stage.work_id),),
                ).fetchone()
                if assignment and assignment[0] in (
                    "assigned",
                    "waiting",
                    "ready",
                    "stop_requested",
                    "unknown",
                ):
                    raise FoundationError(
                        "unknown_outcome" if assignment[0] == "unknown" else "setup_running",
                        "Finish or stop the old stage before migration",
                    )
                if stage.output is None and not stage.retired:
                    row = connection.execute(
                        "SELECT c.payload FROM subject_records w JOIN subject_content c ON "
                        "c.record_id=w.record_id AND c.revision=w.current_revision WHERE "
                        "w.record_id=?",
                        (str(stage.work_id),),
                    ).fetchone()
                    if row and row[0] and WorkState.model_validate_json(row[0]).linked_outputs:
                        raise FoundationError(
                            "setup_result_pending",
                            "Process the retained old output before migration",
                        )
            from .models import WorkflowRequest
            from .workflows import _run, apply_workflow_change, setup_workflow_begin

            workflow, root_work_id = setup_workflow_begin(
                connection,
                request,
                state.sources,
                now=now,
                epoch=epoch,
                authority=authority,
                grants=grants,
                decisions=decisions,
            )
            updates = dict(
                workflow=workflow,
                root_work_id=root_work_id,
                stages=tuple(
                    item.model_copy(update={"retired": True}) if item.output is None else item
                    for item in state.stages
                ),
            )
            if state.question:
                apply_workflow_change(
                    connection,
                    WorkflowRequest(
                        operation_id=request.operation_id,
                        space_id=request.space_id,
                        actor=request.actor,
                        action="ask",
                        root_work_id=root_work_id,
                        expected_revision=_run(connection, root_work_id)[1],
                        node_key="interview",
                        question=state.question,
                        purpose="Continue the saved owner question",
                        source_refs=state.sources,
                    ),
                    now=now,
                    epoch=epoch,
                    authority=authority,
                    grants=grants,
                    decisions=decisions,
                )
        elif request.action in ("resume", "retry"):
            if state.question:
                raise FoundationError("incomplete_context", "Answer the saved question first")
            unfinished = _unfinished_stages(state)
            pending_stages = tuple(
                stage for stage in unfinished if _stage_execution(connection, stage).pending_outcome
            )
            if pending_stages:
                if request.action != "retry":
                    _require_known_stage_outcomes(connection, state)
                if state.phase != "paused" or any(
                    stage.result_protocol != "setup_json"
                    or stage.input_version >= state.input_version
                    or not _stage_execution(connection, stage).stopped
                    for stage in pending_stages
                ):
                    raise FoundationError(
                        "unknown_effect",
                        "A fresh setup stage requires an explicit retry of paused setup_json "
                        "work, changed inputs and an observed local stop. The earlier outcome "
                        "and accounting remain unknown.",
                    )
                updates["stages"] = tuple(
                    stage.model_copy(update={"retired": True}) if stage in pending_stages else stage
                    for stage in state.stages
                )
                retire_stage_nodes(state, pending_stages)
            if state.phase == "paused" and any(
                not _stage_execution(connection, stage).stopped for stage in unfinished
            ):
                raise FoundationError(
                    "setup_stopping", "The setup executor has not yet confirmed its local stop"
                )
            successful_review = False
            if state.review and state.draft:
                report = review_from_bytes(
                    _artifact(connection, state.review, request.actor, epoch),
                    state.contract_version,
                )
                successful_review = (
                    report.draft == state.draft
                    and report.input_version == state.input_version
                    and not report.unresolved
                    and not any(item.blocking for item in report.findings)
                )
            if request.action == "retry":
                updates["pass_boundary"] = state.reviews_started
                updates["recovery_boundary"] = len(state.stages)
            elif state.phase == "needs_attention" and state.stages and state.stages[-1].rejection:
                raise FoundationError(
                    "setup_result_exhausted",
                    "Explicit retry is required after stopped result corrections",
                )
            elif state.reviews_started - state.pass_boundary >= 5 and not successful_review:
                raise FoundationError(
                    "setup_review_exhausted", "Explicit retry is required after five review passes"
                )
            updates["phase"] = (
                "activating"
                if successful_review
                else "collecting"
                if not state.draft
                else "correcting"
                if state.review
                else "drafting"
            )
            updates["result"] = None
            updates["auto_resume"] = False
            if state.root_work_id:
                connection.execute(
                    "UPDATE workflow_runs SET control='running' WHERE root_work_id=?",
                    (str(state.root_work_id),),
                )
        elif request.action == "start_stage":
            _require_known_stage_outcomes(connection, state)
            if (
                state.phase in ("paused", "needs_input", "needs_attention")
                or not request.stage_kind
                or not request.stage_instruction
            ):
                raise FoundationError(
                    "invalid_transition", "Setup must be runnable with a stage instruction"
                )
            if state.stages and state.stages[-1].output is None and not state.stages[-1].retired:
                raise FoundationError(
                    "setup_running", "Existing stage must finish or be explicitly retired"
                )
            if request.stage_kind != "draft" and state.draft is None:
                raise FoundationError(
                    "invalid_transition", "Correction/review needs the whole current draft"
                )
            if state.reviews_started - state.pass_boundary >= 5:
                raise FoundationError("setup_review_exhausted", "Five reviews already started")
            previous = state.stages[-1] if state.stages and state.stages[-1].rejection else None
            repairing = previous is not None and previous.input_version == state.input_version
            if repairing and previous is not None and request.stage_kind != previous.kind:
                raise FoundationError(
                    "invalid_transition", "A rejected result repeats its original stage kind"
                )
            continuing_series = repairing and len(state.stages) > state.recovery_boundary
            if continuing_series and previous is not None and previous.repair_number >= 2:
                raise FoundationError(
                    "setup_result_exhausted", "Explicit retry is required after two corrections"
                )
            review_manifest: ActivityActivationManifest | None = None
            packet: dict[str, Any] = {
                "setup_id": str(request.setup_id),
                "activity_id": str(state.activity_id),
                "input_version": state.input_version,
                "sources": [_basis(connection, ref, request.actor, epoch) for ref in state.sources],
                "interactions": [
                    {
                        "question": item.question,
                        "input_version": item.input_version,
                        "answer": _basis(connection, item.answer, request.actor, epoch)
                        if item.answer
                        else None,
                    }
                    for item in state.interactions
                ],
            }
            if state.draft:
                packet["draft_ref"] = state.draft.model_dump(mode="json")
                packet["draft"] = draft_from_bytes(
                    _artifact(connection, state.draft, request.actor, epoch), state.contract_version
                ).model_dump(mode="json")
            if state.review:
                packet["previous_review"] = review_from_bytes(
                    _artifact(connection, state.review, request.actor, epoch),
                    state.contract_version,
                ).model_dump(mode="json")
            packet["contract_version"] = state.contract_version
            packet["supported_operations"] = procedure_operation_catalog()
            if repairing and previous is not None and previous.rejection is not None:
                packet["rejected_result"] = {
                    **previous.rejection.model_dump(mode="json"),
                    "content_text": _artifact(
                        connection, previous.rejection.artifact, request.actor, epoch
                    ).decode("utf-8"),
                    "stage_kind": previous.kind,
                }
            if state.contract_version == 2:
                packet["supported_path"] = (
                    "Public typed data operations, exact formats, durable ordinary Work "
                    "procedures, scoped memory; no mandatory domain templates. "
                    "Original Sources and owner acceptance remain separate."
                )
                if state.manifest:
                    packet["manifest_ref"] = state.manifest.model_dump(mode="json")
                    manifest_bytes = _artifact(connection, state.manifest, request.actor, epoch)
                    packet["activation_manifest"] = json.loads(manifest_bytes)
                    try:
                        review_manifest = ActivityActivationManifest.model_validate_json(
                            manifest_bytes
                        )
                    except ValidationError as error:
                        raise FoundationError(
                            "corrupt_space", "Saved activation manifest is invalid"
                        ) from error
                    packet["review_components"] = review_component_catalog(review_manifest)
                if state.previous_structure:
                    from .data_store import exact_state

                    packet["previous_structure"] = exact_state(
                        connection, state.previous_structure, request.actor, epoch
                    ).model_dump(mode="json")
            packet["result_schema"] = (
                (
                    ActivitySetupReviewV2 if state.contract_version == 2 else ActivitySetupReview
                ).model_json_schema()
                if request.stage_kind == "review"
                else (
                    ActivitySetupDraftV2 if state.contract_version == 2 else ActivitySetupDraft
                ).model_json_schema()
            )
            if (
                request.stage_kind == "review"
                and state.contract_version == 2
                and review_manifest is not None
            ):
                packet["result_schema"] = review_result_schema(review_manifest)
                packet["review_component_instruction"] = (
                    "coverage.components uses exact addresses from review_components; "
                    "explanations describe the reasoning in prose."
                )
            packet.setdefault(
                "supported_path",
                (
                    "Source originals and revisioned knowledge; "
                    "public memory catalog/batch/history/cache; "
                    "plain Work with output contracts or composite Method Work "
                    "with at least one child; "
                    "all initial children are fresh plain Work in this Activity. "
                    "Named inputs must match "
                    "the Method exactly. Initial Methods are self-contained "
                    "(no existing role Methods or capability admission). "
                    "Outputs remain separately owner-accepted. Sleep stores "
                    "experience and scoped Candidates for later change. Manual external exchange "
                    "preserves provenance; external API sending is not provided by this setup."
                ),
            )
            packet_id = uuid5(request.operation_id, "packet")
            work_id = uuid5(request.operation_id, "stage-work")
            effect(
                CreateArtifactRequest,
                artifact_id=packet_id,
                media_type="application/json",
                content=canonical_json(packet).encode("utf-8"),
            )
            stage_state = WorkState(
                activity_id=state.activity_id,
                goal=request.stage_instruction,
                inputs=(ArtifactRef(artifact_id=packet_id, revision=1),),
                expected_outputs=(
                    OutputContract(slot="report", media_type="text/plain", allow_empty=True),
                ),
            )
            if state.root_work_id:
                from .workflows import setup_workflow_add_stage

                setup_workflow_add_stage(
                    connection,
                    request,
                    state,
                    PlanChild(role=request.stage_kind, work_id=work_id, state=stage_state),
                    ArtifactRef(artifact_id=packet_id, revision=1),
                    now=now,
                    epoch=epoch,
                    authority=authority,
                    grants=grants,
                    decisions=decisions,
                )
            else:
                effect(CreateWorkRequest, work_id=work_id, state=stage_state)
            reviews = state.reviews_started + int(request.stage_kind == "review")
            stage = SetupStage(
                work_id=work_id,
                kind=request.stage_kind,
                input_version=state.input_version,
                packet=ArtifactRef(artifact_id=packet_id, revision=1),
                draft=state.draft,
                review_pass=reviews if request.stage_kind == "review" else 0,
                result_protocol="setup_json",
                model=request.stage_model,
                repair_of=previous.work_id if repairing and previous is not None else None,
                repair_series=previous.rejection.series_id
                if continuing_series and previous is not None and previous.rejection
                else None,
                repair_number=previous.repair_number + 1
                if continuing_series and previous is not None
                else 0,
            )
            updates = dict(
                stages=state.stages + (stage,),
                reviews_started=reviews,
                phase={"draft": "drafting", "correction": "correcting", "review": "reviewing"}[
                    request.stage_kind
                ],
            )
        elif request.action == "complete_stage":
            if not state.stages or not request.output or state.stages[-1].output is not None:
                raise FoundationError(
                    "invalid_transition", "Completion needs one active stage output"
                )
            stage = state.stages[-1]
            if stage.retired:
                raise FoundationError("stale_basis", "The stage was retired after changed inputs")
            from .operations import _subject_state

            row = connection.execute(
                "SELECT current_revision FROM subject_records WHERE record_id=?",
                (str(stage.work_id),),
            ).fetchone()
            work = WorkState.model_validate(_subject_state(connection, stage.work_id, row[0]))
            if (
                request.output not in [item.artifact for item in work.linked_outputs]
                or stage.input_version != state.input_version
            ):
                raise FoundationError(
                    "stale_basis", "Output does not belong to the current setup stage"
                )
            raw = _artifact(connection, request.output, request.actor, epoch)
            issues: tuple[SetupValidationIssue, ...] = ()
            try:
                parsed = (
                    review_from_bytes(raw, state.contract_version)
                    if stage.kind == "review"
                    else draft_from_bytes(raw, state.contract_version)
                )
            except ValidationError as error:
                issues = validation_issues(error)
                parsed = None
            manifest = None
            if parsed is not None:
                if stage.kind == "review":
                    assert isinstance(parsed, (ActivitySetupReview, ActivitySetupReviewV2))
                    review = parsed
                    if review.draft != state.draft or review.input_version != state.input_version:
                        raise FoundationError(
                            "stale_basis", "Review addresses an old draft or interview"
                        )
                    if isinstance(review, ActivitySetupReviewV2):
                        if review.manifest != state.manifest or state.manifest is None:
                            raise FoundationError(
                                "stale_basis", "Review must address the exact compiled manifest"
                            )
                        saved_manifest = _artifact(connection, state.manifest, request.actor, epoch)
                        try:
                            manifest = ActivityActivationManifest.model_validate_json(
                                saved_manifest
                            )
                        except ValidationError as error:
                            raise FoundationError(
                                "corrupt_space", "Saved activation manifest is invalid"
                            ) from error
                        try:
                            validate_review_components(review, manifest)
                        except SetupResultError as error:
                            issues = error.issues
                    updates = dict(
                        review=request.output,
                        reviews_completed=state.reviews_completed + 1,
                        phase="correcting"
                        if any(item.blocking for item in review.findings)
                        else "needs_input"
                        if review.unresolved
                        else "activating",
                        question="\n".join(review.unresolved) or None,
                    )
                    if (
                        state.root_work_id
                        and not review.unresolved
                        and not any(item.blocking for item in review.findings)
                        and state.draft
                    ):
                        reviewed_draft = draft_from_bytes(
                            _artifact(connection, state.draft, request.actor, epoch),
                            state.contract_version,
                        )
                        if reviewed_draft.open_questions:
                            issues = (
                                SetupValidationIssue(
                                    code="unreviewed_setup_question",
                                    path=("questions",),
                                    message="A successful review must resolve or request "
                                    "correction of setup-blocking draft questions",
                                ),
                            )
                    if (
                        updates["phase"] == "correcting"
                        and state.reviews_started - state.pass_boundary >= 5
                    ):
                        updates.update(phase="needs_attention", result=review.conclusion)
                    if updates["phase"] == "needs_input" and updates["question"]:
                        updates["interactions"] = state.interactions + (
                            SetupInteraction(
                                interaction_id=uuid5(request.operation_id, "review-question"),
                                question=updates["question"],
                                input_version=state.input_version,
                                sources=state.sources,
                            ),
                        )
                else:
                    assert isinstance(parsed, (ActivitySetupDraft, ActivitySetupDraftV2))
                    draft = parsed
                    updates = dict(
                        draft=request.output,
                        review=None,
                        phase="needs_input"
                        if draft.open_questions
                        and int(connection.execute("PRAGMA user_version").fetchone()[0]) < 16
                        else "drafting",
                        question="\n".join(draft.open_questions) or None
                        if int(connection.execute("PRAGMA user_version").fetchone()[0]) < 16
                        else None,
                    )
                    if isinstance(draft, ActivitySetupDraftV2):
                        try:
                            manifest = compile_structure(
                                connection,
                                request.setup_id,
                                state,
                                draft,
                                request.output,
                                request.actor,
                                epoch,
                            )
                        except SetupResultError as error:
                            issues = error.issues
            if issues:
                updates = _rejected_result(state, stage, request.output, issues)
            else:
                if stage.kind != "review" and manifest is not None:
                    manifest_id = uuid5(request.output.artifact_id, "activation-manifest")
                    effect(
                        CreateArtifactRequest,
                        artifact_id=manifest_id,
                        media_type="application/json",
                        content=manifest.model_dump_json().encode("utf-8"),
                    )
                    updates["manifest"] = ArtifactRef(artifact_id=manifest_id, revision=1)
                updates["stages"] = state.stages[:-1] + (
                    stage.model_copy(update={"output": request.output}),
                )
                if updates["phase"] != "needs_attention":
                    updates["result"] = None
            if state.root_work_id:
                from .workflows import setup_workflow_complete_stage

                setup_workflow_complete_stage(connection, request, state, stage, issues, now=now)
                if not issues and updates.get("phase") == "needs_input" and updates.get("question"):
                    from .models import WorkflowRequest
                    from .workflows import _run, apply_workflow_change

                    apply_workflow_change(
                        connection,
                        WorkflowRequest(
                            operation_id=request.operation_id,
                            space_id=request.space_id,
                            actor=request.actor,
                            action="ask",
                            root_work_id=state.root_work_id,
                            expected_revision=_run(connection, state.root_work_id)[1],
                            node_key=stage.kind,
                            question=updates["question"],
                            purpose="Resolve an owner decision checked by the full Activity review",
                            source_refs=state.sources,
                        ),
                        now=now,
                        epoch=epoch,
                        authority=authority,
                        grants=grants,
                        decisions=decisions,
                    )
        elif request.action == "finish":
            state = _activate(connection, request, state, effect, epoch)
            if state.root_work_id:
                from .models import WorkflowRequest
                from .workflows import _run, apply_workflow_change

                apply_workflow_change(
                    connection,
                    WorkflowRequest(
                        operation_id=request.operation_id,
                        space_id=request.space_id,
                        actor=request.actor,
                        action="finish",
                        root_work_id=state.root_work_id,
                        expected_revision=_run(connection, state.root_work_id)[1],
                    ),
                    now=now,
                    epoch=epoch,
                    authority=authority,
                    grants=grants,
                    decisions=decisions,
                )
        else:
            raise FoundationError("invalid_request", "Unknown setup action")
        state = ActivitySetupState.model_validate({**state.model_dump(), **updates})
    _save(connection, request, state, revision, now)
    targets.append({"record_id": str(request.setup_id), "revision": revision})
    return {
        "setup_id": str(request.setup_id),
        "revision": revision,
        "phase": state.phase,
        "activity_id": str(state.activity_id),
    }, targets


def _activate(
    connection: sqlite3.Connection,
    request: ActivitySetupRequest,
    state: ActivitySetupState,
    effect: Any,
    epoch: int,
) -> ActivitySetupState:
    from .composition import method_checksum

    if state.phase != "activating" or not state.draft or not state.review:
        raise FoundationError(
            "setup_not_reviewed", "Activation needs a successful whole current review"
        )
    for basis in state.sources:
        _basis(connection, basis, request.actor, epoch)
    draft = draft_from_bytes(
        _artifact(connection, state.draft, request.actor, epoch), state.contract_version
    )
    review = review_from_bytes(
        _artifact(connection, state.review, request.actor, epoch), state.contract_version
    )
    if (
        review.draft != state.draft
        or review.input_version != state.input_version
        or review.unresolved
        or draft.open_questions
        or any(item.blocking for item in review.findings)
    ):
        raise FoundationError("stale_basis", "Setup does not have a current successful review")
    manifest = None
    if isinstance(draft, ActivitySetupDraftV2):
        if (
            not isinstance(review, ActivitySetupReviewV2)
            or state.manifest != review.manifest
            or not state.manifest
        ):
            raise FoundationError("stale_basis", "Exact manifest review is required")
        manifest = ActivityActivationManifest.model_validate_json(
            _artifact(connection, state.manifest, request.actor, epoch)
        )
        if manifest != compile_structure(
            connection, request.setup_id, state, draft, state.draft, request.actor, epoch
        ):
            raise FoundationError("stale_basis", "Compiled definitions changed after review")
    activity_revision = connection.execute(
        "SELECT current_revision FROM subject_records WHERE record_id=?",
        (str(state.activity_id),),
    ).fetchone()[0]
    if state.mode == "create":
        effect(
            ReviseActivityRequest,
            activity_id=state.activity_id,
            expected_revision=activity_revision,
            state=ActivityState(title=draft.title, goal=draft.goal),
        )
    if manifest is None:
        effect(
            CreateKnowledgeRequest,
            record_id=uuid5(request.setup_id, "instructions"),
            state=ClaimState(
                proposition=draft.instructions,
                epistemic_kind="derived",
                status="current",
                scope_activity_id=state.activity_id,
                evidence=state.sources
                + (
                    KnowledgeRef(record_id=state.draft.artifact_id, revision=state.draft.revision),
                    KnowledgeRef(
                        record_id=state.review.artifact_id, revision=state.review.revision
                    ),
                ),
                interpretation_basis="Initial setup admitted after its exact complete review",
                memory=MemoryMetadata(
                    title="Activity instructions",
                    activity_id=state.activity_id,
                    context_role="required",
                ),
            ),
        )
    definitions = (
        manifest.method_definitions
        if manifest
        else {item.key: item.definition for item in draft.methods}
    )
    refs = {
        item.key: MethodRef(
            method_id=uuid5(request.setup_id, f"method:{item.key}"),
            version=1,
            checksum=method_checksum(definitions[item.key]),
        )
        for item in draft.methods
    }
    if draft.methods:
        candidate_id = uuid5(request.setup_id, f"candidate:{state.draft.artifact_id}")
        decision_id = uuid5(candidate_id, "adoption")
        changes = tuple(
            MethodChange(
                method_id=refs[item.key].method_id, to_version=1, definition=definitions[item.key]
            )
            for item in draft.methods
        )
        evidence = KnowledgeRef(record_id=state.review.artifact_id, revision=state.review.revision)
        results = tuple(
            ValidationResultState(
                result_id=uuid5(candidate_id, area),
                criterion=area,
                outcome="met",
                evidence=(evidence,),
                actual_input=(
                    f"Whole setup {state.draft.artifact_id}@{state.draft.revision}; "
                    f"interview {state.input_version}"
                ),
                environment=(
                    "Structure review in an assigned ordinary Pi; no trial or owner acceptance"
                ),
            )
            for area in AREAS
        )
        candidate = ChangeCandidateState(
            target=changes[0]
            if len(changes) == 1
            else CompositeChange(
                package_id=uuid5(candidate_id, "methods"), to_version=1, parts=changes
            ),
            proposal="Reviewed initial setup of this new Activity",
            evidence=state.sources + (evidence,),
            expected_outcome="Usable initial Methods preserving versioned history",
            scope_activity_ids=(state.activity_id,),
            exclusions="No other Activity, Grant, deletion, program change or publication",
            impact="Only new Methods and Work of this setup",
            affected_work_ids=(),
            unknowns="Semantic review is not proof of future behavior",
            validation_plan=ValidationPlanState(
                baseline=str(state.draft),
                environment="Ordinary Pi setup review",
                criteria=tuple(
                    ValidationCriterion(
                        key=area,
                        question=f"Review {area}",
                        pass_condition="No material obstacle",
                        basis=(evidence,),
                    )
                    for area in AREAS
                ),
                cases="Whole current setup and actual user requirements",
                method="Fresh full review after every correction",
                sufficiency="Initial structure; no claim of real-use quality",
                limits="No synthetic onboarding trial",
                stop_and_restore="Retain draft and stop setup",
                decision_condition="All areas reviewed; no blocking finding",
                follow_up="Real use and Sleep",
            ),
            results=results,
            restore_plan="Stop adoption without rewriting history",
            irreversible_effects="None outside this new Activity",
        )
        effect(CreateDevelopmentRequest, record_id=candidate_id, state=candidate)
        effect(
            CreateDecisionRequest,
            decision_id=decision_id,
            state=ChangeDecisionState(
                statement=(
                    f"Initial setup authorized by {state.owner}; "
                    f"exact complete review {state.review.artifact_id}"
                ),
                candidate_id=candidate_id,
                candidate_revision=1,
                mode="regular",
                use="permitted",
                scope_activity_id=state.activity_id,
                validation_result_ids=tuple(item.result_id for item in results),
                review_condition="Review again when premises or process change",
            ),
        )
        effect(
            ApplyCandidateRequest,
            candidate_id=candidate_id,
            candidate_revision=1,
            decision_id=decision_id,
            decision_revision=1,
            mode="regular",
        )
    if manifest is not None:
        for ordinal, definition in enumerate(manifest.workflow_definitions):
            identifier = uuid5(request.setup_id, f"workflow:{ordinal}")
            candidate_id = uuid5(request.setup_id, f"workflow-candidate:{ordinal}")
            decision_id = uuid5(request.setup_id, f"workflow-decision:{ordinal}")
            evidence = KnowledgeRef(
                record_id=state.review.artifact_id, revision=state.review.revision
            )
            results = tuple(
                ValidationResultState(
                    result_id=uuid5(candidate_id, area),
                    criterion=area,
                    outcome="met",
                    evidence=(evidence,),
                    actual_input="Entire exact reviewed Activity package",
                    environment="Core setup review",
                )
                for area in AREAS
            )
            effect(
                CreateDevelopmentRequest,
                record_id=candidate_id,
                state=ChangeCandidateState(
                    target=WorkflowChange(
                        workflow_id=identifier, to_version=1, definition=definition
                    ),
                    proposal="Adopt the exact workflow in the fully reviewed Activity",
                    evidence=state.sources + (evidence,),
                    expected_outcome=manifest.structure.first_action,
                    scope_activity_ids=(state.activity_id,),
                    exclusions="No grants, code, external publication or Work acceptance",
                    impact="Only declared workflows in this Activity",
                    unknowns="Future experience",
                    validation_plan=ValidationPlanState(
                        baseline=str(state.draft),
                        environment="Core and ordinary Pi",
                        criteria=tuple(
                            ValidationCriterion(
                                key=area,
                                question=area,
                                pass_condition="No substantial obstacle",
                                basis=(evidence,),
                            )
                            for area in AREAS
                        ),
                        cases="Whole current setup",
                        method="Whole exact review",
                        sufficiency="All seven areas",
                        limits="No mandatory trial",
                        stop_and_restore="Stop future starts",
                        decision_condition="Exact current review",
                        follow_up="Use and Sleep",
                    ),
                    results=results,
                    restore_plan="Stop future use; preserve history",
                    irreversible_effects="Actual work effects retain their own receipts",
                ),
            )
            effect(
                CreateDecisionRequest,
                decision_id=decision_id,
                state=ChangeDecisionState(
                    statement="Adopt one reviewed workflow within the initial setup permission",
                    candidate_id=candidate_id,
                    candidate_revision=1,
                    mode="regular",
                    use="permitted",
                    scope_activity_id=state.activity_id,
                    validation_result_ids=tuple(item.result_id for item in results),
                    review_condition="Review when needs or process change",
                ),
            )
            effect(
                ApplyCandidateRequest,
                candidate_id=candidate_id,
                candidate_revision=1,
                decision_id=decision_id,
                decision_revision=1,
                mode="regular",
            )
        from .structure_change import activate_setup_structure

        activate_setup_structure(connection, request, state, manifest, review, effect, epoch)
    works = []
    for template in manifest.initial_works if manifest is not None else draft.works:
        identifier = uuid5(request.setup_id, f"work:{template.key}")
        method = refs.get(template.method_key) if template.method_key else None
        outputs = (
            definitions[template.method_key or ""].named_outputs
            if method
            else template.expected_outputs
        )
        work = WorkState(
            activity_id=state.activity_id,
            goal=template.goal,
            inputs=tuple(item.artifact for item in template.plan.named_inputs)
            if template.plan is not None
            else (state.draft,),
            constraints=(draft.instructions,),
            expected_outputs=outputs,
            method=method or "none",
        )
        if method:
            if template.plan is None:
                raise FoundationError(
                    "invalid_setup_result", "A Method Work needs its actual typed composite plan"
                )
            for child in template.plan.children:
                if (
                    child.state.activity_id != state.activity_id
                    or (manifest is None and child.state.method != "none")
                    or child.state.status != "proposed"
                    or child.state.linked_outputs
                ):
                    raise FoundationError(
                        "out_of_scope",
                        "Initial plan children must be fresh plain Work in this Activity",
                    )
            plan = template.plan.model_copy(
                update={"basis": tuple(dict.fromkeys(template.plan.basis + (state.draft,)))}
            )
            effect(CreateCompositeWorkRequest, work_id=identifier, state=work, plan=plan)
        else:
            effect(CreateWorkRequest, work_id=identifier, state=work)
        works.append(identifier)
    return state.model_copy(
        update={
            "phase": "ready",
            "activated_works": tuple(works),
            "activated_methods": tuple(refs.values()),
            "result": draft.instructions + "\n\n" + draft.first_action,
        }
    )


def sanitize_setup_dependency(connection: sqlite3.Connection, record_id: UUID, now: str) -> None:
    """Retire copies and receipts, keeping addresses when their basis is deleted."""
    if int(connection.execute("PRAGMA user_version").fetchone()[0]) < 14:
        return
    affected = [
        row[0]
        for row in connection.execute(
            "SELECT DISTINCT setup_id FROM activity_setup_edges WHERE target_id=? "
            "AND role IN ('basis','owned_source','derived_artifact','method','activity',"
            "'referenced_activity')",
            (str(record_id),),
        )
    ]
    for identifier in affected:
        if (
            connection.execute(
                "SELECT status FROM activity_setups WHERE setup_id=?", (identifier,)
            ).fetchone()[0]
            != "active"
        ):
            continue
        connection.execute(
            "UPDATE activity_setups SET status='unavailable' WHERE setup_id=?", (identifier,)
        )
        for (operation,) in connection.execute(
            "SELECT operation_id FROM activity_setup_revisions WHERE setup_id=?", (identifier,)
        ):
            connection.execute("DELETE FROM receipts WHERE operation_id=?", (operation,))
            connection.execute(
                "UPDATE operations SET fingerprint='DELETED' WHERE operation_id=?", (operation,)
            )
        connection.execute(
            "UPDATE activity_setup_revisions SET payload=NULL,sha256=NULL WHERE setup_id=?",
            (identifier,),
        )
        assigned = [
            {"work_id": row[0], "attempt_id": row[1]}
            for row in connection.execute(
                "SELECT a.work_id,a.attempt_id FROM execution_assignments a WHERE a.work_id IN "
                "(SELECT target_id FROM activity_setup_edges WHERE setup_id=? AND role='work')",
                (identifier,),
            )
        ]
        connection.execute(
            "UPDATE execution_waits SET question=NULL,remainder=NULL,answer=NULL,status='purged' "
            "WHERE work_id IN (SELECT target_id FROM activity_setup_edges "
            "WHERE setup_id=? AND role='work')",
            (identifier,),
        )
        for target, role in connection.execute(
            (
                "SELECT DISTINCT target_id,role FROM activity_setup_edges WHERE setup_id=? "
                "AND role IN ('derived_artifact','derived_knowledge','owned_source',"
                "'method','work','activity','derived_format')"
            ),
            (identifier,),
        ):
            if role == "derived_format" or (
                role == "derived_knowledge"
                and int(connection.execute("PRAGMA user_version").fetchone()[0]) >= 15
                and connection.execute(
                    "SELECT kind FROM knowledge_records WHERE record_id=?", (target,)
                ).fetchone()[0]
                == "activity_structure"
            ):
                from .data_store import sanitize_data_revision

                for (version,) in connection.execute(
                    "SELECT DISTINCT target_revision FROM activity_setup_edges WHERE "
                    "setup_id=? AND target_id=? AND role=?",
                    (identifier, target, role),
                ):
                    sanitize_data_revision(
                        connection, KnowledgeRef(record_id=UUID(target), revision=version), now
                    )
                continue
            if role in ("derived_knowledge", "owned_source"):
                from .knowledge import _sanitize_deleted

                _sanitize_deleted(connection, UUID(target), now)
            elif role == "derived_artifact":
                from .operations import _queue_derived_artifact_deletion

                origin = connection.execute(
                    "SELECT operation_id FROM record_revisions WHERE record_id=? "
                    "ORDER BY revision LIMIT 1",
                    (target,),
                ).fetchone()[0]
                _queue_derived_artifact_deletion(connection, origin, target, assigned, now)
                connection.execute(
                    "DELETE FROM managed_content WHERE record_id=?",
                    (target,),
                )
                connection.execute(
                    "UPDATE records SET status='deleted' WHERE record_id=?", (target,)
                )
                for (operation,) in connection.execute(
                    "SELECT operation_id FROM record_revisions WHERE record_id=?", (target,)
                ):
                    connection.execute("DELETE FROM receipts WHERE operation_id=?", (operation,))
                    connection.execute(
                        "UPDATE operations SET fingerprint='DELETED' WHERE operation_id=?",
                        (operation,),
                    )
            elif role == "method":
                from .composition import _sanitize_deleted_method_sources

                for version, checksum in connection.execute(
                    "SELECT version,checksum FROM method_versions WHERE method_id=?", (target,)
                ):
                    _sanitize_deleted_method_sources(
                        connection,
                        MethodRef(method_id=UUID(target), version=version, checksum=checksum),
                    )
                connection.execute(
                    "UPDATE method_versions SET payload=NULL,status='deleted' WHERE method_id=?",
                    (target,),
                )
            else:
                connection.execute("DELETE FROM subject_content WHERE record_id=?", (target,))
                if role == "activity":
                    origin = connection.execute(
                        "SELECT operation_id FROM subject_revisions WHERE record_id=? "
                        "ORDER BY revision LIMIT 1",
                        (target,),
                    ).fetchone()[0]
                    connection.execute(
                        "INSERT OR IGNORE INTO subject_deletion_jobs"
                        "(operation_id,record_id,status,created_at) VALUES (?,?,'pending',?)",
                        (origin, target, now),
                    )
            from .development import sanitize_deleted_development_dependency
            from .knowledge import sanitize_deleted_knowledge_dependency

            sanitize_deleted_knowledge_dependency(connection, UUID(target), now)
            sanitize_deleted_development_dependency(connection, UUID(target), now)
            from .composition import sanitize_deleted_dependency

            if role == "derived_artifact":
                sanitize_deleted_dependency(
                    connection,
                    artifact_id=UUID(target),
                    operation_id=uuid5(UUID(identifier), f"retire:{target}"),
                    now=now,
                )
            elif role in ("work", "activity"):
                for (operation,) in connection.execute(
                    "SELECT operation_id FROM subject_revisions WHERE record_id=?", (target,)
                ):
                    connection.execute("DELETE FROM receipts WHERE operation_id=?", (operation,))
                    connection.execute(
                        "UPDATE operations SET fingerprint='DELETED' WHERE operation_id=?",
                        (operation,),
                    )
        connection.execute(
            (
                "UPDATE backup_inventory SET status='contaminated' WHERE status IN "
                "('planned','failed','complete') AND state_revision >= (SELECT "
                "MIN(o.state_revision) FROM operations o JOIN activity_setup_revisions s ON "
                "s.operation_id=o.operation_id WHERE s.setup_id=?)"
            ),
            (identifier,),
        )
