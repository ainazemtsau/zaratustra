# Zaratustra

## Owner-authorized restart — 2026-10-16

`docs/restart/OWNER-LAUNCH.md` records the exact owner acceptance of revision 2
and implementation authorization for package A only. Its accepted plan/review
supersede the old one-package/consolidation layout solely in this restart branch.
`packages/core` and `packages/app` are independent installable packages; no old
runtime imports or user-data migration. The root native check also covers these
sources, boundaries, tests and both wheels. Frozen REVIEW.md/validation.config
remain unchanged. Local technical evidence never means owner acceptance.

The owner accepted A as a technical stage on 2026-10-16 and authorized package B
followed by an independent review. `docs/restart/PACKAGE-B-RETURN.md` records the
exact words and bounded continuation matrix. This extends only revision 2 §10 B;
C/D, live/paid models, merge and publication are not authorized by that launch.

The owner subsequently accepted B as a technical stage and authorized package C,
then an independent review: «Окей, пакет B принимаю как технический этап.
Запускай исполнителя на Sol 6.1 для пакета C, потом независимую проверку.
Существенные отклонения согласуй со мной, остальное делай сам.» This extends
revision 2 §10 C only. The owner separately allowed paid Luna: «можешь
использвоать платную моджель luna сколько угодно». Each Work still requires a
finite explicit resource limit and selected supported access. D, migration,
merge, push and publication remain outside this authorization.

## Current product authority — Core v0.1
- On 2026-10-01 the owner chose the latest Core/Activity implementation as the
  single main basis and authorized consolidation. Read
  `docs/core-v0.1/CONSOLIDATION-20261001.md` before branch, setup or adapter work.
  The former Home/file-first main is retained in Git history, not a second
  current backend. Core's SQLite domain authority and the accepted specification
  remain unchanged. Current ordinary entry is `zaratustra`, using ordinary Pi
  from PATH; `zara-core` is the compatible maintenance entry. Earlier `zara`,
  `zara-agent` instructions and Home-era plans are historical context.
  The installed integration boundary supplies manual prepare/retain/read and
  adaptable external-chat guidance. Repository reading by an external account
  is distinct from a Zaratustra API connector; do not infer account setup from code.
- The owner delivery policy for the current release work is `docs/core-v0.1/DELIVERY-POLICY-20260926.md`; it changes validation organization, not product contracts. The stabilization technical review closed at `afe995d9739f655a6f495216f56dc4f53558dd97`; see `docs/core-v0.1/STABILIZATION-REVIEW-CLOSURE-20260926.md`. Nine independent targeted tests passed; the full 728-test gate is implementation evidence. Historical SQLite lock-holder and Pi exit causes remain unestablished.
- The current product basis is `docs/core-v0.1/IMPLEMENTATION-BASELINE.md`, the
  owner-approved Core v0.1 implementation plan recorded there,
  `docs/core-v0.1/STAGE4-PLAN.md`, `docs/core-v0.1/STAGE5-PLAN.md`,
  `docs/core-v0.1/STAGE6-PLAN.md`, this AGENTS.md, and `validation.config`.
  Stage 5 is owner-accepted at `245e7288c08eb4d49c84edd89f01e746a45c37a5`.
  The owner accepted Stage 6 pass 1 at
  `29d887d41f1639dc6ddb354a2039603cb1a30d94`; see
  `docs/core-v0.1/STAGE6-PASS1-ACCEPTANCE.md`. The owner accepted Stage 6
  pass 2 at `d33b676c57b8319cb4a4d2527f64d41fe800c154`; see
  `docs/core-v0.1/STAGE6-PASS2-ACCEPTANCE.md`. On 2026-09-24 the owner
  approved decisions on the pass 3 plan, `docs/core-v0.1/STAGE6-PASS3-PLAN.md`,
  and authorized only its part 3.1, followed by a stop for technical review.
  Part 3.1 is implemented as a development checkpoint; see
  `docs/core-v0.1/STAGE6-PASS3-CHECKPOINT-3.1.md`. Two defects reproduced by
  the independent review of `e2d5b90` are corrected there, and the owner
  authorized the narrow outcome-basis sanitation fix after the review of
  `a7226f8` and the upgrade-first order for schemas 2–6 after the review of
  `f13ffa8`. On Codex's independent Windows check of `d07ffa5` the owner
  closed the technical review of checkpoint 3.1 and authorized only part 3.2,
  followed by a stop for review; part 3.2 is implemented as a development
  checkpoint, with one readiness correction after Codex's Windows check of
  `4b65fed`, see `docs/core-v0.1/STAGE6-PASS3-CHECKPOINT-3.2.md`. On Codex's
  Windows check of `c554cf8` the owner closed the technical review of
  checkpoint 3.2 with one open observation for the pass 4 failure matrix (a
  first checkout Pi-probe run failed with `database is locked`; cause not
  established, not fixed) and authorized only part 3.3, followed by a stop for
  review; part 3.3 is implemented as a development checkpoint, with one review
  correction after Codex's Windows check of `05e089e` (a formal conflict keeps
  its code through composite conditions), see
  `docs/core-v0.1/STAGE6-PASS3-CHECKPOINT-3.3.md`. On Codex's Windows check of
  `d251604` the owner closed the technical review of checkpoint 3.3 (the
  `stale_basis`-inside-`any` discrepancy stays a known question, not fixed) and
  authorized one package: parts 3.4 and 3.5 in sequence, followed by a stop for
  overall review; the package is implemented as a development checkpoint, with one
  correction after Codex's Windows check of `c11d54f` (recheck and waiver bases
  retired by structural dependency; `premise_changed` keeps its code through
  composite conditions), see `docs/core-v0.1/STAGE6-PASS3-CHECKPOINT-3.4-3.5.md`.
  On Codex's Windows check of `0af7034` the owner closed the technical review of the
  3.4–3.5 package and authorized one package: parts 3.6 and 3.7 in sequence (active
  plan revision, then transfer and fencing of running Attempts, with maintenance of the
  new data), followed by a stop for one overall review; the package is implemented as a
  development checkpoint, see `docs/core-v0.1/STAGE6-PASS3-CHECKPOINT-3.6-3.7.md`.
  The owner closed technical review of the complete 3.6–3.7 package at
  `98a61f20bf0eec06fa3e9e1501b35f0bb31b6ecc`, separately from acceptance;
  see `docs/core-v0.1/STAGE6-PASS3-REVIEW-3.6-3.7.md`. The owner authorized
  part 3.8 from that commit: exact Method transition through an active plan
  revision, obligation mapping, evidence recheck, Attempt transfer/fencing and
  data maintenance. Its development checkpoint is
  `docs/core-v0.1/STAGE6-PASS3-CHECKPOINT-3.8.md`. Codex's independent Windows
  review of `907a739` found three defects in active versus retired obligations,
  deletion of copied Method source text, and inherited origin of a new
  confirmation; all were corrected in part 3.8. Technical review 3.8 closed
  separately on `512fcd37accce339b487d006420e3e3ce2deec4f`; see
  `docs/core-v0.1/STAGE6-PASS3-REVIEW-3.8.md`. From that commit the owner
  authorized only part 3.9, nested composite Work and exact role Methods;
  its development checkpoint is
  `docs/core-v0.1/STAGE6-PASS3-CHECKPOINT-3.9.md`. The owner closed only its
  technical review on `73fffa7afb7bdfcc815938a132ab73d3955115e0`; see
  `docs/core-v0.1/STAGE6-PASS3-REVIEW-3.9.md`. Part 3.10 adds Pi visibility
  and a live synthetic localhost trace, documented in
  `docs/core-v0.1/STAGE6-PASS3-IMPLEMENTATION.md`. The owner closed its
  technical review separately on `4c9c8ece607bb58602c2573b9b23e8f60134470c`;
  see `docs/core-v0.1/STAGE6-PASS3-REVIEW-3.10.md`. The separate
  composite-parent execution slice was implemented as schema 8; its technical
  review closed at `2cd3cf8bd021be5584db4ea963799ec0fc2bc4f7`; see
  `docs/core-v0.1/STAGE6-PARENT-EXECUTION-REVIEW.md`. This is not schema 7,
  schema 8, pass 3 or Stage 6 acceptance. Pass 4 follows the working plan
  `docs/core-v0.1/STAGE6-PASS4-PLAN.md`. The owner closed technical review
  of package 1 on `6deaaf17d8432db629ddfd788589087e28a13c2c` after an
  independent 60-test scoped gate and three external crash scenarios. The owner
  authorized only package 2, the live DBOS/Pi windows. The owner separately
  closed its corrected technical review at `8468fae0e90e8002bfd1d0189c872e43ac711d03`:
  independent 45 scoped tests, one external recovery scenario and three live
  probes; the 700-test full gate belongs to implementation. See
  `docs/core-v0.1/STAGE6-PASS4-PACKAGE2-REVIEW.md`. The owner authorized only
  package 3, maintenance and release evidence, followed by one overall
  independent review. Package 3 evidence is
  `docs/core-v0.1/STAGE6-PASS4-PACKAGE3-RESULT.md`. Its technical review
  closed on `c8a546485e756afc2b0c5c99360e9ea2a42ae84d`; see
  `docs/core-v0.1/STAGE6-PASS4-PACKAGE3-REVIEW.md`. The owner separately
  accepted Stage 6 at that exact commit in the scope of `STAGE6-PLAN.md`;
  see `docs/core-v0.1/STAGE6-ACCEPTANCE.md`. This does not accept the whole
  Core or authorize development migration. One stabilization package for
  Core → DBOS → Pi is authorized, then stops for one independent review.
  `database is locked` and `rpc_transport` remain open observations until
  that investigation establishes a cause or an explicit evidence limit;
  `stale_basis` inside `any` remains outside this package.
- Earlier CALLs, ordered Works 1–8, M0/M1 plans and their acceptance records are
  retained as engineering history. They do not prohibit or define the new Core.
- Stage 1 stopped after recording the G07-1 DBOS and G08-1 Pi technical outcomes.
  Stage 2 delivered the independent domain foundation and was accepted by the
  owner at commit `62a173c7d9a875e6709bf2e0dbe0d8d7e7fa31df`. The owner
  accepted Stage 3 at `fa4c1773b0b4a8b75a03702be1e524cf8d5ea7a9`. The
  owner accepted the complete Stage 4 at
  `afa367c10ad949b1610810d4f2e6f106c1a7b7cc`, separately from accepting
  one synthetic Work; see `docs/core-v0.1/STAGE4-ACCEPTANCE.md`. The current
  owner accepted Stage 5 pass 1 at
  `03a3887f7d50aa1dccf8c761ce5bc933a57f86c9`; see
  `docs/core-v0.1/STAGE5-PASS1-ACCEPTANCE.md`. The owner accepted pass 2 at
  `b0b923bfb4c4b42e448b2a5a61dcc39dd3937c3e`; see
  `docs/core-v0.1/STAGE5-PASS2-ACCEPTANCE.md`. The owner accepted pass 3 at
  `8a34c09f342059e4cedc1011e81b83a4272fd289`;
  see `docs/core-v0.1/STAGE5-PASS3-ACCEPTANCE.md`. The owner accepted pass 4 and
  the complete Stage 5 at `245e7288c08eb4d49c84edd89f01e746a45c37a5`;
  see `docs/core-v0.1/STAGE5-ACCEPTANCE.md`. This is separate from accepting
  the synthetic Stage 5 Work.

## Product and instance boundary

Shared functionality and non-personal instructions belong in this source tree.
User Activity goals, access reports, instance paths/IDs, raw conversations and operational
receipts belong in the user's Core or selected private delivery copies, not public docs.
The package's integrations sit above the public foundation and below Pi/release.
Technical contracts are exact; user goals are open. GitHub is the changing context source
when available; an attached Project file is a fallback, never an obligatory duplicate.
Publication requires an explicit request naming the destination. Preserve local history
and parallel dirty work; do not publish private preparation branches merely to keep ancestry.

## Commands (run from this repository)
- Prepare: `uv sync --locked`
- Full build + hygiene + types + boundaries + tests: `uv run --locked python -m tools.check`
- File scoped: `uv run --locked python -m tools.check --files src/zaratustra/core/__init__.py`
- Deliver with report structure: `uv run --locked python -m tools.check --deliver`
- Install local hygiene hook after cloning: `git config core.hooksPath .githooks`
- A focused run is feedback, not full-delivery evidence. Do not claim green from individual tools.

## What exists

Related-material selections (0.25.5) keep schema 18. Exact typed relations and
full-history closure resolve Artifact, knowledge and structural anchors by
their actual family. Composition, rendering, opening and provider admission
share current rights/availability checks. Fragments stay bounded; subject prose
is not imported. Corrected membership may stale old selections without changing
saved bytes or Work input pins. See `docs/read-boundaries.md`; observed release
verification and owner acceptance remain separate.

Ordinary read boundaries (0.25.4) keep schema 18. Exact material readers span
Artifact and knowledge families without widening fragments. Runtime query inputs
are distinct from saved definition bindings; adapters default to literal text
search with explicit advanced FTS5. Native preparation preserves the first error
and fences automatic retry of an unknown send through its exact saved delivery.
See `docs/read-boundaries.md` and `docs/read-boundaries-audit-plan.md`; observed
verification and owner acceptance remain separate.

Ordinary selection correction (0.25.3) keeps schema
18. The owner approved one common Work/project/assigned-executor transition in
`docs/ordinary-work-selection-transition-plan.md`. A native pre-tool observation
retains the actual assistant entry and accounted invocation. Guarded Core
interruption precedes selection commit; assigned handoff detaches ordinary
execution. It cannot complete or accept Work. Release evidence is separate.

Procedure-resource correction (0.25.2) keeps schema 18. The coordinator consumes
the committed configured selection before considering fallback creation. Current
resource choice is rechecked after receipts; a revoked history cannot masquerade
as a successful choice. Legacy setup pins the actual active ID/revision. Core
continues to allow explicit multiple resources; single-root adapters refuse
ambiguity. Actual release evidence is separate from owner acceptance.

Owner-approved 0.25.1 client lifetime correction keeps schema 18. The existing Pi
bridge owns a checked idle query-only physical rw Core client until native HTTP
drain completes, under the existing session/maintenance fence. Each operation
retains its own current identity, rights and transaction admission; no snapshot,
write lock, queue or alternate authority is held. Native default FULL/checkpoint
policy is unchanged. See `docs/sqlite-client-lifecycle-plan.md`; actual evidence
and historical cause limits are reported separately from owner acceptance.

Single conversational ownership (0.25.0) keeps Core schema 18. Ordinary Pi tools
await addressed process boundaries; workers/status watchers cannot trigger a
completion conversation. Native progress and passive startup leave continuation
to the main agent. Known empty completed replies use two durable native repair
reservations with append-only context omission, exact Core terminal validation
and response-only tool/effect admission. Invocation pins and owner acceptance
remain separate. See `docs/single-conversation-owner-plan.md`; release evidence
is reported separately from owner acceptance.

The same 0.25.0 package implements the owner-approved completed assigned-response
recovery contract without changing schema 18. Exact retained terminal proof can
produce an honestly sourced proposed output while leaving the stopped Attempt
interrupted. Setup/workflow/procedure validators use it before dispatch. Missing
proof and unresolved earlier sends fence regeneration; genuine partial
publication preserves multi-slot continuation. See
`docs/completed-response-recovery-audit.md` and the release evidence.

Native response recovery (0.24.1) explicitly upgrades schema 17 to 18. Durable
delivery correlation preserves exact Work/Attempt/session identity through
content deletion; unresolved legacy evidence cannot claim no-send cleanup.
Exact typed terminal
assistant observations retain visible bytes before response classification.
Existing delivery operations/events/receipts derive response outcomes and a
two-correction bound; unknown sends are never empty-response retries. Whitespace
cannot acknowledge delivery or complete ordinary execution. Native boundary
continuation preserves host origin and exact proof; Work acceptance stays separate.
See `docs/conversation-response-recovery-plan.md`; release checks are reported
separately from owner acceptance.

Conversation continuation (0.24.0) explicitly upgrades Core 16 to 17. Current
setup, workflow and Work state derives addressed conversation actions; typed
delivery receipts record observed context inclusion and final replies, without
another execution graph. Native owner input and trusted host continuation have
separate origins. Work acceptance remains separate. See
`docs/conversation-continuation-plan.md`; release evidence is reported separately.

Workflow release work (0.23.0) explicitly upgrades Core 15 to 16. Definitions
instantiate native WorkPlan/Work/Attempt graphs; host waits, exact internal
validation, addressed user answers and version transfer use the same Core
operation/receipt authority. Internal continuation never accepts owner Work.
Activity creation is the first system workflow. Sleep retains its domain cursors
and change admission; exports remain a separate package. See docs/workflows.md.
Release checks and owner acceptance are reported separately.

Owner-authorized Activity structures (0.22.0) explicitly upgrade Core 14 to 15.
Finite DataFormat, versioned DataEntry and reviewed ActivityStructure use existing
knowledge/operation authority. Setup v2 reviews an exact compiled manifest.
Existing Activity adoption preserves identity and old Work pins. Durable procedure
intent/selection/Work use ordinary assigned Pi/DBOS; acceptance stays separate.
Export writers are outside this package. See `docs/activity-structures.md`.

Owner-authorized workspace separation (0.21.0) adds explicit local config v2,
registered project resources and exact private Git delivery. Core schema stays 14;
Core remains authoritative. Ordinary and assigned Pi use the chosen resource root.
Personal workspace, installed runtime and product source are separate. See
`docs/workspace.md`; old personal repositories are never automatically imported.

Owner-authorized Activity setup (0.20.0) explicitly upgrades schema 13 to 14.
A typed durable interview and exact full draft/review/correction cycle gates
activation of one new Activity; existing Candidate/adoption authority and separate
Work acceptance remain. The Pi window owns coordination over ordinary assigned
Pi/DBOS, at most five started review Work per explicitly continued run.
See `docs/activity-setup.md`.

Owner-authorized general-memory implementation (0.19.0) explicitly upgrades schema
12 to 13. It extends existing knowledge with optional typed organization, indexed
catalog/batch/history, durable exact selections, scoped cache checks and Markdown
export. Method requirements and Pi/integrations use the public Core; see
`docs/general-memory.md`. Existing versions/history and separate acceptance remain.
Python 3.13 / uv / sqlite3 / Pydantic v2 / pytest / ruff / SHA-256.
Core v0.1 Stage 2 adds the independent `zaratustra.foundation` package: a new empty
`.zara-core` space, typed Artifact/Decision/Grant revisions and managed bytes,
one atomic operation/audit/receipt path, current epoch-bound local admission, exact
reads, model-free inspection and bounded backup/restore/deletion. It does not import
legacy `zaratustra.core`; exact surface and reproduction are in
`docs/core-v0.1/STAGE2-IMPLEMENTATION.md` and `tools.probe_foundation`.
Stage 3 adds an explicit additive schema 2 upgrade, typed Activity/Work revisions,
separate write/accept rights, exact Artifact inputs and output slots, and a manual
acceptance operation. See `docs/core-v0.1/STAGE3-IMPLEMENTATION.md` and
`tools.probe_stage3`. A succeeded Work does not complete its Activity.
Stage 4 adds an ordinary interactive Pi path through `zaratustra.pi_adapter`,
schema 3 resource/Attempt/invocation records, observable provider sends, exact
output publication and separate Work acceptance. The owner accepted Stage 4 at
`afa367c10ad949b1610810d4f2e6f106c1a7b7cc`; see
`docs/core-v0.1/STAGE4-ACCEPTANCE.md` and `STAGE4-IMPLEMENTATION.md`. Stage 5
adds explicit schema 4 and Core-owned durable continuation, one assigned ordinary
Pi RPC through DBOS queue/wait, recovery and stop fencing, and shared maintenance
for Core/DBOS/Pi. See `docs/core-v0.1/STAGE5-IMPLEMENTATION.md` and
`STAGE5-ACCEPTANCE.md`.
Stage 6 pass 1 adds explicit schema 5 Method versions, composite Work plans,
materialized obligations, child issue and separate parent acceptance; see
`STAGE6-PASS1-IMPLEMENTATION.md`. Pass 2 adds explicit schema 6 child Attempt plan
pins, runs an issued child through the same assigned Pi RPC with Core rechecks
before every effect, and derives proposed/ready/running/waiting/blocked/succeeded
from Core records; see `STAGE6-PASS2-IMPLEMENTATION.md`. Pass 2 is owner-accepted
at `d33b676`. `STAGE6-PASS3-PLAN.md` divides pass 3 into parts 3.1–3.10. Checkpoint
3.1 adds explicit schema 7 and the subject Work outcomes failed/cancelled/stale
through `close_work`; see `STAGE6-PASS3-CHECKPOINT-3.1.md`. Checkpoint 3.2 runs
independent children at once, keeps an exclusive root single, names active and closed
branches by address (`branch_review`) and refuses integration needing a closed branch;
see `STAGE6-PASS3-CHECKPOINT-3.2.md`. Checkpoint 3.3 adds addressed Decision choices
(named value and one Work/Activity scope, never an access rule), obligations applicable
by a choice (`unresolved` until `resolve_obligation_applicability`), `decision_value`
leaves and formal `decision_conflict` of overlapping scopes, rechecked by every
dependent operation and derived state; see `STAGE6-PASS3-CHECKPOINT-3.3.md`. Checkpoint
3.4–3.5 adds an addressed exception (a Decision variant naming one requirement and exact
Method versions, never an access rule) and `waive_obligation` (`waived` apart from
`satisfied`, rechecked and named at acceptance), and at schema 7 `premise_changed` for an
accepted child result whose own inputs or readiness leaves changed, lifted only by an
exact `revalidate_result` stored in the new schema 7 table `result_revalidations`, kept
through composite conditions like a formal conflict; recheck bases go with any known
structural dependency; see `STAGE6-PASS3-CHECKPOINT-3.4-3.5.md`. Checkpoint 3.6–3.7 adds
`revise_active_plan` (`zaratustra.foundation.active_plan`): a started plan gets revision
N+1 only with an explicit decision per node (keep/replace/cancel/stale/release/add); a
kept issued node carries its issue after a recheck, leaving nodes get their outcome, an
obligation whose evidence Work left the role reopens (`node_replaced`), and address-only
schema 7 tables keep members, node decisions and role history (`read_plan_nodes`,
`read_role_history`). An active Attempt of a kept node continues through an explicit
transfer (`execution_plan_transfers`); every other Attempt is fenced (`stale_plan`, a late
answer to a closed wait `stale_wait`); see `STAGE6-PASS3-CHECKPOINT-3.6-3.7.md`.
The closed review correction sanitizes plan text addressing a departed Work and
keeps replacement evidence and outcome bases independent of the former role
filler. Part 3.8 adds exact Method transition via the active plan revision,
obligation mapping, evidence recheck, Attempt transfer/fencing and maintenance;
see `STAGE6-PASS3-CHECKPOINT-3.8.md`. Part 3.9 is implemented as a development
checkpoint, with technical review closed at `73fffa7`; see
`STAGE6-PASS3-REVIEW-3.9.md`. Part 3.10 is implemented, with technical review
closed at `4c9c8ec`; see `STAGE6-PASS3-IMPLEMENTATION.md` and
`STAGE6-PASS3-REVIEW-3.10.md`. The separate parent-execution slice is
implemented and its technical review closed at `2cd3cf8`; see
`STAGE6-PARENT-EXECUTION-REVIEW.md`. Pass 4 packages 1 and 2 have separate
closed technical reviews; package 3 is the authorized maintenance/release
checkpoint under `STAGE6-PASS4-PLAN.md` and
`STAGE6-PASS4-PACKAGE3-RESULT.md`.
Work 1 implements installed `zara init` / `zara status`, SQLite bootstrap
metadata and explicit migration v1. Work 2 adds explicit `zara migrate` to schema 2,
initial draft records and consistent `zara records read`. Work 3 adds schema 3,
one mutation API, exact local confirmation, atomic audit/receipts and current rights.
Work 4 adds explicit schema 4, exact scoped versioned artifact publication/repair,
verified content reads and deterministic owner-local projection rebuild.
Work 5 adds explicit schema 5 and exact accepted-result Handoff import from file/stdin,
with separate trusted console confirmation and durable acceptance/provenance reads.
Work 6 adds read-only open_work with exact trusted query, bounded actual manifest,
scope/reference closure and full final revalidation. Work7 adds explicit schema6,
atomic Result/completion/next Work and exact inherited context; Work8 is unimplemented.
M1 T2 adds explicit schema7 and exact immutable Process/Work pack binding through
Mutation API, external runtime registration/resolution and pinned continuation.
Missing/incompatible packs refuse package execution; no in-place version migration.
Technical plan and lifecycle reproduction: docs/m1-packs/PLAN.md and tools.probe_packs.
M1 T3 adds seven derived read capabilities through process_packs.read_capabilities,
exact metadata ProcessQuery scope, one locked revision and separately authorized
selected ContextQuery. Public API and reproduction: docs/m1-capabilities/PLAN.md,
tools.probe_capabilities. T4 adds one finite fictional_lot Process using those exact
contracts; reproduce via tools.probe_first_process and docs/m1-first-process/PLAN.md.
Core and generic process_packs bytes are unchanged. T5 adds development-only
fictional_signal (observe/compare rounds), a shared host and two-process/install
scenarios; see docs/m1-second-process/PLAN.md. T5 passed its full native gate and
binding fresh review (f4e3a26, then fa4e079: 235 tests, 11 contracts); the owner
accepted that step as owner-ack:solmax-m1-second-process-accepted-20260910.
T6 adds process_packs.read_overview: one derived shared view of several explicitly
selected Processes through that same seven-answer contract, with overview_lines and
tools.probe_overview; see docs/m1-overview/PLAN.md. Rows stay independent and the
view writes nothing. T6's owner acceptance and five review rounds are recorded in
RESULT.md at baseline d7304c9. M1 was accepted in the Direction review on
September 11, 2026; this does not establish end-user process creation or daily use.
T4 candidate 46718e4 passed fresh G5 (9c9c978); owner
accepted its testing purpose and requires fictional examples only in dev tests.
T1/T4 examples live in tests/fixtures, outside the installed product. Reproduction
tools explicitly load those external fixtures. See docs/m1-test-only/PLAN.md and
OWNER-DECISION.md there; the earlier G5 does not review later packaging changes.
Entry T4 adds one recoverable exact external-material transfer around the existing
publication/acceptance seam, with coordinator journal/lock and authorized Core
receipt recovery; see docs/entry-t4/PLAN.md and tools.probe_entry_t4.
Entry T5 adds the modest installed first-use coordinator and designation-based
context/manual external-chat request/return path; see docs/entry-t5/PLAN.md and
tools.probe_entry_t5. It uses generic unbound Core records and existing mutations.
Public onboarding R2 T1 adds explicit schema8, Process-owned material and terminal
Result without a continuation. R2 T2 adds explicit schema9, truthful common Process
current-or-no-current read with explicit ambiguous-many refusal, and a separately
authorized Pack-compatible ordinary Work creation event; see
docs/public-onboarding-r2-t2/PLAN.md.
Public onboarding R2 T3 adds the installed common `zara entry` prose/resume/change
composition and one recoverable explicit later-Work plan over those existing
authorities; see docs/public-onboarding-r2-t3/PLAN.md and
tools.probe_public_onboarding_r2_t3.
`src/zaratustra/core` owns workspace logic; `src/zaratustra/cli` delegates to it.
Installed product code and user-chosen data workspace are separate.
For legacy implementation context only, the last pre-v0.1 mechanics and W19–W27
disposition are in docs/work7/PLAN.md.
W21 owner trust decision: docs/work3/OWNER-DECISION-20260908.md.
Outside-checkout runtime proof: `uv run --locked python -m tools.probe_install`.
Work 2 installed/migration proof: `uv run --locked python -m tools.probe_records --accepted-trial <path>`.

## Run contract (v36)
1. Execution authority is the current owner request + `docs/core-v0.1/IMPLEMENTATION-BASELINE.md` + the applicable Stage plan + this AGENTS.md + validation.config; global skills/tools are support and never add requirements.
2. PROBA is the default; only the owner's explicit words select OPORA. This repo enables PROBA only; an OPORA CALL STOPs until its applicable gates are installed.
3. PROBA keeps native build/hygiene, tests for answers not visible by eye, owner/tool STOPs; it owes no frozen pair, independent test-author, stage receipts, mutation, property audit or review artifact.
4. Never use self-written source scanning as product behavior evidence. Hygiene/presence checks below make no semantic acceptance claim. Never test tuning magnitudes or an owner-visible answer.
5. An unavailable REQUIRED tool STOPs by name. A real owner-owned choice or plan divergence goes to the owner; no silent scope cuts. Retry at most 3 times per failed gate, then ESCALATE.
6. Completion in PROBA comes from the owner's words, never tasks/ledger checkboxes. Record actual checks separately from owner acceptance; adding tests beside frozen files is legal, editing frozen bytes is not.
7. Engineering REPORT/ESCALATE returns HOME: `RESULT.md` fields outcome/evidence/assumptions/cuts/cost/manual-acceptance/next; `next: solmax`. Only Direction issues Direction CALLs; never edit Direction OS.
8. OPORA requires independent contract-author/build/review sessions and the CALL-pinned gate surface before BUILD; subagent smoke checks here are not binding fresh Direction G5.
9. Read `STOP` / `STEER.md` before mutation and commands. STOP means halt; read and resolve STEER with the owner's intent, without auto-deleting either.
10. Setup verification includes one bounded read-only evaluator smoke agent; otherwise delegate only when the CALL or owner explicitly asks. Inherited model defaults; no provider identity gate.

## Owner scope — 2026-09-07
CI/CD, GitHub Actions and push notifications are excluded requirements until the owner separately asks. Do not configure them or block setup/delivery on their absence, even if a generic checklist requires them. The owner authorized public GitHub hosting and integration into main on September 11–12, 2026; local checks stay required. That authorization does not grant access to user workspaces or authorize paid services. The original automation boundary remains docs/setup/OWNER-DECISION-20260907.md, owner-ack:solmax-zaratustra-local-setup-no-automation-20260907.

## Constitution
- Keep the accepted Core v0.1 functional composition and completed Stage 1–5
  evidence. Stage 6 is owner-accepted only in the scope of `STAGE6-PLAN.md`
  at exact `c8a5464`; pass 4 package 3 technical closure and Stage 6
  acceptance have separate records. This does not accept the whole Core or
  authorize development migration. The current stabilization package covers
  the two open SQLite/RPC observations and stops for one independent review.
  Preserve the known `stale_basis`-inside-`any` discrepancy outside this work.
  Preserve earlier Works/CALLs as history, not current scope.
- CLI calls Core through public module surfaces; Core never imports CLI.
- No product writes to Direction OS, old repositories, or unselected user workspaces.
- No real personal data, remote publication, paid service or new external rights without authorization.
- No direct DB/state Markdown edits to fake product success.
- Reuse small native tools before adding infrastructure.

## Conventions
- Managed Python pinned in .python-version; tools pinned in pyproject.toml, dependencies in uv.lock.
- One installable top-level package with nested modules; add new modules to import-linter contracts.
- Cross-module imports use public __init__.py. Add nearest-file AGENTS.md with every module.
- tests/zaratustra mirrors the package; tests/tools mirrors development-only tools/.
- Tests outside tests/, skip/xfail, assertion-free tests, non-portable literals fail hygiene.
- Explorations stay in _scratch/; its content is ignored and tracked scratch content blocks the local commit hook/check.
- The hook runs hygiene only. The full check remains required; its report gate checks presence, never truth.
- Sources use LF. Runtime paths use pathlib; subprocess text capture declares UTF-8.
- REVIEW.md and validation.config changes require explicit owner request or repeated recorded friction.
- Denied actions: force-push, destructive Git reset/clean, deleting unrelated files, reading secrets, edits outside authorized product scope.
- Inherited desktop permissions remain authoritative; repo config does not weaken managed restrictions.

END_OF_FILE: AGENTS.md
