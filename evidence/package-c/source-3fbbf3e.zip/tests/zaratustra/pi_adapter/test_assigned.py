"""Assigned bridge and managed technical-state boundaries without a model service."""

from __future__ import annotations

import io
import json
import pickle
import secrets
import shutil
import sqlite3
import subprocess
import sys
import threading
import time
from contextlib import closing
from pathlib import Path
from typing import cast
from uuid import UUID, uuid4, uuid5

import pytest
from dbos import DBOS, DBOSClient

import zaratustra.foundation.storage as storage
import zaratustra.pi_adapter.assigned as assigned_module
from tests.zaratustra.foundation.test_activity_setup import _step
from tests.zaratustra.foundation.test_activity_setup_recovery import _recovery_case, _start
from tests.zaratustra.foundation.test_child_execution import _claim, _stop
from tests.zaratustra.foundation.test_continuation import ready
from zaratustra.foundation import (
    ALL_ACTIONS,
    AdmitInvocationRequest,
    AssignAttemptRequest,
    ClaimAttemptLaunchRequest,
    CreateGrantRequest,
    CreateResourceRequest,
    CreateWorkRequest,
    DeleteActivityRequest,
    DeleteArtifactRequest,
    DeleteWorkRequest,
    FinishInvocationRequest,
    FoundationError,
    GrantState,
    LocalAuthority,
    OutputContract,
    PrepareInvocationRequest,
    RecordAttemptStopRequest,
    RecoverRequest,
    RequestAttemptStopRequest,
    ResourceState,
    RevokeGrantRequest,
    SendInvocationRequest,
    WorkState,
    apply_operation,
    authorize_local,
    authorize_recovery,
    complete_deletions,
    create_backup,
    inspect_space,
    list_activity_setups,
    managed_executor_start_lock,
    managed_pi_lock,
    managed_pi_session_lock,
    read_activity_setup,
    read_artifact,
    read_assigned_control,
    read_context_delivery,
    read_execution,
    read_knowledge,
    read_technical_deletion_targets,
    read_work,
    restore_backup,
)
from zaratustra.pi_adapter import Bridge, BridgeServer
from zaratustra.pi_adapter.assigned import (
    EXECUTOR_VERSION,
    PI_VERSION,
    WORKFLOW_NAME,
    AssignedConfig,
    _purge_technical_data,
    _record_stop,
    _rpc_line_with_stop,
    _terminate_pi,
    _watch_core_stop,
    complete_assigned_deletions,
    create_assigned_backup,
    deliver_outbox,
    resolve_assigned_work,
    run_assigned,
)


def assigned(tmp_path: Path) -> tuple[Path, Path, UUID, UUID, UUID, UUID]:
    root, workspace, space_id, _, work_id, resource_id = ready(tmp_path)
    authority = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    attempt_id, session_id = uuid4(), uuid4()
    apply_operation(
        root,
        AssignAttemptRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            attempt_id=attempt_id,
            work_id=work_id,
            expected_work_revision=1,
            resource_id=resource_id,
            expected_resource_revision=1,
            session_id=session_id,
            executor_version=EXECUTOR_VERSION,
        ),
        authority,
    )
    return root, workspace, space_id, work_id, attempt_id, session_id


def test_assigned_bridge_saves_partial_question_and_one_addressed_answer(tmp_path: Path) -> None:
    root, workspace, _, work_id, attempt_id, session_id = assigned(tmp_path)
    authority = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    activity_id = read_execution(root, work_id, authority).activity.activity_id
    rpc = Bridge(
        root,
        authority,
        workspace,
        100,
        assigned_attempt_id=attempt_id,
        assigned_session_id=session_id,
    )
    rpc.connect(session_id)
    rpc.select(session_id, activity_id, work_id)
    with pytest.raises(FoundationError, match="unknown_session"):
        rpc.connect(uuid4())
    with pytest.raises(FoundationError, match="permission_denied"):
        rpc.start_attempt(session_id, interrupt_previous=False)
    wait_id = uuid4()
    rpc.open_wait(session_id, attempt_id, wait_id, "Partial fiction", "Which code?", "Add code")
    snapshot = read_execution(root, work_id, authority)
    wait = snapshot.waits[0]
    assert wait.status == "open" and wait.remainder == "Add code"
    assert (
        read_artifact(root, wait.partial_refs[0].artifact_id, authority).content
        == b"Partial fiction"
    )
    interactive = Bridge(root, authority, workspace, 100)
    user_session = uuid4()
    interactive.connect(user_session)
    interactive.select(user_session, activity_id, work_id)
    visible_waits = cast(list[dict[str, object]], interactive.snapshot(user_session)["waits"])
    assert visible_waits[0]["question"] == "Which code?"
    first = interactive.answer_wait(user_session, wait_id, "Code A")
    assert interactive.answer_wait(user_session, wait_id, "Code A") == first
    with pytest.raises(FoundationError, match="stale_wait"):
        interactive.answer_wait(user_session, wait_id, "Code B")
    after = read_execution(root, work_id, authority)
    assert [item.kind for item in after.outbox] == ["launch", "resume"]
    assert after.assignments[0].status == "ready"


def test_assigned_rpc_prompt_is_not_a_new_owner_answer(tmp_path: Path) -> None:
    """Risk: a coordinator's RPC instructions masquerade as fresh owner answers."""
    root, workspace, _, work, attempt, session = assigned(tmp_path)
    owner = authorize_local(root, actor="owner", source_ref="fictional-local-console")
    interactive = Bridge(root, owner, workspace)
    local_session = uuid4()
    interactive.connect(local_session)
    interactive.knowledge_upgrade(local_session)
    rpc = Bridge(root, owner, workspace, assigned_attempt_id=attempt, assigned_session_id=session)
    rpc.connect(session)
    rpc.select(session, read_execution(root, work, owner).activity.activity_id, work)
    rpc.capture_source(
        session,
        channel="conversation_user",
        content="Perform assigned work",
        source_event_id="coordinator-input",
        input_source="rpc",
    )
    source = read_knowledge(root, rpc.last_sources[session].record_id, owner).state
    assert source is not None and source.kind == "source" and source.sender == "pi-rpc"
    with pytest.raises(FoundationError) as error:
        rpc._fresh_user_source(session)
    assert error.value.code == "permission_denied"


def test_concurrent_pi_locks_exclude_deletion_maintenance(tmp_path: Path) -> None:
    root, _, _, _, _, _ = assigned(tmp_path)
    with managed_pi_session_lock(root), managed_pi_session_lock(root):
        with pytest.raises(FoundationError, match="history_busy"):
            with managed_pi_lock(root):
                raise AssertionError("Maintenance must not enter while Pi is active")
    with managed_pi_lock(root):
        assert root.is_dir()


def test_executor_start_serializes_processes_without_serializing_sessions(tmp_path: Path) -> None:
    root, _, _, _, _, _ = assigned(tmp_path)
    ready_file = tmp_path / "child-ready"
    script = (
        "from pathlib import Path\n"
        "from zaratustra.foundation import managed_executor_start_lock\n"
        "import sys\n"
        "Path(sys.argv[2]).write_text('ready', encoding='utf-8')\n"
        "with managed_executor_start_lock(Path(sys.argv[1])):\n"
        "    print('acquired', flush=True)\n"
    )
    with managed_pi_session_lock(root), managed_executor_start_lock(root):
        process = subprocess.Popen(
            [sys.executable, "-c", script, str(root), str(ready_file)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
        )
        try:
            deadline = time.monotonic() + 10
            while not ready_file.is_file() and time.monotonic() < deadline:
                assert process.poll() is None
                time.sleep(0.01)
            assert ready_file.is_file()
            time.sleep(0.1)
            assert process.poll() is None
        finally:
            if process.poll() is not None:
                process.communicate(timeout=10)
    stdout, stderr = process.communicate(timeout=10)
    assert process.returncode == 0, stderr
    assert stdout.strip() == "acquired"


def test_assigned_launch_delivery_and_backup_share_maintenance_boundary(
    tmp_path: Path, dbos_template: Path
) -> None:
    root, workspace, _, _, attempt_id, _ = _managed_space(tmp_path, dbos_template)
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    config = AssignedConfig(
        space=root,
        workspace=workspace,
        pi_cli=tmp_path / "unused-pi.js",
        pi_runtime=tmp_path / "unused-runtime",
        node="node",
        provider_profile="local-completions",
        provider_base_url="http://127.0.0.1:9/v1",
        provider_id="synthetic",
        model_id="synthetic",
        context_window=4096,
        max_tokens=512,
        reserve_units=10,
        limit_units=100,
    )
    with managed_pi_lock(root):
        with pytest.raises(FoundationError, match="history_busy"):
            deliver_outbox(root, owner)
        with pytest.raises(FoundationError, match="history_busy"):
            run_assigned(config, owner, attempt_id)
    with managed_pi_session_lock(root):
        with pytest.raises(FoundationError, match="history_busy"):
            create_assigned_backup(root, uuid4(), owner)
    with pytest.raises(FoundationError, match="maintenance_boundary"):
        create_backup(root, uuid4(), owner)
    assert inspect_space(root, owner).completed_backups == 0
    backup = create_assigned_backup(root, uuid4(), owner)
    assert backup.manifest.format_version == 2
    assert backup.manifest.technical_versions is not None
    assert backup.manifest.technical_versions.executor == EXECUTOR_VERSION


def test_dbos_writer_blocks_backup_without_publishing_partial_package(
    tmp_path: Path, dbos_template: Path
) -> None:
    root, _, _, _, attempt_id, _ = _managed_space(tmp_path, dbos_template)
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    copy = _managed_copy(root, attempt_id, "Synthetic retained data")
    database = root / ".zara-core" / "executor.sqlite3"
    with closing(sqlite3.connect(database, timeout=0.1)) as writer:
        writer.execute("BEGIN IMMEDIATE")
        with pytest.raises(FoundationError) as refused:
            create_assigned_backup(root, uuid4(), owner)
        assert refused.value.code == "maintenance_busy"
        writer.rollback()
    assert copy.read_text(encoding="utf-8") == "Synthetic retained data"
    assert inspect_space(root, owner).completed_backups == 0
    assert create_assigned_backup(root, uuid4(), owner).package.is_dir()


def test_dbos_writer_blocks_deletion_before_technical_payload_is_removed(
    tmp_path: Path, dbos_template: Path
) -> None:
    root, _, space_id, work_id, attempt_id, _ = _managed_space(tmp_path, dbos_template)
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    deliver_outbox(root, owner)
    copy = _managed_copy(root, attempt_id, "Synthetic retained data")
    _delete_work(root, space_id, work_id)
    database = root / ".zara-core" / "executor.sqlite3"
    with closing(sqlite3.connect(database, timeout=0.1)) as writer:
        writer.execute("BEGIN IMMEDIATE")
        with pytest.raises(FoundationError) as refused:
            complete_assigned_deletions(root, owner)
        assert refused.value.code == "maintenance_busy"
        writer.rollback()
    assert copy.read_text(encoding="utf-8") == "Synthetic retained data"
    assert inspect_space(root, owner).pending_deletions == 1
    assert len(_workflows(root)) == 1
    assert complete_assigned_deletions(root, owner).live_store_sanitized
    assert not copy.exists()


@pytest.mark.parametrize("corrupt_address", (False, True))
def test_workflow_setup_deletion_cleans_grouped_packets_and_assigned_state(
    tmp_path: Path, dbos_template: Path, corrupt_address: bool
) -> None:
    """Several derived packets share a creation operation but all need exact cleanup."""
    case = _recovery_case(tmp_path, 16)
    root, space, owner, setup, activity, *_ = case
    _start(case)
    stage = read_activity_setup(root, setup, owner).state.stages[-1]
    resource = uuid4()
    apply_operation(
        root,
        CreateResourceRequest(
            operation_id=uuid4(),
            space_id=space,
            actor="owner",
            work_id=stage.work_id,
            resource_id=resource,
            state=ResourceState(label="Fictional setup", root=root, mode="shared"),
        ),
        owner,
    )
    attempt, session = uuid4(), uuid4()
    apply_operation(
        root,
        AssignAttemptRequest(
            operation_id=uuid4(),
            space_id=space,
            actor="owner",
            attempt_id=attempt,
            work_id=stage.work_id,
            expected_work_revision=read_work(root, stage.work_id, owner).revision,
            resource_id=resource,
            expected_resource_revision=1,
            session_id=session,
            executor_version=EXECUTOR_VERSION,
        ),
        owner,
    )
    shutil.copyfile(dbos_template, root / ".zara-core" / "executor.sqlite3")
    deliver_outbox(root, owner)
    _claim(root, space, owner, stage.work_id, attempt, session)
    copy = _managed_copy(root, attempt, "Fictional setup context")
    assert len(_workflows(root)) == 1
    protected = {
        row.record_id: read_work(root, row.record_id, owner)
        for row in inspect_space(root, owner).records
        if row.kind == "work"
        and read_work(root, row.record_id, owner).state.activity_id != activity
    }
    works = {
        row.record_id
        for row in inspect_space(root, owner).records
        if row.kind == "work" and row.record_id not in protected
    }
    with sqlite3.connect(root / ".zara-core" / "core.sqlite3") as connection:
        grouped = connection.execute(
            "SELECT r.operation_id,count(DISTINCT r.record_id) FROM record_revisions r "
            "JOIN workflow_edges e ON e.target_id=r.record_id AND e.target_revision=r.revision "
            "WHERE e.role IN ('packet','output','obstacle') GROUP BY r.operation_id "
            "HAVING count(DISTINCT r.record_id)>1"
        ).fetchall()
    assert grouped, "The fixture must retain the real shared-origin packets"
    _step(case, "cancel")
    _stop(root, space, owner, stage.work_id, attempt, session)
    remaining = set(works)
    while remaining:
        rows = {row.record_id: row for row in inspect_space(root, owner).records}
        for identifier in sorted(remaining, key=str):
            try:
                apply_operation(
                    root,
                    DeleteWorkRequest(
                        operation_id=uuid4(),
                        space_id=space,
                        actor="owner",
                        work_id=identifier,
                        expected_revision=rows[identifier].current_revision,
                    ),
                    owner,
                )
            except FoundationError as error:
                if error.code == "dependent_work":
                    continue
                raise
            remaining.remove(identifier)
            break
        else:
            raise AssertionError("The owned Work family must be deletable leaves first")
    row = next(row for row in inspect_space(root, owner).records if row.record_id == activity)
    apply_operation(
        root,
        DeleteActivityRequest(
            operation_id=uuid4(),
            space_id=space,
            actor="owner",
            activity_id=activity,
            expected_revision=row.current_revision,
        ),
        owner,
    )
    with sqlite3.connect(root / ".zara-core" / "core.sqlite3") as connection:
        jobs = connection.execute(
            "SELECT j.operation_id,j.record_id,e.detail_json FROM deletion_jobs j "
            "JOIN maintenance_events e ON e.event_id=j.operation_id WHERE j.status='pending'"
        ).fetchall()
        grouped_jobs = [
            (operation, identifier, json.loads(detail))
            for operation, identifier, detail in jobs
            if operation in {value[0] for value in grouped}
        ]
        assert grouped_jobs
        assert all(
            {"work_id": str(stage.work_id), "attempt_id": str(attempt)} in detail["assigned"]
            for _, _, detail in grouped_jobs
        )
        for operation, _, _ in grouped_jobs:
            assert (
                connection.execute(
                    "SELECT count(*) FROM managed_content m JOIN record_revisions r "
                    "ON r.record_id=m.record_id AND r.revision=m.revision WHERE r.operation_id=?",
                    (operation,),
                ).fetchone()[0]
                == 0
            )
        assert all(
            json.loads(detail)["artifact_id"] == identifier for _, identifier, detail in jobs
        )
    targets = read_technical_deletion_targets(
        root, owner, tuple(UUID(identifier) for _, identifier, _ in jobs)
    )
    assert attempt in targets.attempt_ids
    if corrupt_address:
        operation, _, detail = jobs[0]
        invalid = json.loads(detail)
        invalid["artifact_id"] = str(uuid4())
        with sqlite3.connect(root / ".zara-core" / "core.sqlite3") as connection:
            connection.execute(
                "UPDATE maintenance_events SET detail_json=? WHERE event_id=?",
                (json.dumps(invalid), operation),
            )
        with pytest.raises(FoundationError) as refused:
            complete_assigned_deletions(root, owner)
        assert refused.value.code == "technical_state"
        assert copy.exists() and _workflows(root)
        assert {
            identifier: read_work(root, identifier, owner) for identifier in protected
        } == protected
        return
    result = complete_assigned_deletions(root, owner)
    assert result.live_store_sanitized and result.pending_jobs == 0
    assert not copy.exists() and not _workflows(root)
    assert not any(item.setup_id == setup for item in list_activity_setups(root, owner))
    assert {identifier: read_work(root, identifier, owner) for identifier in protected} == protected
    assert complete_assigned_deletions(root, owner).pending_jobs == 0


def test_composite_restore_preserves_question_usage_and_unknown(
    tmp_path: Path, dbos_template: Path
) -> None:
    root, workspace, space_id, work_id, attempt_id, session_id = _managed_space(
        tmp_path, dbos_template
    )
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    invocation_id = uuid4()
    apply_operation(
        root,
        PrepareInvocationRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            purpose="content",
            provider="local",
            model="synthetic",
            transport="http-sse",
            request_sha256="A" * 64,
            request_bytes=12,
            reserve_units=20,
            invocation_id=invocation_id,
            attempt_id=attempt_id,
            work_id=work_id,
            session_id=session_id,
        ),
        owner,
    )
    apply_operation(
        root,
        AdmitInvocationRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            invocation_id=invocation_id,
            attempt_id=attempt_id,
            work_id=work_id,
            session_id=session_id,
        ),
        owner,
    )
    apply_operation(
        root,
        SendInvocationRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            invocation_id=invocation_id,
            attempt_id=attempt_id,
            work_id=work_id,
            session_id=session_id,
        ),
        owner,
    )
    apply_operation(
        root,
        FinishInvocationRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            outcome="answered",
            usage_units=7,
            http_status=200,
            invocation_id=invocation_id,
            attempt_id=attempt_id,
            work_id=work_id,
            session_id=session_id,
        ),
        owner,
    )
    rpc = Bridge(
        root, owner, workspace, 100, assigned_attempt_id=attempt_id, assigned_session_id=session_id
    )
    rpc.connect(session_id)
    rpc.select(session_id, read_execution(root, work_id, owner).activity.activity_id, work_id)
    rpc.open_wait(session_id, attempt_id, uuid4(), "Synthetic partial", "Which code?", "Add code")
    waiting = read_execution(root, work_id, owner)
    apply_operation(
        root,
        RequestAttemptStopRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            work_id=work_id,
            attempt_id=attempt_id,
            session_id=session_id,
            expected_assignment_revision=waiting.assignments[0].revision,
            reason="Synthetic process outcome is uncertain",
        ),
        owner,
    )
    stopped = read_execution(root, work_id, owner)
    apply_operation(
        root,
        RecordAttemptStopRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            work_id=work_id,
            attempt_id=attempt_id,
            session_id=session_id,
            expected_assignment_revision=stopped.assignments[0].revision,
            outcome="unknown",
        ),
        owner,
    )
    backup = create_assigned_backup(root, uuid4(), owner)
    destination = tmp_path / "restored"
    destination.mkdir()
    recovery = authorize_recovery(actor="owner", source_ref="synthetic-recovery")
    restored = restore_backup(backup.package, destination, recovery)
    assert restored.recovery_state == "quarantined" and restored.execution_epoch == 2
    with pytest.raises(FoundationError, match="permission_denied"):
        read_execution(destination, work_id, owner)
    apply_operation(
        destination,
        RecoverRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            decision_id=uuid4(),
            grant_id=uuid4(),
        ),
        recovery,
    )
    new_owner = authorize_local(destination, actor="owner", source_ref="synthetic-new-epoch")
    snapshot = read_execution(destination, work_id, new_owner)
    assert snapshot.assignments[0].status == "unknown"
    assert snapshot.waits[0].question == "Which code?"
    assert snapshot.waits[0].remainder == "Add code"
    assert snapshot.committed_units == 7 and snapshot.held_units == 0
    assert snapshot.invocations[0].status == "answered"
    assert not (destination / ".zara-core" / "executor.sqlite3").exists()
    assert (destination / ".zara-core" / "executor-restored.sqlite3").is_file()
    resource = snapshot.resources[0]
    with pytest.raises(FoundationError, match="resource_busy"):
        apply_operation(
            destination,
            AssignAttemptRequest(
                operation_id=uuid4(),
                space_id=space_id,
                actor="owner",
                attempt_id=uuid4(),
                work_id=work_id,
                expected_work_revision=snapshot.work.revision,
                resource_id=resource.resource_id,
                expected_resource_revision=resource.revision,
                session_id=uuid4(),
                previous_attempt_id=attempt_id,
                executor_version=EXECUTOR_VERSION,
            ),
            new_owner,
        )


def test_technical_backup_is_hashed_restored_inert_and_blocks_bare_cleanup(tmp_path: Path) -> None:
    root, _, space_id, work_id, _, _ = assigned(tmp_path)
    authority = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    state = root / ".zara-core"
    executor = state / "executor.sqlite3"
    with sqlite3.connect(executor) as connection:
        connection.execute("CREATE TABLE synthetic (value TEXT NOT NULL)")
        connection.execute("INSERT INTO synthetic(value) VALUES ('fictional')")
    home = state / "pi-rpc-home" / str(uuid4())
    home.mkdir(parents=True)
    (home / "synthetic.txt").write_text("fictional\n", encoding="utf-8", newline="\n")
    backup = create_assigned_backup(root, uuid4(), authority)
    assert backup.manifest.executor_sha256 is not None
    assert len(backup.manifest.pi_rpc_home_files) == 1
    restored_root = tmp_path / "restored"
    restored_root.mkdir()
    restored = restore_backup(
        backup.package,
        restored_root,
        authorize_recovery(actor="owner", source_ref="synthetic-recovery-console"),
    )
    assert restored.execution_epoch == 2 and restored.recovery_state == "quarantined"
    assert (restored_root / ".zara-core" / "executor-restored.sqlite3").is_file()
    assert not (restored_root / ".zara-core" / "executor.sqlite3").exists()
    revision = read_execution(root, work_id, authority).work.revision
    apply_operation(
        root,
        DeleteWorkRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            work_id=work_id,
            expected_revision=revision,
        ),
        authority,
    )
    with pytest.raises(FoundationError, match="technical_cleanup_required"):
        complete_deletions(root, authority)


@pytest.fixture(scope="module")
def dbos_template(tmp_path_factory: pytest.TempPathFactory) -> Path:
    database = tmp_path_factory.mktemp("assigned-dbos") / "executor.sqlite3"
    DBOS(
        config={
            "name": "zaratustra-assigned-rpc",
            "system_database_url": f"sqlite:///{database.resolve().as_posix()}",
            "application_version": EXECUTOR_VERSION,
        }
    )
    DBOS.launch()
    DBOS.destroy(destroy_registry=True, workflow_completion_timeout_sec=1)
    with sqlite3.connect(database) as connection:
        connection.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchall()
    return database


def _managed_space(
    tmp_path: Path, dbos_template: Path
) -> tuple[Path, Path, UUID, UUID, UUID, UUID]:
    root, workspace, space_id, work_id, attempt_id, session_id = assigned(tmp_path)
    shutil.copyfile(dbos_template, root / ".zara-core" / "executor.sqlite3")
    return root, workspace, space_id, work_id, attempt_id, session_id


def _pending_local_route(root: Path, work_id: UUID, attempt_id: UUID, owner: LocalAuthority) -> str:
    """Create the predecessor's addressed PENDING/local DBOS record without SQL edits."""

    entry = read_execution(root, work_id, owner).outbox[0]
    database = root / ".zara-core" / "executor.sqlite3"
    workflow_id = f"zara-{uuid5(attempt_id, 'launch')}"
    route = f"zara-assigned-rpc-{attempt_id}"
    source = """
import os
import sys
import time
from dbos import DBOS, DBOSClient

url, version, route, workflow_id, work_id, attempt_id, outbox_id, epoch, generation = sys.argv[1:]
DBOS(config={"name": "zaratustra-assigned-rpc", "system_database_url": url,
             "application_version": version, "executor_id": "local"})
@DBOS.workflow(name="zara-assigned-work-v1")
def crash_before_claim(*_args):
    os._exit(90)
DBOS.listen_queues([route])
DBOS.launch()
DBOS.register_queue(route, worker_concurrency=1)
client = DBOSClient(system_database_url=url, application_name="zaratustra-assigned-rpc",
                    retry_connection_errors=False)
client.enqueue({"workflow_name": "zara-assigned-work-v1", "queue_name": route,
                "workflow_id": workflow_id, "app_version": version,
                "deduplication_id": outbox_id, "duplication_policy": "return-existing",
                "attributes": {"work_id": work_id, "attempt_id": attempt_id}},
               work_id, attempt_id, int(epoch), int(generation))
client.destroy()
time.sleep(20)
raise SystemExit(1)
"""
    created = subprocess.run(
        [
            sys.executable,
            "-c",
            source,
            f"sqlite:///{database.resolve().as_posix()}",
            f"{EXECUTOR_VERSION}-{attempt_id}",
            route,
            workflow_id,
            str(work_id),
            str(attempt_id),
            str(entry.outbox_id),
            str(entry.execution_epoch),
            str(entry.generation),
        ],
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=30,
        check=False,
    )
    assert created.returncode == 90, created.stderr
    client = DBOSClient(
        system_database_url=f"sqlite:///{database.resolve().as_posix()}",
        application_name="zaratustra-assigned-rpc",
        retry_connection_errors=False,
    )
    try:
        records = client.list_workflows(workflow_ids=[workflow_id], load_output=False)
        assert len(records) == 1
        assert records[0].status == "PENDING" and records[0].executor_id == "local"
        assert records[0].queue_name == route
    finally:
        client.destroy()
    return workflow_id


def _valid_assigned_config(root: Path, workspace: Path, runtime: Path) -> AssignedConfig:
    package = runtime / "node_modules" / "@earendil-works" / "pi-coding-agent"
    cli = package / "dist" / "bundle" / "cli.js"
    cli.parent.mkdir(parents=True)
    cli.write_text("synthetic", encoding="utf-8")
    (package / "package.json").write_text(
        '{"name":"@earendil-works/pi-coding-agent","version":"' + PI_VERSION + '"}',
        encoding="utf-8",
    )
    return AssignedConfig(
        space=root,
        workspace=workspace,
        pi_cli=cli,
        pi_runtime=runtime,
        node="node",
        provider_profile="local-completions",
        provider_base_url="http://127.0.0.1:9/v1",
        provider_id="synthetic",
        model_id="synthetic",
        context_window=4096,
        max_tokens=512,
        reserve_units=10,
        limit_units=100,
        offline=True,
    )


@pytest.mark.parametrize("refused_thread", ("server", "stderr_reader", "monitor"))
def test_assigned_thread_start_failure_closes_server_and_records_observed_stop(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, refused_thread: str
) -> None:
    root, workspace, _, work, attempt, _ = assigned(tmp_path)
    owner = authorize_local(root, actor="owner", source_ref="fictional-console")
    config = _valid_assigned_config(root, workspace, tmp_path / "runtime")
    before = read_execution(root, work, owner)
    servers: list[BridgeServer] = []
    server_threads: list[threading.Thread] = []
    started_threads: list[threading.Thread] = []
    children: list[subprocess.Popen[bytes]] = []
    failure = RuntimeError(f"Fictional assigned {refused_thread} thread start failed")
    native_start = threading.Thread.start
    native_popen = subprocess.Popen

    def start(thread: threading.Thread) -> None:
        target = getattr(thread, "_target", None)
        server = getattr(target, "__self__", None)
        if isinstance(server, BridgeServer):
            servers.append(server)
            server_threads.append(thread)
        refuses = (
            refused_thread == "server"
            and isinstance(server, BridgeServer)
            or refused_thread == "stderr_reader"
            and target is assigned_module._drain_stderr
            or refused_thread == "monitor"
            and target is assigned_module._watch_core_stop
        )
        if refuses:
            with pytest.raises(FoundationError, match="history_busy"), managed_pi_lock(root):
                raise AssertionError("Acquired assigned server must hold the Core fence")
            raise failure
        native_start(thread)
        started_threads.append(thread)

    def idle_child(
        command: object,
        *,
        cwd: Path,
        env: dict[str, str],
        stdin: int,
        stdout: int,
        stderr: int,
    ) -> subprocess.Popen[bytes]:
        assert refused_thread != "server", "A failed Bridge thread must not launch assigned Pi"
        process = native_popen(
            [sys.executable, "-c", "import sys; sys.stdin.buffer.read()"],
            cwd=cwd,
            env=env,
            stdin=stdin,
            stdout=stdout,
            stderr=stderr,
        )
        children.append(process)
        return process

    monkeypatch.setattr(threading.Thread, "start", start)
    monkeypatch.setattr(subprocess, "Popen", idle_child)
    try:
        with pytest.raises(RuntimeError) as refused:
            assigned_module._execute_under_lock(
                config, owner, work, attempt, before.execution_epoch, before.attempts[0].generation
            )
        assert refused.value is failure
        assert len(servers) == 1 and servers[0].socket.fileno() == -1
        assert len(children) == int(refused_thread != "server")
        assert all(child.pid > 0 and child.poll() is not None for child in children)
        assert not any(thread.is_alive() for thread in started_threads)
        with managed_pi_lock(root):
            after = read_execution(root, work, owner)
            assert after.work == before.work and after.work.state.acceptance is None
            assert after.assignments[0].status == "stopped"
            assert after.attempts[0].status == "interrupted"
            assert after.invocations == before.invocations == ()
            assert not after.outputs and after.committed_units == after.held_units == 0
    finally:
        # Clean only this test's real children if an assertion exposed a leak.
        # All lifecycle assertions above observe product cleanup before this fallback.
        for child in children:
            if child.poll() is None:
                child.kill()
            child.wait(timeout=5)
            for stream in (child.stdin, child.stdout, child.stderr):
                if stream is not None:
                    stream.close()
        for server, thread in zip(servers, server_threads, strict=True):
            if thread.ident is not None:
                server.shutdown()
            server.server_close()
        for thread in started_threads:
            thread.join(timeout=5)


def test_empty_executor_file_recovers_same_attempt_without_recreating_database(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root, workspace, _, work_id, attempt_id, _ = assigned(tmp_path)
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    config = _valid_assigned_config(root, workspace, tmp_path / "runtime")
    database = root / ".zara-core" / "executor.sqlite3"
    with sqlite3.connect(database) as connection:
        assert connection.execute("SELECT name FROM sqlite_master").fetchall() == []
    identity = database.stat().st_ino
    executed: list[UUID] = []

    def execute(
        _config: AssignedConfig,
        _authority: LocalAuthority,
        selected_work: UUID,
        selected_attempt: UUID,
        _epoch: int,
        _generation: int,
    ) -> str:
        assert selected_work == work_id and selected_attempt == attempt_id
        executed.append(selected_attempt)
        return "proposed"

    monkeypatch.setattr(assigned_module, "_execute", execute)
    assert run_assigned(config, owner, attempt_id) == "proposed"
    assert run_assigned(config, owner, attempt_id) == "proposed"
    assert database.stat().st_ino == identity and executed == [attempt_id]
    client = DBOSClient(
        system_database_url=f"sqlite:///{database.resolve().as_posix()}",
        application_name="zaratustra-assigned-rpc",
        retry_connection_errors=False,
    )
    try:
        workflows = client.list_workflows(load_output=True)
        assert len(workflows) == 1
        assert workflows[0].executor_id == str(attempt_id)
        assert workflows[0].status == "SUCCESS"
    finally:
        client.destroy()


@pytest.mark.parametrize("claimed", [False, True])
def test_pending_local_addressed_workflow_recovers_at_core_claim_boundary(
    tmp_path: Path,
    dbos_template: Path,
    monkeypatch: pytest.MonkeyPatch,
    claimed: bool,
) -> None:
    root, workspace, space_id, work_id, attempt_id, session_id = _managed_space(
        tmp_path, dbos_template
    )
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    workflow_id = _pending_local_route(root, work_id, attempt_id, owner)
    config = _valid_assigned_config(root, workspace, tmp_path / "runtime")
    executed: list[UUID] = []
    if claimed:
        assignment = read_execution(root, work_id, owner).assignments[0]
        apply_operation(
            root,
            ClaimAttemptLaunchRequest(
                operation_id=uuid5(attempt_id, "rpc-launch-claim"),
                space_id=space_id,
                actor="owner",
                attempt_id=attempt_id,
                work_id=work_id,
                session_id=session_id,
                expected_assignment_revision=assignment.revision,
                claim_nonce=uuid4(),
            ),
            owner,
        )

        def no_pi(*_args: object, **_kwargs: object) -> None:
            raise AssertionError("A recorded claim must not launch Pi again")

        monkeypatch.setattr(assigned_module, "BridgeServer", no_pi)
        with pytest.raises(FoundationError) as refused:
            run_assigned(config, owner, attempt_id)
        assert refused.value.code == "process_outcome_unknown"
        state = read_execution(root, work_id, owner)
        assert state.assignments[0].status == "unknown" and state.outputs == ()
        assert state.invocations == () and executed == []
        with pytest.raises(FoundationError) as replay:
            run_assigned(config, owner, attempt_id)
        assert replay.value.code == "process_outcome_unknown"
        assert read_execution(root, work_id, owner).assignments[0].status == "unknown"
    else:

        def execute(
            selected: AssignedConfig,
            _authority: LocalAuthority,
            selected_work: UUID,
            selected_attempt: UUID,
            _epoch: int,
            _generation: int,
        ) -> str:
            assert selected.workspace == workspace.resolve()
            assert selected_work == work_id and selected_attempt == attempt_id
            executed.append(selected_attempt)
            return "proposed"

        monkeypatch.setattr(assigned_module, "_execute", execute)
        assert run_assigned(config, owner, attempt_id) == "proposed"
        assert run_assigned(config, owner, attempt_id) == "proposed"
        assert executed == [attempt_id]
        assert deliver_outbox(root, owner) == (
            read_execution(root, work_id, owner).outbox[0].outbox_id,
        )

    client = DBOSClient(
        system_database_url=(
            f"sqlite:///{(root / '.zara-core' / 'executor.sqlite3').resolve().as_posix()}"
        ),
        application_name="zaratustra-assigned-rpc",
        retry_connection_errors=False,
    )
    try:
        records = client.list_workflows(workflow_ids=[workflow_id], load_output=True)
        assert len(records) == 1 and records[0].workflow_id == workflow_id
        assert records[0].executor_id == str(attempt_id)
        assert records[0].status == ("ERROR" if claimed else "SUCCESS")
        assert len(client.list_workflows(load_output=False)) == 1
    finally:
        client.destroy()


def _workflows(root: Path) -> list[dict[str, object]]:
    database = root / ".zara-core" / "executor.sqlite3"
    client = DBOSClient(
        system_database_url=f"sqlite:///{database.resolve().as_posix()}",
        application_name="zaratustra-assigned-rpc",
        retry_connection_errors=False,
    )
    try:
        return [
            dict(workflow.attributes or {})
            for workflow in client.list_workflows(
                name=WORKFLOW_NAME,
                application_name="zaratustra-assigned-rpc",
                load_input=False,
                load_output=False,
            )
        ]
    finally:
        client.destroy()


def _managed_copy(root: Path, attempt_id: UUID, content: str) -> Path:
    home = root / ".zara-core" / "pi-rpc-home" / str(attempt_id)
    home.mkdir(parents=True)
    copy = home / "synthetic-managed-copy.txt"
    copy.write_text(content, encoding="utf-8", newline="\n")
    return copy


def _delete_work(root: Path, space_id: UUID, work_id: UUID) -> None:
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    revision = read_execution(root, work_id, owner).work.revision
    apply_operation(
        root,
        DeleteWorkRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            work_id=work_id,
            expected_revision=revision,
        ),
        owner,
    )


def _second_assigned_work(
    root: Path, workspace: Path, space_id: UUID, first: UUID
) -> tuple[UUID, UUID]:
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    activity_id = read_execution(root, first, owner).activity.activity_id
    work_id, resource_id, attempt_id = uuid4(), uuid4(), uuid4()
    workspace.mkdir()
    apply_operation(
        root,
        CreateWorkRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            work_id=work_id,
            state=WorkState(
                activity_id=activity_id,
                goal="Independent synthetic Work",
                expected_outputs=(OutputContract(slot="summary", media_type="text/plain"),),
            ),
        ),
        owner,
    )
    apply_operation(
        root,
        CreateResourceRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            work_id=work_id,
            resource_id=resource_id,
            state=ResourceState(label="Synthetic second resource", root=workspace, limit_units=100),
        ),
        owner,
    )
    apply_operation(
        root,
        AssignAttemptRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            work_id=work_id,
            attempt_id=attempt_id,
            session_id=uuid4(),
            resource_id=resource_id,
            expected_work_revision=1,
            expected_resource_revision=1,
            executor_version=EXECUTOR_VERSION,
        ),
        owner,
    )
    return work_id, attempt_id


@pytest.mark.parametrize("grant_mode", ["missing", "revoked"])
def test_denied_maintenance_leaves_dbos_home_backup_and_job_untouched(
    tmp_path: Path, dbos_template: Path, grant_mode: str
) -> None:
    root, _, space_id, work_id, attempt_id, _ = _managed_space(tmp_path, dbos_template)
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    deliver_outbox(root, owner)
    copy = _managed_copy(root, attempt_id, "Synthetic private payload")
    backup = create_assigned_backup(root, uuid4(), owner)
    grant_id = uuid4()
    apply_operation(
        root,
        CreateGrantRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            grant_id=grant_id,
            state=GrantState(
                grantee="observer",
                actions=("space.inspect",)
                if grant_mode == "missing"
                else ("space.inspect", "maintenance.delete"),
            ),
        ),
        owner,
    )
    if grant_mode == "revoked":
        apply_operation(
            root,
            RevokeGrantRequest(
                operation_id=uuid4(),
                space_id=space_id,
                actor="owner",
                grant_id=grant_id,
                expected_revision=1,
            ),
            owner,
        )
    observer = authorize_local(root, actor="observer", source_ref="synthetic-observer")
    _delete_work(root, space_id, work_id)
    with pytest.raises(FoundationError, match="permission_denied"):
        complete_assigned_deletions(root, observer)
    assert len(_workflows(root)) == 1
    assert copy.is_file() and backup.package.is_dir()
    assert inspect_space(root, owner).pending_deletions == 1


def test_technical_backup_waits_for_pending_deletion_cleanup(
    tmp_path: Path, dbos_template: Path
) -> None:
    root, _, space_id, work_id, attempt_id, _ = _managed_space(tmp_path, dbos_template)
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    deliver_outbox(root, owner)
    copy = _managed_copy(root, attempt_id, "Synthetic deleted payload")
    _delete_work(root, space_id, work_id)
    with pytest.raises(FoundationError, match="deletion_pending"):
        create_assigned_backup(root, uuid4(), owner)
    inspection = inspect_space(root, owner)
    assert copy.is_file() and inspection.pending_deletions == 1
    assert inspection.completed_backups == 0
    assert complete_assigned_deletions(root, owner).live_store_sanitized
    assert not copy.exists()
    assert create_assigned_backup(root, uuid4(), owner).package.is_dir()


def test_later_work_deletion_remains_pending_until_its_own_technical_cleanup(
    tmp_path: Path, dbos_template: Path
) -> None:
    root, _, space_id, first, first_attempt, _ = _managed_space(tmp_path, dbos_template)
    second, second_attempt = _second_assigned_work(
        root, tmp_path / "second-workspace", space_id, first
    )
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    deliver_outbox(root, owner)
    first_copy = _managed_copy(root, first_attempt, "Synthetic first payload")
    second_copy = _managed_copy(root, second_attempt, "Synthetic second payload")
    _delete_work(root, space_id, first)
    callback_ids: list[UUID] = []

    def interleaved_cleanup(path: Path, authority: LocalAuthority, ids: tuple[UUID, ...]) -> None:
        callback_ids.extend(ids)
        _purge_technical_data(path, authority, ids)
        failures: list[BaseException] = []

        def delete_second() -> None:
            try:
                _delete_work(root, space_id, second)
            except BaseException as error:
                failures.append(error)

        worker = threading.Thread(target=delete_second)
        worker.start()
        worker.join(timeout=10)
        assert not worker.is_alive() and not failures

    first_status = complete_deletions(root, owner, technical_cleanup=interleaved_cleanup)
    assert callback_ids == [first]
    assert first_status.pending_jobs == 1 and first_status.completed_jobs == 1
    assert not first_status.live_store_sanitized
    assert not first_copy.exists() and second_copy.is_file()
    assert [item["work_id"] for item in _workflows(root)] == [str(second)]
    second_status = complete_assigned_deletions(root, owner)
    assert second_status.pending_jobs == 0 and second_status.completed_jobs == 2
    assert second_status.live_store_sanitized
    assert not second_copy.exists() and not _workflows(root)


def test_deleted_partial_of_stopped_assignment_cleans_only_its_addresses(
    tmp_path: Path, dbos_template: Path
) -> None:
    root, workspace, space_id, work_id, attempt_id, session_id = _managed_space(
        tmp_path, dbos_template
    )
    other_work, other_attempt = _second_assigned_work(
        root, tmp_path / "other-workspace", space_id, work_id
    )
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    deliver_outbox(root, owner)
    rpc = Bridge(
        root, owner, workspace, 100, assigned_attempt_id=attempt_id, assigned_session_id=session_id
    )
    rpc.connect(session_id)
    rpc.select(session_id, read_execution(root, work_id, owner).activity.activity_id, work_id)
    rpc.open_wait(
        session_id, attempt_id, uuid4(), "Synthetic partial payload", "Which code?", "Finish it"
    )
    partial_id = read_execution(root, work_id, owner).waits[0].partial_refs[0].artifact_id
    assignment = read_execution(root, work_id, owner).assignments[0]
    apply_operation(
        root,
        RequestAttemptStopRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            work_id=work_id,
            attempt_id=attempt_id,
            session_id=session_id,
            expected_assignment_revision=assignment.revision,
            reason="Synthetic observed stop",
        ),
        owner,
    )
    assignment = read_execution(root, work_id, owner).assignments[0]
    apply_operation(
        root,
        RecordAttemptStopRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            work_id=work_id,
            attempt_id=attempt_id,
            session_id=session_id,
            expected_assignment_revision=assignment.revision,
            outcome="stopped",
        ),
        owner,
    )
    deleted_copy = _managed_copy(root, attempt_id, "Synthetic partial payload")
    other_copy = _managed_copy(root, other_attempt, "Unrelated technical payload")
    apply_operation(
        root,
        DeleteArtifactRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            artifact_id=partial_id,
            expected_revision=1,
        ),
        owner,
    )
    assert complete_assigned_deletions(root, owner).live_store_sanitized
    after = read_execution(root, work_id, owner)
    assert after.assignments[0].status == "stopped"
    assert after.assignments[0].stop_reason is None
    assert not after.waits[0].partial_refs and not after.work.unavailable_refs
    assert not deleted_copy.exists() and other_copy.is_file()
    assert [item["work_id"] for item in _workflows(root)] == [str(other_work)]


def test_live_attempt_resolves_past_unrelated_deleted_work(
    tmp_path: Path, dbos_template: Path
) -> None:
    root, _, space_id, live_work, attempt_id, _ = _managed_space(tmp_path, dbos_template)
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    activity_id = read_execution(root, live_work, owner).activity.activity_id
    deleted_work = UUID(int=1)
    apply_operation(
        root,
        CreateWorkRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            work_id=deleted_work,
            state=WorkState(
                activity_id=activity_id,
                goal="Synthetic deleted history",
                expected_outputs=(OutputContract(slot="summary", media_type="text/plain"),),
            ),
        ),
        owner,
    )
    _delete_work(root, space_id, deleted_work)
    assert resolve_assigned_work(root, owner, attempt_id) == live_work
    deliver_outbox(root, owner)
    assert [item["work_id"] for item in _workflows(root)] == [str(live_work)]
    _delete_work(root, space_id, live_work)
    with pytest.raises(FoundationError, match="stale_attempt"):
        resolve_assigned_work(root, owner, attempt_id)


def test_assigned_refusal_survives_dbos_exception_serialization() -> None:
    original = FoundationError("rpc_extension", "Synthetic local provider is unavailable")
    restored = pickle.loads(pickle.dumps(original))
    assert isinstance(restored, FoundationError)
    assert restored.code == "rpc_extension"
    assert str(restored) == str(original)


def test_launch_claim_is_exact_and_rejects_a_second_process(tmp_path: Path) -> None:
    root, _, space_id, work_id, attempt_id, session_id = assigned(tmp_path)
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    claim_id = uuid5(attempt_id, "rpc-launch-claim")
    first = ClaimAttemptLaunchRequest(
        operation_id=claim_id,
        space_id=space_id,
        actor="owner",
        attempt_id=attempt_id,
        work_id=work_id,
        session_id=session_id,
        expected_assignment_revision=1,
        claim_nonce=uuid4(),
    )
    receipt = apply_operation(root, first, owner)
    assert receipt.result["launch_claimed"] is True
    assert apply_operation(root, first, owner) == receipt
    with pytest.raises(FoundationError, match="operation_conflict"):
        apply_operation(root, first.model_copy(update={"claim_nonce": uuid4()}), owner)
    snapshot = read_execution(root, work_id, owner)
    assert snapshot.assignments[0].status == "assigned"
    assert snapshot.attempts[0].status == "active"


def test_wrong_pi_package_refuses_before_dbos_launch(tmp_path: Path) -> None:
    root, workspace, _, work_id, attempt_id, _ = assigned(tmp_path)
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    runtime = tmp_path / "runtime"
    package = runtime / "node_modules" / "@earendil-works" / "pi-coding-agent"
    cli = package / "dist" / "bundle" / "cli.js"
    cli.parent.mkdir(parents=True)
    cli.write_text("synthetic", encoding="utf-8")
    (package / "package.json").write_text(
        '{"name":"another-package","version":"1.0.4"}',
        encoding="utf-8",
    )
    config = AssignedConfig(
        space=root,
        workspace=workspace,
        pi_cli=cli,
        pi_runtime=runtime,
        node="node",
        provider_profile="local-completions",
        provider_base_url="http://127.0.0.1:9/v1",
        provider_id="synthetic",
        model_id="synthetic",
        context_window=4096,
        max_tokens=512,
        reserve_units=10,
        limit_units=100,
        offline=True,
    )
    with pytest.raises(FoundationError, match="pi_version"):
        run_assigned(config, owner, attempt_id)
    assert not (root / ".zara-core" / "executor.sqlite3").exists()
    assert read_execution(root, work_id, owner).assignments[0].status == "assigned"


def test_refused_child_termination_records_unknown(tmp_path: Path) -> None:
    root, workspace, _, work_id, attempt_id, session_id = assigned(tmp_path)
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    config = AssignedConfig(
        space=root,
        workspace=workspace,
        pi_cli=tmp_path / "unused-pi.js",
        pi_runtime=tmp_path / "unused-runtime",
        node="node",
        provider_profile="local-completions",
        provider_base_url="http://127.0.0.1:9/v1",
        provider_id="synthetic",
        model_id="synthetic",
        context_window=4096,
        max_tokens=512,
        reserve_units=10,
        limit_units=100,
    )

    class RefusingChild:
        def poll(self) -> None:
            return None

        def terminate(self) -> None:
            raise OSError("synthetic termination refusal")

        def kill(self) -> None:
            raise OSError("synthetic kill refusal")

        def wait(self, *, timeout: float) -> None:
            raise subprocess.TimeoutExpired("synthetic-pi", timeout)

    observed = _terminate_pi(cast(subprocess.Popen[bytes], RefusingChild()))
    assert not observed
    _record_stop(config, owner, work_id, attempt_id, session_id, observed=observed)
    state = read_execution(root, work_id, owner)
    assert state.assignments[0].status == "unknown"
    assert state.attempts[0].status == "active"
    assert state.work.state.status == "proposed"


@pytest.mark.parametrize("direct_setup", [False, True])
@pytest.mark.parametrize("observed", [False, True])
@pytest.mark.parametrize("delivery_answered", [False, True])
def test_observed_setup_stop_keeps_unknown_send_and_expense(
    tmp_path: Path, direct_setup: bool, observed: bool, delivery_answered: bool
) -> None:
    """Local setup stop frees execution without pretending its provider replied."""
    from tests.zaratustra.foundation.test_activity_setup_recovery import _recovery_case, _start
    from tests.zaratustra.foundation.test_execution import InvocationFields, invocation

    if direct_setup:
        case = _recovery_case(tmp_path, 16)
        root, space, owner, setup, *_ = case
        _start(case)
        work_id = read_activity_setup(root, setup, owner).state.stages[-1].work_id
        resource_id, attempt_id, session_id = uuid4(), uuid4(), uuid4()
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        apply_operation(
            root,
            CreateResourceRequest(
                operation_id=uuid4(),
                space_id=space,
                actor=owner.actor,
                resource_id=resource_id,
                work_id=work_id,
                state=ResourceState(label="Fictional setup", root=workspace, limit_units=100),
            ),
            owner,
        )
        apply_operation(
            root,
            AssignAttemptRequest(
                operation_id=uuid4(),
                space_id=space,
                actor=owner.actor,
                attempt_id=attempt_id,
                work_id=work_id,
                expected_work_revision=read_work(root, work_id, owner).revision,
                resource_id=resource_id,
                expected_resource_revision=1,
                session_id=session_id,
                executor_version=EXECUTOR_VERSION,
            ),
            owner,
        )
    else:
        root, workspace, space, work_id, attempt_id, session_id = assigned(tmp_path)
        owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    config = _valid_assigned_config(root, workspace, tmp_path / "runtime")
    invocation_id, _ = invocation(root, space, work_id, attempt_id, session_id, owner, 10)
    common: InvocationFields = dict(
        invocation_id=invocation_id, attempt_id=attempt_id, work_id=work_id, session_id=session_id
    )
    for request in (
        AdmitInvocationRequest(operation_id=uuid4(), space_id=space, actor=owner.actor, **common),
        SendInvocationRequest(operation_id=uuid4(), space_id=space, actor=owner.actor, **common),
    ):
        apply_operation(root, request, owner)
    if direct_setup:
        rpc = Bridge(
            root, owner, workspace, assigned_attempt_id=attempt_id, assigned_session_id=session_id
        )
        rpc.connect(session_id)
        rpc.select(session_id, read_execution(root, work_id, owner).activity.activity_id, work_id)
        manifest = rpc.prepare_context(session_id)
        delivery = {
            "invocation_id": str(invocation_id),
            "manifest_id": manifest["manifest_id"],
            "manifest_revision": 1,
        }
        rpc.context_delivery(session_id, {**delivery, "stage": "prepared"})
        rpc.context_delivery(
            session_id,
            {**delivery, "stage": "sent", "request_sha256": "A" * 64, "request_bytes": 123},
        )
        if delivery_answered:
            rpc.context_delivery(session_id, {**delivery, "stage": "answered", "usage_units": 3})
    _record_stop(config, owner, work_id, attempt_id, session_id, observed=observed)
    state = read_execution(root, work_id, owner)
    stopped = direct_setup and observed
    assert state.assignments[0].status == ("stopped" if stopped else "unknown")
    assert state.attempts[0].status == ("interrupted" if stopped else "active")
    assert state.invocations[0].invocation_id == invocation_id
    assert state.invocations[0].status == ("unknown" if stopped else "sent")
    assert state.invocations[0].usage_units is None and state.held_units == 10
    assert not state.outputs and state.work.state.acceptance is None
    if direct_setup:
        delivered = read_context_delivery(root, invocation_id, owner)
        assert delivered["stage"] == (
            "answered" if delivery_answered else "unknown" if stopped else "sent"
        )
    if direct_setup and not observed:
        # A later actual process-exit observation can resolve the local stop,
        # while the same provider outcome and its reserved cost stay unknown.
        _record_stop(config, owner, work_id, attempt_id, session_id, observed=True)
        recovered = read_execution(root, work_id, owner)
        assert recovered.assignments[0].status == "stopped"
        assert recovered.attempts[0].status == "interrupted"
        assert recovered.invocations[0].status == "unknown"
        assert recovered.held_units == 10 and len(recovered.invocations) == 1
        assert read_context_delivery(root, invocation_id, owner)["stage"] == (
            "answered" if delivery_answered else "unknown"
        )
        before_repeat = read_execution(root, work_id, owner)
        _record_stop(config, owner, work_id, attempt_id, session_id, observed=True)
        assert read_execution(root, work_id, owner) == before_repeat


def test_active_rpc_read_is_interruptible_when_stop_is_requested() -> None:
    release = threading.Event()

    class SilentOutput:
        def readline(self, _limit: int) -> bytes:
            release.wait()
            return b""

    class SilentChild:
        stdout = SilentOutput()

    stop = threading.Event()
    stop.set()
    try:
        with pytest.raises(FoundationError, match="rpc_stop_requested"):
            _rpc_line_with_stop(cast(subprocess.Popen[bytes], SilentChild()), stop)
    finally:
        release.set()


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        (b"", "EOF (exit_code=17)"),
        (b"{}", "truncated_line"),
        (b"{broken}\n", "invalid_json"),
        (b"[]\n", "invalid_event"),
        (b"{}\n", None),
    ],
)
def test_rpc_line_identifies_failure_boundary(raw: bytes, expected: str | None) -> None:
    class Child:
        stdout = io.BytesIO(raw)

        def poll(self) -> int:
            return 17

    child = cast(subprocess.Popen[bytes], Child())
    if expected is None:
        assert assigned_module._rpc_line(child) == {}
    else:
        with pytest.raises(FoundationError) as refused:
            assigned_module._rpc_line(child)
        assert refused.value.code == "rpc_transport"
        assert expected in str(refused.value)


def test_rpc_line_limit_and_stderr_tail_are_bounded() -> None:
    class Child:
        stdout = io.BytesIO(b"x" * (assigned_module.MAX_RPC_LINE + 1))
        stderr = io.BytesIO(b"old" + b"x" * assigned_module.MAX_RPC_STDERR + b"new")

        def poll(self) -> int:
            return 9

    child = cast(subprocess.Popen[bytes], Child())
    with pytest.raises(FoundationError, match="line_limit"):
        assigned_module._rpc_line(child)
    tail = bytearray()
    assigned_module._drain_stderr(child, tail)
    assert len(tail) == assigned_module.MAX_RPC_STDERR
    assert tail.endswith(b"new") and not tail.startswith(b"old")


@pytest.mark.parametrize(
    "event_type",
    ["x" * (1024 * 1024), {"text": "x" * (1024 * 1024)}, "synthetic-secret"],
    ids=["long-string", "large-object", "unexpected-type"],
)
def test_valid_large_rpc_event_keeps_diagnostic_evidence_bounded(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    event_type: object,
) -> None:
    request_id = "a" * 32
    raw = b"".join(
        (json.dumps(event, ensure_ascii=False) + "\n").encode("utf-8")
        for event in (
            {"type": event_type, "payload": "synthetic-secret"},
            {"type": "response", "id": request_id, "success": True},
            {"type": "agent_settled"},
        )
    )

    class Child:
        stdin = io.BytesIO()
        stdout = io.BytesIO(raw)

        def poll(self) -> None:
            return None

    child = cast(subprocess.Popen[bytes], Child())
    monkeypatch.setattr(secrets, "token_hex", lambda _n: request_id)
    events: list[dict[str, object]] = []
    assigned_module._rpc_prompt(child, "synthetic prompt", threading.Event(), events)
    assert b"synthetic prompt" in Child.stdin.getvalue()
    assert events[1]["event_type"] == "<omitted>"
    assert events[1]["event_type_omitted"] is True
    assert assigned_module._trace_size(events) <= assigned_module.MAX_RPC_TRACE_BYTES

    root, workspace, _, work_id, attempt_id, _ = assigned(tmp_path)
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    config = _valid_assigned_config(root, workspace, tmp_path / "runtime")
    monkeypatch.setenv("ZARATUSTRA_RPC_DIAGNOSTICS", "1")
    capsys.readouterr()
    assigned_module._emit_rpc_diagnostics(
        config, owner, work_id, attempt_id, child, None, bytearray(), events, None
    )
    line = capsys.readouterr().err
    assert len(line.encode("utf-8")) <= assigned_module.MAX_RPC_DIAGNOSTIC_BYTES
    assert "synthetic-secret" not in line
    assert "x" * 1000 not in line


def test_rpc_event_trace_marks_count_or_byte_truncation() -> None:
    events: list[dict[str, object]] = []
    for _ in range(200):
        assigned_module._trace_event(
            events,
            kind="rpc_event",
            event_type="response",
            request_id="a" * 32,
            request_match=False,
            success=False,
        )
    assert len(events) <= assigned_module.MAX_RPC_EVENTS
    assert assigned_module._trace_size(events) <= assigned_module.MAX_RPC_TRACE_BYTES
    assert events[-1] == {"kind": "trace_truncated"}


def test_rpc_diagnostic_omits_unbounded_failure_and_core_error(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    root, workspace, _, work_id, attempt_id, _ = assigned(tmp_path)
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    config = _valid_assigned_config(root, workspace, tmp_path / "runtime")
    large = "z" * (1024 * 1024)

    def failed_read(*_args: object) -> None:
        raise FoundationError("storage", large)

    monkeypatch.setattr(assigned_module, "read_execution", failed_read)
    monkeypatch.setenv("ZARATUSTRA_RPC_DIAGNOSTICS", "1")
    capsys.readouterr()
    assigned_module._emit_rpc_diagnostics(
        config,
        owner,
        work_id,
        attempt_id,
        None,
        17,
        bytearray(b"\x00" * assigned_module.MAX_RPC_STDERR),
        [{"kind": "rpc_event", "event_type": large}],
        FoundationError("rpc_transport", large),
    )
    line = capsys.readouterr().err
    assert len(line.encode("utf-8")) <= assigned_module.MAX_RPC_DIAGNOSTIC_BYTES
    assert "z" * 1000 not in line
    report = json.loads(line.removeprefix("ZARATUSTRA_RPC_DIAGNOSTIC "))
    assert report["exit_before_host_stop"] == 17
    assert report["failure_code"] == "rpc_transport"
    assert report["core_read_error"]["code"] == "storage"
    assert report["diagnostic_omitted_for_bound"] is True


def test_rpc_runtime_exit_keeps_stderr_separate_from_eof() -> None:
    child = subprocess.Popen(
        [
            sys.executable,
            "-c",
            "import sys; sys.stderr.write('synthetic runtime load failure'); sys.exit(17)",
        ],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    tail = bytearray()
    reader = threading.Thread(target=assigned_module._drain_stderr, args=(child, tail))
    reader.start()
    with pytest.raises(FoundationError, match="Pi RPC EOF") as refused:
        assigned_module._rpc_line(child)
    assert refused.value.code == "rpc_transport"
    assert child.wait(timeout=5) == 17
    reader.join(timeout=5)
    assert b"synthetic runtime load failure" in tail


@pytest.mark.parametrize("exit_before_prompt", [False, True])
def test_claimed_runtime_exit_does_not_start_a_second_pi_process(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    exit_before_prompt: bool,
) -> None:
    root, workspace, _, work_id, attempt_id, _ = assigned(tmp_path)
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    config = _valid_assigned_config(root, workspace, tmp_path / "runtime")
    original_popen = subprocess.Popen
    starts: list[object] = []

    def failed_runtime(
        command: object,
        *,
        cwd: Path,
        env: dict[str, str],
        stdin: int,
        stdout: int,
        stderr: int,
    ) -> subprocess.Popen[bytes]:
        starts.append(command)
        process = original_popen(
            [
                sys.executable,
                "-c",
                "import sys; sys.stderr.write('synthetic Pi runtime failed'); sys.exit(17)",
            ],
            cwd=cwd,
            env=env,
            stdin=stdin,
            stdout=stdout,
            stderr=stderr,
        )

        if exit_before_prompt:
            assert process.wait(timeout=5) == 17
        return process

    monkeypatch.setattr(subprocess, "Popen", failed_runtime)
    monkeypatch.setenv("ZARATUSTRA_RPC_DIAGNOSTICS", "1")
    # The child may exit before the prompt is written or while RPC reads it.
    # Both are observed failures; neither permits a second claimed launch.
    with pytest.raises(FoundationError, match="Pi RPC") as refused:
        run_assigned(config, owner, attempt_id)
    assert refused.value.code in {"rpc_stopped", "rpc_transport"}
    if exit_before_prompt:
        assert refused.value.code == "rpc_stopped"
    first = read_execution(root, work_id, owner)
    assert first.assignments[0].status == "stopped"
    assert first.invocations == () and first.held_units == 0
    with pytest.raises(FoundationError):
        run_assigned(config, owner, attempt_id)
    assert len(starts) == 1
    assert "synthetic Pi runtime failed" in capsys.readouterr().err


def test_control_read_error_is_named_before_safe_stop(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root, workspace, _, work_id, attempt_id, _ = assigned(tmp_path)
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    config = _valid_assigned_config(root, workspace, tmp_path / "runtime")
    errors: list[FoundationError] = []

    def unavailable(*_args: object) -> bool:
        raise FoundationError("storage", "SQLite identity failed (SQLITE_BUSY)")

    monkeypatch.setattr(assigned_module, "read_assigned_control", unavailable)
    assert assigned_module._control_stop_requested(
        config, owner, work_id, attempt_id, errors.append
    )
    assert len(errors) == 1 and errors[0].code == "storage"


@pytest.mark.parametrize("busy_reads", [1, 3])
def test_record_stop_first_core_read_busy_is_bounded(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, busy_reads: int
) -> None:
    root, workspace, _, work_id, attempt_id, session_id = assigned(tmp_path)
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    config = _valid_assigned_config(root, workspace, tmp_path / "runtime")
    original_connect = storage._connect
    attempts = 0

    class BusyFirstRead:
        def __init__(self, actual: sqlite3.Connection) -> None:
            self.actual = actual

        def execute(self, statement: str, parameters: tuple[object, ...] = ()) -> sqlite3.Cursor:
            nonlocal attempts
            if statement == "PRAGMA application_id":
                attempts += 1
                if attempts <= busy_reads:
                    raise sqlite3.OperationalError("database is locked")
            return self.actual.execute(statement, parameters)

        def __getattr__(self, name: str) -> object:
            return getattr(self.actual, name)

    def connect(database: Path, *, writable: bool) -> BusyFirstRead:
        return BusyFirstRead(original_connect(database, writable=writable))

    monkeypatch.setattr(storage, "_connect", connect)
    if busy_reads == 1:
        _record_stop(config, owner, work_id, attempt_id, session_id, observed=True)
    else:
        with pytest.raises(FoundationError) as refused:
            _record_stop(config, owner, work_id, attempt_id, session_id, observed=True)
        assert refused.value.code == "storage"
        assert "SQLite identity failed" in str(refused.value)
    monkeypatch.undo()
    state = read_execution(root, work_id, owner)
    assert state.assignments[0].status == ("stopped" if busy_reads == 1 else "assigned")
    assert state.invocations == () and state.outputs == ()


def test_control_read_follows_stop_and_current_runner_rights(tmp_path: Path) -> None:
    root, _, space_id, work_id, attempt_id, session_id = assigned(tmp_path)
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    grant_id = uuid4()
    apply_operation(
        root,
        CreateGrantRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            grant_id=grant_id,
            state=GrantState(grantee="runner", actions=tuple(ALL_ACTIONS)),
        ),
        owner,
    )
    runner = authorize_local(root, actor="runner", source_ref="synthetic-runner")
    assert read_assigned_control(root, work_id, attempt_id, runner)
    apply_operation(
        root,
        RevokeGrantRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            grant_id=grant_id,
            expected_revision=1,
        ),
        owner,
    )
    with pytest.raises(FoundationError, match="permission_denied"):
        read_assigned_control(root, work_id, attempt_id, runner)
    assert read_assigned_control(root, work_id, attempt_id, owner)
    apply_operation(
        root,
        RequestAttemptStopRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            attempt_id=attempt_id,
            work_id=work_id,
            session_id=session_id,
            expected_assignment_revision=1,
            reason="Stop this fictional assigned child",
        ),
        owner,
    )
    assert not read_assigned_control(root, work_id, attempt_id, owner)


def test_stop_monitor_terminates_before_failed_dbos_wake(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root, workspace, space_id, work_id, attempt_id, session_id = assigned(tmp_path)
    owner = authorize_local(root, actor="owner", source_ref="synthetic-local-console")
    apply_operation(
        root,
        RequestAttemptStopRequest(
            operation_id=uuid4(),
            space_id=space_id,
            actor="owner",
            attempt_id=attempt_id,
            work_id=work_id,
            session_id=session_id,
            expected_assignment_revision=1,
            reason="Stop this fictional child before a failed technical wake",
        ),
        owner,
    )
    config = AssignedConfig(
        space=root,
        workspace=workspace,
        pi_cli=tmp_path / "unused-pi.js",
        pi_runtime=tmp_path / "unused-runtime",
        node="node",
        provider_profile="local-completions",
        provider_base_url="http://127.0.0.1:9/v1",
        provider_id="synthetic",
        model_id="synthetic",
        context_window=4096,
        max_tokens=512,
        reserve_units=10,
        limit_units=100,
    )

    class Child:
        def __init__(self) -> None:
            self.stdin = io.BytesIO()
            self.terminated = False

        def poll(self) -> int | None:
            return 1 if self.terminated else None

        def terminate(self) -> None:
            self.terminated = True

        def kill(self) -> None:
            self.terminated = True

        def wait(self, *, timeout: float) -> int:
            assert self.terminated
            return 1

    child = Child()

    class FailedWake:
        def __init__(self) -> None:
            self.called = False
            self.destroyed = False

        def send(self, *args: object, **kwargs: object) -> None:
            assert child.terminated
            self.called = True
            raise OSError("synthetic DBOS wake failure")

        def destroy(self) -> None:
            self.destroyed = True

    wake = FailedWake()
    monkeypatch.setattr("zaratustra.pi_adapter.assigned._client", lambda _space: wake)
    stop = threading.Event()
    _watch_core_stop(
        config,
        owner,
        work_id,
        attempt_id,
        cast(subprocess.Popen[bytes], child),
        threading.Event(),
        stop,
        threading.Lock(),
    )
    commands = [json.loads(raw)["type"] for raw in child.stdin.getvalue().splitlines()]
    assert stop.is_set() and child.terminated
    assert commands == ["clear_queue", "abort"]
    assert wake.called and wake.destroyed
