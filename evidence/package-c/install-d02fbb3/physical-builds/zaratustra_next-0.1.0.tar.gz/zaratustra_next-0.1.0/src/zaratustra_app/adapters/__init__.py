"""Application adapters."""
