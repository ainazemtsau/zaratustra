"""Pi native transport internals."""
