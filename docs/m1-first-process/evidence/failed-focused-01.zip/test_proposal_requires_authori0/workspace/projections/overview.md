# Zaratustra — generated overview

generated_from_revision: 7
generated_at: 2026-09-10T07:29:20.323844+00:00
workspace_id: 751ad273-e53d-47b6-8ebd-4d3757c8ff69

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "b369fc88-0c1f-4427-bfa7-c43eb6642bd9",
  "revision": 2,
  "created_at": "2026-09-10T07:29:20.007069Z",
  "kind": "artifact",
  "process_id": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
  "work_id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
  "title": "KITE inspection",
  "status": "registered",
  "active_version": "97bfb1d2-6208-487c-bd1b-282ae806e861"
}
```

## event

```json
{
  "id": "2384f990-43cb-4301-a616-a7ff496e7c1d",
  "revision": 1,
  "created_at": "2026-09-10T07:29:20.007069Z",
  "kind": "event",
  "process_id": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
  "work_id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.0",
  "state_revision": 1,
  "affected_ids": [
    "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
    "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "b369fc88-0c1f-4427-bfa7-c43eb6642bd9"
  ]
}
```

## process

```json
{
  "id": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
  "revision": 4,
  "created_at": "2026-09-10T07:29:20.007069Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
  "revision": 7,
  "created_at": "2026-09-10T07:29:20.007069Z",
  "kind": "work",
  "process_id": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "ready",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 97bfb1d2-6208-487c-bd1b-282ae806e861; Artifact revision: 2
  SHA-256: e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312; bytes: 147
  File: artifacts/b369fc88-0c1f-4427-bfa7-c43eb6642bd9/97bfb1d2-6208-487c-bd1b-282ae806e861.blob

## Mutation provenance

```json
{
  "id": "bf23d113-a766-44cb-a177-758d3b4fa2c8",
  "state_revision": 2,
  "recorded_at": "2026-09-10T07:29:20.041486Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "001b1486-9cad-45b7-a0e1-84df6b61d078",
    "workspace_id": "751ad273-e53d-47b6-8ebd-4d3757c8ff69",
    "work_id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:20.025366Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_proposal_requires_authori0/workspace",
    "request_sha256": "028af7aee1f0c5a8ebb14f64b696f135737575cc5109322bcc35d5029775a6f9"
  },
  "fingerprint": "457491091759466696598ab1dc8e02124113f328d3d69e469f7fed665c7c07d1",
  "before": {
    "id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "revision": 1,
    "created_at": "2026-09-10T07:29:20.007069Z",
    "kind": "work",
    "process_id": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "revision": 2,
    "created_at": "2026-09-10T07:29:20.007069Z",
    "kind": "work",
    "process_id": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "db626ad9-ed32-4751-afe2-fff6f2a42d97",
  "state_revision": 3,
  "recorded_at": "2026-09-10T07:29:20.086347Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "cdd3d70a-49b1-41f8-8fe7-ed28b6b9d8d7",
    "workspace_id": "751ad273-e53d-47b6-8ebd-4d3757c8ff69",
    "work_id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:20.070754Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_proposal_requires_authori0/workspace",
    "request_sha256": "17e9fc8d561696a10377b1302fd8fd39f9f1dd7d484affa6cdee881f9f4e7c99"
  },
  "fingerprint": "269b55a8eeb135c86f6f5fb43564bd6763c05f9519fdc8913635af10aa626800",
  "before": {
    "id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "revision": 2,
    "created_at": "2026-09-10T07:29:20.007069Z",
    "kind": "work",
    "process_id": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "revision": 3,
    "created_at": "2026-09-10T07:29:20.007069Z",
    "kind": "work",
    "process_id": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "e177b1d2-3d06-4c35-8600-17857f40f178",
  "state_revision": 4,
  "recorded_at": "2026-09-10T07:29:20.142313Z",
  "product_version": "0.10.0",
  "request": {
    "version": 5,
    "operation_id": "0c857fe6-d362-4a1d-936b-2d980cf667eb",
    "workspace_id": "751ad273-e53d-47b6-8ebd-4d3757c8ff69",
    "work_id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional lot binding under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:20.124628Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_proposal_requires_authori0/workspace",
    "request_sha256": "35f86f4709764b0556a53324b9413cee60096a7443155cddcb44046e738572eb"
  },
  "fingerprint": "9482ca3be5b470b8b60573c77a8b6e8704e580a206284e0eb5ffb293192692c5",
  "before": {
    "id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "revision": 3,
    "created_at": "2026-09-10T07:29:20.007069Z",
    "kind": "work",
    "process_id": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "revision": 4,
    "created_at": "2026-09-10T07:29:20.007069Z",
    "kind": "work",
    "process_id": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
    "revision": 1,
    "created_at": "2026-09-10T07:29:20.007069Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
    "revision": 4,
    "created_at": "2026-09-10T07:29:20.007069Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "11be0c69-9b97-41fb-80ac-ff740118df05",
  "state_revision": 5,
  "recorded_at": "2026-09-10T07:29:20.199303Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "eb5e5f73-0c5f-43bf-8acb-da15dea7e4cf",
    "workspace_id": "751ad273-e53d-47b6-8ebd-4d3757c8ff69",
    "work_id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "b369fc88-0c1f-4427-bfa7-c43eb6642bd9",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:20.179817Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_proposal_requires_authori0/workspace",
    "request_sha256": "38006f41b7d3bc13641b7c3228371f6c724555b940c78ab6b639d477575c01f5"
  },
  "fingerprint": "9c12cbf1a0a88022af9b1c80f461a373dfafece458f8b4ab39cea103369066cf",
  "before": {
    "id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "revision": 4,
    "created_at": "2026-09-10T07:29:20.007069Z",
    "kind": "work",
    "process_id": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "revision": 5,
    "created_at": "2026-09-10T07:29:20.007069Z",
    "kind": "work",
    "process_id": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "f5a569bc-06ff-4b73-ab4d-e75c45cd90d8",
  "state_revision": 6,
  "recorded_at": "2026-09-10T07:29:20.253785Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "97bfb1d2-6208-487c-bd1b-282ae806e861",
    "workspace_id": "751ad273-e53d-47b6-8ebd-4d3757c8ff69",
    "work_id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "b369fc88-0c1f-4427-bfa7-c43eb6642bd9",
    "artifact_revision": 1,
    "content_sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312",
    "content_size": 147,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:20.233756Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_proposal_requires_authori0/workspace",
    "request_sha256": "e7d9371462880d02fc0673affc13195912b14c479e85ff9a2feee21173a0138e"
  },
  "fingerprint": "7bf1fa087ce1a1f17a6d2d3a5e36eab9b2d3cadfcfd8245138efab7f7e3455a4",
  "before": {
    "id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "revision": 5,
    "created_at": "2026-09-10T07:29:20.007069Z",
    "kind": "work",
    "process_id": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "revision": 6,
    "created_at": "2026-09-10T07:29:20.007069Z",
    "kind": "work",
    "process_id": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "b369fc88-0c1f-4427-bfa7-c43eb6642bd9",
    "revision": 1,
    "created_at": "2026-09-10T07:29:20.007069Z",
    "kind": "artifact",
    "process_id": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
    "work_id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "title": "KITE inspection",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "b369fc88-0c1f-4427-bfa7-c43eb6642bd9",
    "revision": 2,
    "created_at": "2026-09-10T07:29:20.007069Z",
    "kind": "artifact",
    "process_id": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
    "work_id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "97bfb1d2-6208-487c-bd1b-282ae806e861"
  },
  "artifact_version": {
    "id": "97bfb1d2-6208-487c-bd1b-282ae806e861",
    "artifact_id": "b369fc88-0c1f-4427-bfa7-c43eb6642bd9",
    "work_id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "process_id": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
    "artifact_revision": 2,
    "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312",
    "size": 147,
    "created_at": "2026-09-10T07:29:20.253785Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "22e7d60a-c3b4-4cf2-8f6e-fe1a5f07d319",
  "state_revision": 7,
  "recorded_at": "2026-09-10T07:29:20.323844Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "bcb7ad48-55a7-4b91-9306-58cc1c3ef002",
    "workspace_id": "751ad273-e53d-47b6-8ebd-4d3757c8ff69",
    "work_id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "b369fc88-0c1f-4427-bfa7-c43eb6642bd9",
        "version_id": "97bfb1d2-6208-487c-bd1b-282ae806e861",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "bcb7ad48-55a7-4b91-9306-58cc1c3ef002",
      "workspace_id": "751ad273-e53d-47b6-8ebd-4d3757c8ff69",
      "process": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
      "related_work": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "b369fc88-0c1f-4427-bfa7-c43eb6642bd9",
        "version_id": "97bfb1d2-6208-487c-bd1b-282ae806e861",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "0afcbfdac630cc979d6c8f02881298a1f673fbc1822027417cafc2b41fbb7348"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:20.302797Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_proposal_requires_authori0/workspace",
    "request_sha256": "b4f746cc11870610ebaba0ad038963f480404189fc70e9f5faf460e48a6ed877"
  },
  "fingerprint": "922b246b73507a467fbd137f8bb2efc7b369fc4896f598c83f101cd0c0506d83",
  "before": {
    "id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "revision": 6,
    "created_at": "2026-09-10T07:29:20.007069Z",
    "kind": "work",
    "process_id": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "c957bf58-9b7a-4be0-b128-e91ee75a42bf",
    "revision": 7,
    "created_at": "2026-09-10T07:29:20.007069Z",
    "kind": "work",
    "process_id": "8c1a68f1-561f-4b5d-8c0e-fa98255c45b7",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

