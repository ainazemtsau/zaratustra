# Zaratustra — generated overview

generated_from_revision: 4
generated_at: 2026-09-10T07:29:23.327979+00:00
workspace_id: 0e5f66d1-4718-43e8-9c45-2680aaa4ca9f

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "9147abd3-d03c-4182-9fc8-328c65b5564f",
  "revision": 1,
  "created_at": "2026-09-10T07:29:23.196449Z",
  "kind": "artifact",
  "process_id": "16989f57-05da-4b16-a14f-d55a5d646a28",
  "work_id": "4d2c8aa2-cdb4-4d7a-8126-6bb696c27e0a",
  "title": "KITE inspection",
  "status": "declared",
  "active_version": null
}
```

## event

```json
{
  "id": "8605d592-88a6-4807-ba4e-6cd542ceff79",
  "revision": 1,
  "created_at": "2026-09-10T07:29:23.196449Z",
  "kind": "event",
  "process_id": "16989f57-05da-4b16-a14f-d55a5d646a28",
  "work_id": "4d2c8aa2-cdb4-4d7a-8126-6bb696c27e0a",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.0",
  "state_revision": 1,
  "affected_ids": [
    "16989f57-05da-4b16-a14f-d55a5d646a28",
    "4d2c8aa2-cdb4-4d7a-8126-6bb696c27e0a",
    "9147abd3-d03c-4182-9fc8-328c65b5564f"
  ]
}
```

## process

```json
{
  "id": "16989f57-05da-4b16-a14f-d55a5d646a28",
  "revision": 4,
  "created_at": "2026-09-10T07:29:23.196449Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "4d2c8aa2-cdb4-4d7a-8126-6bb696c27e0a",
  "revision": 4,
  "created_at": "2026-09-10T07:29:23.196449Z",
  "kind": "work",
  "process_id": "16989f57-05da-4b16-a14f-d55a5d646a28",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

## Mutation provenance

```json
{
  "id": "b3d6b6a3-7e03-43e4-9b98-b24a83efaa4c",
  "state_revision": 2,
  "recorded_at": "2026-09-10T07:29:23.231345Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "de57e1e2-7faa-4f82-8c56-becb44f75eb1",
    "workspace_id": "0e5f66d1-4718-43e8-9c45-2680aaa4ca9f",
    "work_id": "4d2c8aa2-cdb4-4d7a-8126-6bb696c27e0a",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:23.214682Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_lot_reader_preserves_t3_s3/workspace",
    "request_sha256": "a9809cafa00b4f437c76bbba7753b061ed6ee00c480a82c36f9beadc624cafa4"
  },
  "fingerprint": "c22992fa4e9f1a1474fe77653c6f51ece708db3f35fcfa3fb38129cd571a2d59",
  "before": {
    "id": "4d2c8aa2-cdb4-4d7a-8126-6bb696c27e0a",
    "revision": 1,
    "created_at": "2026-09-10T07:29:23.196449Z",
    "kind": "work",
    "process_id": "16989f57-05da-4b16-a14f-d55a5d646a28",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "4d2c8aa2-cdb4-4d7a-8126-6bb696c27e0a",
    "revision": 2,
    "created_at": "2026-09-10T07:29:23.196449Z",
    "kind": "work",
    "process_id": "16989f57-05da-4b16-a14f-d55a5d646a28",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "340788fe-aca2-4399-ad12-22051f183ef5",
  "state_revision": 3,
  "recorded_at": "2026-09-10T07:29:23.279189Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "f979c090-c5f3-4aa9-8e5c-88b4ebb34282",
    "workspace_id": "0e5f66d1-4718-43e8-9c45-2680aaa4ca9f",
    "work_id": "4d2c8aa2-cdb4-4d7a-8126-6bb696c27e0a",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:23.263823Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_lot_reader_preserves_t3_s3/workspace",
    "request_sha256": "db679258792049306715bd397ad5d0f91400c968960f599e94ca7572a226e96e"
  },
  "fingerprint": "e331b6fb683fdc1ae0afc1505c79a4ea476d72bd335c69d243644836623466a1",
  "before": {
    "id": "4d2c8aa2-cdb4-4d7a-8126-6bb696c27e0a",
    "revision": 2,
    "created_at": "2026-09-10T07:29:23.196449Z",
    "kind": "work",
    "process_id": "16989f57-05da-4b16-a14f-d55a5d646a28",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "4d2c8aa2-cdb4-4d7a-8126-6bb696c27e0a",
    "revision": 3,
    "created_at": "2026-09-10T07:29:23.196449Z",
    "kind": "work",
    "process_id": "16989f57-05da-4b16-a14f-d55a5d646a28",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "98badbbb-9936-4fe5-a154-223be97067a4",
  "state_revision": 4,
  "recorded_at": "2026-09-10T07:29:23.327979Z",
  "product_version": "0.10.0",
  "request": {
    "version": 5,
    "operation_id": "b42c1102-6136-43a2-85b7-1a8eff499db5",
    "workspace_id": "0e5f66d1-4718-43e8-9c45-2680aaa4ca9f",
    "work_id": "4d2c8aa2-cdb4-4d7a-8126-6bb696c27e0a",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional lot binding under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:23.311574Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_lot_reader_preserves_t3_s3/workspace",
    "request_sha256": "1c8032daed06aa17e972df09f9b68d2b1b0a1fa33e16368343b738d23190d0db"
  },
  "fingerprint": "79e2bbc9c4ccbdc07c7b1ff351225c590303e7ae95455bf866db5a674cbd18d3",
  "before": {
    "id": "4d2c8aa2-cdb4-4d7a-8126-6bb696c27e0a",
    "revision": 3,
    "created_at": "2026-09-10T07:29:23.196449Z",
    "kind": "work",
    "process_id": "16989f57-05da-4b16-a14f-d55a5d646a28",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "4d2c8aa2-cdb4-4d7a-8126-6bb696c27e0a",
    "revision": 4,
    "created_at": "2026-09-10T07:29:23.196449Z",
    "kind": "work",
    "process_id": "16989f57-05da-4b16-a14f-d55a5d646a28",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "16989f57-05da-4b16-a14f-d55a5d646a28",
    "revision": 1,
    "created_at": "2026-09-10T07:29:23.196449Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "16989f57-05da-4b16-a14f-d55a5d646a28",
    "revision": 4,
    "created_at": "2026-09-10T07:29:23.196449Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

