# Zaratustra — generated overview

generated_from_revision: 7
generated_at: 2026-09-10T07:29:19.913091+00:00
workspace_id: 4d2beaa3-c40a-4916-875a-e7edb1555b6d

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "30270ca2-ca0f-414f-90ee-dd84c297a8dc",
  "revision": 2,
  "created_at": "2026-09-10T07:29:19.650874Z",
  "kind": "artifact",
  "process_id": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
  "work_id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
  "title": "KITE inspection",
  "status": "registered",
  "active_version": "8ef9fe40-ba5d-4db7-a297-e19337aaf009"
}
```

## event

```json
{
  "id": "3562bb89-960c-4927-9fa2-6ade18f970de",
  "revision": 1,
  "created_at": "2026-09-10T07:29:19.650874Z",
  "kind": "event",
  "process_id": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
  "work_id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.0",
  "state_revision": 1,
  "affected_ids": [
    "2e2177a7-e30d-492a-a1ae-65972f4647c6",
    "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "30270ca2-ca0f-414f-90ee-dd84c297a8dc"
  ]
}
```

## process

```json
{
  "id": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
  "revision": 4,
  "created_at": "2026-09-10T07:29:19.650874Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
  "revision": 7,
  "created_at": "2026-09-10T07:29:19.650874Z",
  "kind": "work",
  "process_id": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "ready",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 8ef9fe40-ba5d-4db7-a297-e19337aaf009; Artifact revision: 2
  SHA-256: f3a72fd371b23ca3e8c7f03a9c6390be88b6d9ca69fb8e994c640da91e48a7d3; bytes: 148
  File: artifacts/30270ca2-ca0f-414f-90ee-dd84c297a8dc/8ef9fe40-ba5d-4db7-a297-e19337aaf009.blob

## Mutation provenance

```json
{
  "id": "0fcc8b07-eceb-4930-bd5b-c56dffac35d9",
  "state_revision": 2,
  "recorded_at": "2026-09-10T07:29:19.678996Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "a7acd9a2-2150-4634-9778-e09ae4e122ba",
    "workspace_id": "4d2beaa3-c40a-4916-875a-e7edb1555b6d",
    "work_id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:19.665424Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h5/workspace",
    "request_sha256": "a46a5bf95ecf294bbc065a2d65cb92dd0429a817d5ee50faece8dcf89d704c59"
  },
  "fingerprint": "04e03ea9dd24fc026917722def0ec1c4cb9de2be89e53490fa2b014ca81bdfaa",
  "before": {
    "id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "revision": 1,
    "created_at": "2026-09-10T07:29:19.650874Z",
    "kind": "work",
    "process_id": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "revision": 2,
    "created_at": "2026-09-10T07:29:19.650874Z",
    "kind": "work",
    "process_id": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "70e54eab-ca3a-4f31-aa23-7334b7644356",
  "state_revision": 3,
  "recorded_at": "2026-09-10T07:29:19.719206Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "2f9ded7e-8602-4afe-bd2f-9592ce80cd2f",
    "workspace_id": "4d2beaa3-c40a-4916-875a-e7edb1555b6d",
    "work_id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:19.704459Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h5/workspace",
    "request_sha256": "1add718f5ef5ebbef51a008ef0aac20baab189d812837979f6f0a087a02c2a33"
  },
  "fingerprint": "f91d7c75363ca51009327b21cec7bbeace8b46bd94cd2fd33761f4d2cb132866",
  "before": {
    "id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "revision": 2,
    "created_at": "2026-09-10T07:29:19.650874Z",
    "kind": "work",
    "process_id": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "revision": 3,
    "created_at": "2026-09-10T07:29:19.650874Z",
    "kind": "work",
    "process_id": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "8a1dd72c-2237-4f3b-9f4f-3210e1afc0e0",
  "state_revision": 4,
  "recorded_at": "2026-09-10T07:29:19.761704Z",
  "product_version": "0.10.0",
  "request": {
    "version": 5,
    "operation_id": "85faeacd-c2c2-4143-852c-0a0f672fe776",
    "workspace_id": "4d2beaa3-c40a-4916-875a-e7edb1555b6d",
    "work_id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional lot binding under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:19.748029Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h5/workspace",
    "request_sha256": "647dfd54bcf8b50b1a73cd149618b744c7c1ce9c9f2320b063be60366ad5395d"
  },
  "fingerprint": "5c7e2f15e2111bdd7bb4290dce5128702f713802c5dd97f34cccb7be5f6be657",
  "before": {
    "id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "revision": 3,
    "created_at": "2026-09-10T07:29:19.650874Z",
    "kind": "work",
    "process_id": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "revision": 4,
    "created_at": "2026-09-10T07:29:19.650874Z",
    "kind": "work",
    "process_id": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
    "revision": 1,
    "created_at": "2026-09-10T07:29:19.650874Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
    "revision": 4,
    "created_at": "2026-09-10T07:29:19.650874Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "5d0d6b5a-79c3-4b8b-bc70-d769253cccf7",
  "state_revision": 5,
  "recorded_at": "2026-09-10T07:29:19.808221Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "3565715f-1b4f-41c7-964f-08bf66fae825",
    "workspace_id": "4d2beaa3-c40a-4916-875a-e7edb1555b6d",
    "work_id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "30270ca2-ca0f-414f-90ee-dd84c297a8dc",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:19.793080Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h5/workspace",
    "request_sha256": "22c830b34419ba361a9ff1a185fc4632072c2008971601d93aa5ca5324e62855"
  },
  "fingerprint": "904fda6e772620c8af8e8f2aca87aae84db8adfc30932f042bbf89f0c94adf31",
  "before": {
    "id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "revision": 4,
    "created_at": "2026-09-10T07:29:19.650874Z",
    "kind": "work",
    "process_id": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "revision": 5,
    "created_at": "2026-09-10T07:29:19.650874Z",
    "kind": "work",
    "process_id": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "54607644-3399-4487-84d0-7e190f7b01ef",
  "state_revision": 6,
  "recorded_at": "2026-09-10T07:29:19.853440Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "8ef9fe40-ba5d-4db7-a297-e19337aaf009",
    "workspace_id": "4d2beaa3-c40a-4916-875a-e7edb1555b6d",
    "work_id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "30270ca2-ca0f-414f-90ee-dd84c297a8dc",
    "artifact_revision": 1,
    "content_sha256": "f3a72fd371b23ca3e8c7f03a9c6390be88b6d9ca69fb8e994c640da91e48a7d3",
    "content_size": 148,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:19.837721Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h5/workspace",
    "request_sha256": "a56c6d0051229b8712882bb8f22bb8b92989d397708d8a5d3251e3649d50c572"
  },
  "fingerprint": "d74de03397af86d04adfbdda0509b5f6f05351a3546f93e0bd626f7a601e72b7",
  "before": {
    "id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "revision": 5,
    "created_at": "2026-09-10T07:29:19.650874Z",
    "kind": "work",
    "process_id": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "revision": 6,
    "created_at": "2026-09-10T07:29:19.650874Z",
    "kind": "work",
    "process_id": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "30270ca2-ca0f-414f-90ee-dd84c297a8dc",
    "revision": 1,
    "created_at": "2026-09-10T07:29:19.650874Z",
    "kind": "artifact",
    "process_id": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
    "work_id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "title": "KITE inspection",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "30270ca2-ca0f-414f-90ee-dd84c297a8dc",
    "revision": 2,
    "created_at": "2026-09-10T07:29:19.650874Z",
    "kind": "artifact",
    "process_id": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
    "work_id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "8ef9fe40-ba5d-4db7-a297-e19337aaf009"
  },
  "artifact_version": {
    "id": "8ef9fe40-ba5d-4db7-a297-e19337aaf009",
    "artifact_id": "30270ca2-ca0f-414f-90ee-dd84c297a8dc",
    "work_id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "process_id": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
    "artifact_revision": 2,
    "sha256": "f3a72fd371b23ca3e8c7f03a9c6390be88b6d9ca69fb8e994c640da91e48a7d3",
    "size": 148,
    "created_at": "2026-09-10T07:29:19.853440Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "dfa1d50b-0dc5-4750-a5aa-2c1982575cc8",
  "state_revision": 7,
  "recorded_at": "2026-09-10T07:29:19.913091Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "eea71227-6182-4c4e-86e6-c8c1f2c000b8",
    "workspace_id": "4d2beaa3-c40a-4916-875a-e7edb1555b6d",
    "work_id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "30270ca2-ca0f-414f-90ee-dd84c297a8dc",
        "version_id": "8ef9fe40-ba5d-4db7-a297-e19337aaf009",
        "sha256": "f3a72fd371b23ca3e8c7f03a9c6390be88b6d9ca69fb8e994c640da91e48a7d3"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "eea71227-6182-4c4e-86e6-c8c1f2c000b8",
      "workspace_id": "4d2beaa3-c40a-4916-875a-e7edb1555b6d",
      "process": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
      "related_work": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "30270ca2-ca0f-414f-90ee-dd84c297a8dc",
        "version_id": "8ef9fe40-ba5d-4db7-a297-e19337aaf009",
        "sha256": "f3a72fd371b23ca3e8c7f03a9c6390be88b6d9ca69fb8e994c640da91e48a7d3"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "1b0e98e5fbf3dd112e45bf5b8a20568f5cbbffda08a7655e3d357dac94784ad8"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:19.896789Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h5/workspace",
    "request_sha256": "6876bcfc31d4e2f13fd54a9c35addb168d818e03590989826e5a459798f0e5b7"
  },
  "fingerprint": "94c8ced95febcc08553c3ca0cb56888fb512cf5e787644eec415954d3015ac0b",
  "before": {
    "id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "revision": 6,
    "created_at": "2026-09-10T07:29:19.650874Z",
    "kind": "work",
    "process_id": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "31280faf-b921-4c08-a69e-b2cecc5d3c70",
    "revision": 7,
    "created_at": "2026-09-10T07:29:19.650874Z",
    "kind": "work",
    "process_id": "2e2177a7-e30d-492a-a1ae-65972f4647c6",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

