# Zaratustra — generated overview

generated_from_revision: 7
generated_at: 2026-09-10T07:29:18.846151+00:00
workspace_id: 11ed290a-c86b-4ece-9bbd-1b687d721c48

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "700cf14b-9a5b-46a9-b709-af8c3670d752",
  "revision": 2,
  "created_at": "2026-09-10T07:29:18.478953Z",
  "kind": "artifact",
  "process_id": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
  "work_id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
  "title": "KITE inspection",
  "status": "registered",
  "active_version": "a0870545-7fe3-422b-8a25-77c6c1a226f8"
}
```

## event

```json
{
  "id": "463bd215-475e-4497-b467-dfbef69c8303",
  "revision": 1,
  "created_at": "2026-09-10T07:29:18.478953Z",
  "kind": "event",
  "process_id": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
  "work_id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.0",
  "state_revision": 1,
  "affected_ids": [
    "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
    "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "700cf14b-9a5b-46a9-b709-af8c3670d752"
  ]
}
```

## process

```json
{
  "id": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
  "revision": 4,
  "created_at": "2026-09-10T07:29:18.478953Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
  "revision": 7,
  "created_at": "2026-09-10T07:29:18.478953Z",
  "kind": "work",
  "process_id": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "ready",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: a0870545-7fe3-422b-8a25-77c6c1a226f8; Artifact revision: 2
  SHA-256: e646aaa5fc8211ff5d8cb708a9d1ff6fdbd8318c9c643c67e6e73e6c00608f1d; bytes: 98
  File: artifacts/700cf14b-9a5b-46a9-b709-af8c3670d752/a0870545-7fe3-422b-8a25-77c6c1a226f8.blob

## Mutation provenance

```json
{
  "id": "56acba4b-d85e-4b6b-96c5-a0d465295e20",
  "state_revision": 2,
  "recorded_at": "2026-09-10T07:29:18.508516Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "d59e7e9e-05b3-45db-a379-b5a7b6d0f4c7",
    "workspace_id": "11ed290a-c86b-4ece-9bbd-1b687d721c48",
    "work_id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:18.494869Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h2/workspace",
    "request_sha256": "ad65a1b8d6b28befcc36d47128da9761719c6074a04ca16d6791d6b9f6715697"
  },
  "fingerprint": "bcaa2df0aa23d39b8f0cbf3d11c243115f533edeaa9ab4321caa6b3b7e5d21a1",
  "before": {
    "id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "revision": 1,
    "created_at": "2026-09-10T07:29:18.478953Z",
    "kind": "work",
    "process_id": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "revision": 2,
    "created_at": "2026-09-10T07:29:18.478953Z",
    "kind": "work",
    "process_id": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "067c39ab-37be-4da5-8b21-c17ee19502d3",
  "state_revision": 3,
  "recorded_at": "2026-09-10T07:29:18.548074Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "13bfe829-26b7-408a-8195-ce07d1870ac3",
    "workspace_id": "11ed290a-c86b-4ece-9bbd-1b687d721c48",
    "work_id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:18.533914Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h2/workspace",
    "request_sha256": "b31a073c6cb613237b8da9a819ddc3cb3fc18506fdbf09f1f3974ac857172a59"
  },
  "fingerprint": "03401d03410fdc5c2a1622b4c157bddf6973c4a7613079cd18a25f85fa863e3f",
  "before": {
    "id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "revision": 2,
    "created_at": "2026-09-10T07:29:18.478953Z",
    "kind": "work",
    "process_id": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "revision": 3,
    "created_at": "2026-09-10T07:29:18.478953Z",
    "kind": "work",
    "process_id": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "a0f4f122-35de-4763-bd48-9ec11ee2805a",
  "state_revision": 4,
  "recorded_at": "2026-09-10T07:29:18.593214Z",
  "product_version": "0.10.0",
  "request": {
    "version": 5,
    "operation_id": "828d4c30-02e5-4665-bf1c-3170ff95e4d8",
    "workspace_id": "11ed290a-c86b-4ece-9bbd-1b687d721c48",
    "work_id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional lot binding under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:18.578625Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h2/workspace",
    "request_sha256": "2e62e42ea773ba6ec339e18305235596402d4277f603489aa5192593c557ef13"
  },
  "fingerprint": "d79f968e4cc74fab6a1227bd0f903b847967bd87106577a2ec2398acd22d8ceb",
  "before": {
    "id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "revision": 3,
    "created_at": "2026-09-10T07:29:18.478953Z",
    "kind": "work",
    "process_id": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "revision": 4,
    "created_at": "2026-09-10T07:29:18.478953Z",
    "kind": "work",
    "process_id": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
    "revision": 1,
    "created_at": "2026-09-10T07:29:18.478953Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
    "revision": 4,
    "created_at": "2026-09-10T07:29:18.478953Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "700a14ce-0364-4a04-bd39-834ea17f6a42",
  "state_revision": 5,
  "recorded_at": "2026-09-10T07:29:18.738491Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "8121d630-b48f-4c9a-8393-fafbe80e9a54",
    "workspace_id": "11ed290a-c86b-4ece-9bbd-1b687d721c48",
    "work_id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "700cf14b-9a5b-46a9-b709-af8c3670d752",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:18.723200Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h2/workspace",
    "request_sha256": "6527f562253cdb98436c81f389856740dc6014e981ae9e60ed645ca0369de59e"
  },
  "fingerprint": "ff9987985969752963c4175029f586e5fb09937e274f6e99629fdd2621b710f3",
  "before": {
    "id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "revision": 4,
    "created_at": "2026-09-10T07:29:18.478953Z",
    "kind": "work",
    "process_id": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "revision": 5,
    "created_at": "2026-09-10T07:29:18.478953Z",
    "kind": "work",
    "process_id": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "e0d4102e-b936-411d-8823-27c0a96d39c3",
  "state_revision": 6,
  "recorded_at": "2026-09-10T07:29:18.784405Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "a0870545-7fe3-422b-8a25-77c6c1a226f8",
    "workspace_id": "11ed290a-c86b-4ece-9bbd-1b687d721c48",
    "work_id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "700cf14b-9a5b-46a9-b709-af8c3670d752",
    "artifact_revision": 1,
    "content_sha256": "e646aaa5fc8211ff5d8cb708a9d1ff6fdbd8318c9c643c67e6e73e6c00608f1d",
    "content_size": 98,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:18.769253Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h2/workspace",
    "request_sha256": "6af32948ffa7ddaa08d4daac538d9512ea97ac68052be2d7aa6d71a2ecd8529b"
  },
  "fingerprint": "989a6d502bf9b1e8934bf2fc2aa091347ca214285662e20140866eb8229670ee",
  "before": {
    "id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "revision": 5,
    "created_at": "2026-09-10T07:29:18.478953Z",
    "kind": "work",
    "process_id": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "revision": 6,
    "created_at": "2026-09-10T07:29:18.478953Z",
    "kind": "work",
    "process_id": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "700cf14b-9a5b-46a9-b709-af8c3670d752",
    "revision": 1,
    "created_at": "2026-09-10T07:29:18.478953Z",
    "kind": "artifact",
    "process_id": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
    "work_id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "title": "KITE inspection",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "700cf14b-9a5b-46a9-b709-af8c3670d752",
    "revision": 2,
    "created_at": "2026-09-10T07:29:18.478953Z",
    "kind": "artifact",
    "process_id": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
    "work_id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "a0870545-7fe3-422b-8a25-77c6c1a226f8"
  },
  "artifact_version": {
    "id": "a0870545-7fe3-422b-8a25-77c6c1a226f8",
    "artifact_id": "700cf14b-9a5b-46a9-b709-af8c3670d752",
    "work_id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "process_id": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
    "artifact_revision": 2,
    "sha256": "e646aaa5fc8211ff5d8cb708a9d1ff6fdbd8318c9c643c67e6e73e6c00608f1d",
    "size": 98,
    "created_at": "2026-09-10T07:29:18.784405Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "f5d6a9b5-b6c8-43f3-a175-3997f40df6e3",
  "state_revision": 7,
  "recorded_at": "2026-09-10T07:29:18.846151Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "009effcd-8761-490f-9a08-86762a235e89",
    "workspace_id": "11ed290a-c86b-4ece-9bbd-1b687d721c48",
    "work_id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "700cf14b-9a5b-46a9-b709-af8c3670d752",
        "version_id": "a0870545-7fe3-422b-8a25-77c6c1a226f8",
        "sha256": "e646aaa5fc8211ff5d8cb708a9d1ff6fdbd8318c9c643c67e6e73e6c00608f1d"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "009effcd-8761-490f-9a08-86762a235e89",
      "workspace_id": "11ed290a-c86b-4ece-9bbd-1b687d721c48",
      "process": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
      "related_work": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "700cf14b-9a5b-46a9-b709-af8c3670d752",
        "version_id": "a0870545-7fe3-422b-8a25-77c6c1a226f8",
        "sha256": "e646aaa5fc8211ff5d8cb708a9d1ff6fdbd8318c9c643c67e6e73e6c00608f1d"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "7eb7fa85cf28ad82dd9f31f0de6a7fd243696dee8503cae14ee0fc161dc1d6ce"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:18.829457Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h2/workspace",
    "request_sha256": "f940c95950cfa09a056ed971b0e982b0b646a1e3f61f1acefffc7ee41b7e6a4d"
  },
  "fingerprint": "6ff5183f94341ef7f8554490f5b1fafeff75332aa7fe085a8b8e579d3fb0f8e6",
  "before": {
    "id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "revision": 6,
    "created_at": "2026-09-10T07:29:18.478953Z",
    "kind": "work",
    "process_id": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "6bb7a4f6-dc50-45fb-a977-71f1f3d1f061",
    "revision": 7,
    "created_at": "2026-09-10T07:29:18.478953Z",
    "kind": "work",
    "process_id": "3458ee15-82c4-4a88-bd45-72f9c420d5dc",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

