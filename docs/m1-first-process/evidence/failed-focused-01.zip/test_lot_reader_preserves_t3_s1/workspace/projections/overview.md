# Zaratustra — generated overview

generated_from_revision: 5
generated_at: 2026-09-10T07:29:22.872007+00:00
workspace_id: 3e78c7fe-4a89-49d5-ace4-69353775e3be

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "b09991c3-7437-4758-a039-13dc5933e6be",
  "revision": 1,
  "created_at": "2026-09-10T07:29:22.669503Z",
  "kind": "artifact",
  "process_id": "5420ca5a-b2bc-49e1-8cfa-d3e933f26b96",
  "work_id": "734bb00e-393f-405a-aba5-03d5143063b5",
  "title": "KITE inspection",
  "status": "declared",
  "active_version": null
}
```

## event

```json
{
  "id": "4de9b0b2-9190-49cb-870a-da94d4b7cb03",
  "revision": 1,
  "created_at": "2026-09-10T07:29:22.669503Z",
  "kind": "event",
  "process_id": "5420ca5a-b2bc-49e1-8cfa-d3e933f26b96",
  "work_id": "734bb00e-393f-405a-aba5-03d5143063b5",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.0",
  "state_revision": 1,
  "affected_ids": [
    "5420ca5a-b2bc-49e1-8cfa-d3e933f26b96",
    "734bb00e-393f-405a-aba5-03d5143063b5",
    "b09991c3-7437-4758-a039-13dc5933e6be"
  ]
}
```

## process

```json
{
  "id": "5420ca5a-b2bc-49e1-8cfa-d3e933f26b96",
  "revision": 4,
  "created_at": "2026-09-10T07:29:22.669503Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "734bb00e-393f-405a-aba5-03d5143063b5",
  "revision": 5,
  "created_at": "2026-09-10T07:29:22.669503Z",
  "kind": "work",
  "process_id": "5420ca5a-b2bc-49e1-8cfa-d3e933f26b96",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "ready",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

## Mutation provenance

```json
{
  "id": "9a140370-4112-40d5-8a7e-a6a69563de63",
  "state_revision": 2,
  "recorded_at": "2026-09-10T07:29:22.704811Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "a93e8a60-2829-485f-98cd-3a0b680f75aa",
    "workspace_id": "3e78c7fe-4a89-49d5-ace4-69353775e3be",
    "work_id": "734bb00e-393f-405a-aba5-03d5143063b5",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:22.688629Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_lot_reader_preserves_t3_s1/workspace",
    "request_sha256": "9be0273dd455cd4ee77f60a880ee81311920715d2f5b61c8ee0b2276c4a1b8cc"
  },
  "fingerprint": "af0f8161a35d31866f8871eb0ca3142839d432e1008ffe6eca966fe0ba5d17ae",
  "before": {
    "id": "734bb00e-393f-405a-aba5-03d5143063b5",
    "revision": 1,
    "created_at": "2026-09-10T07:29:22.669503Z",
    "kind": "work",
    "process_id": "5420ca5a-b2bc-49e1-8cfa-d3e933f26b96",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "734bb00e-393f-405a-aba5-03d5143063b5",
    "revision": 2,
    "created_at": "2026-09-10T07:29:22.669503Z",
    "kind": "work",
    "process_id": "5420ca5a-b2bc-49e1-8cfa-d3e933f26b96",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "25ff9c6e-9f56-43b4-b6ba-3381880eb46e",
  "state_revision": 3,
  "recorded_at": "2026-09-10T07:29:22.754027Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "4981fd76-a54f-496b-b2ca-4c77b4da8288",
    "workspace_id": "3e78c7fe-4a89-49d5-ace4-69353775e3be",
    "work_id": "734bb00e-393f-405a-aba5-03d5143063b5",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:22.737030Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_lot_reader_preserves_t3_s1/workspace",
    "request_sha256": "87715a05724f06901d5aa54507d9a093cd77b5fc56f86a913df6e0f761d35912"
  },
  "fingerprint": "ff0a5d61b49c808882a2ae30478b0aa6272bb54a9cdc70e57c7cbd8bf62b3a06",
  "before": {
    "id": "734bb00e-393f-405a-aba5-03d5143063b5",
    "revision": 2,
    "created_at": "2026-09-10T07:29:22.669503Z",
    "kind": "work",
    "process_id": "5420ca5a-b2bc-49e1-8cfa-d3e933f26b96",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "734bb00e-393f-405a-aba5-03d5143063b5",
    "revision": 3,
    "created_at": "2026-09-10T07:29:22.669503Z",
    "kind": "work",
    "process_id": "5420ca5a-b2bc-49e1-8cfa-d3e933f26b96",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "198b6b0f-f0b5-4591-a4ed-fca49d4f1a1b",
  "state_revision": 4,
  "recorded_at": "2026-09-10T07:29:22.806945Z",
  "product_version": "0.10.0",
  "request": {
    "version": 5,
    "operation_id": "af27af25-b297-45dc-92dc-f2970e5bebef",
    "workspace_id": "3e78c7fe-4a89-49d5-ace4-69353775e3be",
    "work_id": "734bb00e-393f-405a-aba5-03d5143063b5",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional lot binding under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:22.790627Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_lot_reader_preserves_t3_s1/workspace",
    "request_sha256": "45a600ad51c39951ac75180aee413a181cbcb325da3fbee23f35e7acc5a3daa8"
  },
  "fingerprint": "2c6762df621dbcf9fb9e9b050b5f6f303ef92a9775cd931a40b03163815c49a8",
  "before": {
    "id": "734bb00e-393f-405a-aba5-03d5143063b5",
    "revision": 3,
    "created_at": "2026-09-10T07:29:22.669503Z",
    "kind": "work",
    "process_id": "5420ca5a-b2bc-49e1-8cfa-d3e933f26b96",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "734bb00e-393f-405a-aba5-03d5143063b5",
    "revision": 4,
    "created_at": "2026-09-10T07:29:22.669503Z",
    "kind": "work",
    "process_id": "5420ca5a-b2bc-49e1-8cfa-d3e933f26b96",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "5420ca5a-b2bc-49e1-8cfa-d3e933f26b96",
    "revision": 1,
    "created_at": "2026-09-10T07:29:22.669503Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "5420ca5a-b2bc-49e1-8cfa-d3e933f26b96",
    "revision": 4,
    "created_at": "2026-09-10T07:29:22.669503Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "5d644269-304a-42ee-aaeb-4571c6de1cf2",
  "state_revision": 5,
  "recorded_at": "2026-09-10T07:29:22.872007Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "7dd87e63-a327-4444-a867-f0166f059690",
    "workspace_id": "3e78c7fe-4a89-49d5-ace4-69353775e3be",
    "work_id": "734bb00e-393f-405a-aba5-03d5143063b5",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "b09991c3-7437-4758-a039-13dc5933e6be",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:22.853936Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_lot_reader_preserves_t3_s1/workspace",
    "request_sha256": "ccc809e5f943d8c472351dbb7b7718fe880b4d634013fd0a95ed375601db1862"
  },
  "fingerprint": "f549af7d1a46abe2874c19f6aba2df66e8e10d2adb7d43f71b9821129954fa4a",
  "before": {
    "id": "734bb00e-393f-405a-aba5-03d5143063b5",
    "revision": 4,
    "created_at": "2026-09-10T07:29:22.669503Z",
    "kind": "work",
    "process_id": "5420ca5a-b2bc-49e1-8cfa-d3e933f26b96",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "734bb00e-393f-405a-aba5-03d5143063b5",
    "revision": 5,
    "created_at": "2026-09-10T07:29:22.669503Z",
    "kind": "work",
    "process_id": "5420ca5a-b2bc-49e1-8cfa-d3e933f26b96",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

