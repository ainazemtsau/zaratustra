# Zaratustra — generated overview

generated_from_revision: 7
generated_at: 2026-09-10T07:29:18.030501+00:00
workspace_id: 460753ea-bc96-4e3a-aae6-3b3e52758d8d

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "a8394577-890b-449a-ac0b-1032f457f62e",
  "revision": 2,
  "created_at": "2026-09-10T07:29:17.733389Z",
  "kind": "artifact",
  "process_id": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
  "work_id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
  "title": "KITE inspection",
  "status": "registered",
  "active_version": "186bf64b-c514-4d58-9567-2657c3b7f6c0"
}
```

## event

```json
{
  "id": "67293102-4440-4ab8-bcf6-a620d079a54d",
  "revision": 1,
  "created_at": "2026-09-10T07:29:17.733389Z",
  "kind": "event",
  "process_id": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
  "work_id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.0",
  "state_revision": 1,
  "affected_ids": [
    "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
    "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "a8394577-890b-449a-ac0b-1032f457f62e"
  ]
}
```

## process

```json
{
  "id": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
  "revision": 4,
  "created_at": "2026-09-10T07:29:17.733389Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
  "revision": 7,
  "created_at": "2026-09-10T07:29:17.733389Z",
  "kind": "work",
  "process_id": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "ready",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 186bf64b-c514-4d58-9567-2657c3b7f6c0; Artifact revision: 2
  SHA-256: 79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f; bytes: 148
  File: artifacts/a8394577-890b-449a-ac0b-1032f457f62e/186bf64b-c514-4d58-9567-2657c3b7f6c0.blob

## Mutation provenance

```json
{
  "id": "fcf3fcd6-2a6f-42bf-9156-88a04e59ec32",
  "state_revision": 2,
  "recorded_at": "2026-09-10T07:29:17.789272Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "7a7bcf15-95d7-4801-b1d5-8937fb3d8e83",
    "workspace_id": "460753ea-bc96-4e3a-aae6-3b3e52758d8d",
    "work_id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:17.770926Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h0/workspace",
    "request_sha256": "734f86842d0c751c1cd7496a65e7bb73a45a398e3da38abb2119c01fed18b6aa"
  },
  "fingerprint": "bb29338f2a3ac4bdf1541fa22354df9a0d183af2ee5c6c2f85410c666aaf0b9e",
  "before": {
    "id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "revision": 1,
    "created_at": "2026-09-10T07:29:17.733389Z",
    "kind": "work",
    "process_id": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "revision": 2,
    "created_at": "2026-09-10T07:29:17.733389Z",
    "kind": "work",
    "process_id": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "048b7263-2ccb-4f7a-bcf6-9837f0528c74",
  "state_revision": 3,
  "recorded_at": "2026-09-10T07:29:17.832017Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "a1c3677c-6609-4dd4-a555-b24faefca260",
    "workspace_id": "460753ea-bc96-4e3a-aae6-3b3e52758d8d",
    "work_id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:17.816009Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h0/workspace",
    "request_sha256": "9b223d988596d0437aceda28502c2b4fdca014bdf1b6d9ed7ab609a5bdd6092f"
  },
  "fingerprint": "2997deb5e51e227f26e2f8d9be19ad91e7961f1951cbdd5fb21c7810186c0a45",
  "before": {
    "id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "revision": 2,
    "created_at": "2026-09-10T07:29:17.733389Z",
    "kind": "work",
    "process_id": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "revision": 3,
    "created_at": "2026-09-10T07:29:17.733389Z",
    "kind": "work",
    "process_id": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "cba11716-123f-4070-890c-9d1adf5d51f9",
  "state_revision": 4,
  "recorded_at": "2026-09-10T07:29:17.877535Z",
  "product_version": "0.10.0",
  "request": {
    "version": 5,
    "operation_id": "50a15abf-deab-4393-859b-46833edd6751",
    "workspace_id": "460753ea-bc96-4e3a-aae6-3b3e52758d8d",
    "work_id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional lot binding under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:17.863094Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h0/workspace",
    "request_sha256": "e3dc95a3e249b1134522b61f7e0a0c871ca6914ab03838225157bb1d86f30506"
  },
  "fingerprint": "602aa861a670d713029b39877613c58506e905ecc2c925b58fa137e825d00dc8",
  "before": {
    "id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "revision": 3,
    "created_at": "2026-09-10T07:29:17.733389Z",
    "kind": "work",
    "process_id": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "revision": 4,
    "created_at": "2026-09-10T07:29:17.733389Z",
    "kind": "work",
    "process_id": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
    "revision": 1,
    "created_at": "2026-09-10T07:29:17.733389Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
    "revision": 4,
    "created_at": "2026-09-10T07:29:17.733389Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "2b8cd97d-fcf8-4f5c-aa61-c11969a235b6",
  "state_revision": 5,
  "recorded_at": "2026-09-10T07:29:17.921626Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "22b26e77-9f5d-4b40-94ef-19843d7fa1bb",
    "workspace_id": "460753ea-bc96-4e3a-aae6-3b3e52758d8d",
    "work_id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "a8394577-890b-449a-ac0b-1032f457f62e",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:17.907361Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h0/workspace",
    "request_sha256": "1831a97f228e037b0aa79a05654a7927b6f90d8b2275e3a36644c9cf5f4de62b"
  },
  "fingerprint": "4eec66ff9fbfead47503c93c62971a6e06d318a92a262a700b0306733e73476e",
  "before": {
    "id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "revision": 4,
    "created_at": "2026-09-10T07:29:17.733389Z",
    "kind": "work",
    "process_id": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "revision": 5,
    "created_at": "2026-09-10T07:29:17.733389Z",
    "kind": "work",
    "process_id": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "a3547199-fa0d-45c5-8d11-76ec13a6b143",
  "state_revision": 6,
  "recorded_at": "2026-09-10T07:29:17.966691Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "186bf64b-c514-4d58-9567-2657c3b7f6c0",
    "workspace_id": "460753ea-bc96-4e3a-aae6-3b3e52758d8d",
    "work_id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "a8394577-890b-449a-ac0b-1032f457f62e",
    "artifact_revision": 1,
    "content_sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f",
    "content_size": 148,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:17.950854Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h0/workspace",
    "request_sha256": "5b37d60c25c06e4bd82092da591365890a2257f237d00056ad3772a17ff60050"
  },
  "fingerprint": "1d07075ed0f5824b6704eff748d1bf004bd2b81422d95665a83a5c66732625ad",
  "before": {
    "id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "revision": 5,
    "created_at": "2026-09-10T07:29:17.733389Z",
    "kind": "work",
    "process_id": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "revision": 6,
    "created_at": "2026-09-10T07:29:17.733389Z",
    "kind": "work",
    "process_id": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "a8394577-890b-449a-ac0b-1032f457f62e",
    "revision": 1,
    "created_at": "2026-09-10T07:29:17.733389Z",
    "kind": "artifact",
    "process_id": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
    "work_id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "title": "KITE inspection",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "a8394577-890b-449a-ac0b-1032f457f62e",
    "revision": 2,
    "created_at": "2026-09-10T07:29:17.733389Z",
    "kind": "artifact",
    "process_id": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
    "work_id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "186bf64b-c514-4d58-9567-2657c3b7f6c0"
  },
  "artifact_version": {
    "id": "186bf64b-c514-4d58-9567-2657c3b7f6c0",
    "artifact_id": "a8394577-890b-449a-ac0b-1032f457f62e",
    "work_id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "process_id": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
    "artifact_revision": 2,
    "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f",
    "size": 148,
    "created_at": "2026-09-10T07:29:17.966691Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "14f0b150-5167-4578-88da-f014cc6d9b19",
  "state_revision": 7,
  "recorded_at": "2026-09-10T07:29:18.030501Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "d9b8f05e-5f40-4bae-9133-d51f6beaab4f",
    "workspace_id": "460753ea-bc96-4e3a-aae6-3b3e52758d8d",
    "work_id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "a8394577-890b-449a-ac0b-1032f457f62e",
        "version_id": "186bf64b-c514-4d58-9567-2657c3b7f6c0",
        "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "d9b8f05e-5f40-4bae-9133-d51f6beaab4f",
      "workspace_id": "460753ea-bc96-4e3a-aae6-3b3e52758d8d",
      "process": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
      "related_work": "6a4f022f-248c-479d-b4b4-60d61a13b119",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "a8394577-890b-449a-ac0b-1032f457f62e",
        "version_id": "186bf64b-c514-4d58-9567-2657c3b7f6c0",
        "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "2c4aaacaaab8bc782dd01dfe00dd9d68b126aadcab9b8d5c93927b490eaa65bd"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:18.012588Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h0/workspace",
    "request_sha256": "dda7fdd7c75d33baae9d8bf26836d7161e1af5bcd2b442b8afcb32dd10490df9"
  },
  "fingerprint": "c6ee0c8f537ac2d1ebd1f761118ebc4abf1bdba7141e8eb40d0bf9429a427a99",
  "before": {
    "id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "revision": 6,
    "created_at": "2026-09-10T07:29:17.733389Z",
    "kind": "work",
    "process_id": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "6a4f022f-248c-479d-b4b4-60d61a13b119",
    "revision": 7,
    "created_at": "2026-09-10T07:29:17.733389Z",
    "kind": "work",
    "process_id": "527e5439-4b00-41ce-a4e3-f7bf8f68d3ce",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

