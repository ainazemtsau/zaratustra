# Zaratustra — generated overview

generated_from_revision: 10
generated_at: 2026-09-10T07:29:22.266940+00:00
workspace_id: 003a786c-fcc2-4946-a95f-d454fe89851a

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "58b0d1d9-b839-4e01-9b41-0deba812515a",
  "revision": 2,
  "created_at": "2026-09-10T07:29:21.922546Z",
  "kind": "artifact",
  "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
  "work_id": "9092ad95-73fe-437a-b12e-3310b2791142",
  "title": "KITE disposition",
  "status": "registered",
  "active_version": "f3a1edbf-98c7-4470-a511-975692ff9968"
}
```

## artifact

```json
{
  "id": "a22d3732-fbf6-4321-b72b-4c50b9045e27",
  "revision": 2,
  "created_at": "2026-09-10T07:29:21.474549Z",
  "kind": "artifact",
  "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
  "work_id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
  "title": "KITE inspection",
  "status": "registered",
  "active_version": "4bb84b7a-cb88-4986-ac39-6482cde0fd89"
}
```

## event

```json
{
  "id": "37604b99-57a4-4074-821c-6b93d4a4689e",
  "revision": 1,
  "created_at": "2026-09-10T07:29:21.474549Z",
  "kind": "event",
  "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
  "work_id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.0",
  "state_revision": 1,
  "affected_ids": [
    "dac49dce-d264-44f0-b005-8606d35a63c3",
    "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "a22d3732-fbf6-4321-b72b-4c50b9045e27"
  ]
}
```

## process

```json
{
  "id": "dac49dce-d264-44f0-b005-8606d35a63c3",
  "revision": 4,
  "created_at": "2026-09-10T07:29:21.474549Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "9092ad95-73fe-437a-b12e-3310b2791142",
  "revision": 10,
  "created_at": "2026-09-10T07:29:21.922546Z",
  "kind": "work",
  "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
  "goal": "Choose release or discard for inspected fictional KITE",
  "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
  "acceptance": [
    "Explicit disposition naming the exact accepted inspection SHA256"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "ready",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:decide",
    "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
  "revision": 8,
  "created_at": "2026-09-10T07:29:21.474549Z",
  "kind": "work",
  "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "completion_id": "93b5a446-6bd7-48b9-8a2d-76834800570e",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 4bb84b7a-cb88-4986-ac39-6482cde0fd89; Artifact revision: 2
  SHA-256: e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312; bytes: 147
  File: artifacts/a22d3732-fbf6-4321-b72b-4c50b9045e27/4bb84b7a-cb88-4986-ac39-6482cde0fd89.blob

- Version: f3a1edbf-98c7-4470-a511-975692ff9968; Artifact revision: 2
  SHA-256: b42a75d1b5f1a9821a388858a1666aaf8c11f976569e5ce17c49b97cf1da0145; bytes: 146
  File: artifacts/58b0d1d9-b839-4e01-9b41-0deba812515a/f3a1edbf-98c7-4470-a511-975692ff9968.blob

## Mutation provenance

```json
{
  "id": "887769ac-31df-4c7a-a3a7-a9117b497ca8",
  "state_revision": 2,
  "recorded_at": "2026-09-10T07:29:21.508522Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "2e612c4d-df1a-43d0-8347-848b54587ac1",
    "workspace_id": "003a786c-fcc2-4946-a95f-d454fe89851a",
    "work_id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:21.492541Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_exact_basis_result_grants1/workspace",
    "request_sha256": "08db12667ee7cef9ddc2349cc786260dc65385b02aedb9813d2659790c44e499"
  },
  "fingerprint": "38aab448daaaafa5bb7dafcf58a326218290ccb379abb26011ea8d92dc82cf6c",
  "before": {
    "id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "revision": 1,
    "created_at": "2026-09-10T07:29:21.474549Z",
    "kind": "work",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "revision": 2,
    "created_at": "2026-09-10T07:29:21.474549Z",
    "kind": "work",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "96d4509d-96fd-4152-8fd5-c3477eb03a85",
  "state_revision": 3,
  "recorded_at": "2026-09-10T07:29:21.554187Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "46dd2a1e-f175-43c5-90d6-b4c462d79017",
    "workspace_id": "003a786c-fcc2-4946-a95f-d454fe89851a",
    "work_id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:21.538373Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_exact_basis_result_grants1/workspace",
    "request_sha256": "55dc22c3c604e0c322fe636d04f8f909093ee9fbabab0cca70cd596b3012be1b"
  },
  "fingerprint": "8c365b4f4d525183874252cdd5aec5d2e4c5454b4e9217ae199fb6bf8b3d7887",
  "before": {
    "id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "revision": 2,
    "created_at": "2026-09-10T07:29:21.474549Z",
    "kind": "work",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "revision": 3,
    "created_at": "2026-09-10T07:29:21.474549Z",
    "kind": "work",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "11dcae06-dd8d-4ce8-a14f-6ed0d2b2f200",
  "state_revision": 4,
  "recorded_at": "2026-09-10T07:29:21.611000Z",
  "product_version": "0.10.0",
  "request": {
    "version": 5,
    "operation_id": "b634d825-855e-45cc-a6a1-8176b6bd9b05",
    "workspace_id": "003a786c-fcc2-4946-a95f-d454fe89851a",
    "work_id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional lot binding under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:21.591236Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_exact_basis_result_grants1/workspace",
    "request_sha256": "34ca7a477a27d3b3c78e3346613d1e0668e45781bcaadcf6f3d31e7aa825cf7d"
  },
  "fingerprint": "b0e627bd84f21c7b18f67519ff8e059d12a736ca90d7640122241a2b81cfa9c5",
  "before": {
    "id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "revision": 3,
    "created_at": "2026-09-10T07:29:21.474549Z",
    "kind": "work",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "revision": 4,
    "created_at": "2026-09-10T07:29:21.474549Z",
    "kind": "work",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "revision": 1,
    "created_at": "2026-09-10T07:29:21.474549Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "revision": 4,
    "created_at": "2026-09-10T07:29:21.474549Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "ec759689-279a-402c-a024-030d5889f95f",
  "state_revision": 5,
  "recorded_at": "2026-09-10T07:29:21.669804Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "6cba6a63-87df-44b9-be3a-abd7ff46f89c",
    "workspace_id": "003a786c-fcc2-4946-a95f-d454fe89851a",
    "work_id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "a22d3732-fbf6-4321-b72b-4c50b9045e27",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:21.652007Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_exact_basis_result_grants1/workspace",
    "request_sha256": "c9bb1eb54c732a1d93f5e04f1f992df1b4d9456dce6f2b7fddbed6a5a132cc86"
  },
  "fingerprint": "4124b732c4062fb83bbe02934563799a700f60d8efa33c64beba56a8cbf46239",
  "before": {
    "id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "revision": 4,
    "created_at": "2026-09-10T07:29:21.474549Z",
    "kind": "work",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "revision": 5,
    "created_at": "2026-09-10T07:29:21.474549Z",
    "kind": "work",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "037c2b4a-489c-49dd-98b4-56e809dafc61",
  "state_revision": 6,
  "recorded_at": "2026-09-10T07:29:21.725377Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "4bb84b7a-cb88-4986-ac39-6482cde0fd89",
    "workspace_id": "003a786c-fcc2-4946-a95f-d454fe89851a",
    "work_id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "a22d3732-fbf6-4321-b72b-4c50b9045e27",
    "artifact_revision": 1,
    "content_sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312",
    "content_size": 147,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:21.705116Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_exact_basis_result_grants1/workspace",
    "request_sha256": "76f62a7af047aeea5547e94efbeeac88b339eae50c8d6af552f438b446ba50fb"
  },
  "fingerprint": "f59d6863a90dfa3e1b0e9a9c0f918f748e49e3204497dbf66a35040c893dcf1a",
  "before": {
    "id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "revision": 5,
    "created_at": "2026-09-10T07:29:21.474549Z",
    "kind": "work",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "revision": 6,
    "created_at": "2026-09-10T07:29:21.474549Z",
    "kind": "work",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "a22d3732-fbf6-4321-b72b-4c50b9045e27",
    "revision": 1,
    "created_at": "2026-09-10T07:29:21.474549Z",
    "kind": "artifact",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "work_id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "title": "KITE inspection",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "a22d3732-fbf6-4321-b72b-4c50b9045e27",
    "revision": 2,
    "created_at": "2026-09-10T07:29:21.474549Z",
    "kind": "artifact",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "work_id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "4bb84b7a-cb88-4986-ac39-6482cde0fd89"
  },
  "artifact_version": {
    "id": "4bb84b7a-cb88-4986-ac39-6482cde0fd89",
    "artifact_id": "a22d3732-fbf6-4321-b72b-4c50b9045e27",
    "work_id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "artifact_revision": 2,
    "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312",
    "size": 147,
    "created_at": "2026-09-10T07:29:21.725377Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "2ee627ad-a00a-4769-80a2-f82cc93d28fd",
  "state_revision": 7,
  "recorded_at": "2026-09-10T07:29:21.798980Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "28fe3a12-1fb7-46ce-954a-7d109e8f3d2c",
    "workspace_id": "003a786c-fcc2-4946-a95f-d454fe89851a",
    "work_id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "a22d3732-fbf6-4321-b72b-4c50b9045e27",
        "version_id": "4bb84b7a-cb88-4986-ac39-6482cde0fd89",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "28fe3a12-1fb7-46ce-954a-7d109e8f3d2c",
      "workspace_id": "003a786c-fcc2-4946-a95f-d454fe89851a",
      "process": "dac49dce-d264-44f0-b005-8606d35a63c3",
      "related_work": "db2fab94-cc7c-484a-b05e-bcccef22f397",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "a22d3732-fbf6-4321-b72b-4c50b9045e27",
        "version_id": "4bb84b7a-cb88-4986-ac39-6482cde0fd89",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "3c66dc3514f1e46509e744fc9ae7f90d86ce45df6b72a2823290687bb978d24b"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:21.776295Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_exact_basis_result_grants1/workspace",
    "request_sha256": "68cc98e6ea48edf34666c428507b32a83b968fd90851d363ce66f23bf721c60a"
  },
  "fingerprint": "96c3cabf4750ed86e96d86a296bc74cf55a65e2a8773523444ae9a1c79cb8656",
  "before": {
    "id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "revision": 6,
    "created_at": "2026-09-10T07:29:21.474549Z",
    "kind": "work",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "revision": 7,
    "created_at": "2026-09-10T07:29:21.474549Z",
    "kind": "work",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "42b70c91-e1e1-41e1-96d5-126e4536a740",
  "state_revision": 8,
  "recorded_at": "2026-09-10T07:29:21.922546Z",
  "product_version": "0.10.0",
  "request": {
    "version": 4,
    "operation_id": "93b5a446-6bd7-48b9-8a2d-76834800570e",
    "workspace_id": "003a786c-fcc2-4946-a95f-d454fe89851a",
    "work_id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "expected_revision": 7,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.lot\",\"pack_version\":\"1.0.0\",\"process_type\":\"fictional.lot-release\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "a22d3732-fbf6-4321-b72b-4c50b9045e27",
        "version_id": "4bb84b7a-cb88-4986-ac39-6482cde0fd89",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 7,
      "result": {
        "artifact_id": "a22d3732-fbf6-4321-b72b-4c50b9045e27",
        "version_id": "4bb84b7a-cb88-4986-ac39-6482cde0fd89",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      },
      "acceptance_ids": [
        "28fe3a12-1fb7-46ce-954a-7d109e8f3d2c"
      ],
      "next_work": {
        "work_id": "9092ad95-73fe-437a-b12e-3310b2791142",
        "artifact_id": "58b0d1d9-b839-4e01-9b41-0deba812515a",
        "goal": "Choose release or discard for inspected fictional KITE",
        "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
        "acceptance": [
          "Explicit disposition naming the exact accepted inspection SHA256"
        ],
        "boundaries": [
          "Fictional local evidence only; no real release or external action"
        ],
        "budget": "One finite fictional lot",
        "executor_requirements": [
          "fictional.lot/v1:decide",
          "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
        ],
        "artifact_title": "KITE disposition",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:21.899632Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_exact_basis_result_grants1/workspace",
    "request_sha256": "016de6073b5eb2bfc8fa7946ac1f8a489de473dac449a551686a1de48d2b449d"
  },
  "fingerprint": "ce29dc2b1905ec99d4da6f0897e8b2baed7bec984422bfbb7195ec2431f981df",
  "before": {
    "id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "revision": 7,
    "created_at": "2026-09-10T07:29:21.474549Z",
    "kind": "work",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "revision": 8,
    "created_at": "2026-09-10T07:29:21.474549Z",
    "kind": "work",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "completion_id": "93b5a446-6bd7-48b9-8a2d-76834800570e",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "9092ad95-73fe-437a-b12e-3310b2791142",
    "revision": 8,
    "created_at": "2026-09-10T07:29:21.922546Z",
    "kind": "work",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "58b0d1d9-b839-4e01-9b41-0deba812515a",
    "revision": 1,
    "created_at": "2026-09-10T07:29:21.922546Z",
    "kind": "artifact",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "work_id": "9092ad95-73fe-437a-b12e-3310b2791142",
    "title": "KITE disposition",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "a22d3732-fbf6-4321-b72b-4c50b9045e27",
    "revision": 2,
    "created_at": "2026-09-10T07:29:21.474549Z",
    "kind": "artifact",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "work_id": "db2fab94-cc7c-484a-b05e-bcccef22f397",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "4bb84b7a-cb88-4986-ac39-6482cde0fd89"
  },
  "result_references": [
    {
      "artifact_id": "a22d3732-fbf6-4321-b72b-4c50b9045e27",
      "version_id": "4bb84b7a-cb88-4986-ac39-6482cde0fd89",
      "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    }
  ]
}
```

```json
{
  "id": "479b16bc-ab70-411e-8b05-c0938c204e73",
  "state_revision": 9,
  "recorded_at": "2026-09-10T07:29:22.192010Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "f37dcbc3-7338-42b2-8308-c03ad69851aa",
    "workspace_id": "003a786c-fcc2-4946-a95f-d454fe89851a",
    "work_id": "9092ad95-73fe-437a-b12e-3310b2791142",
    "expected_revision": 8,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "58b0d1d9-b839-4e01-9b41-0deba812515a",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:22.168384Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_exact_basis_result_grants1/workspace",
    "request_sha256": "e4cb54bf2b8ba4e840ccf595d2db91a48f72a5fbe5bc9c170a884b78719ec57d"
  },
  "fingerprint": "4852e53a0733108b1b76ba886f2ddf7a07e34a03a50537458e2f72b91b34a7fe",
  "before": {
    "id": "9092ad95-73fe-437a-b12e-3310b2791142",
    "revision": 8,
    "created_at": "2026-09-10T07:29:21.922546Z",
    "kind": "work",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "9092ad95-73fe-437a-b12e-3310b2791142",
    "revision": 9,
    "created_at": "2026-09-10T07:29:21.922546Z",
    "kind": "work",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "f63ba64d-6b1f-40ce-b4f7-9a6bf91ba69b",
  "state_revision": 10,
  "recorded_at": "2026-09-10T07:29:22.266940Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "f3a1edbf-98c7-4470-a511-975692ff9968",
    "workspace_id": "003a786c-fcc2-4946-a95f-d454fe89851a",
    "work_id": "9092ad95-73fe-437a-b12e-3310b2791142",
    "expected_revision": 9,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "58b0d1d9-b839-4e01-9b41-0deba812515a",
    "artifact_revision": 1,
    "content_sha256": "b42a75d1b5f1a9821a388858a1666aaf8c11f976569e5ce17c49b97cf1da0145",
    "content_size": 146,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:22.239310Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_exact_basis_result_grants1/workspace",
    "request_sha256": "f19a9974e472e265801d54a6b6bea1572dac419c1fc4b8ae31a24ac7934eb626"
  },
  "fingerprint": "c2cf1951f41153679f40915802a7d5d6d8f4c3cbf6360828851c4da3012086d2",
  "before": {
    "id": "9092ad95-73fe-437a-b12e-3310b2791142",
    "revision": 9,
    "created_at": "2026-09-10T07:29:21.922546Z",
    "kind": "work",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "9092ad95-73fe-437a-b12e-3310b2791142",
    "revision": 10,
    "created_at": "2026-09-10T07:29:21.922546Z",
    "kind": "work",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "58b0d1d9-b839-4e01-9b41-0deba812515a",
    "revision": 1,
    "created_at": "2026-09-10T07:29:21.922546Z",
    "kind": "artifact",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "work_id": "9092ad95-73fe-437a-b12e-3310b2791142",
    "title": "KITE disposition",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "58b0d1d9-b839-4e01-9b41-0deba812515a",
    "revision": 2,
    "created_at": "2026-09-10T07:29:21.922546Z",
    "kind": "artifact",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "work_id": "9092ad95-73fe-437a-b12e-3310b2791142",
    "title": "KITE disposition",
    "status": "registered",
    "active_version": "f3a1edbf-98c7-4470-a511-975692ff9968"
  },
  "artifact_version": {
    "id": "f3a1edbf-98c7-4470-a511-975692ff9968",
    "artifact_id": "58b0d1d9-b839-4e01-9b41-0deba812515a",
    "work_id": "9092ad95-73fe-437a-b12e-3310b2791142",
    "process_id": "dac49dce-d264-44f0-b005-8606d35a63c3",
    "artifact_revision": 2,
    "sha256": "b42a75d1b5f1a9821a388858a1666aaf8c11f976569e5ce17c49b97cf1da0145",
    "size": 146,
    "created_at": "2026-09-10T07:29:22.266940Z",
    "state_revision": 10
  }
}
```

