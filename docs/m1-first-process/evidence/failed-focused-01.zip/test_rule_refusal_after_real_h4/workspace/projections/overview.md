# Zaratustra — generated overview

generated_from_revision: 7
generated_at: 2026-09-10T07:29:19.562061+00:00
workspace_id: d1f1e7ba-adef-4b37-bc28-8b3c9df6175d

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "f4e014d8-641a-4d43-8e41-45b28c779c4c",
  "revision": 2,
  "created_at": "2026-09-10T07:29:19.286536Z",
  "kind": "artifact",
  "process_id": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
  "work_id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
  "title": "KITE inspection",
  "status": "registered",
  "active_version": "47dc84e5-f64c-4f82-a4ee-e18ae5cfc545"
}
```

## event

```json
{
  "id": "b58d057b-67db-451c-8d45-e13f4f634d56",
  "revision": 1,
  "created_at": "2026-09-10T07:29:19.286536Z",
  "kind": "event",
  "process_id": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
  "work_id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.0",
  "state_revision": 1,
  "affected_ids": [
    "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
    "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "f4e014d8-641a-4d43-8e41-45b28c779c4c"
  ]
}
```

## process

```json
{
  "id": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
  "revision": 4,
  "created_at": "2026-09-10T07:29:19.286536Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
  "revision": 7,
  "created_at": "2026-09-10T07:29:19.286536Z",
  "kind": "work",
  "process_id": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "ready",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 47dc84e5-f64c-4f82-a4ee-e18ae5cfc545; Artifact revision: 2
  SHA-256: 0bab61a8c0872ce969b3a0d3199901e26d9c1665d52f52a8b0a2662ca088768e; bytes: 150
  File: artifacts/f4e014d8-641a-4d43-8e41-45b28c779c4c/47dc84e5-f64c-4f82-a4ee-e18ae5cfc545.blob

## Mutation provenance

```json
{
  "id": "d883cd87-0e89-46b7-921f-9b6a544e9c5d",
  "state_revision": 2,
  "recorded_at": "2026-09-10T07:29:19.316760Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "ca76c6f5-fcc8-4343-b579-a88972af75dc",
    "workspace_id": "d1f1e7ba-adef-4b37-bc28-8b3c9df6175d",
    "work_id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:19.302840Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h4/workspace",
    "request_sha256": "b1a0f467e2c26b9fb0f82c169ffa6246348e054aa035e4faa2dda8d954dc7ef6"
  },
  "fingerprint": "dbb4212d5995c5285d3c86c626adc4a40f21bfbc1831db5bb05157653e7d03d8",
  "before": {
    "id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "revision": 1,
    "created_at": "2026-09-10T07:29:19.286536Z",
    "kind": "work",
    "process_id": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "revision": 2,
    "created_at": "2026-09-10T07:29:19.286536Z",
    "kind": "work",
    "process_id": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "28d1e17d-6502-4127-a848-ec656d1e0245",
  "state_revision": 3,
  "recorded_at": "2026-09-10T07:29:19.356474Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "9e61911e-9c47-45c6-8fa8-85063eae47c6",
    "workspace_id": "d1f1e7ba-adef-4b37-bc28-8b3c9df6175d",
    "work_id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:19.342225Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h4/workspace",
    "request_sha256": "f381fdd9e393040e19a27174b52f223e4a311fb429056ff4fc6dea2a3279d264"
  },
  "fingerprint": "a6a9a0aa0b42cb96253b03aa50cdf34105a6ccaa1ec7d0c18ebb443dde60f939",
  "before": {
    "id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "revision": 2,
    "created_at": "2026-09-10T07:29:19.286536Z",
    "kind": "work",
    "process_id": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "revision": 3,
    "created_at": "2026-09-10T07:29:19.286536Z",
    "kind": "work",
    "process_id": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "a0a59935-ce8e-484a-b467-315b4c8abea8",
  "state_revision": 4,
  "recorded_at": "2026-09-10T07:29:19.401666Z",
  "product_version": "0.10.0",
  "request": {
    "version": 5,
    "operation_id": "47c75105-9342-4fff-b674-b712c1770efa",
    "workspace_id": "d1f1e7ba-adef-4b37-bc28-8b3c9df6175d",
    "work_id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional lot binding under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:19.387305Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h4/workspace",
    "request_sha256": "eff354e59df1827ba332914d855c721706ff92bd5ebe2928928c76da51b3659e"
  },
  "fingerprint": "7e23095b2ab61c9089e1ea32392b564b7abc63b49c64b04a8d65ae170c9580d6",
  "before": {
    "id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "revision": 3,
    "created_at": "2026-09-10T07:29:19.286536Z",
    "kind": "work",
    "process_id": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "revision": 4,
    "created_at": "2026-09-10T07:29:19.286536Z",
    "kind": "work",
    "process_id": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
    "revision": 1,
    "created_at": "2026-09-10T07:29:19.286536Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
    "revision": 4,
    "created_at": "2026-09-10T07:29:19.286536Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "9f20cc94-c1cd-49eb-8843-dd3dc9bb8764",
  "state_revision": 5,
  "recorded_at": "2026-09-10T07:29:19.448466Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "0ea72236-5ca7-4d5a-9d2b-52248df909f8",
    "workspace_id": "d1f1e7ba-adef-4b37-bc28-8b3c9df6175d",
    "work_id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "f4e014d8-641a-4d43-8e41-45b28c779c4c",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:19.433149Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h4/workspace",
    "request_sha256": "de97881da2072d927eb69dfbb83f3f7ef9efb04ec512cf4a9b814ca87c2d7e25"
  },
  "fingerprint": "d8981f9725cec58ecbb1733343ad999d2a658d0657b032074900204bf2a181ac",
  "before": {
    "id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "revision": 4,
    "created_at": "2026-09-10T07:29:19.286536Z",
    "kind": "work",
    "process_id": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "revision": 5,
    "created_at": "2026-09-10T07:29:19.286536Z",
    "kind": "work",
    "process_id": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "f9fdb57a-6508-4ddf-aea3-12ef82a435f5",
  "state_revision": 6,
  "recorded_at": "2026-09-10T07:29:19.498705Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "47dc84e5-f64c-4f82-a4ee-e18ae5cfc545",
    "workspace_id": "d1f1e7ba-adef-4b37-bc28-8b3c9df6175d",
    "work_id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "f4e014d8-641a-4d43-8e41-45b28c779c4c",
    "artifact_revision": 1,
    "content_sha256": "0bab61a8c0872ce969b3a0d3199901e26d9c1665d52f52a8b0a2662ca088768e",
    "content_size": 150,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:19.484253Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h4/workspace",
    "request_sha256": "f048ca975e13a6f30248fab594858319cbeed3b839ad502bbac6ab3f8070620d"
  },
  "fingerprint": "9914f4a62a1e2c79bf2cdee314ae19e5afeab45de16ca548ff067fd3d25c3732",
  "before": {
    "id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "revision": 5,
    "created_at": "2026-09-10T07:29:19.286536Z",
    "kind": "work",
    "process_id": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "revision": 6,
    "created_at": "2026-09-10T07:29:19.286536Z",
    "kind": "work",
    "process_id": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "f4e014d8-641a-4d43-8e41-45b28c779c4c",
    "revision": 1,
    "created_at": "2026-09-10T07:29:19.286536Z",
    "kind": "artifact",
    "process_id": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
    "work_id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "title": "KITE inspection",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "f4e014d8-641a-4d43-8e41-45b28c779c4c",
    "revision": 2,
    "created_at": "2026-09-10T07:29:19.286536Z",
    "kind": "artifact",
    "process_id": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
    "work_id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "47dc84e5-f64c-4f82-a4ee-e18ae5cfc545"
  },
  "artifact_version": {
    "id": "47dc84e5-f64c-4f82-a4ee-e18ae5cfc545",
    "artifact_id": "f4e014d8-641a-4d43-8e41-45b28c779c4c",
    "work_id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "process_id": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
    "artifact_revision": 2,
    "sha256": "0bab61a8c0872ce969b3a0d3199901e26d9c1665d52f52a8b0a2662ca088768e",
    "size": 150,
    "created_at": "2026-09-10T07:29:19.498705Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "2f1a46e2-6834-4bfd-89aa-e1c993d4cd1e",
  "state_revision": 7,
  "recorded_at": "2026-09-10T07:29:19.562061Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "3dac19bf-704f-41d4-90c4-95a1a7a517bc",
    "workspace_id": "d1f1e7ba-adef-4b37-bc28-8b3c9df6175d",
    "work_id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "f4e014d8-641a-4d43-8e41-45b28c779c4c",
        "version_id": "47dc84e5-f64c-4f82-a4ee-e18ae5cfc545",
        "sha256": "0bab61a8c0872ce969b3a0d3199901e26d9c1665d52f52a8b0a2662ca088768e"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "3dac19bf-704f-41d4-90c4-95a1a7a517bc",
      "workspace_id": "d1f1e7ba-adef-4b37-bc28-8b3c9df6175d",
      "process": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
      "related_work": "54b712ab-fd22-4652-8820-cf7fe9b45082",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "f4e014d8-641a-4d43-8e41-45b28c779c4c",
        "version_id": "47dc84e5-f64c-4f82-a4ee-e18ae5cfc545",
        "sha256": "0bab61a8c0872ce969b3a0d3199901e26d9c1665d52f52a8b0a2662ca088768e"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "066731df0856dc25622f4e6095192b281d2d4e370f0c46326ebf165317d26026"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:19.544377Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h4/workspace",
    "request_sha256": "5a8d4bfcc0525dd12a40cfa4861e94f0f69ca94f3b62fe3b0fb7a6cb2bea3809"
  },
  "fingerprint": "a99fd07c53ef6af8b60c619cc9c3cb203b4bc3ff018ae827c82390ad885e9ba9",
  "before": {
    "id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "revision": 6,
    "created_at": "2026-09-10T07:29:19.286536Z",
    "kind": "work",
    "process_id": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "54b712ab-fd22-4652-8820-cf7fe9b45082",
    "revision": 7,
    "created_at": "2026-09-10T07:29:19.286536Z",
    "kind": "work",
    "process_id": "fcd8ac3d-2c6b-468f-a472-f08be81971d3",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

