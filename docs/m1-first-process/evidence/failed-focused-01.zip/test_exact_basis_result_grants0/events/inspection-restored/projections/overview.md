# Zaratustra — generated overview

generated_from_revision: 8
generated_at: 2026-09-10T07:29:20.969434+00:00
workspace_id: 82c48c2a-d57e-48a3-b713-47f15e57356d

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "550299e6-5481-4efe-8cb6-d4c1d441d1ea",
  "revision": 1,
  "created_at": "2026-09-10T07:29:20.969434Z",
  "kind": "artifact",
  "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
  "work_id": "9fd3e04e-2f94-4c98-94be-672dd7ac9147",
  "title": "KITE disposition",
  "status": "declared",
  "active_version": null
}
```

## artifact

```json
{
  "id": "81196b6b-9a11-48cc-897f-e000574778e1",
  "revision": 2,
  "created_at": "2026-09-10T07:29:20.464054Z",
  "kind": "artifact",
  "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
  "work_id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
  "title": "KITE inspection",
  "status": "registered",
  "active_version": "63f67eff-7e3d-4a78-8fee-0aed24645433"
}
```

## event

```json
{
  "id": "fd82d5f0-eccd-44fd-9420-046caf1944f5",
  "revision": 1,
  "created_at": "2026-09-10T07:29:20.464054Z",
  "kind": "event",
  "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
  "work_id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.0",
  "state_revision": 1,
  "affected_ids": [
    "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "81196b6b-9a11-48cc-897f-e000574778e1"
  ]
}
```

## process

```json
{
  "id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
  "revision": 4,
  "created_at": "2026-09-10T07:29:20.464054Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "9fd3e04e-2f94-4c98-94be-672dd7ac9147",
  "revision": 8,
  "created_at": "2026-09-10T07:29:20.969434Z",
  "kind": "work",
  "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
  "goal": "Choose release or discard for inspected fictional KITE",
  "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
  "acceptance": [
    "Explicit disposition naming the exact accepted inspection SHA256"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:decide",
    "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
  "revision": 8,
  "created_at": "2026-09-10T07:29:20.464054Z",
  "kind": "work",
  "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "completion_id": "be15ecfe-2d23-4bd5-83c8-3e7048ebe681",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 63f67eff-7e3d-4a78-8fee-0aed24645433; Artifact revision: 2
  SHA-256: e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312; bytes: 147
  File: artifacts/81196b6b-9a11-48cc-897f-e000574778e1/63f67eff-7e3d-4a78-8fee-0aed24645433.blob

## Mutation provenance

```json
{
  "id": "4ce4c340-14eb-441e-9e8a-94ad49e203eb",
  "state_revision": 2,
  "recorded_at": "2026-09-10T07:29:20.496007Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "8bddf272-1107-4ac8-9126-cf570dc0eb9a",
    "workspace_id": "82c48c2a-d57e-48a3-b713-47f15e57356d",
    "work_id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:20.480717Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_exact_basis_result_grants0/workspace",
    "request_sha256": "1aa9e439beb24889982eaec8c55d86eb8ad6deceb3884ed542f71c08c78f0c8f"
  },
  "fingerprint": "459ab84bbbebad4e573c07667f4a3d227dcc8547147aa5541743cf540d87b6c7",
  "before": {
    "id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "revision": 1,
    "created_at": "2026-09-10T07:29:20.464054Z",
    "kind": "work",
    "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "revision": 2,
    "created_at": "2026-09-10T07:29:20.464054Z",
    "kind": "work",
    "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "ae58ddd1-075e-4aa2-86a5-5898d006a211",
  "state_revision": 3,
  "recorded_at": "2026-09-10T07:29:20.539443Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "c23649dd-2f58-4867-8f33-b1bd98f25562",
    "workspace_id": "82c48c2a-d57e-48a3-b713-47f15e57356d",
    "work_id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:20.525385Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_exact_basis_result_grants0/workspace",
    "request_sha256": "8deb4f6e8390599d93eb34c6e54d1c97c9a93754a5ceda14d57f6364d637ba39"
  },
  "fingerprint": "f26129db2570456c464e5db875cc9dec8f1a66f632d37543815cc66cd0abcc6c",
  "before": {
    "id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "revision": 2,
    "created_at": "2026-09-10T07:29:20.464054Z",
    "kind": "work",
    "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "revision": 3,
    "created_at": "2026-09-10T07:29:20.464054Z",
    "kind": "work",
    "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "595dba63-d2d3-4264-9655-825ea9b83f86",
  "state_revision": 4,
  "recorded_at": "2026-09-10T07:29:20.589299Z",
  "product_version": "0.10.0",
  "request": {
    "version": 5,
    "operation_id": "a0fcf898-ef1d-4137-9cce-fc71702414b6",
    "workspace_id": "82c48c2a-d57e-48a3-b713-47f15e57356d",
    "work_id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional lot binding under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:20.573391Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_exact_basis_result_grants0/workspace",
    "request_sha256": "c12095270f930e2afca144fd16ad8e5e8237dde5fa72cbb82fbbe5f21f64088f"
  },
  "fingerprint": "c4d9157e0bccb5b0a2bb9a3259bf27a288456261c964fc561bf7ff818cf96d1c",
  "before": {
    "id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "revision": 3,
    "created_at": "2026-09-10T07:29:20.464054Z",
    "kind": "work",
    "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "revision": 4,
    "created_at": "2026-09-10T07:29:20.464054Z",
    "kind": "work",
    "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "revision": 1,
    "created_at": "2026-09-10T07:29:20.464054Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "revision": 4,
    "created_at": "2026-09-10T07:29:20.464054Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "855bb2bd-9238-4044-aedd-fab476ee2415",
  "state_revision": 5,
  "recorded_at": "2026-09-10T07:29:20.642557Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "587c335b-3389-475e-9481-3be6ce2d5475",
    "workspace_id": "82c48c2a-d57e-48a3-b713-47f15e57356d",
    "work_id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "81196b6b-9a11-48cc-897f-e000574778e1",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:20.625006Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_exact_basis_result_grants0/workspace",
    "request_sha256": "b0e0510e0ad6f41fc5e0dcff51a8daff6c055e5b853f8f2e710af4914c016e29"
  },
  "fingerprint": "5374c8e67a1a6623afc8711141c06f62a85a2e9491ad020022359719e2f485cf",
  "before": {
    "id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "revision": 4,
    "created_at": "2026-09-10T07:29:20.464054Z",
    "kind": "work",
    "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "revision": 5,
    "created_at": "2026-09-10T07:29:20.464054Z",
    "kind": "work",
    "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "873d2ab3-7cb3-4678-9970-54ef6888939c",
  "state_revision": 6,
  "recorded_at": "2026-09-10T07:29:20.693761Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "63f67eff-7e3d-4a78-8fee-0aed24645433",
    "workspace_id": "82c48c2a-d57e-48a3-b713-47f15e57356d",
    "work_id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "81196b6b-9a11-48cc-897f-e000574778e1",
    "artifact_revision": 1,
    "content_sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312",
    "content_size": 147,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:20.675467Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_exact_basis_result_grants0/workspace",
    "request_sha256": "d6f25aab332ab4cb7ea8392ded1783497ecb4f72acda690f585181fd7ead4db6"
  },
  "fingerprint": "c302e67c937be412a5ace370409113bcd22cf1832f14e4fd098ee1dbb77e4ddb",
  "before": {
    "id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "revision": 5,
    "created_at": "2026-09-10T07:29:20.464054Z",
    "kind": "work",
    "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "revision": 6,
    "created_at": "2026-09-10T07:29:20.464054Z",
    "kind": "work",
    "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "81196b6b-9a11-48cc-897f-e000574778e1",
    "revision": 1,
    "created_at": "2026-09-10T07:29:20.464054Z",
    "kind": "artifact",
    "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "work_id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "title": "KITE inspection",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "81196b6b-9a11-48cc-897f-e000574778e1",
    "revision": 2,
    "created_at": "2026-09-10T07:29:20.464054Z",
    "kind": "artifact",
    "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "work_id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "63f67eff-7e3d-4a78-8fee-0aed24645433"
  },
  "artifact_version": {
    "id": "63f67eff-7e3d-4a78-8fee-0aed24645433",
    "artifact_id": "81196b6b-9a11-48cc-897f-e000574778e1",
    "work_id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "artifact_revision": 2,
    "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312",
    "size": 147,
    "created_at": "2026-09-10T07:29:20.693761Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "260f34b5-e22b-4cc0-862a-791f9fb03fca",
  "state_revision": 7,
  "recorded_at": "2026-09-10T07:29:20.761340Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "a23ce4e2-e4ec-41ce-9131-19dd1c48a801",
    "workspace_id": "82c48c2a-d57e-48a3-b713-47f15e57356d",
    "work_id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "81196b6b-9a11-48cc-897f-e000574778e1",
        "version_id": "63f67eff-7e3d-4a78-8fee-0aed24645433",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "a23ce4e2-e4ec-41ce-9131-19dd1c48a801",
      "workspace_id": "82c48c2a-d57e-48a3-b713-47f15e57356d",
      "process": "567258a2-7d90-4aa0-85b0-ea37258aa380",
      "related_work": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "81196b6b-9a11-48cc-897f-e000574778e1",
        "version_id": "63f67eff-7e3d-4a78-8fee-0aed24645433",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "a9a541c5d7c95dd9f1e1ffcb853dd68b7311fcb6389806ef806cb5c204f5c68c"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:20.740451Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_exact_basis_result_grants0/workspace",
    "request_sha256": "8dbb00726992e4d5f378d9862ba7bde87a93e314a643bc112d82241592209f7b"
  },
  "fingerprint": "3bb205f0a4263a37c50eedd5536572da998095c684cd4153567c95edd076b0ac",
  "before": {
    "id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "revision": 6,
    "created_at": "2026-09-10T07:29:20.464054Z",
    "kind": "work",
    "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "revision": 7,
    "created_at": "2026-09-10T07:29:20.464054Z",
    "kind": "work",
    "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "cb21704b-d116-41aa-ae85-649e4b0f05a7",
  "state_revision": 8,
  "recorded_at": "2026-09-10T07:29:20.969434Z",
  "product_version": "0.10.0",
  "request": {
    "version": 4,
    "operation_id": "be15ecfe-2d23-4bd5-83c8-3e7048ebe681",
    "workspace_id": "82c48c2a-d57e-48a3-b713-47f15e57356d",
    "work_id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "expected_revision": 7,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.lot\",\"pack_version\":\"1.0.0\",\"process_type\":\"fictional.lot-release\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "81196b6b-9a11-48cc-897f-e000574778e1",
        "version_id": "63f67eff-7e3d-4a78-8fee-0aed24645433",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 7,
      "result": {
        "artifact_id": "81196b6b-9a11-48cc-897f-e000574778e1",
        "version_id": "63f67eff-7e3d-4a78-8fee-0aed24645433",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      },
      "acceptance_ids": [
        "a23ce4e2-e4ec-41ce-9131-19dd1c48a801"
      ],
      "next_work": {
        "work_id": "9fd3e04e-2f94-4c98-94be-672dd7ac9147",
        "artifact_id": "550299e6-5481-4efe-8cb6-d4c1d441d1ea",
        "goal": "Choose release or discard for inspected fictional KITE",
        "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
        "acceptance": [
          "Explicit disposition naming the exact accepted inspection SHA256"
        ],
        "boundaries": [
          "Fictional local evidence only; no real release or external action"
        ],
        "budget": "One finite fictional lot",
        "executor_requirements": [
          "fictional.lot/v1:decide",
          "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
        ],
        "artifact_title": "KITE disposition",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:20.962936Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_exact_basis_result_grants0/events/inspection-restored",
    "request_sha256": "b75f31f233ae1ff3665b7d23edc0ae7e9655c2f7baa800a9415f6037dfda80ff"
  },
  "fingerprint": "d25f18a3436dab06894dea7e53e6bdc4d1788a315e2a069413430e488eba16cb",
  "before": {
    "id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "revision": 7,
    "created_at": "2026-09-10T07:29:20.464054Z",
    "kind": "work",
    "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "revision": 8,
    "created_at": "2026-09-10T07:29:20.464054Z",
    "kind": "work",
    "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "completion_id": "be15ecfe-2d23-4bd5-83c8-3e7048ebe681",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "9fd3e04e-2f94-4c98-94be-672dd7ac9147",
    "revision": 8,
    "created_at": "2026-09-10T07:29:20.969434Z",
    "kind": "work",
    "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "550299e6-5481-4efe-8cb6-d4c1d441d1ea",
    "revision": 1,
    "created_at": "2026-09-10T07:29:20.969434Z",
    "kind": "artifact",
    "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "work_id": "9fd3e04e-2f94-4c98-94be-672dd7ac9147",
    "title": "KITE disposition",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "81196b6b-9a11-48cc-897f-e000574778e1",
    "revision": 2,
    "created_at": "2026-09-10T07:29:20.464054Z",
    "kind": "artifact",
    "process_id": "567258a2-7d90-4aa0-85b0-ea37258aa380",
    "work_id": "fe722209-8a74-4436-94e9-4ab5bc34ff2a",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "63f67eff-7e3d-4a78-8fee-0aed24645433"
  },
  "result_references": [
    {
      "artifact_id": "81196b6b-9a11-48cc-897f-e000574778e1",
      "version_id": "63f67eff-7e3d-4a78-8fee-0aed24645433",
      "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    }
  ]
}
```

