# Zaratustra — generated overview

generated_from_revision: 5
generated_at: 2026-09-10T07:29:23.128431+00:00
workspace_id: eb17ccb2-aca7-4fb5-8de5-a4fb214e2f0d

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "70e6b181-aa92-4fa6-a644-f57a0b76443d",
  "revision": 1,
  "created_at": "2026-09-10T07:29:22.941462Z",
  "kind": "artifact",
  "process_id": "4c29f6a8-eef1-4a07-8d9a-c0a95454a9dc",
  "work_id": "a63f906c-eae9-4c53-907f-85010061707d",
  "title": "KITE inspection",
  "status": "declared",
  "active_version": null
}
```

## event

```json
{
  "id": "94180ab8-9be8-44f5-95f0-bdac5dcf9f40",
  "revision": 1,
  "created_at": "2026-09-10T07:29:22.941462Z",
  "kind": "event",
  "process_id": "4c29f6a8-eef1-4a07-8d9a-c0a95454a9dc",
  "work_id": "a63f906c-eae9-4c53-907f-85010061707d",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.0",
  "state_revision": 1,
  "affected_ids": [
    "4c29f6a8-eef1-4a07-8d9a-c0a95454a9dc",
    "a63f906c-eae9-4c53-907f-85010061707d",
    "70e6b181-aa92-4fa6-a644-f57a0b76443d"
  ]
}
```

## process

```json
{
  "id": "4c29f6a8-eef1-4a07-8d9a-c0a95454a9dc",
  "revision": 4,
  "created_at": "2026-09-10T07:29:22.941462Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "a63f906c-eae9-4c53-907f-85010061707d",
  "revision": 5,
  "created_at": "2026-09-10T07:29:22.941462Z",
  "kind": "work",
  "process_id": "4c29f6a8-eef1-4a07-8d9a-c0a95454a9dc",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "ready",
  "authority_scope": "none",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

## Mutation provenance

```json
{
  "id": "521cc541-6b96-42b0-b359-71d61c7396e0",
  "state_revision": 2,
  "recorded_at": "2026-09-10T07:29:22.973210Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "aacd4a59-692c-4e9d-b7d7-b69de8827eb9",
    "workspace_id": "eb17ccb2-aca7-4fb5-8de5-a4fb214e2f0d",
    "work_id": "a63f906c-eae9-4c53-907f-85010061707d",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:22.958173Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_lot_reader_preserves_t3_s2/workspace",
    "request_sha256": "cda36c2fcb07589279e7d011123db0abde2c9b900ae1cb735cd1e4107d5590da"
  },
  "fingerprint": "d5006acc05ce092d6c6af9eb8f8e6901bfd5716cac032b21b09f7dc392a7dab6",
  "before": {
    "id": "a63f906c-eae9-4c53-907f-85010061707d",
    "revision": 1,
    "created_at": "2026-09-10T07:29:22.941462Z",
    "kind": "work",
    "process_id": "4c29f6a8-eef1-4a07-8d9a-c0a95454a9dc",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "a63f906c-eae9-4c53-907f-85010061707d",
    "revision": 2,
    "created_at": "2026-09-10T07:29:22.941462Z",
    "kind": "work",
    "process_id": "4c29f6a8-eef1-4a07-8d9a-c0a95454a9dc",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "af68e179-c2c4-47ab-97c7-e442d0fab4c8",
  "state_revision": 3,
  "recorded_at": "2026-09-10T07:29:23.018489Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "e330b90f-6417-4657-9f3d-addc0d471e36",
    "workspace_id": "eb17ccb2-aca7-4fb5-8de5-a4fb214e2f0d",
    "work_id": "a63f906c-eae9-4c53-907f-85010061707d",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:23.003832Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_lot_reader_preserves_t3_s2/workspace",
    "request_sha256": "db226395a63dfc27ed621aba599cb09014a02e3169fe4137a60422bdead0259e"
  },
  "fingerprint": "7c627baffe46e95c148335be16b6ff853d735bf0fac69f2a424a58861520776d",
  "before": {
    "id": "a63f906c-eae9-4c53-907f-85010061707d",
    "revision": 2,
    "created_at": "2026-09-10T07:29:22.941462Z",
    "kind": "work",
    "process_id": "4c29f6a8-eef1-4a07-8d9a-c0a95454a9dc",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "a63f906c-eae9-4c53-907f-85010061707d",
    "revision": 3,
    "created_at": "2026-09-10T07:29:22.941462Z",
    "kind": "work",
    "process_id": "4c29f6a8-eef1-4a07-8d9a-c0a95454a9dc",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "b1ea03d0-9bfa-4250-9848-c14b83678546",
  "state_revision": 4,
  "recorded_at": "2026-09-10T07:29:23.065951Z",
  "product_version": "0.10.0",
  "request": {
    "version": 5,
    "operation_id": "b3af79d2-b795-4a3c-82a9-59e56d60acd4",
    "workspace_id": "eb17ccb2-aca7-4fb5-8de5-a4fb214e2f0d",
    "work_id": "a63f906c-eae9-4c53-907f-85010061707d",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional lot binding under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:23.050517Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_lot_reader_preserves_t3_s2/workspace",
    "request_sha256": "dab7c81181d53b2e3ba01eeffcc5dd58768c45e7b312235f4ea038a289ed19b9"
  },
  "fingerprint": "3e5e067926a6a8d3237929174e648f17dd95dfb66c9156034f7c14974cee9456",
  "before": {
    "id": "a63f906c-eae9-4c53-907f-85010061707d",
    "revision": 3,
    "created_at": "2026-09-10T07:29:22.941462Z",
    "kind": "work",
    "process_id": "4c29f6a8-eef1-4a07-8d9a-c0a95454a9dc",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "a63f906c-eae9-4c53-907f-85010061707d",
    "revision": 4,
    "created_at": "2026-09-10T07:29:22.941462Z",
    "kind": "work",
    "process_id": "4c29f6a8-eef1-4a07-8d9a-c0a95454a9dc",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "4c29f6a8-eef1-4a07-8d9a-c0a95454a9dc",
    "revision": 1,
    "created_at": "2026-09-10T07:29:22.941462Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "4c29f6a8-eef1-4a07-8d9a-c0a95454a9dc",
    "revision": 4,
    "created_at": "2026-09-10T07:29:22.941462Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "33130533-73f6-4b8a-839c-ff5ebf0063aa",
  "state_revision": 5,
  "recorded_at": "2026-09-10T07:29:23.128431Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "a1ecaa6b-c372-4137-9481-c190d50abe68",
    "workspace_id": "eb17ccb2-aca7-4fb5-8de5-a4fb214e2f0d",
    "work_id": "a63f906c-eae9-4c53-907f-85010061707d",
    "expected_revision": 4,
    "operation": "revoke_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:23.111768Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_lot_reader_preserves_t3_s2/workspace",
    "request_sha256": "e87ebadb5eb271abb0537b472338d10df31df897315b3981ca6fb33a570f2248"
  },
  "fingerprint": "3ca4747ed97fff2e819a5950dde6d8f49a68ac9cf26e9391cf20050bf8982cb0",
  "before": {
    "id": "a63f906c-eae9-4c53-907f-85010061707d",
    "revision": 4,
    "created_at": "2026-09-10T07:29:22.941462Z",
    "kind": "work",
    "process_id": "4c29f6a8-eef1-4a07-8d9a-c0a95454a9dc",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "a63f906c-eae9-4c53-907f-85010061707d",
    "revision": 5,
    "created_at": "2026-09-10T07:29:22.941462Z",
    "kind": "work",
    "process_id": "4c29f6a8-eef1-4a07-8d9a-c0a95454a9dc",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

