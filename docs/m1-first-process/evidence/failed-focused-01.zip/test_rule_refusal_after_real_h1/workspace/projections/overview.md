# Zaratustra — generated overview

generated_from_revision: 7
generated_at: 2026-09-10T07:29:18.394704+00:00
workspace_id: 512c4778-7382-4b11-863c-e54e7a77a73a

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "81b04369-f2a0-4d91-8c7c-5737f28aafbf",
  "revision": 2,
  "created_at": "2026-09-10T07:29:18.122148Z",
  "kind": "artifact",
  "process_id": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
  "work_id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
  "title": "KITE inspection",
  "status": "registered",
  "active_version": "36e5bac0-adf0-4b70-ad65-31260ed64641"
}
```

## event

```json
{
  "id": "012a6d7c-15b6-45a2-bb7e-79fa768347cf",
  "revision": 1,
  "created_at": "2026-09-10T07:29:18.122148Z",
  "kind": "event",
  "process_id": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
  "work_id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.0",
  "state_revision": 1,
  "affected_ids": [
    "6c3538f9-70d2-4882-8718-4ddfe7b43679",
    "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "81b04369-f2a0-4d91-8c7c-5737f28aafbf"
  ]
}
```

## process

```json
{
  "id": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
  "revision": 4,
  "created_at": "2026-09-10T07:29:18.122148Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
  "revision": 7,
  "created_at": "2026-09-10T07:29:18.122148Z",
  "kind": "work",
  "process_id": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "ready",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 36e5bac0-adf0-4b70-ad65-31260ed64641; Artifact revision: 2
  SHA-256: 4704344fab172700fa089e534b166b324e2bcdf30b5887dc9e4d12932d8f8c27; bytes: 148
  File: artifacts/81b04369-f2a0-4d91-8c7c-5737f28aafbf/36e5bac0-adf0-4b70-ad65-31260ed64641.blob

## Mutation provenance

```json
{
  "id": "4172aaa2-c3ae-4bb4-a60f-3d4917b25257",
  "state_revision": 2,
  "recorded_at": "2026-09-10T07:29:18.153654Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "fdf5de23-113c-4296-b414-e67349ff6247",
    "workspace_id": "512c4778-7382-4b11-863c-e54e7a77a73a",
    "work_id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:18.138974Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h1/workspace",
    "request_sha256": "cc5eae4d8546ee557d4edbdc97db1a4daf6918fd754118c5f02e05256517e156"
  },
  "fingerprint": "e73f370d67f32ed76e2df2f8accbe610775f476882dc3abedcb2c522a367710e",
  "before": {
    "id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "revision": 1,
    "created_at": "2026-09-10T07:29:18.122148Z",
    "kind": "work",
    "process_id": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "revision": 2,
    "created_at": "2026-09-10T07:29:18.122148Z",
    "kind": "work",
    "process_id": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "deae06e0-1b8f-47a2-8d74-c4df57950508",
  "state_revision": 3,
  "recorded_at": "2026-09-10T07:29:18.195079Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "f6a36985-dc18-4773-80e9-22b97c054ce6",
    "workspace_id": "512c4778-7382-4b11-863c-e54e7a77a73a",
    "work_id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:18.181335Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h1/workspace",
    "request_sha256": "baee1e05c9ed0c65b8250c50aa84de66869ab7c625358248321282e62907212e"
  },
  "fingerprint": "f932939800a1f03a5ea9cc1fa784caa8b4fd2d59601cfbb149635b7495a82e21",
  "before": {
    "id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "revision": 2,
    "created_at": "2026-09-10T07:29:18.122148Z",
    "kind": "work",
    "process_id": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "revision": 3,
    "created_at": "2026-09-10T07:29:18.122148Z",
    "kind": "work",
    "process_id": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "60c2ff7b-57c4-4914-add5-4dd3a2d68f64",
  "state_revision": 4,
  "recorded_at": "2026-09-10T07:29:18.240116Z",
  "product_version": "0.10.0",
  "request": {
    "version": 5,
    "operation_id": "ce4f3d06-76c7-4b25-9844-c86c4d3ba31a",
    "workspace_id": "512c4778-7382-4b11-863c-e54e7a77a73a",
    "work_id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional lot binding under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:18.225472Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h1/workspace",
    "request_sha256": "1a129bf4318408fb8145731f9353ce51ecb153e75b7f5f0d50c78b0c95f3ade4"
  },
  "fingerprint": "df3919486057355b01aaa05aa3f2e32779a5e4fb28360fa42477fc58a395729b",
  "before": {
    "id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "revision": 3,
    "created_at": "2026-09-10T07:29:18.122148Z",
    "kind": "work",
    "process_id": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "revision": 4,
    "created_at": "2026-09-10T07:29:18.122148Z",
    "kind": "work",
    "process_id": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
    "revision": 1,
    "created_at": "2026-09-10T07:29:18.122148Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
    "revision": 4,
    "created_at": "2026-09-10T07:29:18.122148Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "213c2e93-7721-487a-a89d-5d7528d9914c",
  "state_revision": 5,
  "recorded_at": "2026-09-10T07:29:18.286756Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "2940272b-f504-4533-bf9d-894befd79b4e",
    "workspace_id": "512c4778-7382-4b11-863c-e54e7a77a73a",
    "work_id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "81b04369-f2a0-4d91-8c7c-5737f28aafbf",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:18.270590Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h1/workspace",
    "request_sha256": "f0771fb48fe84e36641850c3ca6dc77d193f68bd66dc04a957100a65dc0d896a"
  },
  "fingerprint": "00c32c7319945cc5a683723e44917e8e155832dbe877690a3108e2ad7c2db075",
  "before": {
    "id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "revision": 4,
    "created_at": "2026-09-10T07:29:18.122148Z",
    "kind": "work",
    "process_id": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "revision": 5,
    "created_at": "2026-09-10T07:29:18.122148Z",
    "kind": "work",
    "process_id": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "90c69388-b470-4cd8-b02d-baaafdbebd95",
  "state_revision": 6,
  "recorded_at": "2026-09-10T07:29:18.331649Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "36e5bac0-adf0-4b70-ad65-31260ed64641",
    "workspace_id": "512c4778-7382-4b11-863c-e54e7a77a73a",
    "work_id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "81b04369-f2a0-4d91-8c7c-5737f28aafbf",
    "artifact_revision": 1,
    "content_sha256": "4704344fab172700fa089e534b166b324e2bcdf30b5887dc9e4d12932d8f8c27",
    "content_size": 148,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:18.315370Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h1/workspace",
    "request_sha256": "60617259fb6fb7bd144a0db7dfc31b7b2977c7b27efcfcfad4a6748cb8cf0a5c"
  },
  "fingerprint": "98cdbf70a6461a6c6e7bc82df25fa621d185a9d8a68099b67efe9bcb0707033d",
  "before": {
    "id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "revision": 5,
    "created_at": "2026-09-10T07:29:18.122148Z",
    "kind": "work",
    "process_id": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "revision": 6,
    "created_at": "2026-09-10T07:29:18.122148Z",
    "kind": "work",
    "process_id": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "81b04369-f2a0-4d91-8c7c-5737f28aafbf",
    "revision": 1,
    "created_at": "2026-09-10T07:29:18.122148Z",
    "kind": "artifact",
    "process_id": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
    "work_id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "title": "KITE inspection",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "81b04369-f2a0-4d91-8c7c-5737f28aafbf",
    "revision": 2,
    "created_at": "2026-09-10T07:29:18.122148Z",
    "kind": "artifact",
    "process_id": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
    "work_id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "36e5bac0-adf0-4b70-ad65-31260ed64641"
  },
  "artifact_version": {
    "id": "36e5bac0-adf0-4b70-ad65-31260ed64641",
    "artifact_id": "81b04369-f2a0-4d91-8c7c-5737f28aafbf",
    "work_id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "process_id": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
    "artifact_revision": 2,
    "sha256": "4704344fab172700fa089e534b166b324e2bcdf30b5887dc9e4d12932d8f8c27",
    "size": 148,
    "created_at": "2026-09-10T07:29:18.331649Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "7e259ec6-25c0-4580-af1b-63004dc39bf4",
  "state_revision": 7,
  "recorded_at": "2026-09-10T07:29:18.394704Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "a6fbe01e-9144-42c4-97ca-bb695ce094ea",
    "workspace_id": "512c4778-7382-4b11-863c-e54e7a77a73a",
    "work_id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "81b04369-f2a0-4d91-8c7c-5737f28aafbf",
        "version_id": "36e5bac0-adf0-4b70-ad65-31260ed64641",
        "sha256": "4704344fab172700fa089e534b166b324e2bcdf30b5887dc9e4d12932d8f8c27"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "a6fbe01e-9144-42c4-97ca-bb695ce094ea",
      "workspace_id": "512c4778-7382-4b11-863c-e54e7a77a73a",
      "process": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
      "related_work": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "81b04369-f2a0-4d91-8c7c-5737f28aafbf",
        "version_id": "36e5bac0-adf0-4b70-ad65-31260ed64641",
        "sha256": "4704344fab172700fa089e534b166b324e2bcdf30b5887dc9e4d12932d8f8c27"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "76322296f382534d080ec976351d0d860f674facd636c7cdf119a5f92aa17f53"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:18.378016Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h1/workspace",
    "request_sha256": "83cfade1e6c463c4a0dbaf7f672361b38b00df10fcffd00fa549034b965ab912"
  },
  "fingerprint": "75e2a8d7ff880b4cb80df9829cdb03f0ff89c9be8a302f276ca6774c82fbc469",
  "before": {
    "id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "revision": 6,
    "created_at": "2026-09-10T07:29:18.122148Z",
    "kind": "work",
    "process_id": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "6f6e010f-904d-40b8-ad0d-6cd961df11f9",
    "revision": 7,
    "created_at": "2026-09-10T07:29:18.122148Z",
    "kind": "work",
    "process_id": "6c3538f9-70d2-4882-8718-4ddfe7b43679",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

