# Zaratustra — generated overview

generated_from_revision: 7
generated_at: 2026-09-10T07:29:19.196123+00:00
workspace_id: fbe91a58-060a-47d1-9f68-06f060770247

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "7d671b75-7e62-4c2e-9386-669e5085cd6f",
  "revision": 2,
  "created_at": "2026-09-10T07:29:18.932715Z",
  "kind": "artifact",
  "process_id": "0db67925-8a3f-42c2-9871-631abaddfbcb",
  "work_id": "af62fec1-8ff1-451f-8171-08190b37a749",
  "title": "KITE inspection",
  "status": "registered",
  "active_version": "c07dcffe-407a-469c-8d5e-04d0dffdf22a"
}
```

## event

```json
{
  "id": "8302dee1-6eb6-43ad-ae61-4e0444a26015",
  "revision": 1,
  "created_at": "2026-09-10T07:29:18.932715Z",
  "kind": "event",
  "process_id": "0db67925-8a3f-42c2-9871-631abaddfbcb",
  "work_id": "af62fec1-8ff1-451f-8171-08190b37a749",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.0",
  "state_revision": 1,
  "affected_ids": [
    "0db67925-8a3f-42c2-9871-631abaddfbcb",
    "af62fec1-8ff1-451f-8171-08190b37a749",
    "7d671b75-7e62-4c2e-9386-669e5085cd6f"
  ]
}
```

## process

```json
{
  "id": "0db67925-8a3f-42c2-9871-631abaddfbcb",
  "revision": 4,
  "created_at": "2026-09-10T07:29:18.932715Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "af62fec1-8ff1-451f-8171-08190b37a749",
  "revision": 7,
  "created_at": "2026-09-10T07:29:18.932715Z",
  "kind": "work",
  "process_id": "0db67925-8a3f-42c2-9871-631abaddfbcb",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "ready",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: c07dcffe-407a-469c-8d5e-04d0dffdf22a; Artifact revision: 2
  SHA-256: 8406bc2368452afc6b44bdcbdc0609613360573fa958af154ec399e7c6022115; bytes: 149
  File: artifacts/7d671b75-7e62-4c2e-9386-669e5085cd6f/c07dcffe-407a-469c-8d5e-04d0dffdf22a.blob

## Mutation provenance

```json
{
  "id": "a67c3678-68e7-4884-bee2-60355ab448ea",
  "state_revision": 2,
  "recorded_at": "2026-09-10T07:29:18.962831Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "0ab19eb7-ed90-403e-8c6c-cfbf62129acb",
    "workspace_id": "fbe91a58-060a-47d1-9f68-06f060770247",
    "work_id": "af62fec1-8ff1-451f-8171-08190b37a749",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:18.948444Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h3/workspace",
    "request_sha256": "ef44602ebbad67fac5f3194981ee23275b913e7bca9cea938b078309264893d6"
  },
  "fingerprint": "77610d100993bf87729672328a67746d1d1bb6301cfecf069202f5b67b869a16",
  "before": {
    "id": "af62fec1-8ff1-451f-8171-08190b37a749",
    "revision": 1,
    "created_at": "2026-09-10T07:29:18.932715Z",
    "kind": "work",
    "process_id": "0db67925-8a3f-42c2-9871-631abaddfbcb",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "af62fec1-8ff1-451f-8171-08190b37a749",
    "revision": 2,
    "created_at": "2026-09-10T07:29:18.932715Z",
    "kind": "work",
    "process_id": "0db67925-8a3f-42c2-9871-631abaddfbcb",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "9ff44f12-9f7a-41af-917f-27889c377f8b",
  "state_revision": 3,
  "recorded_at": "2026-09-10T07:29:19.003436Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "14028511-d768-40b6-a735-b21207070d68",
    "workspace_id": "fbe91a58-060a-47d1-9f68-06f060770247",
    "work_id": "af62fec1-8ff1-451f-8171-08190b37a749",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:18.989155Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h3/workspace",
    "request_sha256": "5f7ddd8237dd5668780b036f8763be5c8c37ed87c73d72babfc8c40d1d01dc92"
  },
  "fingerprint": "9d38cf83bb3d03e25ac0f7b5d7b699a0861d00781bb06fb4b22daae7fc01db42",
  "before": {
    "id": "af62fec1-8ff1-451f-8171-08190b37a749",
    "revision": 2,
    "created_at": "2026-09-10T07:29:18.932715Z",
    "kind": "work",
    "process_id": "0db67925-8a3f-42c2-9871-631abaddfbcb",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "af62fec1-8ff1-451f-8171-08190b37a749",
    "revision": 3,
    "created_at": "2026-09-10T07:29:18.932715Z",
    "kind": "work",
    "process_id": "0db67925-8a3f-42c2-9871-631abaddfbcb",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "e16edfd7-d780-4239-a857-9383bad98429",
  "state_revision": 4,
  "recorded_at": "2026-09-10T07:29:19.046232Z",
  "product_version": "0.10.0",
  "request": {
    "version": 5,
    "operation_id": "9902e16d-2449-4f27-9fec-3e3faae9470d",
    "workspace_id": "fbe91a58-060a-47d1-9f68-06f060770247",
    "work_id": "af62fec1-8ff1-451f-8171-08190b37a749",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional lot binding under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:19.032707Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h3/workspace",
    "request_sha256": "c8cdda4002ec9ea4fadea42b06585460c1c46d214b3bd87a21882f1718848735"
  },
  "fingerprint": "a467f856033ed69ffed7a96145b2c2b20cf2abfb877bb5f702838de1970de55f",
  "before": {
    "id": "af62fec1-8ff1-451f-8171-08190b37a749",
    "revision": 3,
    "created_at": "2026-09-10T07:29:18.932715Z",
    "kind": "work",
    "process_id": "0db67925-8a3f-42c2-9871-631abaddfbcb",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "af62fec1-8ff1-451f-8171-08190b37a749",
    "revision": 4,
    "created_at": "2026-09-10T07:29:18.932715Z",
    "kind": "work",
    "process_id": "0db67925-8a3f-42c2-9871-631abaddfbcb",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "0db67925-8a3f-42c2-9871-631abaddfbcb",
    "revision": 1,
    "created_at": "2026-09-10T07:29:18.932715Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "0db67925-8a3f-42c2-9871-631abaddfbcb",
    "revision": 4,
    "created_at": "2026-09-10T07:29:18.932715Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "706047eb-c015-42a0-bb72-dd1821040948",
  "state_revision": 5,
  "recorded_at": "2026-09-10T07:29:19.090224Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "dfeb2388-fafa-43af-a2aa-69a0e9874717",
    "workspace_id": "fbe91a58-060a-47d1-9f68-06f060770247",
    "work_id": "af62fec1-8ff1-451f-8171-08190b37a749",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "7d671b75-7e62-4c2e-9386-669e5085cd6f",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:19.076189Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h3/workspace",
    "request_sha256": "462eaa2723fa4b7696c4a547957ab925ed2a48589fce94307278bcf804233f27"
  },
  "fingerprint": "23dedbe2e6c9cfa1114b3b1b81946cb931fb02f5ab398aa0562ee73d79d984c2",
  "before": {
    "id": "af62fec1-8ff1-451f-8171-08190b37a749",
    "revision": 4,
    "created_at": "2026-09-10T07:29:18.932715Z",
    "kind": "work",
    "process_id": "0db67925-8a3f-42c2-9871-631abaddfbcb",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "af62fec1-8ff1-451f-8171-08190b37a749",
    "revision": 5,
    "created_at": "2026-09-10T07:29:18.932715Z",
    "kind": "work",
    "process_id": "0db67925-8a3f-42c2-9871-631abaddfbcb",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "18380b39-3949-4107-903f-2853da9bdea5",
  "state_revision": 6,
  "recorded_at": "2026-09-10T07:29:19.135295Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "c07dcffe-407a-469c-8d5e-04d0dffdf22a",
    "workspace_id": "fbe91a58-060a-47d1-9f68-06f060770247",
    "work_id": "af62fec1-8ff1-451f-8171-08190b37a749",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "7d671b75-7e62-4c2e-9386-669e5085cd6f",
    "artifact_revision": 1,
    "content_sha256": "8406bc2368452afc6b44bdcbdc0609613360573fa958af154ec399e7c6022115",
    "content_size": 149,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:19.119699Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h3/workspace",
    "request_sha256": "198d12ef3d54f5207d6788ad94a067a5f2745ab5167935c31fc09f74bf45e984"
  },
  "fingerprint": "39f14a966247c0c5a9845278ed444c9b4201548f1431f92f197a3ce012302a07",
  "before": {
    "id": "af62fec1-8ff1-451f-8171-08190b37a749",
    "revision": 5,
    "created_at": "2026-09-10T07:29:18.932715Z",
    "kind": "work",
    "process_id": "0db67925-8a3f-42c2-9871-631abaddfbcb",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "af62fec1-8ff1-451f-8171-08190b37a749",
    "revision": 6,
    "created_at": "2026-09-10T07:29:18.932715Z",
    "kind": "work",
    "process_id": "0db67925-8a3f-42c2-9871-631abaddfbcb",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "7d671b75-7e62-4c2e-9386-669e5085cd6f",
    "revision": 1,
    "created_at": "2026-09-10T07:29:18.932715Z",
    "kind": "artifact",
    "process_id": "0db67925-8a3f-42c2-9871-631abaddfbcb",
    "work_id": "af62fec1-8ff1-451f-8171-08190b37a749",
    "title": "KITE inspection",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "7d671b75-7e62-4c2e-9386-669e5085cd6f",
    "revision": 2,
    "created_at": "2026-09-10T07:29:18.932715Z",
    "kind": "artifact",
    "process_id": "0db67925-8a3f-42c2-9871-631abaddfbcb",
    "work_id": "af62fec1-8ff1-451f-8171-08190b37a749",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "c07dcffe-407a-469c-8d5e-04d0dffdf22a"
  },
  "artifact_version": {
    "id": "c07dcffe-407a-469c-8d5e-04d0dffdf22a",
    "artifact_id": "7d671b75-7e62-4c2e-9386-669e5085cd6f",
    "work_id": "af62fec1-8ff1-451f-8171-08190b37a749",
    "process_id": "0db67925-8a3f-42c2-9871-631abaddfbcb",
    "artifact_revision": 2,
    "sha256": "8406bc2368452afc6b44bdcbdc0609613360573fa958af154ec399e7c6022115",
    "size": 149,
    "created_at": "2026-09-10T07:29:19.135295Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "e42b36e4-bd70-4be3-aec0-390d9f2d8b87",
  "state_revision": 7,
  "recorded_at": "2026-09-10T07:29:19.196123Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "710d67c6-62fe-4a86-8ba7-ffeb797227a3",
    "workspace_id": "fbe91a58-060a-47d1-9f68-06f060770247",
    "work_id": "af62fec1-8ff1-451f-8171-08190b37a749",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "7d671b75-7e62-4c2e-9386-669e5085cd6f",
        "version_id": "c07dcffe-407a-469c-8d5e-04d0dffdf22a",
        "sha256": "8406bc2368452afc6b44bdcbdc0609613360573fa958af154ec399e7c6022115"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "710d67c6-62fe-4a86-8ba7-ffeb797227a3",
      "workspace_id": "fbe91a58-060a-47d1-9f68-06f060770247",
      "process": "0db67925-8a3f-42c2-9871-631abaddfbcb",
      "related_work": "af62fec1-8ff1-451f-8171-08190b37a749",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "7d671b75-7e62-4c2e-9386-669e5085cd6f",
        "version_id": "c07dcffe-407a-469c-8d5e-04d0dffdf22a",
        "sha256": "8406bc2368452afc6b44bdcbdc0609613360573fa958af154ec399e7c6022115"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "832823949e8ada0c5ba5cea904ac952aac4e65a5a4f1ee09baa6bc2ac192f821"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:19.177857Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_rule_refusal_after_real_h3/workspace",
    "request_sha256": "8f2b24877263f881d33adf9860ffe39e65819e16665f9ef95bc36c4860d7f211"
  },
  "fingerprint": "be59126c412dd655a5c9286d1f664993ccc016f03624ccebfeb5b047b6f6ca3e",
  "before": {
    "id": "af62fec1-8ff1-451f-8171-08190b37a749",
    "revision": 6,
    "created_at": "2026-09-10T07:29:18.932715Z",
    "kind": "work",
    "process_id": "0db67925-8a3f-42c2-9871-631abaddfbcb",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "af62fec1-8ff1-451f-8171-08190b37a749",
    "revision": 7,
    "created_at": "2026-09-10T07:29:18.932715Z",
    "kind": "work",
    "process_id": "0db67925-8a3f-42c2-9871-631abaddfbcb",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

