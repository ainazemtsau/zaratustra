# Zaratustra — generated overview

generated_from_revision: 4
generated_at: 2026-09-10T07:29:22.589237+00:00
workspace_id: 7a0cd9eb-7623-4f53-9cb2-46cbeca6fad8

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "7cfa6b47-bee1-4088-993e-a6790d60b480",
  "revision": 1,
  "created_at": "2026-09-10T07:29:22.447908Z",
  "kind": "artifact",
  "process_id": "4bd8a44d-ab4d-4ecb-83a0-72f49ccf28a2",
  "work_id": "fc36e8e0-a23f-4162-9f4d-67f08c987081",
  "title": "KITE inspection",
  "status": "declared",
  "active_version": null
}
```

## event

```json
{
  "id": "4ca313ee-4629-4ad6-9005-5ff0a8d34a6b",
  "revision": 1,
  "created_at": "2026-09-10T07:29:22.447908Z",
  "kind": "event",
  "process_id": "4bd8a44d-ab4d-4ecb-83a0-72f49ccf28a2",
  "work_id": "fc36e8e0-a23f-4162-9f4d-67f08c987081",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.0",
  "state_revision": 1,
  "affected_ids": [
    "4bd8a44d-ab4d-4ecb-83a0-72f49ccf28a2",
    "fc36e8e0-a23f-4162-9f4d-67f08c987081",
    "7cfa6b47-bee1-4088-993e-a6790d60b480"
  ]
}
```

## process

```json
{
  "id": "4bd8a44d-ab4d-4ecb-83a0-72f49ccf28a2",
  "revision": 4,
  "created_at": "2026-09-10T07:29:22.447908Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "fc36e8e0-a23f-4162-9f4d-67f08c987081",
  "revision": 4,
  "created_at": "2026-09-10T07:29:22.447908Z",
  "kind": "work",
  "process_id": "4bd8a44d-ab4d-4ecb-83a0-72f49ccf28a2",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

## Mutation provenance

```json
{
  "id": "02baa0c4-38cc-4097-a59c-1c67330445c1",
  "state_revision": 2,
  "recorded_at": "2026-09-10T07:29:22.483303Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "dc00f2d2-22f7-4abf-9803-6930b8e6cbc6",
    "workspace_id": "7a0cd9eb-7623-4f53-9cb2-46cbeca6fad8",
    "work_id": "fc36e8e0-a23f-4162-9f4d-67f08c987081",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:22.466411Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_lot_reader_preserves_t3_s0/workspace",
    "request_sha256": "8f0b015d27a958d4bb33e89ccf21f61220da782fa586bba3119024d180102cc4"
  },
  "fingerprint": "a749d632f88ae93e77aba0de35896effa84fa7c146992ec495ae6bc62791d212",
  "before": {
    "id": "fc36e8e0-a23f-4162-9f4d-67f08c987081",
    "revision": 1,
    "created_at": "2026-09-10T07:29:22.447908Z",
    "kind": "work",
    "process_id": "4bd8a44d-ab4d-4ecb-83a0-72f49ccf28a2",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "fc36e8e0-a23f-4162-9f4d-67f08c987081",
    "revision": 2,
    "created_at": "2026-09-10T07:29:22.447908Z",
    "kind": "work",
    "process_id": "4bd8a44d-ab4d-4ecb-83a0-72f49ccf28a2",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "95b1fab2-5bd0-49b2-9d40-e60b1af465a6",
  "state_revision": 3,
  "recorded_at": "2026-09-10T07:29:22.532711Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "0a987616-b7b7-4298-86d4-8c82ae7546b6",
    "workspace_id": "7a0cd9eb-7623-4f53-9cb2-46cbeca6fad8",
    "work_id": "fc36e8e0-a23f-4162-9f4d-67f08c987081",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:22.515574Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_lot_reader_preserves_t3_s0/workspace",
    "request_sha256": "bbd666aeac9726f46b8d0079bf7be2fd9fc20868d16b7c01a1882b481a38f5e2"
  },
  "fingerprint": "60225ea36f3f454a497e3eead686563a15563d2fb960bd20caa17fa267c7a34a",
  "before": {
    "id": "fc36e8e0-a23f-4162-9f4d-67f08c987081",
    "revision": 2,
    "created_at": "2026-09-10T07:29:22.447908Z",
    "kind": "work",
    "process_id": "4bd8a44d-ab4d-4ecb-83a0-72f49ccf28a2",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "fc36e8e0-a23f-4162-9f4d-67f08c987081",
    "revision": 3,
    "created_at": "2026-09-10T07:29:22.447908Z",
    "kind": "work",
    "process_id": "4bd8a44d-ab4d-4ecb-83a0-72f49ccf28a2",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "03673166-855b-4a9c-8b45-783711e20e4e",
  "state_revision": 4,
  "recorded_at": "2026-09-10T07:29:22.589237Z",
  "product_version": "0.10.0",
  "request": {
    "version": 5,
    "operation_id": "28c56e0d-e935-44f3-ae72-67a9e616ae06",
    "workspace_id": "7a0cd9eb-7623-4f53-9cb2-46cbeca6fad8",
    "work_id": "fc36e8e0-a23f-4162-9f4d-67f08c987081",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional lot binding under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:29:22.569966Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-focused-01/test_lot_reader_preserves_t3_s0/workspace",
    "request_sha256": "01c4c5e9f4626754338645eaf1253824c54ae90be9ebbe48383edbd48c70cedf"
  },
  "fingerprint": "58ba2c07ce4dbcd89d1d60742a772bae1101c49d167d161f24b7e88a5cf21b0c",
  "before": {
    "id": "fc36e8e0-a23f-4162-9f4d-67f08c987081",
    "revision": 3,
    "created_at": "2026-09-10T07:29:22.447908Z",
    "kind": "work",
    "process_id": "4bd8a44d-ab4d-4ecb-83a0-72f49ccf28a2",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "fc36e8e0-a23f-4162-9f4d-67f08c987081",
    "revision": 4,
    "created_at": "2026-09-10T07:29:22.447908Z",
    "kind": "work",
    "process_id": "4bd8a44d-ab4d-4ecb-83a0-72f49ccf28a2",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "4bd8a44d-ab4d-4ecb-83a0-72f49ccf28a2",
    "revision": 1,
    "created_at": "2026-09-10T07:29:22.447908Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "4bd8a44d-ab4d-4ecb-83a0-72f49ccf28a2",
    "revision": 4,
    "created_at": "2026-09-10T07:29:22.447908Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

