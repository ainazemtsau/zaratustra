# Zaratustra — generated overview

generated_from_revision: 8
generated_at: 2026-09-10T07:18:15.136559+00:00
workspace_id: e259afd6-ca0f-4c31-a858-d695d8643a52

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "0664a14c-d367-4c06-a601-6f382fb3d9ec",
  "revision": 1,
  "created_at": "2026-09-10T07:18:15.136559Z",
  "kind": "artifact",
  "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
  "work_id": "f84bb3a8-151f-4a39-a96f-adf7900b5923",
  "title": "Next fictional batch observation",
  "status": "declared",
  "active_version": null
}
```

## artifact

```json
{
  "id": "d862cd2d-5afe-45b9-b807-1bd59f78a95b",
  "revision": 2,
  "created_at": "2026-09-10T07:18:14.348636Z",
  "kind": "artifact",
  "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
  "work_id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
  "title": "Fictional batch observation",
  "status": "registered",
  "active_version": "2611fb87-d626-4ca3-b651-01e1b809d381"
}
```

## event

```json
{
  "id": "c905793f-dbe7-4bcd-9e0c-b3333d59ff0b",
  "revision": 1,
  "created_at": "2026-09-10T07:18:14.348636Z",
  "kind": "event",
  "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
  "work_id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.9.0",
  "state_revision": 1,
  "affected_ids": [
    "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "d862cd2d-5afe-45b9-b807-1bd59f78a95b"
  ]
}
```

## process

```json
{
  "id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
  "revision": 4,
  "created_at": "2026-09-10T07:18:14.348636Z",
  "kind": "process",
  "title": "Fictional pack lifecycle",
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "1.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
  "revision": 8,
  "created_at": "2026-09-10T07:18:14.348636Z",
  "kind": "work",
  "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
  "goal": "Continue a fictional batch with an exact retained pack version",
  "expected_result": "Recorded observation and continuation",
  "acceptance": [
    "Both fictional marks"
  ],
  "boundaries": [
    "Local fictional data only"
  ],
  "budget": "One T2 lifecycle example",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ],
  "completion_id": "6671ec11-b3c5-4ed6-8a58-f87e25a37862",
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "1.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "f84bb3a8-151f-4a39-a96f-adf7900b5923",
  "revision": 8,
  "created_at": "2026-09-10T07:18:15.136559Z",
  "kind": "work",
  "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
  "goal": "Inspect the next fictional batch",
  "expected_result": "Both independent marks",
  "acceptance": [
    "Observation and recording marks are both present"
  ],
  "boundaries": [
    "Local fictional data only"
  ],
  "budget": "One T2 lifecycle example",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ],
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "1.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 2611fb87-d626-4ca3-b651-01e1b809d381; Artifact revision: 2
  SHA-256: 9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38; bytes: 36
  File: artifacts/d862cd2d-5afe-45b9-b807-1bd59f78a95b/2611fb87-d626-4ca3-b651-01e1b809d381.blob

## Mutation provenance

```json
{
  "id": "a24c4a85-5903-4e60-983f-3cbdcab7f92b",
  "state_revision": 2,
  "recorded_at": "2026-09-10T07:18:14.386779Z",
  "product_version": "0.9.0",
  "request": {
    "version": 1,
    "operation_id": "bc2c02a2-8e4b-45ba-b166-c607023b7ae3",
    "workspace_id": "e259afd6-ca0f-4c31-a858-d695d8643a52",
    "work_id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional read-contract fixture under RUN c-solmax-zaratustra-m1-capabilities-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T3-fictional-contract-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-capabilities-20260909-exec; explicitly selected fictional fixture; T3 acceptance pending",
    "confirmed_at": "2026-09-10T07:18:14.384240Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-before-edits/workspace",
    "request_sha256": "5141a84c9f4b8ecce728605068ddfb8a89a9752af704dd357a99a689fdf5693d"
  },
  "fingerprint": "636d9d2a07a08aaf00f63a0a4b72f580659fcc720ee4b70ce3c4e83d87ec4e81",
  "before": {
    "id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "revision": 1,
    "created_at": "2026-09-10T07:18:14.348636Z",
    "kind": "work",
    "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "revision": 2,
    "created_at": "2026-09-10T07:18:14.348636Z",
    "kind": "work",
    "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "c0209314-f5ac-4d98-861f-2e883e285117",
  "state_revision": 3,
  "recorded_at": "2026-09-10T07:18:14.414519Z",
  "product_version": "0.9.0",
  "request": {
    "version": 1,
    "operation_id": "20937348-ea40-4c37-ac0e-cf40ea4ad976",
    "workspace_id": "e259afd6-ca0f-4c31-a858-d695d8643a52",
    "work_id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "probe.batch/v1"
    ],
    "artifact_references": [],
    "provenance": "Fictional read-contract fixture under RUN c-solmax-zaratustra-m1-capabilities-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T3-fictional-contract-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-capabilities-20260909-exec; explicitly selected fictional fixture; T3 acceptance pending",
    "confirmed_at": "2026-09-10T07:18:14.411613Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-before-edits/workspace",
    "request_sha256": "aa407f26cadb4f6076fee37c5397ff3ee9f39273f6581cde0074c89224f9612b"
  },
  "fingerprint": "1168084f4077bc6f2c057b44debfbd72e6c1202fd91d4d30bd5af76af43b4d0a",
  "before": {
    "id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "revision": 2,
    "created_at": "2026-09-10T07:18:14.348636Z",
    "kind": "work",
    "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "revision": 3,
    "created_at": "2026-09-10T07:18:14.348636Z",
    "kind": "work",
    "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "6659fea5-d43d-4af3-b4fc-811450c0a76c",
  "state_revision": 4,
  "recorded_at": "2026-09-10T07:18:14.456864Z",
  "product_version": "0.9.0",
  "request": {
    "version": 5,
    "operation_id": "377a9be1-1b68-4f32-b376-45cbdb5e2446",
    "workspace_id": "e259afd6-ca0f-4c31-a858-d695d8643a52",
    "work_id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional Process/Work binding under RUN c-solmax-zaratustra-m1-packs-20260909-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T3-fictional-contract-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-capabilities-20260909-exec; explicitly selected fictional fixture; T3 acceptance pending",
    "confirmed_at": "2026-09-10T07:18:14.453715Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-before-edits/workspace",
    "request_sha256": "9e3563fb319c59d15050ed93b41c8fef0b4863208578d54d4cfbeeecea9cd0e5"
  },
  "fingerprint": "5f69397bccda36c74314f767b0b5ac0e2ef7af11d3c9495f5af23e3b6eb5a9e5",
  "before": {
    "id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "revision": 3,
    "created_at": "2026-09-10T07:18:14.348636Z",
    "kind": "work",
    "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "revision": 4,
    "created_at": "2026-09-10T07:18:14.348636Z",
    "kind": "work",
    "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "revision": 1,
    "created_at": "2026-09-10T07:18:14.348636Z",
    "kind": "process",
    "title": "Fictional pack lifecycle"
  },
  "process_after": {
    "id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "revision": 4,
    "created_at": "2026-09-10T07:18:14.348636Z",
    "kind": "process",
    "title": "Fictional pack lifecycle",
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "f69212f3-2830-45be-955c-a6a2085209c3",
  "state_revision": 5,
  "recorded_at": "2026-09-10T07:18:14.489239Z",
  "product_version": "0.9.0",
  "request": {
    "version": 2,
    "operation_id": "535f34c3-7eb0-4ac8-ac4c-aa38a245a143",
    "workspace_id": "e259afd6-ca0f-4c31-a858-d695d8643a52",
    "work_id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional read-contract fixture under RUN c-solmax-zaratustra-m1-capabilities-20260909-exec",
    "artifact_id": "d862cd2d-5afe-45b9-b807-1bd59f78a95b",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T3-fictional-contract-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-capabilities-20260909-exec; explicitly selected fictional fixture; T3 acceptance pending",
    "confirmed_at": "2026-09-10T07:18:14.485293Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-before-edits/workspace",
    "request_sha256": "f108126ba00604d8fdb9e69ed37d318ad66fe3d074ef12c3a2a2cfcf8684cdc3"
  },
  "fingerprint": "c90d9f6d27685f60134ceff550d8fa1832d6df14f922e87d96e61c96a4dc0830",
  "before": {
    "id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "revision": 4,
    "created_at": "2026-09-10T07:18:14.348636Z",
    "kind": "work",
    "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "revision": 5,
    "created_at": "2026-09-10T07:18:14.348636Z",
    "kind": "work",
    "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "ff74a6b9-8e89-4e25-bbdd-78a7940d1217",
  "state_revision": 6,
  "recorded_at": "2026-09-10T07:18:14.520836Z",
  "product_version": "0.9.0",
  "request": {
    "version": 2,
    "operation_id": "2611fb87-d626-4ca3-b651-01e1b809d381",
    "workspace_id": "e259afd6-ca0f-4c31-a858-d695d8643a52",
    "work_id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional read-contract fixture under RUN c-solmax-zaratustra-m1-capabilities-20260909-exec",
    "artifact_id": "d862cd2d-5afe-45b9-b807-1bd59f78a95b",
    "artifact_revision": 1,
    "content_sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38",
    "content_size": 36,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T3-fictional-contract-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-capabilities-20260909-exec; explicitly selected fictional fixture; T3 acceptance pending",
    "confirmed_at": "2026-09-10T07:18:14.516821Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-before-edits/workspace",
    "request_sha256": "c48750c5cfa1bd9697cc0ee4feeda51808de005827be4dc7c4ed4c435d9bae6d"
  },
  "fingerprint": "a39542e351728c48a1578b4bd911f22e2de641f448fddf490091977dbb5de9f6",
  "before": {
    "id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "revision": 5,
    "created_at": "2026-09-10T07:18:14.348636Z",
    "kind": "work",
    "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "revision": 6,
    "created_at": "2026-09-10T07:18:14.348636Z",
    "kind": "work",
    "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "d862cd2d-5afe-45b9-b807-1bd59f78a95b",
    "revision": 1,
    "created_at": "2026-09-10T07:18:14.348636Z",
    "kind": "artifact",
    "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "work_id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "title": "Fictional batch observation",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "d862cd2d-5afe-45b9-b807-1bd59f78a95b",
    "revision": 2,
    "created_at": "2026-09-10T07:18:14.348636Z",
    "kind": "artifact",
    "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "work_id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "title": "Fictional batch observation",
    "status": "registered",
    "active_version": "2611fb87-d626-4ca3-b651-01e1b809d381"
  },
  "artifact_version": {
    "id": "2611fb87-d626-4ca3-b651-01e1b809d381",
    "artifact_id": "d862cd2d-5afe-45b9-b807-1bd59f78a95b",
    "work_id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "artifact_revision": 2,
    "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38",
    "size": 36,
    "created_at": "2026-09-10T07:18:14.520836Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "5cf27607-6a6a-41dc-8d97-d659943e68f6",
  "state_revision": 7,
  "recorded_at": "2026-09-10T07:18:14.564036Z",
  "product_version": "0.9.0",
  "request": {
    "version": 3,
    "operation_id": "67fe3b49-2bda-4098-8430-bd805abcb36b",
    "workspace_id": "e259afd6-ca0f-4c31-a858-d695d8643a52",
    "work_id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T2 observation; no owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "d862cd2d-5afe-45b9-b807-1bd59f78a95b",
        "version_id": "2611fb87-d626-4ca3-b651-01e1b809d381",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "67fe3b49-2bda-4098-8430-bd805abcb36b",
      "workspace_id": "e259afd6-ca0f-4c31-a858-d695d8643a52",
      "process": "791e6d07-fd1a-4042-bc30-40be60adfdac",
      "related_work": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "d862cd2d-5afe-45b9-b807-1bd59f78a95b",
        "version_id": "2611fb87-d626-4ca3-b651-01e1b809d381",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      },
      "basis": [],
      "provenance": "Fictional T2 observation; no owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T2 fictional adapter"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-packs-20260909-exec",
      "input_sha256": "45dec680cae610527cd8fdd24a739ea837e2c1f6466af82a2a8915a7355672ca"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T3-fictional-contract-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-capabilities-20260909-exec; explicitly selected fictional fixture; T3 acceptance pending",
    "confirmed_at": "2026-09-10T07:18:14.559956Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-before-edits/workspace",
    "request_sha256": "f33daeeb829f014c90d629a93513066f87b5fc4ddd57ad0653b891b90e3621ed"
  },
  "fingerprint": "c0e81db957ffbfe135bb48627633d570e52b6a87c4024982440b33f97bf5a353",
  "before": {
    "id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "revision": 6,
    "created_at": "2026-09-10T07:18:14.348636Z",
    "kind": "work",
    "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "revision": 7,
    "created_at": "2026-09-10T07:18:14.348636Z",
    "kind": "work",
    "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "cbc5743a-6c49-45c1-b8a8-68c9be415f1e",
  "state_revision": 8,
  "recorded_at": "2026-09-10T07:18:15.136559Z",
  "product_version": "0.9.0",
  "request": {
    "version": 4,
    "operation_id": "6671ec11-b3c5-4ed6-8a58-f87e25a37862",
    "workspace_id": "e259afd6-ca0f-4c31-a858-d695d8643a52",
    "work_id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "expected_revision": 7,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.batch\",\"pack_version\":\"1.0.0\",\"process_type\":\"fictional.batch-check\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "d862cd2d-5afe-45b9-b807-1bd59f78a95b",
        "version_id": "2611fb87-d626-4ca3-b651-01e1b809d381",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 7,
      "result": {
        "artifact_id": "d862cd2d-5afe-45b9-b807-1bd59f78a95b",
        "version_id": "2611fb87-d626-4ca3-b651-01e1b809d381",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      },
      "acceptance_ids": [
        "67fe3b49-2bda-4098-8430-bd805abcb36b"
      ],
      "next_work": {
        "work_id": "f84bb3a8-151f-4a39-a96f-adf7900b5923",
        "artifact_id": "0664a14c-d367-4c06-a601-6f382fb3d9ec",
        "goal": "Inspect the next fictional batch",
        "expected_result": "Both independent marks",
        "acceptance": [
          "Observation and recording marks are both present"
        ],
        "boundaries": [
          "Local fictional data only"
        ],
        "budget": "One T2 lifecycle example",
        "executor_requirements": [
          "probe.batch/v1"
        ],
        "artifact_title": "Next fictional batch observation",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T3-fictional-contract-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-capabilities-20260909-exec; explicitly selected fictional fixture; T3 acceptance pending",
    "confirmed_at": "2026-09-10T07:18:15.132497Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-before-edits/restored-before-result",
    "request_sha256": "281157d3bf478f9d30ccf169d4adc0d7bfc3f3f05c544360cfd0fe09044bf748"
  },
  "fingerprint": "379eb8b1ca4071f62a61cbf79d13af6da3274604cad8731fecc009a1d4a23e2f",
  "before": {
    "id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "revision": 7,
    "created_at": "2026-09-10T07:18:14.348636Z",
    "kind": "work",
    "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "revision": 8,
    "created_at": "2026-09-10T07:18:14.348636Z",
    "kind": "work",
    "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "completion_id": "6671ec11-b3c5-4ed6-8a58-f87e25a37862",
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "f84bb3a8-151f-4a39-a96f-adf7900b5923",
    "revision": 8,
    "created_at": "2026-09-10T07:18:15.136559Z",
    "kind": "work",
    "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "goal": "Inspect the next fictional batch",
    "expected_result": "Both independent marks",
    "acceptance": [
      "Observation and recording marks are both present"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "0664a14c-d367-4c06-a601-6f382fb3d9ec",
    "revision": 1,
    "created_at": "2026-09-10T07:18:15.136559Z",
    "kind": "artifact",
    "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "work_id": "f84bb3a8-151f-4a39-a96f-adf7900b5923",
    "title": "Next fictional batch observation",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "d862cd2d-5afe-45b9-b807-1bd59f78a95b",
    "revision": 2,
    "created_at": "2026-09-10T07:18:14.348636Z",
    "kind": "artifact",
    "process_id": "791e6d07-fd1a-4042-bc30-40be60adfdac",
    "work_id": "ddce8456-3fd1-4978-86e2-9d93b6aa90d4",
    "title": "Fictional batch observation",
    "status": "registered",
    "active_version": "2611fb87-d626-4ca3-b651-01e1b809d381"
  },
  "result_references": [
    {
      "artifact_id": "d862cd2d-5afe-45b9-b807-1bd59f78a95b",
      "version_id": "2611fb87-d626-4ca3-b651-01e1b809d381",
      "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
    }
  ]
}
```

