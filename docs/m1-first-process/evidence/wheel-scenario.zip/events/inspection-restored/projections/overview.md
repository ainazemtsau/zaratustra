# Zaratustra — generated overview

generated_from_revision: 11
generated_at: 2026-09-10T07:40:17.890159+00:00
workspace_id: 1e99df17-d6ec-4c4d-a27a-977b75a0ba2c

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "3038ef99-43dc-4415-ab7c-995c5a57b180",
  "revision": 3,
  "created_at": "2026-09-10T07:40:17.180121Z",
  "kind": "artifact",
  "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
  "work_id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
  "title": "KITE inspection",
  "status": "registered",
  "active_version": "73103055-ee10-4025-83c0-0fc8a0b46526"
}
```

## artifact

```json
{
  "id": "e195b869-863f-4010-ba41-986b49d3414f",
  "revision": 1,
  "created_at": "2026-09-10T07:40:17.890159Z",
  "kind": "artifact",
  "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
  "work_id": "029e26dd-d8a3-4c04-b850-a3da72170a28",
  "title": "KITE disposition",
  "status": "declared",
  "active_version": null
}
```

## event

```json
{
  "id": "9fc89286-bbdc-4042-af70-0509e0c04e87",
  "revision": 1,
  "created_at": "2026-09-10T07:40:17.180121Z",
  "kind": "event",
  "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
  "work_id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.0",
  "state_revision": 1,
  "affected_ids": [
    "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "3038ef99-43dc-4415-ab7c-995c5a57b180"
  ]
}
```

## process

```json
{
  "id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
  "revision": 4,
  "created_at": "2026-09-10T07:40:17.180121Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "029e26dd-d8a3-4c04-b850-a3da72170a28",
  "revision": 11,
  "created_at": "2026-09-10T07:40:17.890159Z",
  "kind": "work",
  "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
  "goal": "Choose release or discard for inspected fictional KITE",
  "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
  "acceptance": [
    "Explicit disposition naming the exact accepted inspection SHA256"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:decide",
    "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
  "revision": 11,
  "created_at": "2026-09-10T07:40:17.180121Z",
  "kind": "work",
  "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "completion_id": "2b3aefa4-f63f-4e3a-8809-45f4517854fa",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 759a0ca1-9355-41e1-bf50-6fba43548127; Artifact revision: 2
  SHA-256: 79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f; bytes: 148
  File: artifacts/3038ef99-43dc-4415-ab7c-995c5a57b180/759a0ca1-9355-41e1-bf50-6fba43548127.blob

- Version: 73103055-ee10-4025-83c0-0fc8a0b46526; Artifact revision: 3
  SHA-256: e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312; bytes: 147
  File: artifacts/3038ef99-43dc-4415-ab7c-995c5a57b180/73103055-ee10-4025-83c0-0fc8a0b46526.blob

## Mutation provenance

```json
{
  "id": "b6242277-86d4-4d56-a68a-c6bd21581d43",
  "state_revision": 2,
  "recorded_at": "2026-09-10T07:40:17.227736Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "9b5b98b5-57d4-48a4-b6ff-6f418134db82",
    "workspace_id": "1e99df17-d6ec-4c4d-a27a-977b75a0ba2c",
    "work_id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:40:17.215543Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-wheel-scenario-01/workspace",
    "request_sha256": "f1df8fa63d73418bc5bd8fa6ab67e7fe92f08b4d8140a54c9d4a30cc2c09650d"
  },
  "fingerprint": "90861b411b407d3af9b45066b1fe6c88ca9e936059f99a1ea759d5268d0637c8",
  "before": {
    "id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "revision": 1,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "work",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "revision": 2,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "work",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "764a25aa-ca8b-47a0-8187-c4ac77bb62eb",
  "state_revision": 3,
  "recorded_at": "2026-09-10T07:40:17.266051Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "3c574094-0c9c-464f-aa89-a104b16bbb87",
    "workspace_id": "1e99df17-d6ec-4c4d-a27a-977b75a0ba2c",
    "work_id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:40:17.253284Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-wheel-scenario-01/workspace",
    "request_sha256": "d55c85d0b2ca39c4806ecd2398d375db396ffc57c51869ac931d76a72b4f2d0e"
  },
  "fingerprint": "a4fc889dc77cb624e40fab0c1610077764211b6e6878c591b3727cd433facc4e",
  "before": {
    "id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "revision": 2,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "work",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "revision": 3,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "work",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "007e2278-8441-43ab-9d88-dde12f05244a",
  "state_revision": 4,
  "recorded_at": "2026-09-10T07:40:17.305675Z",
  "product_version": "0.10.0",
  "request": {
    "version": 5,
    "operation_id": "f6fd35ce-3b2d-487d-973e-c1d499e44db3",
    "workspace_id": "1e99df17-d6ec-4c4d-a27a-977b75a0ba2c",
    "work_id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional lot binding under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:40:17.292194Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-wheel-scenario-01/workspace",
    "request_sha256": "f895d5c3e432de87832ba07af5f8fa394677f3e6eb6791ab4be9f271c9d2ecfb"
  },
  "fingerprint": "a2401f70b343de22f0543df1eabfd191c60aba568afdef7153ea1339e799a5ea",
  "before": {
    "id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "revision": 3,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "work",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "revision": 4,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "work",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "revision": 1,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "revision": 4,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "d587d17b-d835-4df5-bc60-8e1c52a9feb4",
  "state_revision": 5,
  "recorded_at": "2026-09-10T07:40:17.372683Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "3cf462a2-7b61-408c-b70c-fbc86b1e1013",
    "workspace_id": "1e99df17-d6ec-4c4d-a27a-977b75a0ba2c",
    "work_id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "3038ef99-43dc-4415-ab7c-995c5a57b180",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:40:17.358203Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-wheel-scenario-01/workspace",
    "request_sha256": "81afbe71bbc22f5f42d519bd592692fe3ce75719837868d7dcabdb6a0bf2964a"
  },
  "fingerprint": "e0b5d6a3640f9f0c45bbbd0ac4fae64c7302f9c0458b0ede6f4ab4f9f27a1c83",
  "before": {
    "id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "revision": 4,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "work",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "revision": 5,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "work",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "679ed355-bdfb-491f-975e-10f6543dd2f6",
  "state_revision": 6,
  "recorded_at": "2026-09-10T07:40:17.415736Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "759a0ca1-9355-41e1-bf50-6fba43548127",
    "workspace_id": "1e99df17-d6ec-4c4d-a27a-977b75a0ba2c",
    "work_id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "3038ef99-43dc-4415-ab7c-995c5a57b180",
    "artifact_revision": 1,
    "content_sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f",
    "content_size": 148,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:40:17.399556Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-wheel-scenario-01/workspace",
    "request_sha256": "99b2cbeaacb1cc5dd6b160d1b61eb942f2e2456b350c40ea4ba61e87438b3ba1"
  },
  "fingerprint": "b5461726c835ffe386641b12f3c42b7118ca152349c168bd3a6e55082ce94c68",
  "before": {
    "id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "revision": 5,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "work",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "revision": 6,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "work",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "3038ef99-43dc-4415-ab7c-995c5a57b180",
    "revision": 1,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "artifact",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "work_id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "title": "KITE inspection",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "3038ef99-43dc-4415-ab7c-995c5a57b180",
    "revision": 2,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "artifact",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "work_id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "759a0ca1-9355-41e1-bf50-6fba43548127"
  },
  "artifact_version": {
    "id": "759a0ca1-9355-41e1-bf50-6fba43548127",
    "artifact_id": "3038ef99-43dc-4415-ab7c-995c5a57b180",
    "work_id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "artifact_revision": 2,
    "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f",
    "size": 148,
    "created_at": "2026-09-10T07:40:17.415736Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "d545f0bf-ad3a-42b5-a01d-0b4c20b0bc3e",
  "state_revision": 7,
  "recorded_at": "2026-09-10T07:40:17.466553Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "ae2c7742-1883-4b72-88f5-3f777351b196",
    "workspace_id": "1e99df17-d6ec-4c4d-a27a-977b75a0ba2c",
    "work_id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "3038ef99-43dc-4415-ab7c-995c5a57b180",
        "version_id": "759a0ca1-9355-41e1-bf50-6fba43548127",
        "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "ae2c7742-1883-4b72-88f5-3f777351b196",
      "workspace_id": "1e99df17-d6ec-4c4d-a27a-977b75a0ba2c",
      "process": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
      "related_work": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "3038ef99-43dc-4415-ab7c-995c5a57b180",
        "version_id": "759a0ca1-9355-41e1-bf50-6fba43548127",
        "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "0d4259fe710c69e599131a4ad12b6e54daff865d8730065ed7c5612351395c11"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:40:17.450829Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-wheel-scenario-01/workspace",
    "request_sha256": "7700860443dd11f1adcb90ef472e6ca7e55fa18c661f0151e4fcd87218bf0006"
  },
  "fingerprint": "5b53d158357c2eb47eb435ef7ce3d9e4c1f9153c4b3a8592a874a19ca6d0779f",
  "before": {
    "id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "revision": 6,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "work",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "revision": 7,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "work",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "402b758d-5c4d-4df5-8516-0506840611a9",
  "state_revision": 8,
  "recorded_at": "2026-09-10T07:40:17.547562Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "7d761be7-036e-43b7-9976-13c14bbe9dd4",
    "workspace_id": "1e99df17-d6ec-4c4d-a27a-977b75a0ba2c",
    "work_id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "expected_revision": 7,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "3038ef99-43dc-4415-ab7c-995c5a57b180",
    "artifact_revision": 2,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:40:17.529832Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-wheel-scenario-01/workspace",
    "request_sha256": "ef4884cc07cbfb7a405ecd2a58627725c9e7fda8eb09f44d61a9f784af013d28"
  },
  "fingerprint": "a3c15e8700b7f0eaff7263f7de20631c4f6b0f5d969a092bf268a157afb94749",
  "before": {
    "id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "revision": 7,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "work",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "revision": 8,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "work",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "cbba8298-dbc4-4ccc-bd31-11690fa415b0",
  "state_revision": 9,
  "recorded_at": "2026-09-10T07:40:17.599444Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "73103055-ee10-4025-83c0-0fc8a0b46526",
    "workspace_id": "1e99df17-d6ec-4c4d-a27a-977b75a0ba2c",
    "work_id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "expected_revision": 8,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "3038ef99-43dc-4415-ab7c-995c5a57b180",
    "artifact_revision": 2,
    "content_sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312",
    "content_size": 147,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:40:17.578506Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-wheel-scenario-01/workspace",
    "request_sha256": "5906aa33a57d4082bbd4c42a8e298cfa22e85fd4e4adde11c04889fa66384c60"
  },
  "fingerprint": "7880bd9e962fa086cb4cbdce50562f9e8a6282eccdbe651e6f182e4edd006bdb",
  "before": {
    "id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "revision": 8,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "work",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "revision": 9,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "work",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "3038ef99-43dc-4415-ab7c-995c5a57b180",
    "revision": 2,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "artifact",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "work_id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "759a0ca1-9355-41e1-bf50-6fba43548127"
  },
  "artifact_after": {
    "id": "3038ef99-43dc-4415-ab7c-995c5a57b180",
    "revision": 3,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "artifact",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "work_id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "73103055-ee10-4025-83c0-0fc8a0b46526"
  },
  "artifact_version": {
    "id": "73103055-ee10-4025-83c0-0fc8a0b46526",
    "artifact_id": "3038ef99-43dc-4415-ab7c-995c5a57b180",
    "work_id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "artifact_revision": 3,
    "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312",
    "size": 147,
    "created_at": "2026-09-10T07:40:17.599444Z",
    "state_revision": 9
  }
}
```

```json
{
  "id": "5f687053-622a-496d-95b4-30d11ab29929",
  "state_revision": 10,
  "recorded_at": "2026-09-10T07:40:17.660648Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "585a9f43-97ee-4040-9af3-1d00cf1b285d",
    "workspace_id": "1e99df17-d6ec-4c4d-a27a-977b75a0ba2c",
    "work_id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "expected_revision": 9,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "3038ef99-43dc-4415-ab7c-995c5a57b180",
        "version_id": "73103055-ee10-4025-83c0-0fc8a0b46526",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "585a9f43-97ee-4040-9af3-1d00cf1b285d",
      "workspace_id": "1e99df17-d6ec-4c4d-a27a-977b75a0ba2c",
      "process": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
      "related_work": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
      "intent": "accepted_result",
      "source_revision": 9,
      "result": {
        "artifact_id": "3038ef99-43dc-4415-ab7c-995c5a57b180",
        "version_id": "73103055-ee10-4025-83c0-0fc8a0b46526",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "94117e701bf33a827db3b48b5856721d02e44052e7bda691c3d0d062a4cc8579"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:40:17.642779Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-wheel-scenario-01/workspace",
    "request_sha256": "dec486964476336b2d3a45f809020d6fc39df56ffc7d3662868452850b44d28f"
  },
  "fingerprint": "5469f1cca90294c6e9d97947cb7788eb77de39aaeb28bf3eb894b9911d64dfc9",
  "before": {
    "id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "revision": 9,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "work",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "revision": 10,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "work",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "e7bb1c56-9b56-4875-a307-d318d0566902",
  "state_revision": 11,
  "recorded_at": "2026-09-10T07:40:17.890159Z",
  "product_version": "0.10.0",
  "request": {
    "version": 4,
    "operation_id": "2b3aefa4-f63f-4e3a-8809-45f4517854fa",
    "workspace_id": "1e99df17-d6ec-4c4d-a27a-977b75a0ba2c",
    "work_id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "expected_revision": 10,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.lot\",\"pack_version\":\"1.0.0\",\"process_type\":\"fictional.lot-release\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "3038ef99-43dc-4415-ab7c-995c5a57b180",
        "version_id": "73103055-ee10-4025-83c0-0fc8a0b46526",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 10,
      "result": {
        "artifact_id": "3038ef99-43dc-4415-ab7c-995c5a57b180",
        "version_id": "73103055-ee10-4025-83c0-0fc8a0b46526",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      },
      "acceptance_ids": [
        "ae2c7742-1883-4b72-88f5-3f777351b196",
        "585a9f43-97ee-4040-9af3-1d00cf1b285d"
      ],
      "next_work": {
        "work_id": "029e26dd-d8a3-4c04-b850-a3da72170a28",
        "artifact_id": "e195b869-863f-4010-ba41-986b49d3414f",
        "goal": "Choose release or discard for inspected fictional KITE",
        "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
        "acceptance": [
          "Explicit disposition naming the exact accepted inspection SHA256"
        ],
        "boundaries": [
          "Fictional local evidence only; no real release or external action"
        ],
        "budget": "One finite fictional lot",
        "executor_requirements": [
          "fictional.lot/v1:decide",
          "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
        ],
        "artifact_title": "KITE disposition",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:40:17.884674Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-wheel-scenario-01/events/inspection-restored",
    "request_sha256": "a6f33243e5b495c2d8a6643842cd733e55aceeef6bd2d2c64b140ed66a1598c5"
  },
  "fingerprint": "a54b0fb9531849cd5bc842d832d12a525ae74c9827cb9828079a4ed4645a6b98",
  "before": {
    "id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "revision": 10,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "work",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "revision": 11,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "work",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "completion_id": "2b3aefa4-f63f-4e3a-8809-45f4517854fa",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "029e26dd-d8a3-4c04-b850-a3da72170a28",
    "revision": 11,
    "created_at": "2026-09-10T07:40:17.890159Z",
    "kind": "work",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "e195b869-863f-4010-ba41-986b49d3414f",
    "revision": 1,
    "created_at": "2026-09-10T07:40:17.890159Z",
    "kind": "artifact",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "work_id": "029e26dd-d8a3-4c04-b850-a3da72170a28",
    "title": "KITE disposition",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "3038ef99-43dc-4415-ab7c-995c5a57b180",
    "revision": 3,
    "created_at": "2026-09-10T07:40:17.180121Z",
    "kind": "artifact",
    "process_id": "abfcb8a0-3278-4c8e-a462-5a708a3bbaff",
    "work_id": "d7d29e43-cefb-48a0-910e-e0e094aea2f1",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "73103055-ee10-4025-83c0-0fc8a0b46526"
  },
  "result_references": [
    {
      "artifact_id": "3038ef99-43dc-4415-ab7c-995c5a57b180",
      "version_id": "73103055-ee10-4025-83c0-0fc8a0b46526",
      "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    },
    {
      "artifact_id": "3038ef99-43dc-4415-ab7c-995c5a57b180",
      "version_id": "759a0ca1-9355-41e1-bf50-6fba43548127",
      "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
    }
  ]
}
```

