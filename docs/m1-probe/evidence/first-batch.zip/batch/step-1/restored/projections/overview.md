# Zaratustra — generated overview

generated_from_revision: 10
generated_at: 2026-09-09T12:04:44.987425+00:00
workspace_id: 1a8e25d9-0187-4436-99c4-cb6b3209fa02

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "19b1ccca-c8b4-4d42-a6d6-63a9614178dd",
  "revision": 3,
  "created_at": "2026-09-09T12:04:44.430270Z",
  "kind": "artifact",
  "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
  "work_id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
  "title": "Fictional observation",
  "status": "registered",
  "active_version": "89590b54-6b74-4cf2-9eb5-ebadabbda364"
}
```

## artifact

```json
{
  "id": "7fd11ca6-697e-4ee8-9715-5362482f5540",
  "revision": 1,
  "created_at": "2026-09-09T12:04:44.987425Z",
  "kind": "artifact",
  "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
  "work_id": "860c778f-818c-4f3f-8fae-65d1508e7413",
  "title": "Next fictional batch observation",
  "status": "declared",
  "active_version": null
}
```

## event

```json
{
  "id": "cf9963d9-7357-4ca8-8a90-22eee4e2b837",
  "revision": 1,
  "created_at": "2026-09-09T12:04:44.430270Z",
  "kind": "event",
  "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
  "work_id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.7.0",
  "state_revision": 1,
  "affected_ids": [
    "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "19b1ccca-c8b4-4d42-a6d6-63a9614178dd"
  ]
}
```

## process

```json
{
  "id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
  "revision": 1,
  "created_at": "2026-09-09T12:04:44.430270Z",
  "kind": "process",
  "title": "Fictional probe.batch/v1"
}
```

## work

```json
{
  "id": "860c778f-818c-4f3f-8fae-65d1508e7413",
  "revision": 10,
  "created_at": "2026-09-09T12:04:44.987425Z",
  "kind": "work",
  "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
  "goal": "Inspect the next fictional batch",
  "expected_result": "Both independent marks",
  "acceptance": [
    "Observation and recording marks are both present"
  ],
  "boundaries": [
    "Local fictional workspace only"
  ],
  "budget": "One minimal rule contrast",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ]
}
```

## work

```json
{
  "id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
  "revision": 10,
  "created_at": "2026-09-09T12:04:44.430270Z",
  "kind": "work",
  "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
  "goal": "Evaluate the selected fictional rule",
  "expected_result": "Exact recorded observation and permitted continuation",
  "acceptance": [
    "Only explicitly selected fictional inputs"
  ],
  "boundaries": [
    "Local fictional workspace only"
  ],
  "budget": "One minimal rule contrast",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ],
  "completion_id": "52504b72-43c3-44f4-96a2-b47ce967b5fe"
}
```

## Registered versions

- Version: a06c6ae7-9005-42bc-8e23-acbbd77dd602; Artifact revision: 2
  SHA-256: 1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568; bytes: 38
  File: artifacts/19b1ccca-c8b4-4d42-a6d6-63a9614178dd/a06c6ae7-9005-42bc-8e23-acbbd77dd602.blob

- Version: 89590b54-6b74-4cf2-9eb5-ebadabbda364; Artifact revision: 3
  SHA-256: 662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35; bytes: 37
  File: artifacts/19b1ccca-c8b4-4d42-a6d6-63a9614178dd/89590b54-6b74-4cf2-9eb5-ebadabbda364.blob

## Mutation provenance

```json
{
  "id": "3af4cdf0-3c18-4bf6-9f0e-6ef92b1cf098",
  "state_revision": 2,
  "recorded_at": "2026-09-09T12:04:44.466001Z",
  "product_version": "0.7.0",
  "request": {
    "version": 1,
    "operation_id": "a6fe8193-3c4f-4355-b482-ef5da958628f",
    "workspace_id": "1a8e25d9-0187-4436-99c4-cb6b3209fa02",
    "work_id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:04:44.463134Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/first-batch/batch/workspace",
    "request_sha256": "de0f25ade80e116084fd505d4eb6d63a0b6040476fd01e11e9dbc2e735ca58ea"
  },
  "fingerprint": "eec2c8fb43aba3167b798aec7d2fb876054c86b7cf23cff6011770b6b11c1bb5",
  "before": {
    "id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "revision": 1,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "work",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "revision": 2,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "work",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "13060eee-c387-4bb7-aef4-2b0c85252d5b",
  "state_revision": 3,
  "recorded_at": "2026-09-09T12:04:44.493739Z",
  "product_version": "0.7.0",
  "request": {
    "version": 1,
    "operation_id": "cb1012b8-f030-445d-9c21-2b9a61c36d90",
    "workspace_id": "1a8e25d9-0187-4436-99c4-cb6b3209fa02",
    "work_id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "probe.batch/v1"
    ],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:04:44.491127Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/first-batch/batch/workspace",
    "request_sha256": "dfe8a0236d245d168e0a9cd3e2ea168437c9d91a537e3f86388916285b7b1f08"
  },
  "fingerprint": "7e20073fd62e11429c69e0b74a091e2a3f19131f1cae248076011c8aef93486c",
  "before": {
    "id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "revision": 2,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "work",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "revision": 3,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "work",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "5303e597-0a2f-4812-b57a-910af3c31de0",
  "state_revision": 4,
  "recorded_at": "2026-09-09T12:04:44.523139Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "0691ea59-f6f3-4fee-89f5-15bf9f9679e0",
    "workspace_id": "1a8e25d9-0187-4436-99c4-cb6b3209fa02",
    "work_id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "expected_revision": 3,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "19b1ccca-c8b4-4d42-a6d6-63a9614178dd",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:04:44.519271Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/first-batch/batch/workspace",
    "request_sha256": "4bf3298056aa626c2f5a0ca9590a0ad5b3c534429f27136910b6cb85954a956a"
  },
  "fingerprint": "3dd632635811bff1ce3e27ac01c394895d4fec9cdcbc4180fc9aa6c6b085258a",
  "before": {
    "id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "revision": 3,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "work",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "revision": 4,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "work",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "08e84f83-8006-418b-af36-314602503ead",
  "state_revision": 5,
  "recorded_at": "2026-09-09T12:04:44.551096Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "a06c6ae7-9005-42bc-8e23-acbbd77dd602",
    "workspace_id": "1a8e25d9-0187-4436-99c4-cb6b3209fa02",
    "work_id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "expected_revision": 4,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "19b1ccca-c8b4-4d42-a6d6-63a9614178dd",
    "artifact_revision": 1,
    "content_sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568",
    "content_size": 38,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:04:44.547692Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/first-batch/batch/workspace",
    "request_sha256": "679b0d5ef5f8713d02e15be84dff31e603fd3b14fe70e54ee1b86e34b87840f0"
  },
  "fingerprint": "43aa4a5f05485c31c1fe68eede32d160e37cfba511aa428fbfc4ea1da476e216",
  "before": {
    "id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "revision": 4,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "work",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "revision": 5,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "work",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "19b1ccca-c8b4-4d42-a6d6-63a9614178dd",
    "revision": 1,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "artifact",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "work_id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "title": "Fictional observation",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "19b1ccca-c8b4-4d42-a6d6-63a9614178dd",
    "revision": 2,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "artifact",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "work_id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "title": "Fictional observation",
    "status": "registered",
    "active_version": "a06c6ae7-9005-42bc-8e23-acbbd77dd602"
  },
  "artifact_version": {
    "id": "a06c6ae7-9005-42bc-8e23-acbbd77dd602",
    "artifact_id": "19b1ccca-c8b4-4d42-a6d6-63a9614178dd",
    "work_id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "artifact_revision": 2,
    "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568",
    "size": 38,
    "created_at": "2026-09-09T12:04:44.551096Z",
    "state_revision": 5
  }
}
```

```json
{
  "id": "cd018e14-8734-46bf-b205-cb09b5252484",
  "state_revision": 6,
  "recorded_at": "2026-09-09T12:04:44.594831Z",
  "product_version": "0.7.0",
  "request": {
    "version": 3,
    "operation_id": "58b344b6-28de-4a17-b6fd-68fbbfb74a92",
    "workspace_id": "1a8e25d9-0187-4436-99c4-cb6b3209fa02",
    "work_id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "expected_revision": 5,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional observation, not owner product acceptance",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "19b1ccca-c8b4-4d42-a6d6-63a9614178dd",
        "version_id": "a06c6ae7-9005-42bc-8e23-acbbd77dd602",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "58b344b6-28de-4a17-b6fd-68fbbfb74a92",
      "workspace_id": "1a8e25d9-0187-4436-99c4-cb6b3209fa02",
      "process": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
      "related_work": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
      "intent": "accepted_result",
      "source_revision": 5,
      "result": {
        "artifact_id": "19b1ccca-c8b4-4d42-a6d6-63a9614178dd",
        "version_id": "a06c6ae7-9005-42bc-8e23-acbbd77dd602",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      },
      "basis": [],
      "provenance": "Explicit fictional observation, not owner product acceptance",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T1 fictional adapter"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-probe-admission-20260909-exec",
      "input_sha256": "866519f46e18a0c7bdf47357794d11d8185958a3835034385a5c3102f3f5eb3f"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:04:44.590041Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/first-batch/batch/workspace",
    "request_sha256": "423aadab77f0dcfc5fd2bd6b922a843b85bfb17fe2e6510b5ef40b57a67814e8"
  },
  "fingerprint": "d82533b6aabb378839dd8310c0c9347eb3bd2ee9f92e493dfbce78ba65b14170",
  "before": {
    "id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "revision": 5,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "work",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "revision": 6,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "work",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "8f841180-e2cc-4e34-ab2c-992fec69a62a",
  "state_revision": 7,
  "recorded_at": "2026-09-09T12:04:44.684918Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "e3b3dff8-97e9-43ce-8d45-ff7c4d7689aa",
    "workspace_id": "1a8e25d9-0187-4436-99c4-cb6b3209fa02",
    "work_id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "expected_revision": 6,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "19b1ccca-c8b4-4d42-a6d6-63a9614178dd",
    "artifact_revision": 2,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:04:44.680861Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/first-batch/batch/workspace",
    "request_sha256": "191e3f10040d5abaf5c38c67485992e0b042931d18fb59b3c8c004e69dcc06a5"
  },
  "fingerprint": "0580f4c08059b0ded49545fcbef44cae95d97c6be800e37fdb06dc60329a8060",
  "before": {
    "id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "revision": 6,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "work",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "revision": 7,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "work",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "ebcc55b6-190d-4a5a-8a05-15da956231bb",
  "state_revision": 8,
  "recorded_at": "2026-09-09T12:04:44.718661Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "89590b54-6b74-4cf2-9eb5-ebadabbda364",
    "workspace_id": "1a8e25d9-0187-4436-99c4-cb6b3209fa02",
    "work_id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "expected_revision": 7,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "19b1ccca-c8b4-4d42-a6d6-63a9614178dd",
    "artifact_revision": 2,
    "content_sha256": "662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35",
    "content_size": 37,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:04:44.714593Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/first-batch/batch/workspace",
    "request_sha256": "eda4bf657940be979e9ab26e0456e3e2903f767487bc283ec5e057e8a2141e29"
  },
  "fingerprint": "fc66d10a236884a275bc189c0a0ba5ab4ea63c065a16bccc48848bc5afbc79f1",
  "before": {
    "id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "revision": 7,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "work",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "revision": 8,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "work",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "19b1ccca-c8b4-4d42-a6d6-63a9614178dd",
    "revision": 2,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "artifact",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "work_id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "title": "Fictional observation",
    "status": "registered",
    "active_version": "a06c6ae7-9005-42bc-8e23-acbbd77dd602"
  },
  "artifact_after": {
    "id": "19b1ccca-c8b4-4d42-a6d6-63a9614178dd",
    "revision": 3,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "artifact",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "work_id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "title": "Fictional observation",
    "status": "registered",
    "active_version": "89590b54-6b74-4cf2-9eb5-ebadabbda364"
  },
  "artifact_version": {
    "id": "89590b54-6b74-4cf2-9eb5-ebadabbda364",
    "artifact_id": "19b1ccca-c8b4-4d42-a6d6-63a9614178dd",
    "work_id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "artifact_revision": 3,
    "sha256": "662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35",
    "size": 37,
    "created_at": "2026-09-09T12:04:44.718661Z",
    "state_revision": 8
  }
}
```

```json
{
  "id": "cd558e87-39c4-4ae6-9861-9ef4c35e0fc2",
  "state_revision": 9,
  "recorded_at": "2026-09-09T12:04:44.780589Z",
  "product_version": "0.7.0",
  "request": {
    "version": 3,
    "operation_id": "d7e5b30a-9543-4cdb-940d-4762fcf78d19",
    "workspace_id": "1a8e25d9-0187-4436-99c4-cb6b3209fa02",
    "work_id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "expected_revision": 8,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional observation, not owner product acceptance",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "19b1ccca-c8b4-4d42-a6d6-63a9614178dd",
        "version_id": "89590b54-6b74-4cf2-9eb5-ebadabbda364",
        "sha256": "662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "d7e5b30a-9543-4cdb-940d-4762fcf78d19",
      "workspace_id": "1a8e25d9-0187-4436-99c4-cb6b3209fa02",
      "process": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
      "related_work": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
      "intent": "accepted_result",
      "source_revision": 8,
      "result": {
        "artifact_id": "19b1ccca-c8b4-4d42-a6d6-63a9614178dd",
        "version_id": "89590b54-6b74-4cf2-9eb5-ebadabbda364",
        "sha256": "662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35"
      },
      "basis": [],
      "provenance": "Explicit fictional observation, not owner product acceptance",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T1 fictional adapter"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-probe-admission-20260909-exec",
      "input_sha256": "3293c3c6f4c69bc7d9a87296cace6bc921f969f9ba2f7105a66d8b5d471f6a96"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:04:44.776115Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/first-batch/batch/workspace",
    "request_sha256": "6de9b46c951d9ab52834823c92db03c45bc73f746f1090f7cfbfbbe4932edde4"
  },
  "fingerprint": "d1547a661efe603777c024e07fadfec28d68dd2dd8f9e1554b4dbd99853a5baa",
  "before": {
    "id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "revision": 8,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "work",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "revision": 9,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "work",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "d07e1e81-8692-4a11-82ed-9d3a8872a139",
  "state_revision": 10,
  "recorded_at": "2026-09-09T12:04:44.987425Z",
  "product_version": "0.7.0",
  "request": {
    "version": 4,
    "operation_id": "52504b72-43c3-44f4-96a2-b47ce967b5fe",
    "workspace_id": "1a8e25d9-0187-4436-99c4-cb6b3209fa02",
    "work_id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "expected_revision": 9,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "M1 T1 fictional rule proposal; authority supplied separately",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "19b1ccca-c8b4-4d42-a6d6-63a9614178dd",
        "version_id": "89590b54-6b74-4cf2-9eb5-ebadabbda364",
        "sha256": "662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 9,
      "result": {
        "artifact_id": "19b1ccca-c8b4-4d42-a6d6-63a9614178dd",
        "version_id": "89590b54-6b74-4cf2-9eb5-ebadabbda364",
        "sha256": "662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35"
      },
      "acceptance_ids": [
        "58b344b6-28de-4a17-b6fd-68fbbfb74a92",
        "d7e5b30a-9543-4cdb-940d-4762fcf78d19"
      ],
      "next_work": {
        "work_id": "860c778f-818c-4f3f-8fae-65d1508e7413",
        "artifact_id": "7fd11ca6-697e-4ee8-9715-5362482f5540",
        "goal": "Inspect the next fictional batch",
        "expected_result": "Both independent marks",
        "acceptance": [
          "Observation and recording marks are both present"
        ],
        "boundaries": [
          "Local fictional workspace only"
        ],
        "budget": "One minimal rule contrast",
        "executor_requirements": [
          "probe.batch/v1"
        ],
        "artifact_title": "Next fictional batch observation",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:04:44.983202Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/first-batch/batch/step-1/restored",
    "request_sha256": "6f55c36fe4a99aa8d6c7bda0d310061d96439db416eab69a19a77ac7b8f178a9"
  },
  "fingerprint": "30f94817111058fa470746291396c0e9c3f8eda61d177fcc160850d72ceda106",
  "before": {
    "id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "revision": 9,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "work",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "revision": 10,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "work",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "completion_id": "52504b72-43c3-44f4-96a2-b47ce967b5fe"
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "860c778f-818c-4f3f-8fae-65d1508e7413",
    "revision": 10,
    "created_at": "2026-09-09T12:04:44.987425Z",
    "kind": "work",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "goal": "Inspect the next fictional batch",
    "expected_result": "Both independent marks",
    "acceptance": [
      "Observation and recording marks are both present"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "next_artifact": {
    "id": "7fd11ca6-697e-4ee8-9715-5362482f5540",
    "revision": 1,
    "created_at": "2026-09-09T12:04:44.987425Z",
    "kind": "artifact",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "work_id": "860c778f-818c-4f3f-8fae-65d1508e7413",
    "title": "Next fictional batch observation",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "19b1ccca-c8b4-4d42-a6d6-63a9614178dd",
    "revision": 3,
    "created_at": "2026-09-09T12:04:44.430270Z",
    "kind": "artifact",
    "process_id": "1bfad482-1789-41d6-8b89-ee9b1f695aeb",
    "work_id": "c1901d41-5a26-4aaf-8be2-0156b8f6509a",
    "title": "Fictional observation",
    "status": "registered",
    "active_version": "89590b54-6b74-4cf2-9eb5-ebadabbda364"
  },
  "result_references": [
    {
      "artifact_id": "19b1ccca-c8b4-4d42-a6d6-63a9614178dd",
      "version_id": "89590b54-6b74-4cf2-9eb5-ebadabbda364",
      "sha256": "662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35"
    },
    {
      "artifact_id": "19b1ccca-c8b4-4d42-a6d6-63a9614178dd",
      "version_id": "a06c6ae7-9005-42bc-8e23-acbbd77dd602",
      "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
    }
  ]
}
```

