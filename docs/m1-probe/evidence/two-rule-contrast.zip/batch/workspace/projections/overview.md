# Zaratustra — generated overview

generated_from_revision: 10
generated_at: 2026-09-09T12:06:55.292634+00:00
workspace_id: 692cd65d-66fd-43cd-a077-1beb96ab03af

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "1951a12e-bf6c-4fcb-b145-645a36a57742",
  "revision": 1,
  "created_at": "2026-09-09T12:06:55.292634Z",
  "kind": "artifact",
  "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
  "work_id": "3a36c1a8-78fb-4bc6-a8f3-5a1059cb43f4",
  "title": "Next fictional batch observation",
  "status": "declared",
  "active_version": null
}
```

## artifact

```json
{
  "id": "1a43f1f7-e625-49d9-bfe7-265f95c7c957",
  "revision": 3,
  "created_at": "2026-09-09T12:06:54.889233Z",
  "kind": "artifact",
  "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
  "work_id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
  "title": "Fictional observation",
  "status": "registered",
  "active_version": "53c2b87a-826c-4859-8a89-dcf20c26bd5c"
}
```

## event

```json
{
  "id": "e2d6db29-a8a3-430c-b0be-197352c517bc",
  "revision": 1,
  "created_at": "2026-09-09T12:06:54.889233Z",
  "kind": "event",
  "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
  "work_id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.7.0",
  "state_revision": 1,
  "affected_ids": [
    "28dec515-93ab-480c-90a4-dcd5534aa553",
    "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "1a43f1f7-e625-49d9-bfe7-265f95c7c957"
  ]
}
```

## process

```json
{
  "id": "28dec515-93ab-480c-90a4-dcd5534aa553",
  "revision": 1,
  "created_at": "2026-09-09T12:06:54.889233Z",
  "kind": "process",
  "title": "Fictional probe.batch/v1"
}
```

## work

```json
{
  "id": "3a36c1a8-78fb-4bc6-a8f3-5a1059cb43f4",
  "revision": 10,
  "created_at": "2026-09-09T12:06:55.292634Z",
  "kind": "work",
  "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
  "goal": "Inspect the next fictional batch",
  "expected_result": "Both independent marks",
  "acceptance": [
    "Observation and recording marks are both present"
  ],
  "boundaries": [
    "Local fictional workspace only"
  ],
  "budget": "One minimal rule contrast",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ]
}
```

## work

```json
{
  "id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
  "revision": 10,
  "created_at": "2026-09-09T12:06:54.889233Z",
  "kind": "work",
  "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
  "goal": "Evaluate the selected fictional rule",
  "expected_result": "Exact recorded observation and permitted continuation",
  "acceptance": [
    "Only explicitly selected fictional inputs"
  ],
  "boundaries": [
    "Local fictional workspace only"
  ],
  "budget": "One minimal rule contrast",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ],
  "completion_id": "e31b8af2-0c36-4dc5-88b2-16c40a4cf60f"
}
```

## Registered versions

- Version: f9669ff1-7258-4f93-bb8b-8769bb423ead; Artifact revision: 2
  SHA-256: 1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568; bytes: 38
  File: artifacts/1a43f1f7-e625-49d9-bfe7-265f95c7c957/f9669ff1-7258-4f93-bb8b-8769bb423ead.blob

- Version: 53c2b87a-826c-4859-8a89-dcf20c26bd5c; Artifact revision: 3
  SHA-256: 662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35; bytes: 37
  File: artifacts/1a43f1f7-e625-49d9-bfe7-265f95c7c957/53c2b87a-826c-4859-8a89-dcf20c26bd5c.blob

## Mutation provenance

```json
{
  "id": "200e72a5-4479-4385-bb0b-a5794941e5d2",
  "state_revision": 2,
  "recorded_at": "2026-09-09T12:06:54.924670Z",
  "product_version": "0.7.0",
  "request": {
    "version": 1,
    "operation_id": "85dd55d9-da30-45db-bcf3-ccea4988c2fc",
    "workspace_id": "692cd65d-66fd-43cd-a077-1beb96ab03af",
    "work_id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:54.921853Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/batch/workspace",
    "request_sha256": "956cc32bdeffc6ddd24d9318f83e4014fae262eb41f819926d2e496a2df04efa"
  },
  "fingerprint": "aef1e70f7dc246dea5a86720e6cb71a918493c14b5842414c9830485804434b5",
  "before": {
    "id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "revision": 1,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "work",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "revision": 2,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "work",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "246855eb-dd8a-4d63-af1e-6382f02cb4d4",
  "state_revision": 3,
  "recorded_at": "2026-09-09T12:06:54.952194Z",
  "product_version": "0.7.0",
  "request": {
    "version": 1,
    "operation_id": "8fb24c95-35ed-4f0c-aa53-afe3c8ba0ff0",
    "workspace_id": "692cd65d-66fd-43cd-a077-1beb96ab03af",
    "work_id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "probe.batch/v1"
    ],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:54.949793Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/batch/workspace",
    "request_sha256": "07c795bdf11df2738d6b6355a72366cf056125e830cf93c8f2b9a9c9581cbe54"
  },
  "fingerprint": "971e237e721db569e4b795ec83c6d58ba7777fee3ca1dd653ecefc67b484c167",
  "before": {
    "id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "revision": 2,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "work",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "revision": 3,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "work",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "1fa6534d-bfab-418f-bdeb-7e2b088cbb3b",
  "state_revision": 4,
  "recorded_at": "2026-09-09T12:06:54.979964Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "dd4081e4-4839-471b-922d-bd772a2ca448",
    "workspace_id": "692cd65d-66fd-43cd-a077-1beb96ab03af",
    "work_id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "expected_revision": 3,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "1a43f1f7-e625-49d9-bfe7-265f95c7c957",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:54.977150Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/batch/workspace",
    "request_sha256": "47724268392d828ef6f37fc29a5be97fafa7c8225a8ea79d7cb7c2257f02e031"
  },
  "fingerprint": "79b4677e374589c318055b20abce3d18573c2235159ae9712e1e4edfb189a6af",
  "before": {
    "id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "revision": 3,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "work",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "revision": 4,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "work",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "79e23af8-9b81-4f93-9bbd-2ec0bd234cd1",
  "state_revision": 5,
  "recorded_at": "2026-09-09T12:06:55.008476Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "f9669ff1-7258-4f93-bb8b-8769bb423ead",
    "workspace_id": "692cd65d-66fd-43cd-a077-1beb96ab03af",
    "work_id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "expected_revision": 4,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "1a43f1f7-e625-49d9-bfe7-265f95c7c957",
    "artifact_revision": 1,
    "content_sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568",
    "content_size": 38,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:55.004802Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/batch/workspace",
    "request_sha256": "f75ac9b030a58abfcb964e53801989ccfc6f2430be073f14a95467759bc1b355"
  },
  "fingerprint": "cf44ed2a93094b54899f86f381a2fdf2175c818657a00319712195b7dc15c564",
  "before": {
    "id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "revision": 4,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "work",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "revision": 5,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "work",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "1a43f1f7-e625-49d9-bfe7-265f95c7c957",
    "revision": 1,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "artifact",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "work_id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "title": "Fictional observation",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "1a43f1f7-e625-49d9-bfe7-265f95c7c957",
    "revision": 2,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "artifact",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "work_id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "title": "Fictional observation",
    "status": "registered",
    "active_version": "f9669ff1-7258-4f93-bb8b-8769bb423ead"
  },
  "artifact_version": {
    "id": "f9669ff1-7258-4f93-bb8b-8769bb423ead",
    "artifact_id": "1a43f1f7-e625-49d9-bfe7-265f95c7c957",
    "work_id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "artifact_revision": 2,
    "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568",
    "size": 38,
    "created_at": "2026-09-09T12:06:55.008476Z",
    "state_revision": 5
  }
}
```

```json
{
  "id": "6f07cccb-e6fb-4fd0-bfaa-ce26ff4941cc",
  "state_revision": 6,
  "recorded_at": "2026-09-09T12:06:55.047667Z",
  "product_version": "0.7.0",
  "request": {
    "version": 3,
    "operation_id": "1188f388-72ae-4a4a-8fd2-8e252ef3e90d",
    "workspace_id": "692cd65d-66fd-43cd-a077-1beb96ab03af",
    "work_id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "expected_revision": 5,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional observation, not owner product acceptance",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "1a43f1f7-e625-49d9-bfe7-265f95c7c957",
        "version_id": "f9669ff1-7258-4f93-bb8b-8769bb423ead",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "1188f388-72ae-4a4a-8fd2-8e252ef3e90d",
      "workspace_id": "692cd65d-66fd-43cd-a077-1beb96ab03af",
      "process": "28dec515-93ab-480c-90a4-dcd5534aa553",
      "related_work": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
      "intent": "accepted_result",
      "source_revision": 5,
      "result": {
        "artifact_id": "1a43f1f7-e625-49d9-bfe7-265f95c7c957",
        "version_id": "f9669ff1-7258-4f93-bb8b-8769bb423ead",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      },
      "basis": [],
      "provenance": "Explicit fictional observation, not owner product acceptance",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T1 fictional adapter"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-probe-admission-20260909-exec",
      "input_sha256": "dd3015e00dc0b1ecf5053fdacb61fff2d877a473d88c5d989f8f15cf2ae1ef2f"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:55.043839Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/batch/workspace",
    "request_sha256": "ad78052dfbcb9bd5b5464f3f6b20b210c1bcc301ac793ce0bdf5b0ac64ea0a5b"
  },
  "fingerprint": "7067211440cff27f92f17be06422b55457ec6f0db6bdae2d249edd5f467f9902",
  "before": {
    "id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "revision": 5,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "work",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "revision": 6,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "work",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "e9853971-43cb-49f4-8ccb-95caa5d8f767",
  "state_revision": 7,
  "recorded_at": "2026-09-09T12:06:55.132531Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "73d78bec-988a-4dd1-8617-ce5966df8191",
    "workspace_id": "692cd65d-66fd-43cd-a077-1beb96ab03af",
    "work_id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "expected_revision": 6,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "1a43f1f7-e625-49d9-bfe7-265f95c7c957",
    "artifact_revision": 2,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:55.129351Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/batch/workspace",
    "request_sha256": "408e54c48be2fd09b0111bde5b5161a558146adb8f10f475f0b90af90f064aad"
  },
  "fingerprint": "6a3c3c61a3b19438334e1051712af8973fb7c9d69e74b7d32a8122803f5cdf62",
  "before": {
    "id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "revision": 6,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "work",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "revision": 7,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "work",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "6eb8de64-ca14-4a83-8cd1-45b4a1503ee5",
  "state_revision": 8,
  "recorded_at": "2026-09-09T12:06:55.162633Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "53c2b87a-826c-4859-8a89-dcf20c26bd5c",
    "workspace_id": "692cd65d-66fd-43cd-a077-1beb96ab03af",
    "work_id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "expected_revision": 7,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "1a43f1f7-e625-49d9-bfe7-265f95c7c957",
    "artifact_revision": 2,
    "content_sha256": "662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35",
    "content_size": 37,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:55.158692Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/batch/workspace",
    "request_sha256": "9cff7aa87f5828d91f41011b349930c17759057ea9adc0219bc45e90c73bbcfd"
  },
  "fingerprint": "12fa9c3fa36744c077781afcd8e4eb6a1086471d2c61f94e1126cae9be197db9",
  "before": {
    "id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "revision": 7,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "work",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "revision": 8,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "work",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "1a43f1f7-e625-49d9-bfe7-265f95c7c957",
    "revision": 2,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "artifact",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "work_id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "title": "Fictional observation",
    "status": "registered",
    "active_version": "f9669ff1-7258-4f93-bb8b-8769bb423ead"
  },
  "artifact_after": {
    "id": "1a43f1f7-e625-49d9-bfe7-265f95c7c957",
    "revision": 3,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "artifact",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "work_id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "title": "Fictional observation",
    "status": "registered",
    "active_version": "53c2b87a-826c-4859-8a89-dcf20c26bd5c"
  },
  "artifact_version": {
    "id": "53c2b87a-826c-4859-8a89-dcf20c26bd5c",
    "artifact_id": "1a43f1f7-e625-49d9-bfe7-265f95c7c957",
    "work_id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "artifact_revision": 3,
    "sha256": "662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35",
    "size": 37,
    "created_at": "2026-09-09T12:06:55.162633Z",
    "state_revision": 8
  }
}
```

```json
{
  "id": "6df99df8-ade0-47f9-bc37-49b6fcbcdb9e",
  "state_revision": 9,
  "recorded_at": "2026-09-09T12:06:55.203002Z",
  "product_version": "0.7.0",
  "request": {
    "version": 3,
    "operation_id": "0fe357a4-6f25-47b8-b06f-2bcdb54faac6",
    "workspace_id": "692cd65d-66fd-43cd-a077-1beb96ab03af",
    "work_id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "expected_revision": 8,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional observation, not owner product acceptance",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "1a43f1f7-e625-49d9-bfe7-265f95c7c957",
        "version_id": "53c2b87a-826c-4859-8a89-dcf20c26bd5c",
        "sha256": "662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "0fe357a4-6f25-47b8-b06f-2bcdb54faac6",
      "workspace_id": "692cd65d-66fd-43cd-a077-1beb96ab03af",
      "process": "28dec515-93ab-480c-90a4-dcd5534aa553",
      "related_work": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
      "intent": "accepted_result",
      "source_revision": 8,
      "result": {
        "artifact_id": "1a43f1f7-e625-49d9-bfe7-265f95c7c957",
        "version_id": "53c2b87a-826c-4859-8a89-dcf20c26bd5c",
        "sha256": "662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35"
      },
      "basis": [],
      "provenance": "Explicit fictional observation, not owner product acceptance",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T1 fictional adapter"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-probe-admission-20260909-exec",
      "input_sha256": "23c2523f12058aacb20b55922646ded14aff46ac0c8bfcaf8af896e5a70ef7b2"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:55.198887Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/batch/workspace",
    "request_sha256": "57270a75f649e35e9313e75d256ceb3916015a439ecf41cb7cf5b429174b4384"
  },
  "fingerprint": "4567e4fea730ece28309a0b7af0716a293280b72b1b5494574acc84b42f6dd34",
  "before": {
    "id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "revision": 8,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "work",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "revision": 9,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "work",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "b78ff2b3-1ceb-44db-9c0f-07757bdbdcb0",
  "state_revision": 10,
  "recorded_at": "2026-09-09T12:06:55.292634Z",
  "product_version": "0.7.0",
  "request": {
    "version": 4,
    "operation_id": "e31b8af2-0c36-4dc5-88b2-16c40a4cf60f",
    "workspace_id": "692cd65d-66fd-43cd-a077-1beb96ab03af",
    "work_id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "expected_revision": 9,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "M1 T1 fictional rule proposal; authority supplied separately",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "1a43f1f7-e625-49d9-bfe7-265f95c7c957",
        "version_id": "53c2b87a-826c-4859-8a89-dcf20c26bd5c",
        "sha256": "662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 9,
      "result": {
        "artifact_id": "1a43f1f7-e625-49d9-bfe7-265f95c7c957",
        "version_id": "53c2b87a-826c-4859-8a89-dcf20c26bd5c",
        "sha256": "662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35"
      },
      "acceptance_ids": [
        "1188f388-72ae-4a4a-8fd2-8e252ef3e90d",
        "0fe357a4-6f25-47b8-b06f-2bcdb54faac6"
      ],
      "next_work": {
        "work_id": "3a36c1a8-78fb-4bc6-a8f3-5a1059cb43f4",
        "artifact_id": "1951a12e-bf6c-4fcb-b145-645a36a57742",
        "goal": "Inspect the next fictional batch",
        "expected_result": "Both independent marks",
        "acceptance": [
          "Observation and recording marks are both present"
        ],
        "boundaries": [
          "Local fictional workspace only"
        ],
        "budget": "One minimal rule contrast",
        "executor_requirements": [
          "probe.batch/v1"
        ],
        "artifact_title": "Next fictional batch observation",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:55.286857Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/batch/workspace",
    "request_sha256": "6026a33702c7726c475957e9a784586ab46a5feb75f6e89f84b3ba6686885bd2"
  },
  "fingerprint": "845c74ba11031ec45d1dca6dfa591520ddb33a418c5c716ced0437689cbf06a5",
  "before": {
    "id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "revision": 9,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "work",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "revision": 10,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "work",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "completion_id": "e31b8af2-0c36-4dc5-88b2-16c40a4cf60f"
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "3a36c1a8-78fb-4bc6-a8f3-5a1059cb43f4",
    "revision": 10,
    "created_at": "2026-09-09T12:06:55.292634Z",
    "kind": "work",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "goal": "Inspect the next fictional batch",
    "expected_result": "Both independent marks",
    "acceptance": [
      "Observation and recording marks are both present"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "next_artifact": {
    "id": "1951a12e-bf6c-4fcb-b145-645a36a57742",
    "revision": 1,
    "created_at": "2026-09-09T12:06:55.292634Z",
    "kind": "artifact",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "work_id": "3a36c1a8-78fb-4bc6-a8f3-5a1059cb43f4",
    "title": "Next fictional batch observation",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "1a43f1f7-e625-49d9-bfe7-265f95c7c957",
    "revision": 3,
    "created_at": "2026-09-09T12:06:54.889233Z",
    "kind": "artifact",
    "process_id": "28dec515-93ab-480c-90a4-dcd5534aa553",
    "work_id": "d64c9ffb-8789-49cf-8e28-8ef5f19f4916",
    "title": "Fictional observation",
    "status": "registered",
    "active_version": "53c2b87a-826c-4859-8a89-dcf20c26bd5c"
  },
  "result_references": [
    {
      "artifact_id": "1a43f1f7-e625-49d9-bfe7-265f95c7c957",
      "version_id": "53c2b87a-826c-4859-8a89-dcf20c26bd5c",
      "sha256": "662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35"
    },
    {
      "artifact_id": "1a43f1f7-e625-49d9-bfe7-265f95c7c957",
      "version_id": "f9669ff1-7258-4f93-bb8b-8769bb423ead",
      "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
    }
  ]
}
```

