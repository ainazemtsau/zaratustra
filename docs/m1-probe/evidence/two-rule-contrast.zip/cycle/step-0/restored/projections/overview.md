# Zaratustra — generated overview

generated_from_revision: 7
generated_at: 2026-09-09T12:06:55.829036+00:00
workspace_id: 019deb04-9152-486e-afab-e542267b8481

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "7260409e-047b-4286-a2b3-022bf95c9088",
  "revision": 2,
  "created_at": "2026-09-09T12:06:55.481201Z",
  "kind": "artifact",
  "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
  "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
  "title": "Fictional observation",
  "status": "registered",
  "active_version": "e01dfd06-939b-477c-8e70-1da1d946b6f7"
}
```

## artifact

```json
{
  "id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
  "revision": 1,
  "created_at": "2026-09-09T12:06:55.829036Z",
  "kind": "artifact",
  "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
  "work_id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
  "title": "Fictional record observation",
  "status": "declared",
  "active_version": null
}
```

## event

```json
{
  "id": "07291b72-6014-40bb-9caa-35baf6184715",
  "revision": 1,
  "created_at": "2026-09-09T12:06:55.481201Z",
  "kind": "event",
  "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
  "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.7.0",
  "state_revision": 1,
  "affected_ids": [
    "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "7260409e-047b-4286-a2b3-022bf95c9088"
  ]
}
```

## process

```json
{
  "id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
  "revision": 1,
  "created_at": "2026-09-09T12:06:55.481201Z",
  "kind": "process",
  "title": "Fictional probe.cycle/v1:observe"
}
```

## work

```json
{
  "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
  "revision": 7,
  "created_at": "2026-09-09T12:06:55.481201Z",
  "kind": "work",
  "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
  "goal": "Evaluate the selected fictional rule",
  "expected_result": "Exact recorded observation and permitted continuation",
  "acceptance": [
    "Only explicitly selected fictional inputs"
  ],
  "boundaries": [
    "Local fictional workspace only"
  ],
  "budget": "One minimal rule contrast",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.cycle/v1:observe"
  ],
  "completion_id": "7083a011-3640-4ebe-a38c-4de8240ad8f9"
}
```

## work

```json
{
  "id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
  "revision": 7,
  "created_at": "2026-09-09T12:06:55.829036Z",
  "kind": "work",
  "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
  "goal": "Perform the fictional record phase",
  "expected_result": "The record mark",
  "acceptance": [
    "The current record phase has its own mark"
  ],
  "boundaries": [
    "Local fictional workspace only"
  ],
  "budget": "One minimal rule contrast",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.cycle/v1:record"
  ]
}
```

## Registered versions

- Version: e01dfd06-939b-477c-8e70-1da1d946b6f7; Artifact revision: 2
  SHA-256: 1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568; bytes: 38
  File: artifacts/7260409e-047b-4286-a2b3-022bf95c9088/e01dfd06-939b-477c-8e70-1da1d946b6f7.blob

## Mutation provenance

```json
{
  "id": "72073272-e93e-4d23-8826-e3d18a04a906",
  "state_revision": 2,
  "recorded_at": "2026-09-09T12:06:55.498363Z",
  "product_version": "0.7.0",
  "request": {
    "version": 1,
    "operation_id": "10f6af08-63be-44ba-aeec-28c71760e62f",
    "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
    "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:55.495663Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/cycle/workspace",
    "request_sha256": "55297f25b82ea71cae30dc17401afa3c6c7981559ab73b30f1fd4c5f932a2949"
  },
  "fingerprint": "107cce6bb5874e00614e94cb1913ea2e4a35a0d9f1377592fad1836a629244b8",
  "before": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 1,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 2,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "00ec2eda-ec2c-426c-838c-53c70ba866aa",
  "state_revision": 3,
  "recorded_at": "2026-09-09T12:06:55.527249Z",
  "product_version": "0.7.0",
  "request": {
    "version": 1,
    "operation_id": "62ea4ea8-b506-48ed-8b93-b08dbddbea19",
    "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
    "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "probe.cycle/v1:observe"
    ],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:55.523864Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/cycle/workspace",
    "request_sha256": "15c57e13a5e131c15a42d2c20b510e22f83634a5aa3a4ce21fc66abaed99d381"
  },
  "fingerprint": "83065fcb8b36f4b22b7ea6fd7d28f1fdd6efbd49abc0d52bcb67de655e1742b8",
  "before": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 2,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 3,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "ae22dc0b-d61a-495f-a592-ecaec26d88e3",
  "state_revision": 4,
  "recorded_at": "2026-09-09T12:06:55.558178Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "009572c3-76b7-44d7-bb3e-cf92f33b30a8",
    "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
    "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "expected_revision": 3,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "7260409e-047b-4286-a2b3-022bf95c9088",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:55.554709Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/cycle/workspace",
    "request_sha256": "093f77a2d2a618228ea8997065fe6bdf9de908a4d4eb87cfaf18584665444005"
  },
  "fingerprint": "f9630f681031a42d7a659e5051875138db945023456f5db68fae83fe3a1cf438",
  "before": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 3,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "after": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 4,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "9de8b2c1-4023-43d0-af82-32ce615c3108",
  "state_revision": 5,
  "recorded_at": "2026-09-09T12:06:55.588945Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "e01dfd06-939b-477c-8e70-1da1d946b6f7",
    "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
    "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "expected_revision": 4,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "7260409e-047b-4286-a2b3-022bf95c9088",
    "artifact_revision": 1,
    "content_sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568",
    "content_size": 38,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:55.584688Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/cycle/workspace",
    "request_sha256": "e5fa5e0677aeb150e92929dbbfd60b01170b8901f9c9b58b94453aee19f0b19d"
  },
  "fingerprint": "22822c409fd5aa3ffca96eb4e8bd4e7ec5b45e94b4b4efb037b5107999e0b2e6",
  "before": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 4,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "after": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 5,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "7260409e-047b-4286-a2b3-022bf95c9088",
    "revision": 1,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "artifact",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "title": "Fictional observation",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "7260409e-047b-4286-a2b3-022bf95c9088",
    "revision": 2,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "artifact",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "title": "Fictional observation",
    "status": "registered",
    "active_version": "e01dfd06-939b-477c-8e70-1da1d946b6f7"
  },
  "artifact_version": {
    "id": "e01dfd06-939b-477c-8e70-1da1d946b6f7",
    "artifact_id": "7260409e-047b-4286-a2b3-022bf95c9088",
    "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "artifact_revision": 2,
    "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568",
    "size": 38,
    "created_at": "2026-09-09T12:06:55.588945Z",
    "state_revision": 5
  }
}
```

```json
{
  "id": "3ab9bf64-acc6-4246-b448-8ee366df4a20",
  "state_revision": 6,
  "recorded_at": "2026-09-09T12:06:55.631247Z",
  "product_version": "0.7.0",
  "request": {
    "version": 3,
    "operation_id": "3829495c-ffa7-424b-b52a-84e74e872666",
    "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
    "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "expected_revision": 5,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional observation, not owner product acceptance",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "7260409e-047b-4286-a2b3-022bf95c9088",
        "version_id": "e01dfd06-939b-477c-8e70-1da1d946b6f7",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "3829495c-ffa7-424b-b52a-84e74e872666",
      "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
      "process": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
      "related_work": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
      "intent": "accepted_result",
      "source_revision": 5,
      "result": {
        "artifact_id": "7260409e-047b-4286-a2b3-022bf95c9088",
        "version_id": "e01dfd06-939b-477c-8e70-1da1d946b6f7",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      },
      "basis": [],
      "provenance": "Explicit fictional observation, not owner product acceptance",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T1 fictional adapter"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-probe-admission-20260909-exec",
      "input_sha256": "f4afeabfd17e671a68226411578050527d91814e64d6435e07a0cb3cda005b1c"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:55.627148Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/cycle/workspace",
    "request_sha256": "086df3fa38f72f83548a57a371301ca059e922c0804d7f98b6409f3211a76870"
  },
  "fingerprint": "d89065e92287bcc621c0ee17618e60d4833efdf90e7f313f383a6d48c21bbdc8",
  "before": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 5,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "after": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 6,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "c79941c1-51b2-4ce2-85d6-214aa764e4a3",
  "state_revision": 7,
  "recorded_at": "2026-09-09T12:06:55.829036Z",
  "product_version": "0.7.0",
  "request": {
    "version": 4,
    "operation_id": "7083a011-3640-4ebe-a38c-4de8240ad8f9",
    "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
    "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "expected_revision": 6,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "M1 T1 fictional rule proposal; authority supplied separately",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "7260409e-047b-4286-a2b3-022bf95c9088",
        "version_id": "e01dfd06-939b-477c-8e70-1da1d946b6f7",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 6,
      "result": {
        "artifact_id": "7260409e-047b-4286-a2b3-022bf95c9088",
        "version_id": "e01dfd06-939b-477c-8e70-1da1d946b6f7",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      },
      "acceptance_ids": [
        "3829495c-ffa7-424b-b52a-84e74e872666"
      ],
      "next_work": {
        "work_id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
        "artifact_id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
        "goal": "Perform the fictional record phase",
        "expected_result": "The record mark",
        "acceptance": [
          "The current record phase has its own mark"
        ],
        "boundaries": [
          "Local fictional workspace only"
        ],
        "budget": "One minimal rule contrast",
        "executor_requirements": [
          "probe.cycle/v1:record"
        ],
        "artifact_title": "Fictional record observation",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:55.825214Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/cycle/step-0/restored",
    "request_sha256": "6dd0d11b982f315e33c17dd27c72cb16ebcd71aa447753a9a6628304bae4bbe6"
  },
  "fingerprint": "96f6233f62ee7ba2b9219972436dac140df9b15fdcb1c983488d63672d687f12",
  "before": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 6,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "after": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 7,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ],
    "completion_id": "7083a011-3640-4ebe-a38c-4de8240ad8f9"
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "revision": 7,
    "created_at": "2026-09-09T12:06:55.829036Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "next_artifact": {
    "id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
    "revision": 1,
    "created_at": "2026-09-09T12:06:55.829036Z",
    "kind": "artifact",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "work_id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "title": "Fictional record observation",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "7260409e-047b-4286-a2b3-022bf95c9088",
    "revision": 2,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "artifact",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "title": "Fictional observation",
    "status": "registered",
    "active_version": "e01dfd06-939b-477c-8e70-1da1d946b6f7"
  },
  "result_references": [
    {
      "artifact_id": "7260409e-047b-4286-a2b3-022bf95c9088",
      "version_id": "e01dfd06-939b-477c-8e70-1da1d946b6f7",
      "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
    }
  ]
}
```

