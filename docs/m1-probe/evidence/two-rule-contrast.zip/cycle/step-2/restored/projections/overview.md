# Zaratustra — generated overview

generated_from_revision: 14
generated_at: 2026-09-09T12:06:56.429150+00:00
workspace_id: 019deb04-9152-486e-afab-e542267b8481

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "205c0689-c58c-40b6-8c85-3fd75b62b80b",
  "revision": 1,
  "created_at": "2026-09-09T12:06:56.429150Z",
  "kind": "artifact",
  "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
  "work_id": "258d78f5-31ff-42b7-afa5-b757e25c6444",
  "title": "Fictional observe observation",
  "status": "declared",
  "active_version": null
}
```

## artifact

```json
{
  "id": "7260409e-047b-4286-a2b3-022bf95c9088",
  "revision": 2,
  "created_at": "2026-09-09T12:06:55.481201Z",
  "kind": "artifact",
  "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
  "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
  "title": "Fictional observation",
  "status": "registered",
  "active_version": "e01dfd06-939b-477c-8e70-1da1d946b6f7"
}
```

## artifact

```json
{
  "id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
  "revision": 3,
  "created_at": "2026-09-09T12:06:55.722446Z",
  "kind": "artifact",
  "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
  "work_id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
  "title": "Fictional record observation",
  "status": "registered",
  "active_version": "e86d18be-7607-4c12-b490-7bbba6a1cfab"
}
```

## event

```json
{
  "id": "07291b72-6014-40bb-9caa-35baf6184715",
  "revision": 1,
  "created_at": "2026-09-09T12:06:55.481201Z",
  "kind": "event",
  "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
  "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.7.0",
  "state_revision": 1,
  "affected_ids": [
    "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "7260409e-047b-4286-a2b3-022bf95c9088"
  ]
}
```

## process

```json
{
  "id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
  "revision": 1,
  "created_at": "2026-09-09T12:06:55.481201Z",
  "kind": "process",
  "title": "Fictional probe.cycle/v1:observe"
}
```

## work

```json
{
  "id": "258d78f5-31ff-42b7-afa5-b757e25c6444",
  "revision": 14,
  "created_at": "2026-09-09T12:06:56.429150Z",
  "kind": "work",
  "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
  "goal": "Perform the fictional observe phase",
  "expected_result": "The observe mark",
  "acceptance": [
    "The current observe phase has its own mark"
  ],
  "boundaries": [
    "Local fictional workspace only"
  ],
  "budget": "One minimal rule contrast",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.cycle/v1:observe"
  ]
}
```

## work

```json
{
  "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
  "revision": 7,
  "created_at": "2026-09-09T12:06:55.481201Z",
  "kind": "work",
  "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
  "goal": "Evaluate the selected fictional rule",
  "expected_result": "Exact recorded observation and permitted continuation",
  "acceptance": [
    "Only explicitly selected fictional inputs"
  ],
  "boundaries": [
    "Local fictional workspace only"
  ],
  "budget": "One minimal rule contrast",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.cycle/v1:observe"
  ],
  "completion_id": "7083a011-3640-4ebe-a38c-4de8240ad8f9"
}
```

## work

```json
{
  "id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
  "revision": 14,
  "created_at": "2026-09-09T12:06:55.722446Z",
  "kind": "work",
  "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
  "goal": "Perform the fictional record phase",
  "expected_result": "The record mark",
  "acceptance": [
    "The current record phase has its own mark"
  ],
  "boundaries": [
    "Local fictional workspace only"
  ],
  "budget": "One minimal rule contrast",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.cycle/v1:record"
  ],
  "completion_id": "a05b6ba4-43ce-4be4-83ac-448559f689ab"
}
```

## Registered versions

- Version: 19441cd9-c1f4-454c-85af-3e1a4bd29f30; Artifact revision: 2
  SHA-256: 1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568; bytes: 38
  File: artifacts/f1bba092-fe8e-42dc-a3c0-81fed314eed0/19441cd9-c1f4-454c-85af-3e1a4bd29f30.blob

- Version: e01dfd06-939b-477c-8e70-1da1d946b6f7; Artifact revision: 2
  SHA-256: 1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568; bytes: 38
  File: artifacts/7260409e-047b-4286-a2b3-022bf95c9088/e01dfd06-939b-477c-8e70-1da1d946b6f7.blob

- Version: e86d18be-7607-4c12-b490-7bbba6a1cfab; Artifact revision: 3
  SHA-256: a5748ed97ee6d8b0315eed30f85918597e0dded61f5277f290f789872c537741; bytes: 38
  File: artifacts/f1bba092-fe8e-42dc-a3c0-81fed314eed0/e86d18be-7607-4c12-b490-7bbba6a1cfab.blob

## Mutation provenance

```json
{
  "id": "72073272-e93e-4d23-8826-e3d18a04a906",
  "state_revision": 2,
  "recorded_at": "2026-09-09T12:06:55.498363Z",
  "product_version": "0.7.0",
  "request": {
    "version": 1,
    "operation_id": "10f6af08-63be-44ba-aeec-28c71760e62f",
    "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
    "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:55.495663Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/cycle/workspace",
    "request_sha256": "55297f25b82ea71cae30dc17401afa3c6c7981559ab73b30f1fd4c5f932a2949"
  },
  "fingerprint": "107cce6bb5874e00614e94cb1913ea2e4a35a0d9f1377592fad1836a629244b8",
  "before": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 1,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 2,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "00ec2eda-ec2c-426c-838c-53c70ba866aa",
  "state_revision": 3,
  "recorded_at": "2026-09-09T12:06:55.527249Z",
  "product_version": "0.7.0",
  "request": {
    "version": 1,
    "operation_id": "62ea4ea8-b506-48ed-8b93-b08dbddbea19",
    "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
    "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "probe.cycle/v1:observe"
    ],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:55.523864Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/cycle/workspace",
    "request_sha256": "15c57e13a5e131c15a42d2c20b510e22f83634a5aa3a4ce21fc66abaed99d381"
  },
  "fingerprint": "83065fcb8b36f4b22b7ea6fd7d28f1fdd6efbd49abc0d52bcb67de655e1742b8",
  "before": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 2,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 3,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "ae22dc0b-d61a-495f-a592-ecaec26d88e3",
  "state_revision": 4,
  "recorded_at": "2026-09-09T12:06:55.558178Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "009572c3-76b7-44d7-bb3e-cf92f33b30a8",
    "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
    "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "expected_revision": 3,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "7260409e-047b-4286-a2b3-022bf95c9088",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:55.554709Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/cycle/workspace",
    "request_sha256": "093f77a2d2a618228ea8997065fe6bdf9de908a4d4eb87cfaf18584665444005"
  },
  "fingerprint": "f9630f681031a42d7a659e5051875138db945023456f5db68fae83fe3a1cf438",
  "before": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 3,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "after": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 4,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "9de8b2c1-4023-43d0-af82-32ce615c3108",
  "state_revision": 5,
  "recorded_at": "2026-09-09T12:06:55.588945Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "e01dfd06-939b-477c-8e70-1da1d946b6f7",
    "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
    "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "expected_revision": 4,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "7260409e-047b-4286-a2b3-022bf95c9088",
    "artifact_revision": 1,
    "content_sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568",
    "content_size": 38,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:55.584688Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/cycle/workspace",
    "request_sha256": "e5fa5e0677aeb150e92929dbbfd60b01170b8901f9c9b58b94453aee19f0b19d"
  },
  "fingerprint": "22822c409fd5aa3ffca96eb4e8bd4e7ec5b45e94b4b4efb037b5107999e0b2e6",
  "before": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 4,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "after": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 5,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "7260409e-047b-4286-a2b3-022bf95c9088",
    "revision": 1,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "artifact",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "title": "Fictional observation",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "7260409e-047b-4286-a2b3-022bf95c9088",
    "revision": 2,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "artifact",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "title": "Fictional observation",
    "status": "registered",
    "active_version": "e01dfd06-939b-477c-8e70-1da1d946b6f7"
  },
  "artifact_version": {
    "id": "e01dfd06-939b-477c-8e70-1da1d946b6f7",
    "artifact_id": "7260409e-047b-4286-a2b3-022bf95c9088",
    "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "artifact_revision": 2,
    "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568",
    "size": 38,
    "created_at": "2026-09-09T12:06:55.588945Z",
    "state_revision": 5
  }
}
```

```json
{
  "id": "3ab9bf64-acc6-4246-b448-8ee366df4a20",
  "state_revision": 6,
  "recorded_at": "2026-09-09T12:06:55.631247Z",
  "product_version": "0.7.0",
  "request": {
    "version": 3,
    "operation_id": "3829495c-ffa7-424b-b52a-84e74e872666",
    "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
    "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "expected_revision": 5,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional observation, not owner product acceptance",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "7260409e-047b-4286-a2b3-022bf95c9088",
        "version_id": "e01dfd06-939b-477c-8e70-1da1d946b6f7",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "3829495c-ffa7-424b-b52a-84e74e872666",
      "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
      "process": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
      "related_work": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
      "intent": "accepted_result",
      "source_revision": 5,
      "result": {
        "artifact_id": "7260409e-047b-4286-a2b3-022bf95c9088",
        "version_id": "e01dfd06-939b-477c-8e70-1da1d946b6f7",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      },
      "basis": [],
      "provenance": "Explicit fictional observation, not owner product acceptance",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T1 fictional adapter"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-probe-admission-20260909-exec",
      "input_sha256": "f4afeabfd17e671a68226411578050527d91814e64d6435e07a0cb3cda005b1c"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:55.627148Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/cycle/workspace",
    "request_sha256": "086df3fa38f72f83548a57a371301ca059e922c0804d7f98b6409f3211a76870"
  },
  "fingerprint": "d89065e92287bcc621c0ee17618e60d4833efdf90e7f313f383a6d48c21bbdc8",
  "before": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 5,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "after": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 6,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "8a2caba5-110d-49c5-a67b-60896e4ae7a9",
  "state_revision": 7,
  "recorded_at": "2026-09-09T12:06:55.722446Z",
  "product_version": "0.7.0",
  "request": {
    "version": 4,
    "operation_id": "7083a011-3640-4ebe-a38c-4de8240ad8f9",
    "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
    "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "expected_revision": 6,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "M1 T1 fictional rule proposal; authority supplied separately",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "7260409e-047b-4286-a2b3-022bf95c9088",
        "version_id": "e01dfd06-939b-477c-8e70-1da1d946b6f7",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 6,
      "result": {
        "artifact_id": "7260409e-047b-4286-a2b3-022bf95c9088",
        "version_id": "e01dfd06-939b-477c-8e70-1da1d946b6f7",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      },
      "acceptance_ids": [
        "3829495c-ffa7-424b-b52a-84e74e872666"
      ],
      "next_work": {
        "work_id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
        "artifact_id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
        "goal": "Perform the fictional record phase",
        "expected_result": "The record mark",
        "acceptance": [
          "The current record phase has its own mark"
        ],
        "boundaries": [
          "Local fictional workspace only"
        ],
        "budget": "One minimal rule contrast",
        "executor_requirements": [
          "probe.cycle/v1:record"
        ],
        "artifact_title": "Fictional record observation",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:55.717054Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/cycle/workspace",
    "request_sha256": "501f2ff63f863bdf8e6a7a4b7372a7e580c116074fc4bf92ae2d4b068d6f9424"
  },
  "fingerprint": "96f6233f62ee7ba2b9219972436dac140df9b15fdcb1c983488d63672d687f12",
  "before": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 6,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "after": {
    "id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "revision": 7,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ],
    "completion_id": "7083a011-3640-4ebe-a38c-4de8240ad8f9"
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "revision": 7,
    "created_at": "2026-09-09T12:06:55.722446Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "next_artifact": {
    "id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
    "revision": 1,
    "created_at": "2026-09-09T12:06:55.722446Z",
    "kind": "artifact",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "work_id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "title": "Fictional record observation",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "7260409e-047b-4286-a2b3-022bf95c9088",
    "revision": 2,
    "created_at": "2026-09-09T12:06:55.481201Z",
    "kind": "artifact",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "work_id": "8f04941d-7cfb-49f2-b73a-6daaa24f3179",
    "title": "Fictional observation",
    "status": "registered",
    "active_version": "e01dfd06-939b-477c-8e70-1da1d946b6f7"
  },
  "result_references": [
    {
      "artifact_id": "7260409e-047b-4286-a2b3-022bf95c9088",
      "version_id": "e01dfd06-939b-477c-8e70-1da1d946b6f7",
      "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
    }
  ]
}
```

```json
{
  "id": "e9916e59-8942-4f41-9292-5fd908be34d3",
  "state_revision": 8,
  "recorded_at": "2026-09-09T12:06:55.876335Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "dbd18256-5475-4584-8405-f54287bd86ee",
    "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
    "work_id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "expected_revision": 7,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:55.871678Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/cycle/workspace",
    "request_sha256": "eaadc5310b705aef8e041ef9eb97020e0d04cecc7c12d471176e4a6d48bd51af"
  },
  "fingerprint": "5de508dcfac4e6a691d675766548b45ae1645ed2ec52b563124e8bdcc3096acf",
  "before": {
    "id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "revision": 7,
    "created_at": "2026-09-09T12:06:55.722446Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "after": {
    "id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "revision": 8,
    "created_at": "2026-09-09T12:06:55.722446Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "4f254fae-d98f-4279-9b3e-0853df2aeb26",
  "state_revision": 9,
  "recorded_at": "2026-09-09T12:06:55.912517Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "19441cd9-c1f4-454c-85af-3e1a4bd29f30",
    "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
    "work_id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "expected_revision": 8,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
    "artifact_revision": 1,
    "content_sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568",
    "content_size": 38,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:55.907616Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/cycle/workspace",
    "request_sha256": "4df44ea4e87f7c074008044552d9ef30b1a01aac4c80331e99fce3b6b15d2378"
  },
  "fingerprint": "0818df1f4dd893159453c410e881616b3c8c74eb6761fef45674a02e55b254d5",
  "before": {
    "id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "revision": 8,
    "created_at": "2026-09-09T12:06:55.722446Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "after": {
    "id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "revision": 9,
    "created_at": "2026-09-09T12:06:55.722446Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
    "revision": 1,
    "created_at": "2026-09-09T12:06:55.722446Z",
    "kind": "artifact",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "work_id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "title": "Fictional record observation",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
    "revision": 2,
    "created_at": "2026-09-09T12:06:55.722446Z",
    "kind": "artifact",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "work_id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "title": "Fictional record observation",
    "status": "registered",
    "active_version": "19441cd9-c1f4-454c-85af-3e1a4bd29f30"
  },
  "artifact_version": {
    "id": "19441cd9-c1f4-454c-85af-3e1a4bd29f30",
    "artifact_id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
    "work_id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "artifact_revision": 2,
    "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568",
    "size": 38,
    "created_at": "2026-09-09T12:06:55.912517Z",
    "state_revision": 9
  }
}
```

```json
{
  "id": "27071559-b618-4959-8d6b-ba73690c4b5b",
  "state_revision": 10,
  "recorded_at": "2026-09-09T12:06:55.959686Z",
  "product_version": "0.7.0",
  "request": {
    "version": 3,
    "operation_id": "774a84d0-7ef7-4b19-a0ee-ed5359e9fd14",
    "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
    "work_id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "expected_revision": 9,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional observation, not owner product acceptance",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
        "version_id": "19441cd9-c1f4-454c-85af-3e1a4bd29f30",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "774a84d0-7ef7-4b19-a0ee-ed5359e9fd14",
      "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
      "process": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
      "related_work": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
      "intent": "accepted_result",
      "source_revision": 9,
      "result": {
        "artifact_id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
        "version_id": "19441cd9-c1f4-454c-85af-3e1a4bd29f30",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      },
      "basis": [],
      "provenance": "Explicit fictional observation, not owner product acceptance",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T1 fictional adapter"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-probe-admission-20260909-exec",
      "input_sha256": "cf3881019b5bd1e8a462f6ac9c58618da6c20e41d8a2a8e9e8ef8d9b37478e79"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:55.954434Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/cycle/workspace",
    "request_sha256": "17f9e436b7fe5eff7a3253212b29591f5ee5eb9a58d6777e39a304638739f103"
  },
  "fingerprint": "97243ce37ed0ac1c035226d01ecce29a273ddb18a2d6b6170385cdaed0205de6",
  "before": {
    "id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "revision": 9,
    "created_at": "2026-09-09T12:06:55.722446Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "after": {
    "id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "revision": 10,
    "created_at": "2026-09-09T12:06:55.722446Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "57d3e38d-9f4f-42f6-9d34-2c9deaea72d3",
  "state_revision": 11,
  "recorded_at": "2026-09-09T12:06:56.083123Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "d0958510-20af-430a-b27e-1e3242d289f0",
    "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
    "work_id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "expected_revision": 10,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
    "artifact_revision": 2,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:56.078171Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/cycle/workspace",
    "request_sha256": "fb4cc85e10c603b7f6baf26d1b3e4676eafe9868fbf9543aa9a494749162a7ff"
  },
  "fingerprint": "064ffd56a725189cb5a7646863c683bea0e957846e3a3e9d7f8abfd1d04dde0a",
  "before": {
    "id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "revision": 10,
    "created_at": "2026-09-09T12:06:55.722446Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "after": {
    "id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "revision": 11,
    "created_at": "2026-09-09T12:06:55.722446Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "2b0e9a39-b973-4dbe-a01a-298d617633e7",
  "state_revision": 12,
  "recorded_at": "2026-09-09T12:06:56.121744Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "e86d18be-7607-4c12-b490-7bbba6a1cfab",
    "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
    "work_id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "expected_revision": 11,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
    "artifact_revision": 2,
    "content_sha256": "a5748ed97ee6d8b0315eed30f85918597e0dded61f5277f290f789872c537741",
    "content_size": 38,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:56.116146Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/cycle/workspace",
    "request_sha256": "20b9dbb08dd92af3e344d8655e2aaa86a3c174698c864e6c7ef3b23077200d25"
  },
  "fingerprint": "4e2247750f8ebfcc78ba30685d848c89056f3834b10a5dd3cdab134b169ce522",
  "before": {
    "id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "revision": 11,
    "created_at": "2026-09-09T12:06:55.722446Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "after": {
    "id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "revision": 12,
    "created_at": "2026-09-09T12:06:55.722446Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
    "revision": 2,
    "created_at": "2026-09-09T12:06:55.722446Z",
    "kind": "artifact",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "work_id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "title": "Fictional record observation",
    "status": "registered",
    "active_version": "19441cd9-c1f4-454c-85af-3e1a4bd29f30"
  },
  "artifact_after": {
    "id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
    "revision": 3,
    "created_at": "2026-09-09T12:06:55.722446Z",
    "kind": "artifact",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "work_id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "title": "Fictional record observation",
    "status": "registered",
    "active_version": "e86d18be-7607-4c12-b490-7bbba6a1cfab"
  },
  "artifact_version": {
    "id": "e86d18be-7607-4c12-b490-7bbba6a1cfab",
    "artifact_id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
    "work_id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "artifact_revision": 3,
    "sha256": "a5748ed97ee6d8b0315eed30f85918597e0dded61f5277f290f789872c537741",
    "size": 38,
    "created_at": "2026-09-09T12:06:56.121744Z",
    "state_revision": 12
  }
}
```

```json
{
  "id": "5486021c-2753-493b-83d8-fdda60424a9e",
  "state_revision": 13,
  "recorded_at": "2026-09-09T12:06:56.173618Z",
  "product_version": "0.7.0",
  "request": {
    "version": 3,
    "operation_id": "96f78ab1-ab21-4f46-b817-e2a7a179b798",
    "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
    "work_id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "expected_revision": 12,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional observation, not owner product acceptance",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
        "version_id": "e86d18be-7607-4c12-b490-7bbba6a1cfab",
        "sha256": "a5748ed97ee6d8b0315eed30f85918597e0dded61f5277f290f789872c537741"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "96f78ab1-ab21-4f46-b817-e2a7a179b798",
      "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
      "process": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
      "related_work": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
      "intent": "accepted_result",
      "source_revision": 12,
      "result": {
        "artifact_id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
        "version_id": "e86d18be-7607-4c12-b490-7bbba6a1cfab",
        "sha256": "a5748ed97ee6d8b0315eed30f85918597e0dded61f5277f290f789872c537741"
      },
      "basis": [],
      "provenance": "Explicit fictional observation, not owner product acceptance",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T1 fictional adapter"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-probe-admission-20260909-exec",
      "input_sha256": "781d018e22129e15e17f66fd61edba703949ea229fbef26254a16fd3e8c4514f"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:56.168626Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/cycle/workspace",
    "request_sha256": "2a11cea9b8f47301d7794588a7ef533af78b3b780ebdbe4a2ea4ca5ac8ffb445"
  },
  "fingerprint": "afdf5aca44e12b8d1650f46ebe179eec71e4c34851d3198d903b4fb41014229f",
  "before": {
    "id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "revision": 12,
    "created_at": "2026-09-09T12:06:55.722446Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "after": {
    "id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "revision": 13,
    "created_at": "2026-09-09T12:06:55.722446Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "e00e9329-6e38-4c3a-a198-63d2cde9ebc5",
  "state_revision": 14,
  "recorded_at": "2026-09-09T12:06:56.429150Z",
  "product_version": "0.7.0",
  "request": {
    "version": 4,
    "operation_id": "a05b6ba4-43ce-4be4-83ac-448559f689ab",
    "workspace_id": "019deb04-9152-486e-afab-e542267b8481",
    "work_id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "expected_revision": 13,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "M1 T1 fictional rule proposal; authority supplied separately",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
        "version_id": "e86d18be-7607-4c12-b490-7bbba6a1cfab",
        "sha256": "a5748ed97ee6d8b0315eed30f85918597e0dded61f5277f290f789872c537741"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 13,
      "result": {
        "artifact_id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
        "version_id": "e86d18be-7607-4c12-b490-7bbba6a1cfab",
        "sha256": "a5748ed97ee6d8b0315eed30f85918597e0dded61f5277f290f789872c537741"
      },
      "acceptance_ids": [
        "774a84d0-7ef7-4b19-a0ee-ed5359e9fd14",
        "96f78ab1-ab21-4f46-b817-e2a7a179b798"
      ],
      "next_work": {
        "work_id": "258d78f5-31ff-42b7-afa5-b757e25c6444",
        "artifact_id": "205c0689-c58c-40b6-8c85-3fd75b62b80b",
        "goal": "Perform the fictional observe phase",
        "expected_result": "The observe mark",
        "acceptance": [
          "The current observe phase has its own mark"
        ],
        "boundaries": [
          "Local fictional workspace only"
        ],
        "budget": "One minimal rule contrast",
        "executor_requirements": [
          "probe.cycle/v1:observe"
        ],
        "artifact_title": "Fictional observe observation",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T12:06:56.422866Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-probe-20260909/_scratch/two-rule-contrast/cycle/step-2/restored",
    "request_sha256": "69454a758054827a9557d9c324599c345f5213f6d6f689559034c083856d3f0d"
  },
  "fingerprint": "b1d6b647235d3158f3d41e222dcf413004163136fce8f96bf8f376ad4c70f326",
  "before": {
    "id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "revision": 13,
    "created_at": "2026-09-09T12:06:55.722446Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "after": {
    "id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "revision": 14,
    "created_at": "2026-09-09T12:06:55.722446Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ],
    "completion_id": "a05b6ba4-43ce-4be4-83ac-448559f689ab"
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "258d78f5-31ff-42b7-afa5-b757e25c6444",
    "revision": 14,
    "created_at": "2026-09-09T12:06:56.429150Z",
    "kind": "work",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "goal": "Perform the fictional observe phase",
    "expected_result": "The observe mark",
    "acceptance": [
      "The current observe phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "next_artifact": {
    "id": "205c0689-c58c-40b6-8c85-3fd75b62b80b",
    "revision": 1,
    "created_at": "2026-09-09T12:06:56.429150Z",
    "kind": "artifact",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "work_id": "258d78f5-31ff-42b7-afa5-b757e25c6444",
    "title": "Fictional observe observation",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
    "revision": 3,
    "created_at": "2026-09-09T12:06:55.722446Z",
    "kind": "artifact",
    "process_id": "1944132f-c2e2-439b-a81b-c0ef09b8d028",
    "work_id": "8fce0bf7-e314-4ad6-b74e-c8a8d93b69ca",
    "title": "Fictional record observation",
    "status": "registered",
    "active_version": "e86d18be-7607-4c12-b490-7bbba6a1cfab"
  },
  "result_references": [
    {
      "artifact_id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
      "version_id": "e86d18be-7607-4c12-b490-7bbba6a1cfab",
      "sha256": "a5748ed97ee6d8b0315eed30f85918597e0dded61f5277f290f789872c537741"
    },
    {
      "artifact_id": "7260409e-047b-4286-a2b3-022bf95c9088",
      "version_id": "e01dfd06-939b-477c-8e70-1da1d946b6f7",
      "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
    },
    {
      "artifact_id": "f1bba092-fe8e-42dc-a3c0-81fed314eed0",
      "version_id": "19441cd9-c1f4-454c-85af-3e1a4bd29f30",
      "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
    }
  ]
}
```

