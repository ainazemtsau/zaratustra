# Zaratustra — generated overview

generated_from_revision: 8
generated_at: 2026-09-09T13:55:14.492327+00:00
workspace_id: d736d3b9-0933-41e0-bc8b-f8e5875e7e5a

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "378a210b-b6a2-43e2-94bc-31bda092517b",
  "revision": 1,
  "created_at": "2026-09-09T13:55:14.492327Z",
  "kind": "artifact",
  "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
  "work_id": "bc3791c8-b6ec-4d30-8faf-19e9efdc558d",
  "title": "Next fictional batch observation",
  "status": "declared",
  "active_version": null
}
```

## artifact

```json
{
  "id": "99eff619-dde9-49fb-aa0f-296d8af806e2",
  "revision": 2,
  "created_at": "2026-09-09T13:55:14.033860Z",
  "kind": "artifact",
  "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
  "work_id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
  "title": "Fictional batch observation",
  "status": "registered",
  "active_version": "98774d68-837a-4dea-8d5b-4eaa0941a6c5"
}
```

## event

```json
{
  "id": "739c38e1-fc66-4f67-86f6-31210e3a76a5",
  "revision": 1,
  "created_at": "2026-09-09T13:55:14.033860Z",
  "kind": "event",
  "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
  "work_id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.8.0",
  "state_revision": 1,
  "affected_ids": [
    "98a35214-a003-4f7a-a286-6d0091ba9584",
    "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "99eff619-dde9-49fb-aa0f-296d8af806e2"
  ]
}
```

## process

```json
{
  "id": "98a35214-a003-4f7a-a286-6d0091ba9584",
  "revision": 4,
  "created_at": "2026-09-09T13:55:14.033860Z",
  "kind": "process",
  "title": "Fictional pack lifecycle",
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "1.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
  "revision": 8,
  "created_at": "2026-09-09T13:55:14.033860Z",
  "kind": "work",
  "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
  "goal": "Continue a fictional batch with an exact retained pack version",
  "expected_result": "Recorded observation and continuation",
  "acceptance": [
    "Both fictional marks"
  ],
  "boundaries": [
    "Local fictional data only"
  ],
  "budget": "One T2 lifecycle example",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ],
  "completion_id": "7d7fef3a-34a9-47f2-98c7-3275acd1742a",
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "1.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "bc3791c8-b6ec-4d30-8faf-19e9efdc558d",
  "revision": 8,
  "created_at": "2026-09-09T13:55:14.492327Z",
  "kind": "work",
  "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
  "goal": "Inspect the next fictional batch",
  "expected_result": "Both independent marks",
  "acceptance": [
    "Observation and recording marks are both present"
  ],
  "boundaries": [
    "Local fictional data only"
  ],
  "budget": "One T2 lifecycle example",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ],
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "1.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 98774d68-837a-4dea-8d5b-4eaa0941a6c5; Artifact revision: 2
  SHA-256: 9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38; bytes: 36
  File: artifacts/99eff619-dde9-49fb-aa0f-296d8af806e2/98774d68-837a-4dea-8d5b-4eaa0941a6c5.blob

## Mutation provenance

```json
{
  "id": "b13833df-8b80-4a74-a2e8-5ca0a13a6ef2",
  "state_revision": 2,
  "recorded_at": "2026-09-09T13:55:14.063944Z",
  "product_version": "0.8.0",
  "request": {
    "version": 1,
    "operation_id": "1eaa67e9-59fb-4926-9dfa-a7837b2c7e71",
    "workspace_id": "d736d3b9-0933-41e0-bc8b-f8e5875e7e5a",
    "work_id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T2 fixture authorized by RUN c-solmax-zaratustra-m1-packs-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T13:55:14.061494Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-lifecycle-01/workspace",
    "request_sha256": "ca023a3451afbaf7b0b20031e7872174eca3da82fddbbd01245ee50ab7afe045"
  },
  "fingerprint": "0cb9e8fc1f9155c8a71fbc3cf5a115043db628ab038a0c814e0aa9840b03ec21",
  "before": {
    "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "revision": 1,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "work",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "revision": 2,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "work",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "16fdd30a-2bd9-48e7-bea5-97271195e5cf",
  "state_revision": 3,
  "recorded_at": "2026-09-09T13:55:14.089097Z",
  "product_version": "0.8.0",
  "request": {
    "version": 1,
    "operation_id": "7ce60cb8-67c3-404e-8820-7ae0ce5adbc6",
    "workspace_id": "d736d3b9-0933-41e0-bc8b-f8e5875e7e5a",
    "work_id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "probe.batch/v1"
    ],
    "artifact_references": [],
    "provenance": "Fictional T2 fixture authorized by RUN c-solmax-zaratustra-m1-packs-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T13:55:14.086932Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-lifecycle-01/workspace",
    "request_sha256": "4c8b4a1381eedfdab554302f80467c5ad59e1db58c207c1999cf0e3d1de0265b"
  },
  "fingerprint": "bf9f7715ddfa3589703d4119e0374f5cea476751231ecb4e41df3599bee28785",
  "before": {
    "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "revision": 2,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "work",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "revision": 3,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "work",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "83a3e03d-db53-454b-9660-873ec505c271",
  "state_revision": 4,
  "recorded_at": "2026-09-09T13:55:14.156020Z",
  "product_version": "0.8.0",
  "request": {
    "version": 5,
    "operation_id": "9a4deee6-2557-49bf-9fb5-2dd72036ddbc",
    "workspace_id": "d736d3b9-0933-41e0-bc8b-f8e5875e7e5a",
    "work_id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional Process/Work binding under RUN c-solmax-zaratustra-m1-packs-20260909-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T13:55:14.153623Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-lifecycle-01/workspace",
    "request_sha256": "77e84dc781ea7f6714556d6549c9940e726a7d8f49246999286a42bc1797bbd3"
  },
  "fingerprint": "0d66c81dfa7105b0e820688aa2db5fe2793e7a7ee583892618fa89c41ee9c65a",
  "before": {
    "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "revision": 3,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "work",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "revision": 4,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "work",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "revision": 1,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "process",
    "title": "Fictional pack lifecycle"
  },
  "process_after": {
    "id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "revision": 4,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "process",
    "title": "Fictional pack lifecycle",
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "4029876d-87a0-49cd-b3d9-6ef85d154aea",
  "state_revision": 5,
  "recorded_at": "2026-09-09T13:55:14.191072Z",
  "product_version": "0.8.0",
  "request": {
    "version": 2,
    "operation_id": "cbea8da1-0062-4437-a015-daf85f984b05",
    "workspace_id": "d736d3b9-0933-41e0-bc8b-f8e5875e7e5a",
    "work_id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T2 fixture authorized by RUN c-solmax-zaratustra-m1-packs-20260909-exec",
    "artifact_id": "99eff619-dde9-49fb-aa0f-296d8af806e2",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T13:55:14.188459Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-lifecycle-01/workspace",
    "request_sha256": "d6287cac59c352df7d7957354c9a3e44528857abe800033917a5f722d18cdb5f"
  },
  "fingerprint": "19aa0cdfe7c1a6c86b51d2554785f8f0c487d379ea970237a2b4b4743543c3da",
  "before": {
    "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "revision": 4,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "work",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "revision": 5,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "work",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "2de801cd-a881-48eb-a177-baf8ea9f7faf",
  "state_revision": 6,
  "recorded_at": "2026-09-09T13:55:14.220138Z",
  "product_version": "0.8.0",
  "request": {
    "version": 2,
    "operation_id": "98774d68-837a-4dea-8d5b-4eaa0941a6c5",
    "workspace_id": "d736d3b9-0933-41e0-bc8b-f8e5875e7e5a",
    "work_id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T2 fixture authorized by RUN c-solmax-zaratustra-m1-packs-20260909-exec",
    "artifact_id": "99eff619-dde9-49fb-aa0f-296d8af806e2",
    "artifact_revision": 1,
    "content_sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38",
    "content_size": 36,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T13:55:14.216540Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-lifecycle-01/workspace",
    "request_sha256": "da44386c38e0fb1daa5669c02265522d79d36a8f0e834646a89762080a49b098"
  },
  "fingerprint": "df7dd291a9afe2cd0b638beb317d724674cd209a41d8faeed8a936ae5867086c",
  "before": {
    "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "revision": 5,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "work",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "revision": 6,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "work",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "99eff619-dde9-49fb-aa0f-296d8af806e2",
    "revision": 1,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "artifact",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "work_id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "title": "Fictional batch observation",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "99eff619-dde9-49fb-aa0f-296d8af806e2",
    "revision": 2,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "artifact",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "work_id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "title": "Fictional batch observation",
    "status": "registered",
    "active_version": "98774d68-837a-4dea-8d5b-4eaa0941a6c5"
  },
  "artifact_version": {
    "id": "98774d68-837a-4dea-8d5b-4eaa0941a6c5",
    "artifact_id": "99eff619-dde9-49fb-aa0f-296d8af806e2",
    "work_id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "artifact_revision": 2,
    "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38",
    "size": 36,
    "created_at": "2026-09-09T13:55:14.220138Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "c790ae3a-e57c-41fb-9e27-47c5b0238ef4",
  "state_revision": 7,
  "recorded_at": "2026-09-09T13:55:14.258687Z",
  "product_version": "0.8.0",
  "request": {
    "version": 3,
    "operation_id": "f639ef9a-6cd2-4e51-b30a-545feded9997",
    "workspace_id": "d736d3b9-0933-41e0-bc8b-f8e5875e7e5a",
    "work_id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T2 observation; no owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "99eff619-dde9-49fb-aa0f-296d8af806e2",
        "version_id": "98774d68-837a-4dea-8d5b-4eaa0941a6c5",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "f639ef9a-6cd2-4e51-b30a-545feded9997",
      "workspace_id": "d736d3b9-0933-41e0-bc8b-f8e5875e7e5a",
      "process": "98a35214-a003-4f7a-a286-6d0091ba9584",
      "related_work": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "99eff619-dde9-49fb-aa0f-296d8af806e2",
        "version_id": "98774d68-837a-4dea-8d5b-4eaa0941a6c5",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      },
      "basis": [],
      "provenance": "Fictional T2 observation; no owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T2 fictional adapter"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-packs-20260909-exec",
      "input_sha256": "1b8603100f3b0ae7c4f27fb1950970fc6076827becc50289553ae6b7834b944f"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T13:55:14.255073Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-lifecycle-01/workspace",
    "request_sha256": "735809feadd81ed2ebd3edf293586303aefb47366d240d5b9f54ddef07d1ed33"
  },
  "fingerprint": "bb66994f5d2b7889c56328ff13d5dbbe1c9ae84f2a6758de9da6342fb4067ddb",
  "before": {
    "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "revision": 6,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "work",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "revision": 7,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "work",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "6d3ef680-3bab-4be3-b33d-636a2c5d6875",
  "state_revision": 8,
  "recorded_at": "2026-09-09T13:55:14.492327Z",
  "product_version": "0.8.0",
  "request": {
    "version": 4,
    "operation_id": "7d7fef3a-34a9-47f2-98c7-3275acd1742a",
    "workspace_id": "d736d3b9-0933-41e0-bc8b-f8e5875e7e5a",
    "work_id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "expected_revision": 7,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.batch\",\"pack_version\":\"1.0.0\",\"process_type\":\"fictional.batch-check\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "99eff619-dde9-49fb-aa0f-296d8af806e2",
        "version_id": "98774d68-837a-4dea-8d5b-4eaa0941a6c5",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 7,
      "result": {
        "artifact_id": "99eff619-dde9-49fb-aa0f-296d8af806e2",
        "version_id": "98774d68-837a-4dea-8d5b-4eaa0941a6c5",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      },
      "acceptance_ids": [
        "f639ef9a-6cd2-4e51-b30a-545feded9997"
      ],
      "next_work": {
        "work_id": "bc3791c8-b6ec-4d30-8faf-19e9efdc558d",
        "artifact_id": "378a210b-b6a2-43e2-94bc-31bda092517b",
        "goal": "Inspect the next fictional batch",
        "expected_result": "Both independent marks",
        "acceptance": [
          "Observation and recording marks are both present"
        ],
        "boundaries": [
          "Local fictional data only"
        ],
        "budget": "One T2 lifecycle example",
        "executor_requirements": [
          "probe.batch/v1"
        ],
        "artifact_title": "Next fictional batch observation",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T13:55:14.489139Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-lifecycle-01/restored-result",
    "request_sha256": "fbdd869ec8fe8903fd190660a57332fc19bb5809b0caf092d7f1c01ba6c50c61"
  },
  "fingerprint": "4246e6ae1527b79b66cb6b53c908332e48114675f32dfac4175e313889251109",
  "before": {
    "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "revision": 7,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "work",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "revision": 8,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "work",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "completion_id": "7d7fef3a-34a9-47f2-98c7-3275acd1742a",
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "bc3791c8-b6ec-4d30-8faf-19e9efdc558d",
    "revision": 8,
    "created_at": "2026-09-09T13:55:14.492327Z",
    "kind": "work",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "goal": "Inspect the next fictional batch",
    "expected_result": "Both independent marks",
    "acceptance": [
      "Observation and recording marks are both present"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "378a210b-b6a2-43e2-94bc-31bda092517b",
    "revision": 1,
    "created_at": "2026-09-09T13:55:14.492327Z",
    "kind": "artifact",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "work_id": "bc3791c8-b6ec-4d30-8faf-19e9efdc558d",
    "title": "Next fictional batch observation",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "99eff619-dde9-49fb-aa0f-296d8af806e2",
    "revision": 2,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "artifact",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "work_id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "title": "Fictional batch observation",
    "status": "registered",
    "active_version": "98774d68-837a-4dea-8d5b-4eaa0941a6c5"
  },
  "result_references": [
    {
      "artifact_id": "99eff619-dde9-49fb-aa0f-296d8af806e2",
      "version_id": "98774d68-837a-4dea-8d5b-4eaa0941a6c5",
      "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
    }
  ]
}
```

