# Zaratustra — generated overview

generated_from_revision: 8
generated_at: 2026-09-09T13:55:14.821516+00:00
workspace_id: 3d8461ad-93cb-4401-ace4-7b3cdccee21d

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "0be9f950-92ab-4466-9a13-244392e875c9",
  "revision": 1,
  "created_at": "2026-09-09T13:55:14.821516Z",
  "kind": "artifact",
  "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
  "work_id": "ce3f3b0a-4624-46f0-af66-fff3f0b32a6f",
  "title": "Next fictional batch observation",
  "status": "declared",
  "active_version": null
}
```

## artifact

```json
{
  "id": "fa002982-5c45-471f-9e99-1d2e4dbf78eb",
  "revision": 2,
  "created_at": "2026-09-09T13:55:14.590809Z",
  "kind": "artifact",
  "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
  "work_id": "974c00bb-515b-471e-9dce-84c143c91317",
  "title": "Fictional batch observation",
  "status": "registered",
  "active_version": "6a0e2820-df7c-4875-bbb8-6f01d5b45db9"
}
```

## event

```json
{
  "id": "c6493cd6-2d70-4af2-a7cd-c64c21be8e36",
  "revision": 1,
  "created_at": "2026-09-09T13:55:14.590809Z",
  "kind": "event",
  "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
  "work_id": "974c00bb-515b-471e-9dce-84c143c91317",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.8.0",
  "state_revision": 1,
  "affected_ids": [
    "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "974c00bb-515b-471e-9dce-84c143c91317",
    "fa002982-5c45-471f-9e99-1d2e4dbf78eb"
  ]
}
```

## process

```json
{
  "id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
  "revision": 4,
  "created_at": "2026-09-09T13:55:14.590809Z",
  "kind": "process",
  "title": "Fictional pack lifecycle",
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "2.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "974c00bb-515b-471e-9dce-84c143c91317",
  "revision": 8,
  "created_at": "2026-09-09T13:55:14.590809Z",
  "kind": "work",
  "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
  "goal": "Continue a fictional batch with an exact retained pack version",
  "expected_result": "Recorded observation and continuation",
  "acceptance": [
    "Both fictional marks"
  ],
  "boundaries": [
    "Local fictional data only"
  ],
  "budget": "One T2 lifecycle example",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ],
  "completion_id": "ad9ce2b7-c26d-4a69-bc17-67ec5da64ad7",
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "2.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "ce3f3b0a-4624-46f0-af66-fff3f0b32a6f",
  "revision": 8,
  "created_at": "2026-09-09T13:55:14.821516Z",
  "kind": "work",
  "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
  "goal": "Inspect the next fictional batch",
  "expected_result": "Both independent marks",
  "acceptance": [
    "Observation and recording marks are both present"
  ],
  "boundaries": [
    "Local fictional data only"
  ],
  "budget": "One T2 lifecycle example",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ],
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "2.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 6a0e2820-df7c-4875-bbb8-6f01d5b45db9; Artifact revision: 2
  SHA-256: 9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38; bytes: 36
  File: artifacts/fa002982-5c45-471f-9e99-1d2e4dbf78eb/6a0e2820-df7c-4875-bbb8-6f01d5b45db9.blob

## Mutation provenance

```json
{
  "id": "6aa44617-37cc-41b8-a52c-b90016438e92",
  "state_revision": 2,
  "recorded_at": "2026-09-09T13:55:14.607055Z",
  "product_version": "0.8.0",
  "request": {
    "version": 1,
    "operation_id": "6bb944cf-6942-4623-8097-9dd6cca4c3c7",
    "workspace_id": "3d8461ad-93cb-4401-ace4-7b3cdccee21d",
    "work_id": "974c00bb-515b-471e-9dce-84c143c91317",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T2 fixture authorized by RUN c-solmax-zaratustra-m1-packs-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T13:55:14.604750Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-lifecycle-01/new-v2-workspace",
    "request_sha256": "4ba208a24d7d88077417999dca5a57a535c2e45ffa8a66faa7ee8e729e693b06"
  },
  "fingerprint": "42e11fe7199635e1a9f345e0efc21eb05302ce06a85a7d33b1c381a6700f332b",
  "before": {
    "id": "974c00bb-515b-471e-9dce-84c143c91317",
    "revision": 1,
    "created_at": "2026-09-09T13:55:14.590809Z",
    "kind": "work",
    "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "974c00bb-515b-471e-9dce-84c143c91317",
    "revision": 2,
    "created_at": "2026-09-09T13:55:14.590809Z",
    "kind": "work",
    "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "d9008fa6-5d86-49de-aff4-238a47950c4a",
  "state_revision": 3,
  "recorded_at": "2026-09-09T13:55:14.634883Z",
  "product_version": "0.8.0",
  "request": {
    "version": 1,
    "operation_id": "e37d0b4f-409f-4421-bccb-3c7cb626d10d",
    "workspace_id": "3d8461ad-93cb-4401-ace4-7b3cdccee21d",
    "work_id": "974c00bb-515b-471e-9dce-84c143c91317",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "probe.batch/v1"
    ],
    "artifact_references": [],
    "provenance": "Fictional T2 fixture authorized by RUN c-solmax-zaratustra-m1-packs-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T13:55:14.632179Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-lifecycle-01/new-v2-workspace",
    "request_sha256": "1d833d7cbb0e11c7ef9aebd5302091c46b368bd234c6140c9c430bf2db9e352d"
  },
  "fingerprint": "0885e06ca9920245ab478ad084f5fee40bfa6054e9e8abea1796b0f61cc24910",
  "before": {
    "id": "974c00bb-515b-471e-9dce-84c143c91317",
    "revision": 2,
    "created_at": "2026-09-09T13:55:14.590809Z",
    "kind": "work",
    "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "974c00bb-515b-471e-9dce-84c143c91317",
    "revision": 3,
    "created_at": "2026-09-09T13:55:14.590809Z",
    "kind": "work",
    "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "a2a7e793-1347-435f-b4f5-91a0133c837d",
  "state_revision": 4,
  "recorded_at": "2026-09-09T13:55:14.673033Z",
  "product_version": "0.8.0",
  "request": {
    "version": 5,
    "operation_id": "84d4ed2d-aaca-4012-9d41-83669caf0351",
    "workspace_id": "3d8461ad-93cb-4401-ace4-7b3cdccee21d",
    "work_id": "974c00bb-515b-471e-9dce-84c143c91317",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional Process/Work binding under RUN c-solmax-zaratustra-m1-packs-20260909-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T13:55:14.670079Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-lifecycle-01/new-v2-workspace",
    "request_sha256": "3a45d0d824c9f545620a87e05b83a8bc79f2afad5c7e1d2c4ea4207f56527557"
  },
  "fingerprint": "a9b14bb3391ab4c732f1096dabf6838c8e14768a7706bbf89fcc85dfcfe2ee81",
  "before": {
    "id": "974c00bb-515b-471e-9dce-84c143c91317",
    "revision": 3,
    "created_at": "2026-09-09T13:55:14.590809Z",
    "kind": "work",
    "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "974c00bb-515b-471e-9dce-84c143c91317",
    "revision": 4,
    "created_at": "2026-09-09T13:55:14.590809Z",
    "kind": "work",
    "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "revision": 1,
    "created_at": "2026-09-09T13:55:14.590809Z",
    "kind": "process",
    "title": "Fictional pack lifecycle"
  },
  "process_after": {
    "id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "revision": 4,
    "created_at": "2026-09-09T13:55:14.590809Z",
    "kind": "process",
    "title": "Fictional pack lifecycle",
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "458c4ca5-dc17-4502-8b4b-d87491ecb761",
  "state_revision": 5,
  "recorded_at": "2026-09-09T13:55:14.703284Z",
  "product_version": "0.8.0",
  "request": {
    "version": 2,
    "operation_id": "dd00596e-4c03-455e-bdc3-f5286a902229",
    "workspace_id": "3d8461ad-93cb-4401-ace4-7b3cdccee21d",
    "work_id": "974c00bb-515b-471e-9dce-84c143c91317",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T2 fixture authorized by RUN c-solmax-zaratustra-m1-packs-20260909-exec",
    "artifact_id": "fa002982-5c45-471f-9e99-1d2e4dbf78eb",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T13:55:14.700287Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-lifecycle-01/new-v2-workspace",
    "request_sha256": "1e6dace98c24b6ce859c8b7ce5beeda9ebf0f52cfd83b9517741577c0963cd23"
  },
  "fingerprint": "eced23f5b8a128df3f70e741b84452c10a2cf02a82f3718da1d551007dd5fdcd",
  "before": {
    "id": "974c00bb-515b-471e-9dce-84c143c91317",
    "revision": 4,
    "created_at": "2026-09-09T13:55:14.590809Z",
    "kind": "work",
    "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "974c00bb-515b-471e-9dce-84c143c91317",
    "revision": 5,
    "created_at": "2026-09-09T13:55:14.590809Z",
    "kind": "work",
    "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "62e9aaaa-19d5-46b3-ae4c-5ab110116e00",
  "state_revision": 6,
  "recorded_at": "2026-09-09T13:55:14.733349Z",
  "product_version": "0.8.0",
  "request": {
    "version": 2,
    "operation_id": "6a0e2820-df7c-4875-bbb8-6f01d5b45db9",
    "workspace_id": "3d8461ad-93cb-4401-ace4-7b3cdccee21d",
    "work_id": "974c00bb-515b-471e-9dce-84c143c91317",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T2 fixture authorized by RUN c-solmax-zaratustra-m1-packs-20260909-exec",
    "artifact_id": "fa002982-5c45-471f-9e99-1d2e4dbf78eb",
    "artifact_revision": 1,
    "content_sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38",
    "content_size": 36,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T13:55:14.729229Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-lifecycle-01/new-v2-workspace",
    "request_sha256": "b7e55f50dfe28e27928024fe34e5eb742c1f0df79a93356bfbc43fd1a3f90367"
  },
  "fingerprint": "4e8c7db7cf78b5e147b1602dfe63d6ba1801ebc36cd7be1c20b381410ee04ee9",
  "before": {
    "id": "974c00bb-515b-471e-9dce-84c143c91317",
    "revision": 5,
    "created_at": "2026-09-09T13:55:14.590809Z",
    "kind": "work",
    "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "974c00bb-515b-471e-9dce-84c143c91317",
    "revision": 6,
    "created_at": "2026-09-09T13:55:14.590809Z",
    "kind": "work",
    "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "fa002982-5c45-471f-9e99-1d2e4dbf78eb",
    "revision": 1,
    "created_at": "2026-09-09T13:55:14.590809Z",
    "kind": "artifact",
    "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "work_id": "974c00bb-515b-471e-9dce-84c143c91317",
    "title": "Fictional batch observation",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "fa002982-5c45-471f-9e99-1d2e4dbf78eb",
    "revision": 2,
    "created_at": "2026-09-09T13:55:14.590809Z",
    "kind": "artifact",
    "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "work_id": "974c00bb-515b-471e-9dce-84c143c91317",
    "title": "Fictional batch observation",
    "status": "registered",
    "active_version": "6a0e2820-df7c-4875-bbb8-6f01d5b45db9"
  },
  "artifact_version": {
    "id": "6a0e2820-df7c-4875-bbb8-6f01d5b45db9",
    "artifact_id": "fa002982-5c45-471f-9e99-1d2e4dbf78eb",
    "work_id": "974c00bb-515b-471e-9dce-84c143c91317",
    "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "artifact_revision": 2,
    "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38",
    "size": 36,
    "created_at": "2026-09-09T13:55:14.733349Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "277e4f89-cceb-4515-b86a-67dc4bf2b1a1",
  "state_revision": 7,
  "recorded_at": "2026-09-09T13:55:14.774969Z",
  "product_version": "0.8.0",
  "request": {
    "version": 3,
    "operation_id": "e2e36800-4923-4b65-86c6-38b636f1590a",
    "workspace_id": "3d8461ad-93cb-4401-ace4-7b3cdccee21d",
    "work_id": "974c00bb-515b-471e-9dce-84c143c91317",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T2 observation; no owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "fa002982-5c45-471f-9e99-1d2e4dbf78eb",
        "version_id": "6a0e2820-df7c-4875-bbb8-6f01d5b45db9",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "e2e36800-4923-4b65-86c6-38b636f1590a",
      "workspace_id": "3d8461ad-93cb-4401-ace4-7b3cdccee21d",
      "process": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
      "related_work": "974c00bb-515b-471e-9dce-84c143c91317",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "fa002982-5c45-471f-9e99-1d2e4dbf78eb",
        "version_id": "6a0e2820-df7c-4875-bbb8-6f01d5b45db9",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      },
      "basis": [],
      "provenance": "Fictional T2 observation; no owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T2 fictional adapter"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-packs-20260909-exec",
      "input_sha256": "acba4b79a565e5521c120bad2d1d16cbd1adf5c09310697442dc400c88931941"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T13:55:14.771139Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-lifecycle-01/new-v2-workspace",
    "request_sha256": "e0657fe0604b9ae2136bb29ea4af40f6c2f5f58dad2413c2f95b856675591b5f"
  },
  "fingerprint": "862e193da60cec0e0c53c75134415d4a24ef16790e0cfc2728b298190d70017d",
  "before": {
    "id": "974c00bb-515b-471e-9dce-84c143c91317",
    "revision": 6,
    "created_at": "2026-09-09T13:55:14.590809Z",
    "kind": "work",
    "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "974c00bb-515b-471e-9dce-84c143c91317",
    "revision": 7,
    "created_at": "2026-09-09T13:55:14.590809Z",
    "kind": "work",
    "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "0bf8667b-8c15-4ae0-961e-710b464353d7",
  "state_revision": 8,
  "recorded_at": "2026-09-09T13:55:14.821516Z",
  "product_version": "0.8.0",
  "request": {
    "version": 4,
    "operation_id": "ad9ce2b7-c26d-4a69-bc17-67ec5da64ad7",
    "workspace_id": "3d8461ad-93cb-4401-ace4-7b3cdccee21d",
    "work_id": "974c00bb-515b-471e-9dce-84c143c91317",
    "expected_revision": 7,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.batch\",\"pack_version\":\"2.0.0\",\"process_type\":\"fictional.batch-check\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "fa002982-5c45-471f-9e99-1d2e4dbf78eb",
        "version_id": "6a0e2820-df7c-4875-bbb8-6f01d5b45db9",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 7,
      "result": {
        "artifact_id": "fa002982-5c45-471f-9e99-1d2e4dbf78eb",
        "version_id": "6a0e2820-df7c-4875-bbb8-6f01d5b45db9",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      },
      "acceptance_ids": [
        "e2e36800-4923-4b65-86c6-38b636f1590a"
      ],
      "next_work": {
        "work_id": "ce3f3b0a-4624-46f0-af66-fff3f0b32a6f",
        "artifact_id": "0be9f950-92ab-4466-9a13-244392e875c9",
        "goal": "Inspect the next fictional batch",
        "expected_result": "Both independent marks",
        "acceptance": [
          "Observation and recording marks are both present"
        ],
        "boundaries": [
          "Local fictional data only"
        ],
        "budget": "One T2 lifecycle example",
        "executor_requirements": [
          "probe.batch/v1"
        ],
        "artifact_title": "Next fictional batch observation",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T13:55:14.816952Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-lifecycle-01/new-v2-workspace",
    "request_sha256": "b6cd7c0113c31d6415834ae1471b735c2d34fd4401db48e50eac6b154fdcd882"
  },
  "fingerprint": "5794d373d11c2bf6eeba769139cdd2e1723f2256ba54cbe8a7516ade7c9a44d0",
  "before": {
    "id": "974c00bb-515b-471e-9dce-84c143c91317",
    "revision": 7,
    "created_at": "2026-09-09T13:55:14.590809Z",
    "kind": "work",
    "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "974c00bb-515b-471e-9dce-84c143c91317",
    "revision": 8,
    "created_at": "2026-09-09T13:55:14.590809Z",
    "kind": "work",
    "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "completion_id": "ad9ce2b7-c26d-4a69-bc17-67ec5da64ad7",
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "ce3f3b0a-4624-46f0-af66-fff3f0b32a6f",
    "revision": 8,
    "created_at": "2026-09-09T13:55:14.821516Z",
    "kind": "work",
    "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "goal": "Inspect the next fictional batch",
    "expected_result": "Both independent marks",
    "acceptance": [
      "Observation and recording marks are both present"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "0be9f950-92ab-4466-9a13-244392e875c9",
    "revision": 1,
    "created_at": "2026-09-09T13:55:14.821516Z",
    "kind": "artifact",
    "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "work_id": "ce3f3b0a-4624-46f0-af66-fff3f0b32a6f",
    "title": "Next fictional batch observation",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "fa002982-5c45-471f-9e99-1d2e4dbf78eb",
    "revision": 2,
    "created_at": "2026-09-09T13:55:14.590809Z",
    "kind": "artifact",
    "process_id": "bb6ce5eb-0d84-4296-b06e-b858e4431ba8",
    "work_id": "974c00bb-515b-471e-9dce-84c143c91317",
    "title": "Fictional batch observation",
    "status": "registered",
    "active_version": "6a0e2820-df7c-4875-bbb8-6f01d5b45db9"
  },
  "result_references": [
    {
      "artifact_id": "fa002982-5c45-471f-9e99-1d2e4dbf78eb",
      "version_id": "6a0e2820-df7c-4875-bbb8-6f01d5b45db9",
      "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
    }
  ]
}
```

