# Zaratustra — generated overview

generated_from_revision: 4
generated_at: 2026-09-09T13:55:14.530583+00:00
workspace_id: d736d3b9-0933-41e0-bc8b-f8e5875e7e5a

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "99eff619-dde9-49fb-aa0f-296d8af806e2",
  "revision": 1,
  "created_at": "2026-09-09T13:55:14.033860Z",
  "kind": "artifact",
  "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
  "work_id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
  "title": "Fictional batch observation",
  "status": "declared",
  "active_version": null
}
```

## event

```json
{
  "id": "739c38e1-fc66-4f67-86f6-31210e3a76a5",
  "revision": 1,
  "created_at": "2026-09-09T13:55:14.033860Z",
  "kind": "event",
  "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
  "work_id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.8.0",
  "state_revision": 1,
  "affected_ids": [
    "98a35214-a003-4f7a-a286-6d0091ba9584",
    "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "99eff619-dde9-49fb-aa0f-296d8af806e2"
  ]
}
```

## process

```json
{
  "id": "98a35214-a003-4f7a-a286-6d0091ba9584",
  "revision": 4,
  "created_at": "2026-09-09T13:55:14.033860Z",
  "kind": "process",
  "title": "Fictional pack lifecycle",
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "1.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
  "revision": 4,
  "created_at": "2026-09-09T13:55:14.033860Z",
  "kind": "work",
  "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
  "goal": "Continue a fictional batch with an exact retained pack version",
  "expected_result": "Recorded observation and continuation",
  "acceptance": [
    "Both fictional marks"
  ],
  "boundaries": [
    "Local fictional data only"
  ],
  "budget": "One T2 lifecycle example",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ],
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "1.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

## Mutation provenance

```json
{
  "id": "b13833df-8b80-4a74-a2e8-5ca0a13a6ef2",
  "state_revision": 2,
  "recorded_at": "2026-09-09T13:55:14.063944Z",
  "product_version": "0.8.0",
  "request": {
    "version": 1,
    "operation_id": "1eaa67e9-59fb-4926-9dfa-a7837b2c7e71",
    "workspace_id": "d736d3b9-0933-41e0-bc8b-f8e5875e7e5a",
    "work_id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T2 fixture authorized by RUN c-solmax-zaratustra-m1-packs-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T13:55:14.061494Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-lifecycle-01/workspace",
    "request_sha256": "ca023a3451afbaf7b0b20031e7872174eca3da82fddbbd01245ee50ab7afe045"
  },
  "fingerprint": "0cb9e8fc1f9155c8a71fbc3cf5a115043db628ab038a0c814e0aa9840b03ec21",
  "before": {
    "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "revision": 1,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "work",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "revision": 2,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "work",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "16fdd30a-2bd9-48e7-bea5-97271195e5cf",
  "state_revision": 3,
  "recorded_at": "2026-09-09T13:55:14.089097Z",
  "product_version": "0.8.0",
  "request": {
    "version": 1,
    "operation_id": "7ce60cb8-67c3-404e-8820-7ae0ce5adbc6",
    "workspace_id": "d736d3b9-0933-41e0-bc8b-f8e5875e7e5a",
    "work_id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "probe.batch/v1"
    ],
    "artifact_references": [],
    "provenance": "Fictional T2 fixture authorized by RUN c-solmax-zaratustra-m1-packs-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T13:55:14.086932Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-lifecycle-01/workspace",
    "request_sha256": "4c8b4a1381eedfdab554302f80467c5ad59e1db58c207c1999cf0e3d1de0265b"
  },
  "fingerprint": "bf9f7715ddfa3589703d4119e0374f5cea476751231ecb4e41df3599bee28785",
  "before": {
    "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "revision": 2,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "work",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "revision": 3,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "work",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "fd3e1bcd-9ace-47c3-8c22-8c5092074a95",
  "state_revision": 4,
  "recorded_at": "2026-09-09T13:55:14.530583Z",
  "product_version": "0.8.0",
  "request": {
    "version": 5,
    "operation_id": "9a4deee6-2557-49bf-9fb5-2dd72036ddbc",
    "workspace_id": "d736d3b9-0933-41e0-bc8b-f8e5875e7e5a",
    "work_id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional Process/Work binding under RUN c-solmax-zaratustra-m1-packs-20260909-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T13:55:14.528969Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-lifecycle-01/restored-bind",
    "request_sha256": "afbd040a48313e7b936630d0bd3bf08d5abf5406bae14bf86209dcefbc21898b"
  },
  "fingerprint": "0d66c81dfa7105b0e820688aa2db5fe2793e7a7ee583892618fa89c41ee9c65a",
  "before": {
    "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "revision": 3,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "work",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "66fe8ea0-32ef-4bf2-89e5-1cc445779fef",
    "revision": 4,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "work",
    "process_id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "revision": 1,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "process",
    "title": "Fictional pack lifecycle"
  },
  "process_after": {
    "id": "98a35214-a003-4f7a-a286-6d0091ba9584",
    "revision": 4,
    "created_at": "2026-09-09T13:55:14.033860Z",
    "kind": "process",
    "title": "Fictional pack lifecycle",
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

