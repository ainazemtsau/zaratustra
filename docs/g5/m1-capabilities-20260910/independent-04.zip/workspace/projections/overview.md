# Zaratustra — generated overview

generated_from_revision: 13
generated_at: 2026-09-10T05:47:43.948375+00:00
workspace_id: 03bcc5d6-ed0e-4a56-ae5f-0fb095688724

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
  "revision": 2,
  "created_at": "2026-09-09T15:53:36.894632Z",
  "kind": "artifact",
  "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
  "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
  "title": "Fictional batch observation",
  "status": "registered",
  "active_version": "eca36dd8-0023-4dcb-856b-e40c08fe6690"
}
```

## artifact

```json
{
  "id": "fc1db0ef-e77b-40d0-9348-2ac78ed8778a",
  "revision": 2,
  "created_at": "2026-09-10T05:47:42.412121Z",
  "kind": "artifact",
  "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
  "work_id": "d12c443e-fdb6-427e-b325-740967e5789f",
  "title": "Next fictional batch observation",
  "status": "registered",
  "active_version": "0ba98bb4-9cd7-41b6-87e1-4262685eaff3"
}
```

## event

```json
{
  "id": "73a9e7e4-7302-4d0a-ab27-984ead99268b",
  "revision": 1,
  "created_at": "2026-09-09T15:53:36.894632Z",
  "kind": "event",
  "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
  "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.9.0",
  "state_revision": 1,
  "affected_ids": [
    "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "69053218-53b2-4928-b999-d7c610883dcd",
    "c416ce65-6eb2-41eb-8be2-1d641f7a1175"
  ]
}
```

## process

```json
{
  "id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
  "revision": 4,
  "created_at": "2026-09-09T15:53:36.894632Z",
  "kind": "process",
  "title": "Fictional pack lifecycle",
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "1.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "69053218-53b2-4928-b999-d7c610883dcd",
  "revision": 13,
  "created_at": "2026-09-09T15:53:36.894632Z",
  "kind": "work",
  "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
  "goal": "Continue a fictional batch with an exact retained pack version",
  "expected_result": "Recorded observation and continuation",
  "acceptance": [
    "Both fictional marks"
  ],
  "boundaries": [
    "Local fictional data only"
  ],
  "budget": "One T2 lifecycle example",
  "status": "done",
  "authority_scope": "none",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ],
  "completion_id": "a9d08d1e-3b2e-4a62-a8ed-352f424d2475",
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "1.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "d12c443e-fdb6-427e-b325-740967e5789f",
  "revision": 12,
  "created_at": "2026-09-10T05:47:42.412121Z",
  "kind": "work",
  "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
  "goal": "Inspect the next fictional batch",
  "expected_result": "Both independent marks",
  "acceptance": [
    "Observation and recording marks are both present"
  ],
  "boundaries": [
    "Local fictional data only"
  ],
  "budget": "One T2 lifecycle example",
  "status": "ready",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ],
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "1.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 0ba98bb4-9cd7-41b6-87e1-4262685eaff3; Artifact revision: 2
  SHA-256: 33680a803e32d88b241e0292a0b3062b2751d876b06a00271f643313cd8611e7; bytes: 37
  File: artifacts/fc1db0ef-e77b-40d0-9348-2ac78ed8778a/0ba98bb4-9cd7-41b6-87e1-4262685eaff3.blob

- Version: eca36dd8-0023-4dcb-856b-e40c08fe6690; Artifact revision: 2
  SHA-256: 9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38; bytes: 36
  File: artifacts/c416ce65-6eb2-41eb-8be2-1d641f7a1175/eca36dd8-0023-4dcb-856b-e40c08fe6690.blob

## Mutation provenance

```json
{
  "id": "bd37e2bc-789a-4fce-a0cc-4a01b8214158",
  "state_revision": 2,
  "recorded_at": "2026-09-09T15:53:36.967226Z",
  "product_version": "0.9.0",
  "request": {
    "version": 1,
    "operation_id": "6ea33875-8b6d-483f-9a86-314e1d8b7675",
    "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional read-contract fixture under RUN c-solmax-zaratustra-m1-capabilities-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T3-fictional-contract-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-capabilities-20260909-exec; explicitly selected fictional fixture; T3 acceptance pending",
    "confirmed_at": "2026-09-09T15:53:36.962176Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-contract-01/workspace",
    "request_sha256": "bd1e2616e73e99112377ceaf54808f76c991209af80470ae7f772c4d73d0779c"
  },
  "fingerprint": "9212d3b1e53b99da781e0e9a82e5854b1c03ea2191a84aa317955c1888889713",
  "before": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 1,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 2,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "a98f0b4b-ed0d-4cee-92d3-77ac0b61df47",
  "state_revision": 3,
  "recorded_at": "2026-09-09T15:53:37.007187Z",
  "product_version": "0.9.0",
  "request": {
    "version": 1,
    "operation_id": "2fc07b61-701c-4e00-9a75-7603e65868d6",
    "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "probe.batch/v1"
    ],
    "artifact_references": [],
    "provenance": "Fictional read-contract fixture under RUN c-solmax-zaratustra-m1-capabilities-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T3-fictional-contract-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-capabilities-20260909-exec; explicitly selected fictional fixture; T3 acceptance pending",
    "confirmed_at": "2026-09-09T15:53:37.003103Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-contract-01/workspace",
    "request_sha256": "04951a49126f364a088e0c5cfb821f2f877a751a95ceb3b3912c1c5928f180be"
  },
  "fingerprint": "5e49681f06fee660674609df3facefa757a8f567bbaf1f11b456cbaa3f28234c",
  "before": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 2,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 3,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "3b1409d5-b041-4691-9122-a1da326e8cba",
  "state_revision": 4,
  "recorded_at": "2026-09-09T15:53:37.070777Z",
  "product_version": "0.9.0",
  "request": {
    "version": 5,
    "operation_id": "db62f901-8701-4e80-8109-4c183fc84f20",
    "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional Process/Work binding under RUN c-solmax-zaratustra-m1-packs-20260909-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T3-fictional-contract-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-capabilities-20260909-exec; explicitly selected fictional fixture; T3 acceptance pending",
    "confirmed_at": "2026-09-09T15:53:37.066488Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-contract-01/workspace",
    "request_sha256": "13ceeb2ccc26e5a286d484cb8e1422e101bd13d1e0157bc7bf4059a8789fbb95"
  },
  "fingerprint": "1a3892c71d821674a6381e229d26a3e3f3d806e1ef3f90e0291c0aa80cc3c09c",
  "before": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 3,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 4,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "revision": 1,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "process",
    "title": "Fictional pack lifecycle"
  },
  "process_after": {
    "id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "revision": 4,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "process",
    "title": "Fictional pack lifecycle",
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "b908df93-da15-4520-8bcf-9038579a0bf7",
  "state_revision": 5,
  "recorded_at": "2026-09-09T15:53:37.112353Z",
  "product_version": "0.9.0",
  "request": {
    "version": 2,
    "operation_id": "0f873894-f155-42c6-9d83-6d906b8c2bad",
    "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional read-contract fixture under RUN c-solmax-zaratustra-m1-capabilities-20260909-exec",
    "artifact_id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T3-fictional-contract-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-capabilities-20260909-exec; explicitly selected fictional fixture; T3 acceptance pending",
    "confirmed_at": "2026-09-09T15:53:37.108086Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-contract-01/workspace",
    "request_sha256": "d09eb0cb67a6b5eeed0612c1afc8834a807f21f3e52210eeef7e616cc184b493"
  },
  "fingerprint": "d35c69dc098b1f55148e7c69eee17f2190dceb41fd48a7436d7cbcad85945e98",
  "before": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 4,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 5,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "15a09dc8-7521-43e7-a79e-2e3589f2a571",
  "state_revision": 6,
  "recorded_at": "2026-09-09T15:53:37.153370Z",
  "product_version": "0.9.0",
  "request": {
    "version": 2,
    "operation_id": "eca36dd8-0023-4dcb-856b-e40c08fe6690",
    "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional read-contract fixture under RUN c-solmax-zaratustra-m1-capabilities-20260909-exec",
    "artifact_id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
    "artifact_revision": 1,
    "content_sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38",
    "content_size": 36,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T3-fictional-contract-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-capabilities-20260909-exec; explicitly selected fictional fixture; T3 acceptance pending",
    "confirmed_at": "2026-09-09T15:53:37.148518Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-contract-01/workspace",
    "request_sha256": "b9a9d0c4bb66c777d5817ed2b103b34f70948a9b3d935e0c8a034b83e34b97f1"
  },
  "fingerprint": "75cc573df784bcc7162323d08fbc99084a83f3ac406b0075424a46f473e85496",
  "before": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 5,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 6,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
    "revision": 1,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "artifact",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "title": "Fictional batch observation",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
    "revision": 2,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "artifact",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "title": "Fictional batch observation",
    "status": "registered",
    "active_version": "eca36dd8-0023-4dcb-856b-e40c08fe6690"
  },
  "artifact_version": {
    "id": "eca36dd8-0023-4dcb-856b-e40c08fe6690",
    "artifact_id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "artifact_revision": 2,
    "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38",
    "size": 36,
    "created_at": "2026-09-09T15:53:37.153370Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "3f3d97b7-062f-4143-9bff-efb42c4c9dbb",
  "state_revision": 7,
  "recorded_at": "2026-09-09T15:53:37.216613Z",
  "product_version": "0.9.0",
  "request": {
    "version": 3,
    "operation_id": "e7fb717c-8ecd-47d7-9000-f0af88e71174",
    "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T2 observation; no owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
        "version_id": "eca36dd8-0023-4dcb-856b-e40c08fe6690",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "e7fb717c-8ecd-47d7-9000-f0af88e71174",
      "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
      "process": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
      "related_work": "69053218-53b2-4928-b999-d7c610883dcd",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
        "version_id": "eca36dd8-0023-4dcb-856b-e40c08fe6690",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      },
      "basis": [],
      "provenance": "Fictional T2 observation; no owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T2 fictional adapter"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-packs-20260909-exec",
      "input_sha256": "2e42389c1479128740d3ad3b6f0894e307a55e35d27e228d368cc8ceea001465"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T3-fictional-contract-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-capabilities-20260909-exec; explicitly selected fictional fixture; T3 acceptance pending",
    "confirmed_at": "2026-09-09T15:53:37.212107Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-contract-01/workspace",
    "request_sha256": "392a89400ef46466f23e042d4826ba4afc59192c58a70b8ddc244641504593ae"
  },
  "fingerprint": "5febb5760a772661517a041e42fa596f9855b2164560af248aca62ea9ea785af",
  "before": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 6,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 7,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "63ad3130-4f04-4391-aa2a-0211089cbe67",
  "state_revision": 8,
  "recorded_at": "2026-09-10T05:47:42.266293Z",
  "product_version": "0.9.0",
  "request": {
    "version": 1,
    "operation_id": "6d5fb0e8-78a6-4555-8694-da95672245fd",
    "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "expected_revision": 7,
    "operation": "set_work_requirements",
    "requirements": [
      "g5:choice"
    ],
    "artifact_references": [],
    "provenance": "Fictional fresh G5 01a089d2-1faa-78f2-a543-47a480b1744b"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized isolated G5 fixtures; task 01a089d2-1faa-78f2-a543-47a480b1744b; acceptance pending",
    "confirmed_at": "2026-09-10T05:47:42.262690Z",
    "workspace_path": "C:/my_global_workflow/ba2e/zaratustra/_scratch/g5-m1-capabilities-20260910/independent-04/workspace",
    "request_sha256": "b1db1409e033724b40b47917ed717db9c94030cdf30de648f9016dff5aef98e5"
  },
  "fingerprint": "44995d5c99b071ef1b2d60fa442d3d93f16ac87522559397ce90a57339bc7be2",
  "before": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 7,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 8,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "g5:choice"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "16f9924d-86f4-40f9-8d2a-c8f4b14abab7",
  "state_revision": 9,
  "recorded_at": "2026-09-10T05:47:42.364899Z",
  "product_version": "0.9.0",
  "request": {
    "version": 1,
    "operation_id": "e31052d8-f576-46f1-b08f-4a4144749e59",
    "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "expected_revision": 8,
    "operation": "set_work_requirements",
    "requirements": [
      "probe.batch/v1"
    ],
    "artifact_references": [],
    "provenance": "Fictional fresh G5 01a089d2-1faa-78f2-a543-47a480b1744b"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized isolated G5 fixtures; task 01a089d2-1faa-78f2-a543-47a480b1744b; acceptance pending",
    "confirmed_at": "2026-09-10T05:47:42.361369Z",
    "workspace_path": "C:/my_global_workflow/ba2e/zaratustra/_scratch/g5-m1-capabilities-20260910/independent-04/workspace",
    "request_sha256": "8b532857dcaefeec5767b477f6124152cb951df66ea6d9c8ad03d4411f40312f"
  },
  "fingerprint": "c4e32254b5034121b2c633b43fc79ee6c37a9e2ecd69b5759233c655ea0fc67e",
  "before": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 8,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "g5:choice"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 9,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "8e558538-47dd-470e-946d-5f4a2d2b787f",
  "state_revision": 10,
  "recorded_at": "2026-09-10T05:47:42.412121Z",
  "product_version": "0.9.0",
  "request": {
    "version": 4,
    "operation_id": "a9d08d1e-3b2e-4a62-a8ed-352f424d2475",
    "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "expected_revision": 9,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.batch\",\"pack_version\":\"1.0.0\",\"process_type\":\"fictional.batch-check\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
        "version_id": "eca36dd8-0023-4dcb-856b-e40c08fe6690",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 9,
      "result": {
        "artifact_id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
        "version_id": "eca36dd8-0023-4dcb-856b-e40c08fe6690",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      },
      "acceptance_ids": [
        "e7fb717c-8ecd-47d7-9000-f0af88e71174"
      ],
      "next_work": {
        "work_id": "d12c443e-fdb6-427e-b325-740967e5789f",
        "artifact_id": "fc1db0ef-e77b-40d0-9348-2ac78ed8778a",
        "goal": "Inspect the next fictional batch",
        "expected_result": "Both independent marks",
        "acceptance": [
          "Observation and recording marks are both present"
        ],
        "boundaries": [
          "Local fictional data only"
        ],
        "budget": "One T2 lifecycle example",
        "executor_requirements": [
          "probe.batch/v1"
        ],
        "artifact_title": "Next fictional batch observation",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized isolated G5 fixtures; task 01a089d2-1faa-78f2-a543-47a480b1744b; acceptance pending",
    "confirmed_at": "2026-09-10T05:47:42.407286Z",
    "workspace_path": "C:/my_global_workflow/ba2e/zaratustra/_scratch/g5-m1-capabilities-20260910/independent-04/workspace",
    "request_sha256": "82b4a816ff1d43539892add6ae70c3eba79f7c7f596cf5a54d28a67bcc04c6b3"
  },
  "fingerprint": "f85bdc22f9d2560d906060c00e006cf5fa1b19ac934f76f71f960aac664aa452",
  "before": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 9,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 10,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "completion_id": "a9d08d1e-3b2e-4a62-a8ed-352f424d2475",
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "d12c443e-fdb6-427e-b325-740967e5789f",
    "revision": 10,
    "created_at": "2026-09-10T05:47:42.412121Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Inspect the next fictional batch",
    "expected_result": "Both independent marks",
    "acceptance": [
      "Observation and recording marks are both present"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "fc1db0ef-e77b-40d0-9348-2ac78ed8778a",
    "revision": 1,
    "created_at": "2026-09-10T05:47:42.412121Z",
    "kind": "artifact",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "work_id": "d12c443e-fdb6-427e-b325-740967e5789f",
    "title": "Next fictional batch observation",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
    "revision": 2,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "artifact",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "title": "Fictional batch observation",
    "status": "registered",
    "active_version": "eca36dd8-0023-4dcb-856b-e40c08fe6690"
  },
  "result_references": [
    {
      "artifact_id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
      "version_id": "eca36dd8-0023-4dcb-856b-e40c08fe6690",
      "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
    }
  ]
}
```

```json
{
  "id": "c5c5beb8-6ad0-44a8-9caf-3866b9da4297",
  "state_revision": 11,
  "recorded_at": "2026-09-10T05:47:42.829213Z",
  "product_version": "0.9.0",
  "request": {
    "version": 2,
    "operation_id": "a2d53e12-afbe-4941-afd7-996a1846ae79",
    "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
    "work_id": "d12c443e-fdb6-427e-b325-740967e5789f",
    "expected_revision": 10,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional fresh G5 01a089d2-1faa-78f2-a543-47a480b1744b",
    "artifact_id": "fc1db0ef-e77b-40d0-9348-2ac78ed8778a",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized isolated G5 fixtures; task 01a089d2-1faa-78f2-a543-47a480b1744b; acceptance pending",
    "confirmed_at": "2026-09-10T05:47:42.824899Z",
    "workspace_path": "C:/my_global_workflow/ba2e/zaratustra/_scratch/g5-m1-capabilities-20260910/independent-04/workspace",
    "request_sha256": "5c5ae818eef1a27529f2df83ba6230bfac7ddf082dd45d787152012cee857e59"
  },
  "fingerprint": "9b01975cf70f5d19a9e7578434ff63159b4659935ae3b7e761647fee36b0032b",
  "before": {
    "id": "d12c443e-fdb6-427e-b325-740967e5789f",
    "revision": 10,
    "created_at": "2026-09-10T05:47:42.412121Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Inspect the next fictional batch",
    "expected_result": "Both independent marks",
    "acceptance": [
      "Observation and recording marks are both present"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d12c443e-fdb6-427e-b325-740967e5789f",
    "revision": 11,
    "created_at": "2026-09-10T05:47:42.412121Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Inspect the next fictional batch",
    "expected_result": "Both independent marks",
    "acceptance": [
      "Observation and recording marks are both present"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "3d9c994f-9537-4780-848a-c76712e0639f",
  "state_revision": 12,
  "recorded_at": "2026-09-10T05:47:42.867418Z",
  "product_version": "0.9.0",
  "request": {
    "version": 2,
    "operation_id": "0ba98bb4-9cd7-41b6-87e1-4262685eaff3",
    "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
    "work_id": "d12c443e-fdb6-427e-b325-740967e5789f",
    "expected_revision": 11,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional fresh G5 01a089d2-1faa-78f2-a543-47a480b1744b",
    "artifact_id": "fc1db0ef-e77b-40d0-9348-2ac78ed8778a",
    "artifact_revision": 1,
    "content_sha256": "33680a803e32d88b241e0292a0b3062b2751d876b06a00271f643313cd8611e7",
    "content_size": 37,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized isolated G5 fixtures; task 01a089d2-1faa-78f2-a543-47a480b1744b; acceptance pending",
    "confirmed_at": "2026-09-10T05:47:42.862275Z",
    "workspace_path": "C:/my_global_workflow/ba2e/zaratustra/_scratch/g5-m1-capabilities-20260910/independent-04/workspace",
    "request_sha256": "b74ff0b98d080264e89dd88c4b750577441511587742a3d97a8c3d20a715b6f7"
  },
  "fingerprint": "f8a8acbadf54d555f96ea29c8b20d069aa651aad3f55b9e39e1ad718746f5612",
  "before": {
    "id": "d12c443e-fdb6-427e-b325-740967e5789f",
    "revision": 11,
    "created_at": "2026-09-10T05:47:42.412121Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Inspect the next fictional batch",
    "expected_result": "Both independent marks",
    "acceptance": [
      "Observation and recording marks are both present"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d12c443e-fdb6-427e-b325-740967e5789f",
    "revision": 12,
    "created_at": "2026-09-10T05:47:42.412121Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Inspect the next fictional batch",
    "expected_result": "Both independent marks",
    "acceptance": [
      "Observation and recording marks are both present"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "fc1db0ef-e77b-40d0-9348-2ac78ed8778a",
    "revision": 1,
    "created_at": "2026-09-10T05:47:42.412121Z",
    "kind": "artifact",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "work_id": "d12c443e-fdb6-427e-b325-740967e5789f",
    "title": "Next fictional batch observation",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "fc1db0ef-e77b-40d0-9348-2ac78ed8778a",
    "revision": 2,
    "created_at": "2026-09-10T05:47:42.412121Z",
    "kind": "artifact",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "work_id": "d12c443e-fdb6-427e-b325-740967e5789f",
    "title": "Next fictional batch observation",
    "status": "registered",
    "active_version": "0ba98bb4-9cd7-41b6-87e1-4262685eaff3"
  },
  "artifact_version": {
    "id": "0ba98bb4-9cd7-41b6-87e1-4262685eaff3",
    "artifact_id": "fc1db0ef-e77b-40d0-9348-2ac78ed8778a",
    "work_id": "d12c443e-fdb6-427e-b325-740967e5789f",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "artifact_revision": 2,
    "sha256": "33680a803e32d88b241e0292a0b3062b2751d876b06a00271f643313cd8611e7",
    "size": 37,
    "created_at": "2026-09-10T05:47:42.867418Z",
    "state_revision": 12
  }
}
```

```json
{
  "id": "16a29a3b-f054-497e-836e-5430dd00d69a",
  "state_revision": 13,
  "recorded_at": "2026-09-10T05:47:43.948375Z",
  "product_version": "0.9.0",
  "request": {
    "version": 1,
    "operation_id": "9282cc84-f9aa-4a64-8c2c-6b229412dc16",
    "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "expected_revision": 12,
    "operation": "revoke_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional fresh G5 01a089d2-1faa-78f2-a543-47a480b1744b"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized isolated G5 fixtures; task 01a089d2-1faa-78f2-a543-47a480b1744b; acceptance pending",
    "confirmed_at": "2026-09-10T05:47:43.943800Z",
    "workspace_path": "C:/my_global_workflow/ba2e/zaratustra/_scratch/g5-m1-capabilities-20260910/independent-04/workspace",
    "request_sha256": "c4dc1f5609a9f9e945cb78baff4f3c9942190f2b5e801f9d5a60b0a9773ccb12"
  },
  "fingerprint": "7cbe16c6f6c902117349a0055e7d1ea32e335beb8c2850f8b89f4884a0586f35",
  "before": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 10,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "completion_id": "a9d08d1e-3b2e-4a62-a8ed-352f424d2475",
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 13,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "done",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "completion_id": "a9d08d1e-3b2e-4a62-a8ed-352f424d2475",
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

