# Zaratustra — generated overview

generated_from_revision: 10
generated_at: 2026-09-10T05:46:58.053098+00:00
workspace_id: 03bcc5d6-ed0e-4a56-ae5f-0fb095688724

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
  "revision": 2,
  "created_at": "2026-09-09T15:53:36.894632Z",
  "kind": "artifact",
  "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
  "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
  "title": "Fictional batch observation",
  "status": "registered",
  "active_version": "eca36dd8-0023-4dcb-856b-e40c08fe6690"
}
```

## artifact

```json
{
  "id": "d39b3e15-c531-41f3-b2d3-21f5a78104fb",
  "revision": 1,
  "created_at": "2026-09-10T05:46:58.053098Z",
  "kind": "artifact",
  "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
  "work_id": "79a3289c-2ba3-497c-8910-a0969e9dbeaf",
  "title": "Next fictional batch observation",
  "status": "declared",
  "active_version": null
}
```

## event

```json
{
  "id": "73a9e7e4-7302-4d0a-ab27-984ead99268b",
  "revision": 1,
  "created_at": "2026-09-09T15:53:36.894632Z",
  "kind": "event",
  "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
  "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.9.0",
  "state_revision": 1,
  "affected_ids": [
    "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "69053218-53b2-4928-b999-d7c610883dcd",
    "c416ce65-6eb2-41eb-8be2-1d641f7a1175"
  ]
}
```

## process

```json
{
  "id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
  "revision": 4,
  "created_at": "2026-09-09T15:53:36.894632Z",
  "kind": "process",
  "title": "Fictional pack lifecycle",
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "1.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "69053218-53b2-4928-b999-d7c610883dcd",
  "revision": 10,
  "created_at": "2026-09-09T15:53:36.894632Z",
  "kind": "work",
  "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
  "goal": "Continue a fictional batch with an exact retained pack version",
  "expected_result": "Recorded observation and continuation",
  "acceptance": [
    "Both fictional marks"
  ],
  "boundaries": [
    "Local fictional data only"
  ],
  "budget": "One T2 lifecycle example",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ],
  "completion_id": "04f9c683-e299-4b63-b83a-81c50d30b9ef",
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "1.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "79a3289c-2ba3-497c-8910-a0969e9dbeaf",
  "revision": 10,
  "created_at": "2026-09-10T05:46:58.053098Z",
  "kind": "work",
  "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
  "goal": "Inspect the next fictional batch",
  "expected_result": "Both independent marks",
  "acceptance": [
    "Observation and recording marks are both present"
  ],
  "boundaries": [
    "Local fictional data only"
  ],
  "budget": "One T2 lifecycle example",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ],
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "1.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: eca36dd8-0023-4dcb-856b-e40c08fe6690; Artifact revision: 2
  SHA-256: 9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38; bytes: 36
  File: artifacts/c416ce65-6eb2-41eb-8be2-1d641f7a1175/eca36dd8-0023-4dcb-856b-e40c08fe6690.blob

## Mutation provenance

```json
{
  "id": "bd37e2bc-789a-4fce-a0cc-4a01b8214158",
  "state_revision": 2,
  "recorded_at": "2026-09-09T15:53:36.967226Z",
  "product_version": "0.9.0",
  "request": {
    "version": 1,
    "operation_id": "6ea33875-8b6d-483f-9a86-314e1d8b7675",
    "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional read-contract fixture under RUN c-solmax-zaratustra-m1-capabilities-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T3-fictional-contract-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-capabilities-20260909-exec; explicitly selected fictional fixture; T3 acceptance pending",
    "confirmed_at": "2026-09-09T15:53:36.962176Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-contract-01/workspace",
    "request_sha256": "bd1e2616e73e99112377ceaf54808f76c991209af80470ae7f772c4d73d0779c"
  },
  "fingerprint": "9212d3b1e53b99da781e0e9a82e5854b1c03ea2191a84aa317955c1888889713",
  "before": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 1,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 2,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "a98f0b4b-ed0d-4cee-92d3-77ac0b61df47",
  "state_revision": 3,
  "recorded_at": "2026-09-09T15:53:37.007187Z",
  "product_version": "0.9.0",
  "request": {
    "version": 1,
    "operation_id": "2fc07b61-701c-4e00-9a75-7603e65868d6",
    "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "probe.batch/v1"
    ],
    "artifact_references": [],
    "provenance": "Fictional read-contract fixture under RUN c-solmax-zaratustra-m1-capabilities-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T3-fictional-contract-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-capabilities-20260909-exec; explicitly selected fictional fixture; T3 acceptance pending",
    "confirmed_at": "2026-09-09T15:53:37.003103Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-contract-01/workspace",
    "request_sha256": "04951a49126f364a088e0c5cfb821f2f877a751a95ceb3b3912c1c5928f180be"
  },
  "fingerprint": "5e49681f06fee660674609df3facefa757a8f567bbaf1f11b456cbaa3f28234c",
  "before": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 2,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 3,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "3b1409d5-b041-4691-9122-a1da326e8cba",
  "state_revision": 4,
  "recorded_at": "2026-09-09T15:53:37.070777Z",
  "product_version": "0.9.0",
  "request": {
    "version": 5,
    "operation_id": "db62f901-8701-4e80-8109-4c183fc84f20",
    "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional Process/Work binding under RUN c-solmax-zaratustra-m1-packs-20260909-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T3-fictional-contract-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-capabilities-20260909-exec; explicitly selected fictional fixture; T3 acceptance pending",
    "confirmed_at": "2026-09-09T15:53:37.066488Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-contract-01/workspace",
    "request_sha256": "13ceeb2ccc26e5a286d484cb8e1422e101bd13d1e0157bc7bf4059a8789fbb95"
  },
  "fingerprint": "1a3892c71d821674a6381e229d26a3e3f3d806e1ef3f90e0291c0aa80cc3c09c",
  "before": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 3,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 4,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "revision": 1,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "process",
    "title": "Fictional pack lifecycle"
  },
  "process_after": {
    "id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "revision": 4,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "process",
    "title": "Fictional pack lifecycle",
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "b908df93-da15-4520-8bcf-9038579a0bf7",
  "state_revision": 5,
  "recorded_at": "2026-09-09T15:53:37.112353Z",
  "product_version": "0.9.0",
  "request": {
    "version": 2,
    "operation_id": "0f873894-f155-42c6-9d83-6d906b8c2bad",
    "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional read-contract fixture under RUN c-solmax-zaratustra-m1-capabilities-20260909-exec",
    "artifact_id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T3-fictional-contract-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-capabilities-20260909-exec; explicitly selected fictional fixture; T3 acceptance pending",
    "confirmed_at": "2026-09-09T15:53:37.108086Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-contract-01/workspace",
    "request_sha256": "d09eb0cb67a6b5eeed0612c1afc8834a807f21f3e52210eeef7e616cc184b493"
  },
  "fingerprint": "d35c69dc098b1f55148e7c69eee17f2190dceb41fd48a7436d7cbcad85945e98",
  "before": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 4,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 5,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "15a09dc8-7521-43e7-a79e-2e3589f2a571",
  "state_revision": 6,
  "recorded_at": "2026-09-09T15:53:37.153370Z",
  "product_version": "0.9.0",
  "request": {
    "version": 2,
    "operation_id": "eca36dd8-0023-4dcb-856b-e40c08fe6690",
    "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional read-contract fixture under RUN c-solmax-zaratustra-m1-capabilities-20260909-exec",
    "artifact_id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
    "artifact_revision": 1,
    "content_sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38",
    "content_size": 36,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T3-fictional-contract-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-capabilities-20260909-exec; explicitly selected fictional fixture; T3 acceptance pending",
    "confirmed_at": "2026-09-09T15:53:37.148518Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-contract-01/workspace",
    "request_sha256": "b9a9d0c4bb66c777d5817ed2b103b34f70948a9b3d935e0c8a034b83e34b97f1"
  },
  "fingerprint": "75cc573df784bcc7162323d08fbc99084a83f3ac406b0075424a46f473e85496",
  "before": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 5,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 6,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
    "revision": 1,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "artifact",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "title": "Fictional batch observation",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
    "revision": 2,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "artifact",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "title": "Fictional batch observation",
    "status": "registered",
    "active_version": "eca36dd8-0023-4dcb-856b-e40c08fe6690"
  },
  "artifact_version": {
    "id": "eca36dd8-0023-4dcb-856b-e40c08fe6690",
    "artifact_id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "artifact_revision": 2,
    "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38",
    "size": 36,
    "created_at": "2026-09-09T15:53:37.153370Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "3f3d97b7-062f-4143-9bff-efb42c4c9dbb",
  "state_revision": 7,
  "recorded_at": "2026-09-09T15:53:37.216613Z",
  "product_version": "0.9.0",
  "request": {
    "version": 3,
    "operation_id": "e7fb717c-8ecd-47d7-9000-f0af88e71174",
    "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T2 observation; no owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
        "version_id": "eca36dd8-0023-4dcb-856b-e40c08fe6690",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "e7fb717c-8ecd-47d7-9000-f0af88e71174",
      "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
      "process": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
      "related_work": "69053218-53b2-4928-b999-d7c610883dcd",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
        "version_id": "eca36dd8-0023-4dcb-856b-e40c08fe6690",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      },
      "basis": [],
      "provenance": "Fictional T2 observation; no owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T2 fictional adapter"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-packs-20260909-exec",
      "input_sha256": "2e42389c1479128740d3ad3b6f0894e307a55e35d27e228d368cc8ceea001465"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T3-fictional-contract-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-capabilities-20260909-exec; explicitly selected fictional fixture; T3 acceptance pending",
    "confirmed_at": "2026-09-09T15:53:37.212107Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-contract-01/workspace",
    "request_sha256": "392a89400ef46466f23e042d4826ba4afc59192c58a70b8ddc244641504593ae"
  },
  "fingerprint": "5febb5760a772661517a041e42fa596f9855b2164560af248aca62ea9ea785af",
  "before": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 6,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 7,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "49ce72ff-34f3-4863-a1da-ad2fd9420258",
  "state_revision": 8,
  "recorded_at": "2026-09-10T05:46:57.911523Z",
  "product_version": "0.9.0",
  "request": {
    "version": 1,
    "operation_id": "f9dc95bb-4071-4d28-b938-5dd04967bdac",
    "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "expected_revision": 7,
    "operation": "set_work_requirements",
    "requirements": [
      "g5:choice"
    ],
    "artifact_references": [],
    "provenance": "Fictional fresh G5 01a089d2-1faa-78f2-a543-47a480b1744b"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized isolated G5 fixtures; task 01a089d2-1faa-78f2-a543-47a480b1744b; acceptance pending",
    "confirmed_at": "2026-09-10T05:46:57.908048Z",
    "workspace_path": "C:/my_global_workflow/ba2e/zaratustra/_scratch/g5-m1-capabilities-20260910/independent-03/workspace",
    "request_sha256": "4cc9965d00e3a0eaec2e7851a7b2826b2e96cad47ea2085877bce279ccc93615"
  },
  "fingerprint": "44995d5c99b071ef1b2d60fa442d3d93f16ac87522559397ce90a57339bc7be2",
  "before": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 7,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 8,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "g5:choice"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "be5e8948-333b-4f24-86de-347751998e47",
  "state_revision": 9,
  "recorded_at": "2026-09-10T05:46:58.006606Z",
  "product_version": "0.9.0",
  "request": {
    "version": 1,
    "operation_id": "5cad40e9-64db-4b8b-8b0b-e050357cf01d",
    "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "expected_revision": 8,
    "operation": "set_work_requirements",
    "requirements": [
      "probe.batch/v1"
    ],
    "artifact_references": [],
    "provenance": "Fictional fresh G5 01a089d2-1faa-78f2-a543-47a480b1744b"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized isolated G5 fixtures; task 01a089d2-1faa-78f2-a543-47a480b1744b; acceptance pending",
    "confirmed_at": "2026-09-10T05:46:58.002805Z",
    "workspace_path": "C:/my_global_workflow/ba2e/zaratustra/_scratch/g5-m1-capabilities-20260910/independent-03/workspace",
    "request_sha256": "aa6b85938c70d06db8a1247e319849da23b8503e1ee44adf29b923a4a80e3e47"
  },
  "fingerprint": "c4e32254b5034121b2c633b43fc79ee6c37a9e2ecd69b5759233c655ea0fc67e",
  "before": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 8,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "g5:choice"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 9,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "2f02fabd-1324-4d99-872f-37a756ebcd31",
  "state_revision": 10,
  "recorded_at": "2026-09-10T05:46:58.053098Z",
  "product_version": "0.9.0",
  "request": {
    "version": 4,
    "operation_id": "04f9c683-e299-4b63-b83a-81c50d30b9ef",
    "workspace_id": "03bcc5d6-ed0e-4a56-ae5f-0fb095688724",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "expected_revision": 9,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.batch\",\"pack_version\":\"1.0.0\",\"process_type\":\"fictional.batch-check\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
        "version_id": "eca36dd8-0023-4dcb-856b-e40c08fe6690",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 9,
      "result": {
        "artifact_id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
        "version_id": "eca36dd8-0023-4dcb-856b-e40c08fe6690",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      },
      "acceptance_ids": [
        "e7fb717c-8ecd-47d7-9000-f0af88e71174"
      ],
      "next_work": {
        "work_id": "79a3289c-2ba3-497c-8910-a0969e9dbeaf",
        "artifact_id": "d39b3e15-c531-41f3-b2d3-21f5a78104fb",
        "goal": "Inspect the next fictional batch",
        "expected_result": "Both independent marks",
        "acceptance": [
          "Observation and recording marks are both present"
        ],
        "boundaries": [
          "Local fictional data only"
        ],
        "budget": "One T2 lifecycle example",
        "executor_requirements": [
          "probe.batch/v1"
        ],
        "artifact_title": "Next fictional batch observation",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized isolated G5 fixtures; task 01a089d2-1faa-78f2-a543-47a480b1744b; acceptance pending",
    "confirmed_at": "2026-09-10T05:46:58.048248Z",
    "workspace_path": "C:/my_global_workflow/ba2e/zaratustra/_scratch/g5-m1-capabilities-20260910/independent-03/workspace",
    "request_sha256": "0f5ccf3c1154695a9aea1af982940a4dfbcde0db384814450a1205eb526d176f"
  },
  "fingerprint": "679c710b013f91126cd86596fa1775ec11730455f7d26f4b022e99781e027795",
  "before": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 9,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "69053218-53b2-4928-b999-d7c610883dcd",
    "revision": 10,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "completion_id": "04f9c683-e299-4b63-b83a-81c50d30b9ef",
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "79a3289c-2ba3-497c-8910-a0969e9dbeaf",
    "revision": 10,
    "created_at": "2026-09-10T05:46:58.053098Z",
    "kind": "work",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "goal": "Inspect the next fictional batch",
    "expected_result": "Both independent marks",
    "acceptance": [
      "Observation and recording marks are both present"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "d39b3e15-c531-41f3-b2d3-21f5a78104fb",
    "revision": 1,
    "created_at": "2026-09-10T05:46:58.053098Z",
    "kind": "artifact",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "work_id": "79a3289c-2ba3-497c-8910-a0969e9dbeaf",
    "title": "Next fictional batch observation",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
    "revision": 2,
    "created_at": "2026-09-09T15:53:36.894632Z",
    "kind": "artifact",
    "process_id": "5e977706-3159-4c34-9f39-7f1ffd4ae12c",
    "work_id": "69053218-53b2-4928-b999-d7c610883dcd",
    "title": "Fictional batch observation",
    "status": "registered",
    "active_version": "eca36dd8-0023-4dcb-856b-e40c08fe6690"
  },
  "result_references": [
    {
      "artifact_id": "c416ce65-6eb2-41eb-8be2-1d641f7a1175",
      "version_id": "eca36dd8-0023-4dcb-856b-e40c08fe6690",
      "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
    }
  ]
}
```

