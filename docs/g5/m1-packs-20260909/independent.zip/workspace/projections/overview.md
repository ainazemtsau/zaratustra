# Zaratustra — generated overview

generated_from_revision: 9
generated_at: 2026-09-09T14:46:08.703648+00:00
workspace_id: ecb141bf-b16e-4b9b-9de7-aa16d62d6e3d

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "27049b91-d652-4af9-a5a0-e3215fd46d74",
  "revision": 1,
  "created_at": "2026-09-09T14:46:08.525150Z",
  "kind": "artifact",
  "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
  "work_id": "da1f9ad3-16d9-4a0e-9caa-21cbf625a1dd",
  "title": "Independent next artifact",
  "status": "declared",
  "active_version": null
}
```

## artifact

```json
{
  "id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
  "revision": 2,
  "created_at": "2026-09-09T14:46:07.579178Z",
  "kind": "artifact",
  "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
  "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
  "title": "Independent evidence",
  "status": "registered",
  "active_version": "ec88a342-60ef-4875-8eff-774ca02b0906"
}
```

## event

```json
{
  "id": "f1ab5cac-b38c-4c88-8195-9daebeb25efc",
  "revision": 1,
  "created_at": "2026-09-09T14:46:07.579178Z",
  "kind": "event",
  "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
  "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.8.0",
  "state_revision": 1,
  "affected_ids": [
    "2af58028-96b5-41c7-8527-e6f387142032",
    "43353f8b-5629-494c-bee6-c7236fbb91de",
    "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81"
  ]
}
```

## process

```json
{
  "id": "2af58028-96b5-41c7-8527-e6f387142032",
  "revision": 3,
  "created_at": "2026-09-09T14:46:07.579178Z",
  "kind": "process",
  "title": "Unseen fictional review process",
  "pack_binding": {
    "pack_id": "review.unseen",
    "pack_version": "3.1.4",
    "process_type": "review.unseen-type",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
  "revision": 9,
  "created_at": "2026-09-09T14:46:07.579178Z",
  "kind": "work",
  "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
  "goal": "Attempt to refute retained pack identity",
  "expected_result": "Exact persistent reference",
  "acceptance": [
    "Fictional review evidence"
  ],
  "boundaries": [
    "Review _scratch only"
  ],
  "budget": "One independent fixture",
  "status": "done",
  "authority_scope": "none",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [],
  "completion_id": "1c419c8c-54be-4524-98d2-48ebaca1651e",
  "pack_binding": {
    "pack_id": "review.unseen",
    "pack_version": "3.1.4",
    "process_type": "review.unseen-type",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "da1f9ad3-16d9-4a0e-9caa-21cbf625a1dd",
  "revision": 7,
  "created_at": "2026-09-09T14:46:08.525150Z",
  "kind": "work",
  "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
  "goal": "Fictional continuation exact old",
  "expected_result": "Independent retained observation",
  "acceptance": [
    "Fictional check"
  ],
  "boundaries": [
    "Review-only fixture"
  ],
  "budget": "One review transition",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "review.external-rule"
  ],
  "pack_binding": {
    "pack_id": "review.unseen",
    "pack_version": "3.1.4",
    "process_type": "review.unseen-type",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: ec88a342-60ef-4875-8eff-774ca02b0906; Artifact revision: 2
  SHA-256: 32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154; bytes: 57
  File: artifacts/43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81/ec88a342-60ef-4875-8eff-774ca02b0906.blob

## Mutation provenance

```json
{
  "id": "62517146-b4ca-400a-9ee4-2ea6d8550f75",
  "state_revision": 2,
  "recorded_at": "2026-09-09T14:46:07.624067Z",
  "product_version": "0.8.0",
  "request": {
    "version": 1,
    "operation_id": "14e2c63a-ab6b-4439-9ccf-18a326eebd9c",
    "workspace_id": "ecb141bf-b16e-4b9b-9de7-aa16d62d6e3d",
    "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fresh G5 fictional bounded request"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:46:07.621775Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/independent-01/workspace",
    "request_sha256": "3e67f398732815ace1cb6fee2465c12a66ee610615df6ebc9e1f35ecef3c1264"
  },
  "fingerprint": "f5ae38d3704193653286dfe697332410ef05ca37f798d3621b81760a1ca14fe7",
  "before": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 1,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 2,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "6af81b77-7932-4db5-8e82-db9cafac631d",
  "state_revision": 3,
  "recorded_at": "2026-09-09T14:46:07.798693Z",
  "product_version": "0.8.0",
  "request": {
    "version": 5,
    "operation_id": "9967c2c5-9368-47da-9a01-4faa2bb6a9d7",
    "workspace_id": "ecb141bf-b16e-4b9b-9de7-aa16d62d6e3d",
    "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "expected_revision": 2,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fresh G5 explicit fictional binding",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:46:07.796378Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/independent-01/workspace",
    "request_sha256": "d94cb327c2d5c870ae247c6f493e59cda55dbba7c4c6a73b34316499e75985c7"
  },
  "fingerprint": "f0371f59737dbaf2eaf61005bc35e531d3dbcecbc643e5350116ab13c928b509",
  "before": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 2,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 3,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "2af58028-96b5-41c7-8527-e6f387142032",
    "revision": 1,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "process",
    "title": "Unseen fictional review process"
  },
  "process_after": {
    "id": "2af58028-96b5-41c7-8527-e6f387142032",
    "revision": 3,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "process",
    "title": "Unseen fictional review process",
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "98c2ef1e-044a-42c5-8334-0cbe19561c3a",
  "state_revision": 4,
  "recorded_at": "2026-09-09T14:46:07.888115Z",
  "product_version": "0.8.0",
  "request": {
    "version": 2,
    "operation_id": "b86a6fdc-2f78-4503-8783-1dabcedf50a9",
    "workspace_id": "ecb141bf-b16e-4b9b-9de7-aa16d62d6e3d",
    "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "expected_revision": 3,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fresh G5 fictional bounded request",
    "artifact_id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:46:07.885936Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/independent-01/workspace",
    "request_sha256": "9aa7ba6f4008c09aa84f5ce044fabc81148abb11b617b732ede0b6abfebe310b"
  },
  "fingerprint": "ef7313c424dd8bdebcdbaddab410ee8464f130f9f96d21c26498c24bead52903",
  "before": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 3,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 4,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "7850c747-6b28-45b6-a3a8-7337c2b67ab8",
  "state_revision": 5,
  "recorded_at": "2026-09-09T14:46:07.914420Z",
  "product_version": "0.8.0",
  "request": {
    "version": 2,
    "operation_id": "ec88a342-60ef-4875-8eff-774ca02b0906",
    "workspace_id": "ecb141bf-b16e-4b9b-9de7-aa16d62d6e3d",
    "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "expected_revision": 4,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fresh G5 fictional bounded request",
    "artifact_id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
    "artifact_revision": 1,
    "content_sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154",
    "content_size": 57,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:46:07.911683Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/independent-01/workspace",
    "request_sha256": "e704fe6ad07a2fe6548b93f398c64fa5afaf466b36a9ba3d1eefaed9741e7463"
  },
  "fingerprint": "6058a2973dfc5a2390c78a94de6527a29f1eb9bf455058657c0d57393ee9e155",
  "before": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 4,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 5,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
    "revision": 1,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "artifact",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "title": "Independent evidence",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
    "revision": 2,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "artifact",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "title": "Independent evidence",
    "status": "registered",
    "active_version": "ec88a342-60ef-4875-8eff-774ca02b0906"
  },
  "artifact_version": {
    "id": "ec88a342-60ef-4875-8eff-774ca02b0906",
    "artifact_id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
    "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "artifact_revision": 2,
    "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154",
    "size": 57,
    "created_at": "2026-09-09T14:46:07.914420Z",
    "state_revision": 5
  }
}
```

```json
{
  "id": "4cc1f9b8-cc5f-4507-b263-6c00e5fed028",
  "state_revision": 6,
  "recorded_at": "2026-09-09T14:46:07.956439Z",
  "product_version": "0.8.0",
  "request": {
    "version": 3,
    "operation_id": "e7ed6059-2a48-47dd-aae5-f976af75a4b7",
    "workspace_id": "ecb141bf-b16e-4b9b-9de7-aa16d62d6e3d",
    "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "expected_revision": 5,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Independent fictional evidence",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
        "version_id": "ec88a342-60ef-4875-8eff-774ca02b0906",
        "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "e7ed6059-2a48-47dd-aae5-f976af75a4b7",
      "workspace_id": "ecb141bf-b16e-4b9b-9de7-aa16d62d6e3d",
      "process": "2af58028-96b5-41c7-8527-e6f387142032",
      "related_work": "43353f8b-5629-494c-bee6-c7236fbb91de",
      "intent": "accepted_result",
      "source_revision": 5,
      "result": {
        "artifact_id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
        "version_id": "ec88a342-60ef-4875-8eff-774ca02b0906",
        "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154"
      },
      "basis": [],
      "provenance": "Independent fictional evidence",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "Fresh G5 review"
    },
    "delivery": {
      "source_ref": "01a0869b-59b5-7b62-9e19-e2f8056f4341",
      "input_sha256": "735482924d42fe57c85b31a4bb5fb761e649e378967d6429265a58a48a735c5c"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:46:07.952399Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/independent-01/workspace",
    "request_sha256": "a201cafc3267939ed0719826f6fc423afbed89d215ff138e266d618c6641f511"
  },
  "fingerprint": "54d9a0ac2c49f7f52073f0c76fd5941bc416ca98c154e383869f3daa03f1fef3",
  "before": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 5,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 6,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "77591532-318a-4f63-bcef-88acaa2175fd",
  "state_revision": 7,
  "recorded_at": "2026-09-09T14:46:08.525150Z",
  "product_version": "0.8.0",
  "request": {
    "version": 4,
    "operation_id": "1c419c8c-54be-4524-98d2-48ebaca1651e",
    "workspace_id": "ecb141bf-b16e-4b9b-9de7-aa16d62d6e3d",
    "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "expected_revision": 6,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"review.unseen\",\"pack_version\":\"3.1.4\",\"process_type\":\"review.unseen-type\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
        "version_id": "ec88a342-60ef-4875-8eff-774ca02b0906",
        "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 6,
      "result": {
        "artifact_id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
        "version_id": "ec88a342-60ef-4875-8eff-774ca02b0906",
        "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154"
      },
      "acceptance_ids": [
        "e7ed6059-2a48-47dd-aae5-f976af75a4b7"
      ],
      "next_work": {
        "work_id": "da1f9ad3-16d9-4a0e-9caa-21cbf625a1dd",
        "artifact_id": "27049b91-d652-4af9-a5a0-e3215fd46d74",
        "goal": "Fictional continuation exact old",
        "expected_result": "Independent retained observation",
        "acceptance": [
          "Fictional check"
        ],
        "boundaries": [
          "Review-only fixture"
        ],
        "budget": "One review transition",
        "executor_requirements": [
          "review.external-rule"
        ],
        "artifact_title": "Independent next artifact",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:46:08.520246Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/independent-01/workspace",
    "request_sha256": "d64ff8ca692c11f13f28f3777417e5d652f29a643e63dadc4f175df47a2a434e"
  },
  "fingerprint": "73b7367c48faeda9453720653617aff40a007930e256f7ae92d82139bb8cd523",
  "before": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 6,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 7,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "completion_id": "1c419c8c-54be-4524-98d2-48ebaca1651e",
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "da1f9ad3-16d9-4a0e-9caa-21cbf625a1dd",
    "revision": 7,
    "created_at": "2026-09-09T14:46:08.525150Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Fictional continuation exact old",
    "expected_result": "Independent retained observation",
    "acceptance": [
      "Fictional check"
    ],
    "boundaries": [
      "Review-only fixture"
    ],
    "budget": "One review transition",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "review.external-rule"
    ],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "27049b91-d652-4af9-a5a0-e3215fd46d74",
    "revision": 1,
    "created_at": "2026-09-09T14:46:08.525150Z",
    "kind": "artifact",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "work_id": "da1f9ad3-16d9-4a0e-9caa-21cbf625a1dd",
    "title": "Independent next artifact",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
    "revision": 2,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "artifact",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "title": "Independent evidence",
    "status": "registered",
    "active_version": "ec88a342-60ef-4875-8eff-774ca02b0906"
  },
  "result_references": [
    {
      "artifact_id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
      "version_id": "ec88a342-60ef-4875-8eff-774ca02b0906",
      "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154"
    }
  ]
}
```

```json
{
  "id": "419c60ca-c5a1-4756-8f31-b93a4518d2ab",
  "state_revision": 8,
  "recorded_at": "2026-09-09T14:46:08.666136Z",
  "product_version": "0.8.0",
  "request": {
    "version": 2,
    "operation_id": "6c0590c1-74f2-4281-9135-84cf974f820f",
    "workspace_id": "ecb141bf-b16e-4b9b-9de7-aa16d62d6e3d",
    "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "expected_revision": 7,
    "operation": "restore_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fresh G5 fictional bounded request",
    "artifact_id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
    "artifact_revision": 2,
    "content_sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154",
    "content_size": 57,
    "restore_version": "ec88a342-60ef-4875-8eff-774ca02b0906",
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:46:08.662233Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/independent-01/workspace",
    "request_sha256": "fe4aa3696a9959a2a489ebf74ac7d7e4ba45a5fc5563ef4ad8a946a49415b85e"
  },
  "fingerprint": "34644f8d3c2c44f8e88dbfc99b635e8ffe1515c1650f05db77b0f8c5c306ae3a",
  "before": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 7,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "completion_id": "1c419c8c-54be-4524-98d2-48ebaca1651e",
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 8,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "completion_id": "1c419c8c-54be-4524-98d2-48ebaca1651e",
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "a1cd32df-403b-45f5-afbc-2ae625c471b6",
  "state_revision": 9,
  "recorded_at": "2026-09-09T14:46:08.703648Z",
  "product_version": "0.8.0",
  "request": {
    "version": 1,
    "operation_id": "3e9c1263-0251-4fed-8788-48c2898d190f",
    "workspace_id": "ecb141bf-b16e-4b9b-9de7-aa16d62d6e3d",
    "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "expected_revision": 8,
    "operation": "revoke_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fresh G5 fictional bounded request"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:46:08.699881Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/independent-01/workspace",
    "request_sha256": "472103f3755aff946394fb62feccf9198a066264b0fa172287ff6ac10749a46f"
  },
  "fingerprint": "6a4eab29637918996c96cb04daafdf38e2c3fb2277517a318b83310a5bd4802a",
  "before": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 8,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "completion_id": "1c419c8c-54be-4524-98d2-48ebaca1651e",
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 9,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "done",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "completion_id": "1c419c8c-54be-4524-98d2-48ebaca1651e",
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

