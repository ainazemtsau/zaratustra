# Zaratustra — generated overview

generated_from_revision: 2
generated_at: 2026-09-09T14:46:07.624067+00:00
workspace_id: ecb141bf-b16e-4b9b-9de7-aa16d62d6e3d

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
  "revision": 1,
  "created_at": "2026-09-09T14:46:07.579178Z",
  "kind": "artifact",
  "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
  "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
  "title": "Independent evidence",
  "status": "declared",
  "active_version": null
}
```

## event

```json
{
  "id": "f1ab5cac-b38c-4c88-8195-9daebeb25efc",
  "revision": 1,
  "created_at": "2026-09-09T14:46:07.579178Z",
  "kind": "event",
  "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
  "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.8.0",
  "state_revision": 1,
  "affected_ids": [
    "2af58028-96b5-41c7-8527-e6f387142032",
    "43353f8b-5629-494c-bee6-c7236fbb91de",
    "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81"
  ]
}
```

## process

```json
{
  "id": "2af58028-96b5-41c7-8527-e6f387142032",
  "revision": 1,
  "created_at": "2026-09-09T14:46:07.579178Z",
  "kind": "process",
  "title": "Unseen fictional review process"
}
```

## work

```json
{
  "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
  "revision": 2,
  "created_at": "2026-09-09T14:46:07.579178Z",
  "kind": "work",
  "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
  "goal": "Attempt to refute retained pack identity",
  "expected_result": "Exact persistent reference",
  "acceptance": [
    "Fictional review evidence"
  ],
  "boundaries": [
    "Review _scratch only"
  ],
  "budget": "One independent fixture",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": []
}
```

## Registered versions

## Mutation provenance

```json
{
  "id": "62517146-b4ca-400a-9ee4-2ea6d8550f75",
  "state_revision": 2,
  "recorded_at": "2026-09-09T14:46:07.624067Z",
  "product_version": "0.8.0",
  "request": {
    "version": 1,
    "operation_id": "14e2c63a-ab6b-4439-9ccf-18a326eebd9c",
    "workspace_id": "ecb141bf-b16e-4b9b-9de7-aa16d62d6e3d",
    "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fresh G5 fictional bounded request"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:46:07.621775Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/independent-01/workspace",
    "request_sha256": "3e67f398732815ace1cb6fee2465c12a66ee610615df6ebc9e1f35ecef3c1264"
  },
  "fingerprint": "f5ae38d3704193653286dfe697332410ef05ca37f798d3621b81760a1ca14fe7",
  "before": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 1,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 2,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

