# Zaratustra — generated overview

generated_from_revision: 6
generated_at: 2026-09-09T14:52:03.532115+00:00
workspace_id: ecb141bf-b16e-4b9b-9de7-aa16d62d6e3d

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
  "revision": 2,
  "created_at": "2026-09-09T14:46:07.579178Z",
  "kind": "artifact",
  "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
  "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
  "title": "Independent evidence",
  "status": "registered",
  "active_version": "2fefb8b3-d174-4c8e-9928-48035bb4bf72"
}
```

## event

```json
{
  "id": "f1ab5cac-b38c-4c88-8195-9daebeb25efc",
  "revision": 1,
  "created_at": "2026-09-09T14:46:07.579178Z",
  "kind": "event",
  "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
  "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.8.0",
  "state_revision": 1,
  "affected_ids": [
    "2af58028-96b5-41c7-8527-e6f387142032",
    "43353f8b-5629-494c-bee6-c7236fbb91de",
    "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81"
  ]
}
```

## process

```json
{
  "id": "2af58028-96b5-41c7-8527-e6f387142032",
  "revision": 3,
  "created_at": "2026-09-09T14:46:07.579178Z",
  "kind": "process",
  "title": "Unseen fictional review process",
  "pack_binding": {
    "pack_id": "review.unseen",
    "pack_version": "3.1.4",
    "process_type": "review.unseen-type",
    "contract_version": 1,
    "state_version": 2
  }
}
```

## work

```json
{
  "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
  "revision": 6,
  "created_at": "2026-09-09T14:46:07.579178Z",
  "kind": "work",
  "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
  "goal": "Attempt to refute retained pack identity",
  "expected_result": "Exact persistent reference",
  "acceptance": [
    "Fictional review evidence"
  ],
  "boundaries": [
    "Review _scratch only"
  ],
  "budget": "One independent fixture",
  "status": "ready",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [],
  "pack_binding": {
    "pack_id": "review.unseen",
    "pack_version": "3.1.4",
    "process_type": "review.unseen-type",
    "contract_version": 1,
    "state_version": 2
  }
}
```

## Registered versions

- Version: 2fefb8b3-d174-4c8e-9928-48035bb4bf72; Artifact revision: 2
  SHA-256: 32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154; bytes: 57
  File: artifacts/43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81/2fefb8b3-d174-4c8e-9928-48035bb4bf72.blob

## Mutation provenance

```json
{
  "id": "62517146-b4ca-400a-9ee4-2ea6d8550f75",
  "state_revision": 2,
  "recorded_at": "2026-09-09T14:46:07.624067Z",
  "product_version": "0.8.0",
  "request": {
    "version": 1,
    "operation_id": "14e2c63a-ab6b-4439-9ccf-18a326eebd9c",
    "workspace_id": "ecb141bf-b16e-4b9b-9de7-aa16d62d6e3d",
    "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fresh G5 fictional bounded request"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:46:07.621775Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/independent-01/workspace",
    "request_sha256": "3e67f398732815ace1cb6fee2465c12a66ee610615df6ebc9e1f35ecef3c1264"
  },
  "fingerprint": "f5ae38d3704193653286dfe697332410ef05ca37f798d3621b81760a1ca14fe7",
  "before": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 1,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 2,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "5ab9312e-3597-4df2-8a23-d02b7220da62",
  "state_revision": 3,
  "recorded_at": "2026-09-09T14:52:03.425002Z",
  "product_version": "0.8.0",
  "request": {
    "version": 5,
    "operation_id": "b313a51f-16f4-4e0d-a082-bbbcd17ab612",
    "workspace_id": "ecb141bf-b16e-4b9b-9de7-aa16d62d6e3d",
    "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "expected_revision": 2,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional generic Core reference; assess declared host boundary",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 2
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:52:03.421461Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/supplemental-01/generic-host-boundary",
    "request_sha256": "d875a106a98bb2a057dcf4b0cbe72bebda1551b159c19e420e2c20e19448ec18"
  },
  "fingerprint": "ac6a7cad803b85abc00952c7aeccc3696c477d786a78042dfd928435516736e9",
  "before": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 2,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 3,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 2
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "2af58028-96b5-41c7-8527-e6f387142032",
    "revision": 1,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "process",
    "title": "Unseen fictional review process"
  },
  "process_after": {
    "id": "2af58028-96b5-41c7-8527-e6f387142032",
    "revision": 3,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "process",
    "title": "Unseen fictional review process",
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 2
    }
  }
}
```

```json
{
  "id": "7297e9b1-a612-421d-a419-f73852e7c870",
  "state_revision": 4,
  "recorded_at": "2026-09-09T14:52:03.457783Z",
  "product_version": "0.8.0",
  "request": {
    "version": 2,
    "operation_id": "0cd284b8-1dc9-40cb-8c42-80fcdecc698d",
    "workspace_id": "ecb141bf-b16e-4b9b-9de7-aa16d62d6e3d",
    "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "expected_revision": 3,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fresh G5 fictional bounded request",
    "artifact_id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:52:03.454884Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/supplemental-01/generic-host-boundary",
    "request_sha256": "2ca2c4c44a65115fc56a6e44d20b7558c7d14da055217f9a67e8780d2423a5a2"
  },
  "fingerprint": "ef7313c424dd8bdebcdbaddab410ee8464f130f9f96d21c26498c24bead52903",
  "before": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 3,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 2
    }
  },
  "after": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 4,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 2
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "a55a1247-cc6c-4a40-a717-a86952fa5765",
  "state_revision": 5,
  "recorded_at": "2026-09-09T14:52:03.488222Z",
  "product_version": "0.8.0",
  "request": {
    "version": 2,
    "operation_id": "2fefb8b3-d174-4c8e-9928-48035bb4bf72",
    "workspace_id": "ecb141bf-b16e-4b9b-9de7-aa16d62d6e3d",
    "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "expected_revision": 4,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fresh G5 fictional bounded request",
    "artifact_id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
    "artifact_revision": 1,
    "content_sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154",
    "content_size": 57,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:52:03.485047Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/supplemental-01/generic-host-boundary",
    "request_sha256": "9df67233155b7dd4abd724d7b64fa88b929c73a070cc8275aae1bb79b134d643"
  },
  "fingerprint": "6058a2973dfc5a2390c78a94de6527a29f1eb9bf455058657c0d57393ee9e155",
  "before": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 4,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 2
    }
  },
  "after": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 5,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 2
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
    "revision": 1,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "artifact",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "title": "Independent evidence",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
    "revision": 2,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "artifact",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "title": "Independent evidence",
    "status": "registered",
    "active_version": "2fefb8b3-d174-4c8e-9928-48035bb4bf72"
  },
  "artifact_version": {
    "id": "2fefb8b3-d174-4c8e-9928-48035bb4bf72",
    "artifact_id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
    "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "artifact_revision": 2,
    "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154",
    "size": 57,
    "created_at": "2026-09-09T14:52:03.488222Z",
    "state_revision": 5
  }
}
```

```json
{
  "id": "61b1cb5d-03e3-4809-b8e8-665a0ce329a6",
  "state_revision": 6,
  "recorded_at": "2026-09-09T14:52:03.532115Z",
  "product_version": "0.8.0",
  "request": {
    "version": 3,
    "operation_id": "3a6fba5e-1b11-4507-8a34-5f8f97aa1507",
    "workspace_id": "ecb141bf-b16e-4b9b-9de7-aa16d62d6e3d",
    "work_id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "expected_revision": 5,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Independent fictional evidence",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
        "version_id": "2fefb8b3-d174-4c8e-9928-48035bb4bf72",
        "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "3a6fba5e-1b11-4507-8a34-5f8f97aa1507",
      "workspace_id": "ecb141bf-b16e-4b9b-9de7-aa16d62d6e3d",
      "process": "2af58028-96b5-41c7-8527-e6f387142032",
      "related_work": "43353f8b-5629-494c-bee6-c7236fbb91de",
      "intent": "accepted_result",
      "source_revision": 5,
      "result": {
        "artifact_id": "43da8ce6-e8b0-4d1c-8ba8-d4326e2ddc81",
        "version_id": "2fefb8b3-d174-4c8e-9928-48035bb4bf72",
        "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154"
      },
      "basis": [],
      "provenance": "Independent fictional evidence",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "Fresh G5 review"
    },
    "delivery": {
      "source_ref": "01a0869b-59b5-7b62-9e19-e2f8056f4341",
      "input_sha256": "691d62e1dcad5a0db02c77ea4762622c4ae02b09743ffc81771c6559419d0b86"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:52:03.528436Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/supplemental-01/generic-host-boundary",
    "request_sha256": "1fe1c007518af7f758166c77ca71b10c71f2918947b2e1761a35b60b31c076ba"
  },
  "fingerprint": "ed4288ba3851aec713f4b9197edf3e9a9216c9d17fa213bc6c897889ee985395",
  "before": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 5,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 2
    }
  },
  "after": {
    "id": "43353f8b-5629-494c-bee6-c7236fbb91de",
    "revision": 6,
    "created_at": "2026-09-09T14:46:07.579178Z",
    "kind": "work",
    "process_id": "2af58028-96b5-41c7-8527-e6f387142032",
    "goal": "Attempt to refute retained pack identity",
    "expected_result": "Exact persistent reference",
    "acceptance": [
      "Fictional review evidence"
    ],
    "boundaries": [
      "Review _scratch only"
    ],
    "budget": "One independent fixture",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "3.1.4",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 2
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

