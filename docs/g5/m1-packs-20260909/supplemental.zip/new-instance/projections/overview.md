# Zaratustra — generated overview

generated_from_revision: 11
generated_at: 2026-09-09T14:52:03.323053+00:00
workspace_id: 403ac8a8-067b-42aa-b634-07fdcef2d082

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "909925cf-7324-4071-a012-d1bd537356bd",
  "revision": 2,
  "created_at": "2026-09-09T14:52:02.890239Z",
  "kind": "artifact",
  "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
  "work_id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
  "title": "New observation",
  "status": "registered",
  "active_version": "a1374243-6906-4f9b-bbd8-d500bf46c0ef"
}
```

## artifact

```json
{
  "id": "98eff4c4-8104-4f36-bea6-bfa48905c524",
  "revision": 2,
  "created_at": "2026-09-09T14:52:03.131103Z",
  "kind": "artifact",
  "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
  "work_id": "f2e94d16-19fa-4313-9366-6e7290939d93",
  "title": "Independent next artifact",
  "status": "registered",
  "active_version": "c4cc3218-336a-46eb-9173-aa5265404292"
}
```

## artifact

```json
{
  "id": "a08eca0c-ee7e-4449-9fd4-c74748904e53",
  "revision": 1,
  "created_at": "2026-09-09T14:52:03.323053Z",
  "kind": "artifact",
  "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
  "work_id": "5e54eb7e-15b6-4db1-87d5-374031811f4a",
  "title": "Independent next artifact",
  "status": "declared",
  "active_version": null
}
```

## event

```json
{
  "id": "26935af3-b447-4e7c-8856-99e627b9733a",
  "revision": 1,
  "created_at": "2026-09-09T14:52:02.890239Z",
  "kind": "event",
  "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
  "work_id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.8.0",
  "state_revision": 1,
  "affected_ids": [
    "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "909925cf-7324-4071-a012-d1bd537356bd"
  ]
}
```

## process

```json
{
  "id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
  "revision": 3,
  "created_at": "2026-09-09T14:52:02.890239Z",
  "kind": "process",
  "title": "Separate fictional G5 instance",
  "pack_binding": {
    "pack_id": "review.unseen",
    "pack_version": "9.0.0",
    "process_type": "review.unseen-type",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "5e54eb7e-15b6-4db1-87d5-374031811f4a",
  "revision": 11,
  "created_at": "2026-09-09T14:52:03.323053Z",
  "kind": "work",
  "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
  "goal": "Fictional continuation new distinct instance",
  "expected_result": "Independent retained observation",
  "acceptance": [
    "Fictional check"
  ],
  "boundaries": [
    "Review-only fixture"
  ],
  "budget": "One review transition",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "review.external-rule"
  ],
  "pack_binding": {
    "pack_id": "review.unseen",
    "pack_version": "9.0.0",
    "process_type": "review.unseen-type",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
  "revision": 7,
  "created_at": "2026-09-09T14:52:02.890239Z",
  "kind": "work",
  "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
  "goal": "Run an explicitly chosen newer pack",
  "expected_result": "Pinned continuation",
  "acceptance": [
    "Fictional only"
  ],
  "boundaries": [
    "G5 review workspace"
  ],
  "budget": "Two bounded transitions",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [],
  "completion_id": "c2ceb909-26a4-49ce-a56f-2c7718be8e61",
  "pack_binding": {
    "pack_id": "review.unseen",
    "pack_version": "9.0.0",
    "process_type": "review.unseen-type",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "f2e94d16-19fa-4313-9366-6e7290939d93",
  "revision": 11,
  "created_at": "2026-09-09T14:52:03.131103Z",
  "kind": "work",
  "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
  "goal": "Fictional continuation new distinct instance",
  "expected_result": "Independent retained observation",
  "acceptance": [
    "Fictional check"
  ],
  "boundaries": [
    "Review-only fixture"
  ],
  "budget": "One review transition",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "review.external-rule"
  ],
  "completion_id": "715d78b2-178e-4750-851b-b6b6bff52d21",
  "pack_binding": {
    "pack_id": "review.unseen",
    "pack_version": "9.0.0",
    "process_type": "review.unseen-type",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: a1374243-6906-4f9b-bbd8-d500bf46c0ef; Artifact revision: 2
  SHA-256: 32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154; bytes: 57
  File: artifacts/909925cf-7324-4071-a012-d1bd537356bd/a1374243-6906-4f9b-bbd8-d500bf46c0ef.blob

- Version: c4cc3218-336a-46eb-9173-aa5265404292; Artifact revision: 2
  SHA-256: 32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154; bytes: 57
  File: artifacts/98eff4c4-8104-4f36-bea6-bfa48905c524/c4cc3218-336a-46eb-9173-aa5265404292.blob

## Mutation provenance

```json
{
  "id": "ad1deb2c-4b4b-4cfb-b957-cc674f190f00",
  "state_revision": 2,
  "recorded_at": "2026-09-09T14:52:02.937430Z",
  "product_version": "0.8.0",
  "request": {
    "version": 1,
    "operation_id": "e9501483-c5ea-4679-a35c-fad95a864ea1",
    "workspace_id": "403ac8a8-067b-42aa-b634-07fdcef2d082",
    "work_id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fresh G5 fictional bounded request"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:52:02.934702Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/supplemental-01/new-instance",
    "request_sha256": "448a611a37108b74082f360a8e31eae2bec7ef58b461b0e29d6ca460e8a7310a"
  },
  "fingerprint": "f63006e263035ae37f53b4b0c5a739db64e2ad8ca1831f974dfc4818ad76006a",
  "before": {
    "id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "revision": 1,
    "created_at": "2026-09-09T14:52:02.890239Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Run an explicitly chosen newer pack",
    "expected_result": "Pinned continuation",
    "acceptance": [
      "Fictional only"
    ],
    "boundaries": [
      "G5 review workspace"
    ],
    "budget": "Two bounded transitions",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "revision": 2,
    "created_at": "2026-09-09T14:52:02.890239Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Run an explicitly chosen newer pack",
    "expected_result": "Pinned continuation",
    "acceptance": [
      "Fictional only"
    ],
    "boundaries": [
      "G5 review workspace"
    ],
    "budget": "Two bounded transitions",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "397710e1-990d-42ec-9709-f2c8b5e404d6",
  "state_revision": 3,
  "recorded_at": "2026-09-09T14:52:02.977136Z",
  "product_version": "0.8.0",
  "request": {
    "version": 5,
    "operation_id": "444b76c0-bd4a-430d-b06a-ed32be569d39",
    "workspace_id": "403ac8a8-067b-42aa-b634-07fdcef2d082",
    "work_id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "expected_revision": 2,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fresh G5 explicit fictional binding",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "9.0.0",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:52:02.974537Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/supplemental-01/new-instance",
    "request_sha256": "25e7d66e7ca484458e69c74e3f7047f7e7d1a2ab56020ef0c9b2ba6dd6ba6cbb"
  },
  "fingerprint": "9109fffb34d73123dd7ab8e6c34ef1e859ac773c90586c2975441266b0717c4b",
  "before": {
    "id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "revision": 2,
    "created_at": "2026-09-09T14:52:02.890239Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Run an explicitly chosen newer pack",
    "expected_result": "Pinned continuation",
    "acceptance": [
      "Fictional only"
    ],
    "boundaries": [
      "G5 review workspace"
    ],
    "budget": "Two bounded transitions",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "revision": 3,
    "created_at": "2026-09-09T14:52:02.890239Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Run an explicitly chosen newer pack",
    "expected_result": "Pinned continuation",
    "acceptance": [
      "Fictional only"
    ],
    "boundaries": [
      "G5 review workspace"
    ],
    "budget": "Two bounded transitions",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "9.0.0",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "revision": 1,
    "created_at": "2026-09-09T14:52:02.890239Z",
    "kind": "process",
    "title": "Separate fictional G5 instance"
  },
  "process_after": {
    "id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "revision": 3,
    "created_at": "2026-09-09T14:52:02.890239Z",
    "kind": "process",
    "title": "Separate fictional G5 instance",
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "9.0.0",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "8ffd9f46-744b-443f-b43b-1450ac424b9e",
  "state_revision": 4,
  "recorded_at": "2026-09-09T14:52:03.017470Z",
  "product_version": "0.8.0",
  "request": {
    "version": 2,
    "operation_id": "0943a515-71ee-4754-b0b6-d97d2ce75f58",
    "workspace_id": "403ac8a8-067b-42aa-b634-07fdcef2d082",
    "work_id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "expected_revision": 3,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fresh G5 fictional bounded request",
    "artifact_id": "909925cf-7324-4071-a012-d1bd537356bd",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:52:03.014383Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/supplemental-01/new-instance",
    "request_sha256": "2cd4f22b441b5f97bad102a24d560397b7f3742b098a2855c1aecf6493f23dfb"
  },
  "fingerprint": "e6c1ab886674ce7c9ae82d51e367f99b232e23666321e6f9ff2cf851d47cebf9",
  "before": {
    "id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "revision": 3,
    "created_at": "2026-09-09T14:52:02.890239Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Run an explicitly chosen newer pack",
    "expected_result": "Pinned continuation",
    "acceptance": [
      "Fictional only"
    ],
    "boundaries": [
      "G5 review workspace"
    ],
    "budget": "Two bounded transitions",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "9.0.0",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "revision": 4,
    "created_at": "2026-09-09T14:52:02.890239Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Run an explicitly chosen newer pack",
    "expected_result": "Pinned continuation",
    "acceptance": [
      "Fictional only"
    ],
    "boundaries": [
      "G5 review workspace"
    ],
    "budget": "Two bounded transitions",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "9.0.0",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "aa5bcb26-061c-450b-8245-d49588416774",
  "state_revision": 5,
  "recorded_at": "2026-09-09T14:52:03.045371Z",
  "product_version": "0.8.0",
  "request": {
    "version": 2,
    "operation_id": "a1374243-6906-4f9b-bbd8-d500bf46c0ef",
    "workspace_id": "403ac8a8-067b-42aa-b634-07fdcef2d082",
    "work_id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "expected_revision": 4,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fresh G5 fictional bounded request",
    "artifact_id": "909925cf-7324-4071-a012-d1bd537356bd",
    "artifact_revision": 1,
    "content_sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154",
    "content_size": 57,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:52:03.042770Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/supplemental-01/new-instance",
    "request_sha256": "bf22e405a2bbaa3c39efd985abb2b8578806d17efb52939f24f43e7b8f3949af"
  },
  "fingerprint": "f33048269946e2b5ffcd315a86e2730c1e66cdc69ffe0118e4c9c2c3c6a55a41",
  "before": {
    "id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "revision": 4,
    "created_at": "2026-09-09T14:52:02.890239Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Run an explicitly chosen newer pack",
    "expected_result": "Pinned continuation",
    "acceptance": [
      "Fictional only"
    ],
    "boundaries": [
      "G5 review workspace"
    ],
    "budget": "Two bounded transitions",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "9.0.0",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "revision": 5,
    "created_at": "2026-09-09T14:52:02.890239Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Run an explicitly chosen newer pack",
    "expected_result": "Pinned continuation",
    "acceptance": [
      "Fictional only"
    ],
    "boundaries": [
      "G5 review workspace"
    ],
    "budget": "Two bounded transitions",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "9.0.0",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "909925cf-7324-4071-a012-d1bd537356bd",
    "revision": 1,
    "created_at": "2026-09-09T14:52:02.890239Z",
    "kind": "artifact",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "work_id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "title": "New observation",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "909925cf-7324-4071-a012-d1bd537356bd",
    "revision": 2,
    "created_at": "2026-09-09T14:52:02.890239Z",
    "kind": "artifact",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "work_id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "title": "New observation",
    "status": "registered",
    "active_version": "a1374243-6906-4f9b-bbd8-d500bf46c0ef"
  },
  "artifact_version": {
    "id": "a1374243-6906-4f9b-bbd8-d500bf46c0ef",
    "artifact_id": "909925cf-7324-4071-a012-d1bd537356bd",
    "work_id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "artifact_revision": 2,
    "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154",
    "size": 57,
    "created_at": "2026-09-09T14:52:03.045371Z",
    "state_revision": 5
  }
}
```

```json
{
  "id": "4de58df3-af5e-439c-a62a-3d4daa1bc232",
  "state_revision": 6,
  "recorded_at": "2026-09-09T14:52:03.081688Z",
  "product_version": "0.8.0",
  "request": {
    "version": 3,
    "operation_id": "3222962c-3748-48ed-8b5d-f6f8f1ba711e",
    "workspace_id": "403ac8a8-067b-42aa-b634-07fdcef2d082",
    "work_id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "expected_revision": 5,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Independent fictional evidence",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "909925cf-7324-4071-a012-d1bd537356bd",
        "version_id": "a1374243-6906-4f9b-bbd8-d500bf46c0ef",
        "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "3222962c-3748-48ed-8b5d-f6f8f1ba711e",
      "workspace_id": "403ac8a8-067b-42aa-b634-07fdcef2d082",
      "process": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
      "related_work": "9921526d-0edd-4513-9d3f-1feba3f0b629",
      "intent": "accepted_result",
      "source_revision": 5,
      "result": {
        "artifact_id": "909925cf-7324-4071-a012-d1bd537356bd",
        "version_id": "a1374243-6906-4f9b-bbd8-d500bf46c0ef",
        "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154"
      },
      "basis": [],
      "provenance": "Independent fictional evidence",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "Fresh G5 review"
    },
    "delivery": {
      "source_ref": "01a0869b-59b5-7b62-9e19-e2f8056f4341",
      "input_sha256": "c094bfcae677151033c24f31430a3334c2a455e95418c30818c5adf3a9b8ca0d"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:52:03.078567Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/supplemental-01/new-instance",
    "request_sha256": "b20ab781087670ba067676b20b16ac5568c23ec10d6240888ceab1c98bbe05c1"
  },
  "fingerprint": "89474fcab985eb2180877e19fd6368a6c0e357f0e179f599f30de80a3cf4bfcb",
  "before": {
    "id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "revision": 5,
    "created_at": "2026-09-09T14:52:02.890239Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Run an explicitly chosen newer pack",
    "expected_result": "Pinned continuation",
    "acceptance": [
      "Fictional only"
    ],
    "boundaries": [
      "G5 review workspace"
    ],
    "budget": "Two bounded transitions",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "9.0.0",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "revision": 6,
    "created_at": "2026-09-09T14:52:02.890239Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Run an explicitly chosen newer pack",
    "expected_result": "Pinned continuation",
    "acceptance": [
      "Fictional only"
    ],
    "boundaries": [
      "G5 review workspace"
    ],
    "budget": "Two bounded transitions",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "9.0.0",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "a7ec46bd-12b9-4240-8f51-937912660696",
  "state_revision": 7,
  "recorded_at": "2026-09-09T14:52:03.131103Z",
  "product_version": "0.8.0",
  "request": {
    "version": 4,
    "operation_id": "c2ceb909-26a4-49ce-a56f-2c7718be8e61",
    "workspace_id": "403ac8a8-067b-42aa-b634-07fdcef2d082",
    "work_id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "expected_revision": 6,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"review.unseen\",\"pack_version\":\"9.0.0\",\"process_type\":\"review.unseen-type\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "909925cf-7324-4071-a012-d1bd537356bd",
        "version_id": "a1374243-6906-4f9b-bbd8-d500bf46c0ef",
        "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 6,
      "result": {
        "artifact_id": "909925cf-7324-4071-a012-d1bd537356bd",
        "version_id": "a1374243-6906-4f9b-bbd8-d500bf46c0ef",
        "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154"
      },
      "acceptance_ids": [
        "3222962c-3748-48ed-8b5d-f6f8f1ba711e"
      ],
      "next_work": {
        "work_id": "f2e94d16-19fa-4313-9366-6e7290939d93",
        "artifact_id": "98eff4c4-8104-4f36-bea6-bfa48905c524",
        "goal": "Fictional continuation new distinct instance",
        "expected_result": "Independent retained observation",
        "acceptance": [
          "Fictional check"
        ],
        "boundaries": [
          "Review-only fixture"
        ],
        "budget": "One review transition",
        "executor_requirements": [
          "review.external-rule"
        ],
        "artifact_title": "Independent next artifact",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:52:03.127162Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/supplemental-01/new-instance",
    "request_sha256": "a08458ba1f190335293d1cc74337cef6ae91eded39fde716145df0bf814ef737"
  },
  "fingerprint": "3e1f4f8bbbda5e07d1d120ca74b00d60500e32ab44f52a3d9730c86353dff1dd",
  "before": {
    "id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "revision": 6,
    "created_at": "2026-09-09T14:52:02.890239Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Run an explicitly chosen newer pack",
    "expected_result": "Pinned continuation",
    "acceptance": [
      "Fictional only"
    ],
    "boundaries": [
      "G5 review workspace"
    ],
    "budget": "Two bounded transitions",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "9.0.0",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "revision": 7,
    "created_at": "2026-09-09T14:52:02.890239Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Run an explicitly chosen newer pack",
    "expected_result": "Pinned continuation",
    "acceptance": [
      "Fictional only"
    ],
    "boundaries": [
      "G5 review workspace"
    ],
    "budget": "Two bounded transitions",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [],
    "completion_id": "c2ceb909-26a4-49ce-a56f-2c7718be8e61",
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "9.0.0",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "f2e94d16-19fa-4313-9366-6e7290939d93",
    "revision": 7,
    "created_at": "2026-09-09T14:52:03.131103Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Fictional continuation new distinct instance",
    "expected_result": "Independent retained observation",
    "acceptance": [
      "Fictional check"
    ],
    "boundaries": [
      "Review-only fixture"
    ],
    "budget": "One review transition",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "review.external-rule"
    ],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "9.0.0",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "98eff4c4-8104-4f36-bea6-bfa48905c524",
    "revision": 1,
    "created_at": "2026-09-09T14:52:03.131103Z",
    "kind": "artifact",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "work_id": "f2e94d16-19fa-4313-9366-6e7290939d93",
    "title": "Independent next artifact",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "909925cf-7324-4071-a012-d1bd537356bd",
    "revision": 2,
    "created_at": "2026-09-09T14:52:02.890239Z",
    "kind": "artifact",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "work_id": "9921526d-0edd-4513-9d3f-1feba3f0b629",
    "title": "New observation",
    "status": "registered",
    "active_version": "a1374243-6906-4f9b-bbd8-d500bf46c0ef"
  },
  "result_references": [
    {
      "artifact_id": "909925cf-7324-4071-a012-d1bd537356bd",
      "version_id": "a1374243-6906-4f9b-bbd8-d500bf46c0ef",
      "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154"
    }
  ]
}
```

```json
{
  "id": "63ec1ddc-b86b-4c19-916f-787b44df73be",
  "state_revision": 8,
  "recorded_at": "2026-09-09T14:52:03.172103Z",
  "product_version": "0.8.0",
  "request": {
    "version": 2,
    "operation_id": "df6b3705-5c6e-469a-b1db-e0c54574987d",
    "workspace_id": "403ac8a8-067b-42aa-b634-07fdcef2d082",
    "work_id": "f2e94d16-19fa-4313-9366-6e7290939d93",
    "expected_revision": 7,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fresh G5 fictional bounded request",
    "artifact_id": "98eff4c4-8104-4f36-bea6-bfa48905c524",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:52:03.168595Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/supplemental-01/new-instance",
    "request_sha256": "0fa5d63cf284a80e192ee45876074398a50614cdd95594455fe5e5576096de82"
  },
  "fingerprint": "a36c2ca4b4ec14f41cd9c2de8f23846d503175ee77e50df9c17a291c4cf51e83",
  "before": {
    "id": "f2e94d16-19fa-4313-9366-6e7290939d93",
    "revision": 7,
    "created_at": "2026-09-09T14:52:03.131103Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Fictional continuation new distinct instance",
    "expected_result": "Independent retained observation",
    "acceptance": [
      "Fictional check"
    ],
    "boundaries": [
      "Review-only fixture"
    ],
    "budget": "One review transition",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "review.external-rule"
    ],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "9.0.0",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "f2e94d16-19fa-4313-9366-6e7290939d93",
    "revision": 8,
    "created_at": "2026-09-09T14:52:03.131103Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Fictional continuation new distinct instance",
    "expected_result": "Independent retained observation",
    "acceptance": [
      "Fictional check"
    ],
    "boundaries": [
      "Review-only fixture"
    ],
    "budget": "One review transition",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "review.external-rule"
    ],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "9.0.0",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "0873214a-d746-4f53-9f18-ef62ecf87a40",
  "state_revision": 9,
  "recorded_at": "2026-09-09T14:52:03.205141Z",
  "product_version": "0.8.0",
  "request": {
    "version": 2,
    "operation_id": "c4cc3218-336a-46eb-9173-aa5265404292",
    "workspace_id": "403ac8a8-067b-42aa-b634-07fdcef2d082",
    "work_id": "f2e94d16-19fa-4313-9366-6e7290939d93",
    "expected_revision": 8,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fresh G5 fictional bounded request",
    "artifact_id": "98eff4c4-8104-4f36-bea6-bfa48905c524",
    "artifact_revision": 1,
    "content_sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154",
    "content_size": 57,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:52:03.201253Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/supplemental-01/new-instance",
    "request_sha256": "8e3ef76a046145abaf8fbb3d079649b6c08d3088c7d9ac7e836f6e8d9cd59f31"
  },
  "fingerprint": "753cb5a208bee9536c48950b7b6be5c99a97f68b31c45916d588d61037bf1504",
  "before": {
    "id": "f2e94d16-19fa-4313-9366-6e7290939d93",
    "revision": 8,
    "created_at": "2026-09-09T14:52:03.131103Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Fictional continuation new distinct instance",
    "expected_result": "Independent retained observation",
    "acceptance": [
      "Fictional check"
    ],
    "boundaries": [
      "Review-only fixture"
    ],
    "budget": "One review transition",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "review.external-rule"
    ],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "9.0.0",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "f2e94d16-19fa-4313-9366-6e7290939d93",
    "revision": 9,
    "created_at": "2026-09-09T14:52:03.131103Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Fictional continuation new distinct instance",
    "expected_result": "Independent retained observation",
    "acceptance": [
      "Fictional check"
    ],
    "boundaries": [
      "Review-only fixture"
    ],
    "budget": "One review transition",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "review.external-rule"
    ],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "9.0.0",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "98eff4c4-8104-4f36-bea6-bfa48905c524",
    "revision": 1,
    "created_at": "2026-09-09T14:52:03.131103Z",
    "kind": "artifact",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "work_id": "f2e94d16-19fa-4313-9366-6e7290939d93",
    "title": "Independent next artifact",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "98eff4c4-8104-4f36-bea6-bfa48905c524",
    "revision": 2,
    "created_at": "2026-09-09T14:52:03.131103Z",
    "kind": "artifact",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "work_id": "f2e94d16-19fa-4313-9366-6e7290939d93",
    "title": "Independent next artifact",
    "status": "registered",
    "active_version": "c4cc3218-336a-46eb-9173-aa5265404292"
  },
  "artifact_version": {
    "id": "c4cc3218-336a-46eb-9173-aa5265404292",
    "artifact_id": "98eff4c4-8104-4f36-bea6-bfa48905c524",
    "work_id": "f2e94d16-19fa-4313-9366-6e7290939d93",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "artifact_revision": 2,
    "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154",
    "size": 57,
    "created_at": "2026-09-09T14:52:03.205141Z",
    "state_revision": 9
  }
}
```

```json
{
  "id": "95c2c57b-3007-49a3-801c-4032b95c038c",
  "state_revision": 10,
  "recorded_at": "2026-09-09T14:52:03.252364Z",
  "product_version": "0.8.0",
  "request": {
    "version": 3,
    "operation_id": "2cfe7f93-bdd3-4b7e-be8c-37c592af7405",
    "workspace_id": "403ac8a8-067b-42aa-b634-07fdcef2d082",
    "work_id": "f2e94d16-19fa-4313-9366-6e7290939d93",
    "expected_revision": 9,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Independent fictional evidence",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "98eff4c4-8104-4f36-bea6-bfa48905c524",
        "version_id": "c4cc3218-336a-46eb-9173-aa5265404292",
        "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "2cfe7f93-bdd3-4b7e-be8c-37c592af7405",
      "workspace_id": "403ac8a8-067b-42aa-b634-07fdcef2d082",
      "process": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
      "related_work": "f2e94d16-19fa-4313-9366-6e7290939d93",
      "intent": "accepted_result",
      "source_revision": 9,
      "result": {
        "artifact_id": "98eff4c4-8104-4f36-bea6-bfa48905c524",
        "version_id": "c4cc3218-336a-46eb-9173-aa5265404292",
        "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154"
      },
      "basis": [],
      "provenance": "Independent fictional evidence",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "Fresh G5 review"
    },
    "delivery": {
      "source_ref": "01a0869b-59b5-7b62-9e19-e2f8056f4341",
      "input_sha256": "15623f9da8bcd2d178e7ea6b2029b7815bcaf5cda091abe3f2f413d1d4f4dab2"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:52:03.246904Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/supplemental-01/new-instance",
    "request_sha256": "9d4acd5f21bc92edf8b001999b1d9cc4f8211caecf910555eeaac207fa2ddc1a"
  },
  "fingerprint": "9c1678b629da64e16e48115bbfbd98c7f1f2992cb3d507768266591d79431874",
  "before": {
    "id": "f2e94d16-19fa-4313-9366-6e7290939d93",
    "revision": 9,
    "created_at": "2026-09-09T14:52:03.131103Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Fictional continuation new distinct instance",
    "expected_result": "Independent retained observation",
    "acceptance": [
      "Fictional check"
    ],
    "boundaries": [
      "Review-only fixture"
    ],
    "budget": "One review transition",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "review.external-rule"
    ],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "9.0.0",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "f2e94d16-19fa-4313-9366-6e7290939d93",
    "revision": 10,
    "created_at": "2026-09-09T14:52:03.131103Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Fictional continuation new distinct instance",
    "expected_result": "Independent retained observation",
    "acceptance": [
      "Fictional check"
    ],
    "boundaries": [
      "Review-only fixture"
    ],
    "budget": "One review transition",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "review.external-rule"
    ],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "9.0.0",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "e7f2b852-1feb-44e0-99b0-fe1daac9eb9f",
  "state_revision": 11,
  "recorded_at": "2026-09-09T14:52:03.323053Z",
  "product_version": "0.8.0",
  "request": {
    "version": 4,
    "operation_id": "715d78b2-178e-4750-851b-b6b6bff52d21",
    "workspace_id": "403ac8a8-067b-42aa-b634-07fdcef2d082",
    "work_id": "f2e94d16-19fa-4313-9366-6e7290939d93",
    "expected_revision": 10,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"review.unseen\",\"pack_version\":\"9.0.0\",\"process_type\":\"review.unseen-type\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "98eff4c4-8104-4f36-bea6-bfa48905c524",
        "version_id": "c4cc3218-336a-46eb-9173-aa5265404292",
        "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 10,
      "result": {
        "artifact_id": "98eff4c4-8104-4f36-bea6-bfa48905c524",
        "version_id": "c4cc3218-336a-46eb-9173-aa5265404292",
        "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154"
      },
      "acceptance_ids": [
        "2cfe7f93-bdd3-4b7e-be8c-37c592af7405"
      ],
      "next_work": {
        "work_id": "5e54eb7e-15b6-4db1-87d5-374031811f4a",
        "artifact_id": "a08eca0c-ee7e-4449-9fd4-c74748904e53",
        "goal": "Fictional continuation new distinct instance",
        "expected_result": "Independent retained observation",
        "acceptance": [
          "Fictional check"
        ],
        "boundaries": [
          "Review-only fixture"
        ],
        "budget": "One review transition",
        "executor_requirements": [
          "review.external-rule"
        ],
        "artifact_title": "Independent next artifact",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-physical-G5-fictional-review",
    "source_ref": "Owner authorized G5 in source task 01a0865e-b759-7bf3-9d21-e86819e52156; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; fictional fixture only; owner acceptance pending",
    "confirmed_at": "2026-09-09T14:52:03.317049Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/supplemental-01/new-instance",
    "request_sha256": "8de96c160793ac05992178e17dff5eb000d2a11bd64f9634574c20d08fcc488c"
  },
  "fingerprint": "24a6a29e1f3f9848f06a375e6afb95abc3b9323de397f7aa2cc8e020cce24c58",
  "before": {
    "id": "f2e94d16-19fa-4313-9366-6e7290939d93",
    "revision": 10,
    "created_at": "2026-09-09T14:52:03.131103Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Fictional continuation new distinct instance",
    "expected_result": "Independent retained observation",
    "acceptance": [
      "Fictional check"
    ],
    "boundaries": [
      "Review-only fixture"
    ],
    "budget": "One review transition",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "review.external-rule"
    ],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "9.0.0",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "f2e94d16-19fa-4313-9366-6e7290939d93",
    "revision": 11,
    "created_at": "2026-09-09T14:52:03.131103Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Fictional continuation new distinct instance",
    "expected_result": "Independent retained observation",
    "acceptance": [
      "Fictional check"
    ],
    "boundaries": [
      "Review-only fixture"
    ],
    "budget": "One review transition",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "review.external-rule"
    ],
    "completion_id": "715d78b2-178e-4750-851b-b6b6bff52d21",
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "9.0.0",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "5e54eb7e-15b6-4db1-87d5-374031811f4a",
    "revision": 11,
    "created_at": "2026-09-09T14:52:03.323053Z",
    "kind": "work",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "goal": "Fictional continuation new distinct instance",
    "expected_result": "Independent retained observation",
    "acceptance": [
      "Fictional check"
    ],
    "boundaries": [
      "Review-only fixture"
    ],
    "budget": "One review transition",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "review.external-rule"
    ],
    "pack_binding": {
      "pack_id": "review.unseen",
      "pack_version": "9.0.0",
      "process_type": "review.unseen-type",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "a08eca0c-ee7e-4449-9fd4-c74748904e53",
    "revision": 1,
    "created_at": "2026-09-09T14:52:03.323053Z",
    "kind": "artifact",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "work_id": "5e54eb7e-15b6-4db1-87d5-374031811f4a",
    "title": "Independent next artifact",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "98eff4c4-8104-4f36-bea6-bfa48905c524",
    "revision": 2,
    "created_at": "2026-09-09T14:52:03.131103Z",
    "kind": "artifact",
    "process_id": "a8984e6e-7099-4dbd-b4de-5f6883fd474d",
    "work_id": "f2e94d16-19fa-4313-9366-6e7290939d93",
    "title": "Independent next artifact",
    "status": "registered",
    "active_version": "c4cc3218-336a-46eb-9173-aa5265404292"
  },
  "result_references": [
    {
      "artifact_id": "98eff4c4-8104-4f36-bea6-bfa48905c524",
      "version_id": "c4cc3218-336a-46eb-9173-aa5265404292",
      "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154"
    },
    {
      "artifact_id": "909925cf-7324-4071-a012-d1bd537356bd",
      "version_id": "a1374243-6906-4f9b-bbd8-d500bf46c0ef",
      "sha256": "32213d3e00e4cbc005916f88f0f1fb2939db275c350012b61da5827570f28154"
    }
  ]
}
```

