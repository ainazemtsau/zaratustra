# Zaratustra — generated overview

generated_from_revision: 10
generated_at: 2026-09-09T14:50:01.106531+00:00
workspace_id: 79808c51-1d22-4dad-a30a-5d5a6a87ba95

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "5cd8f6cd-d081-44c2-8d11-26606f209cc6",
  "revision": 3,
  "created_at": "2026-09-09T13:37:57.658036Z",
  "kind": "artifact",
  "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
  "work_id": "d3e60b63-5569-4eec-b631-c217dace2472",
  "title": "Fictional observation",
  "status": "registered",
  "active_version": "162287df-92c3-4649-b8d6-04da6365c796"
}
```

## artifact

```json
{
  "id": "c4fbe44c-beba-413a-a808-4b8d15964da7",
  "revision": 1,
  "created_at": "2026-09-09T14:50:01.106531Z",
  "kind": "artifact",
  "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
  "work_id": "0c7e94d8-1fe3-4ded-878f-4bcd2403b54a",
  "title": "Next fictional batch observation",
  "status": "declared",
  "active_version": null
}
```

## event

```json
{
  "id": "cd5acde4-9de7-4f98-8ebb-d81dd186754f",
  "revision": 1,
  "created_at": "2026-09-09T13:37:57.658036Z",
  "kind": "event",
  "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
  "work_id": "d3e60b63-5569-4eec-b631-c217dace2472",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.7.0",
  "state_revision": 1,
  "affected_ids": [
    "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "d3e60b63-5569-4eec-b631-c217dace2472",
    "5cd8f6cd-d081-44c2-8d11-26606f209cc6"
  ]
}
```

## process

```json
{
  "id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
  "revision": 1,
  "created_at": "2026-09-09T13:37:57.658036Z",
  "kind": "process",
  "title": "Fictional probe.batch/v1"
}
```

## work

```json
{
  "id": "0c7e94d8-1fe3-4ded-878f-4bcd2403b54a",
  "revision": 10,
  "created_at": "2026-09-09T14:50:01.106531Z",
  "kind": "work",
  "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
  "goal": "Inspect the next fictional batch",
  "expected_result": "Both independent marks",
  "acceptance": [
    "Observation and recording marks are both present"
  ],
  "boundaries": [
    "Local fictional workspace only"
  ],
  "budget": "One minimal rule contrast",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ]
}
```

## work

```json
{
  "id": "d3e60b63-5569-4eec-b631-c217dace2472",
  "revision": 10,
  "created_at": "2026-09-09T13:37:57.658036Z",
  "kind": "work",
  "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
  "goal": "Evaluate the selected fictional rule",
  "expected_result": "Exact recorded observation and permitted continuation",
  "acceptance": [
    "Only explicitly selected fictional inputs"
  ],
  "boundaries": [
    "Local fictional workspace only"
  ],
  "budget": "One minimal rule contrast",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ],
  "completion_id": "8469b776-a88f-4c44-afa3-39f714cd6970"
}
```

## Registered versions

- Version: 8e662996-f459-4d98-a9c0-ca2a300c0b32; Artifact revision: 2
  SHA-256: 1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568; bytes: 38
  File: artifacts/5cd8f6cd-d081-44c2-8d11-26606f209cc6/8e662996-f459-4d98-a9c0-ca2a300c0b32.blob

- Version: 162287df-92c3-4649-b8d6-04da6365c796; Artifact revision: 3
  SHA-256: 662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35; bytes: 37
  File: artifacts/5cd8f6cd-d081-44c2-8d11-26606f209cc6/162287df-92c3-4649-b8d6-04da6365c796.blob

## Mutation provenance

```json
{
  "id": "3a5c2dfe-f53b-4c32-b554-80a0a12550b7",
  "state_revision": 2,
  "recorded_at": "2026-09-09T13:37:57.693986Z",
  "product_version": "0.7.0",
  "request": {
    "version": 1,
    "operation_id": "62c6cc0e-ee13-4ad7-a9bb-e0d4ca01439c",
    "workspace_id": "79808c51-1d22-4dad-a30a-5d5a6a87ba95",
    "work_id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T13:37:57.690902Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-baseline-probe/batch/workspace",
    "request_sha256": "f938b42d08f9ec9d3922e2916d2582df43bef6a93a347cdb80d89106de03d4cc"
  },
  "fingerprint": "af7c14d544f4ce32f8f6c5c4a85074a83aca1ca9a5f80dd37b42e2f33f7539e1",
  "before": {
    "id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "revision": 1,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "work",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "revision": 2,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "work",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "64e49e15-b016-4426-8811-05de4543f6e5",
  "state_revision": 3,
  "recorded_at": "2026-09-09T13:37:57.722134Z",
  "product_version": "0.7.0",
  "request": {
    "version": 1,
    "operation_id": "15752bab-ce84-475a-b1a0-64efae5672f6",
    "workspace_id": "79808c51-1d22-4dad-a30a-5d5a6a87ba95",
    "work_id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "probe.batch/v1"
    ],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T13:37:57.719129Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-baseline-probe/batch/workspace",
    "request_sha256": "25ee1f637a06effceff00e04026d413fa6513f84368a81b87de8d33a92d14b8a"
  },
  "fingerprint": "7081e56c3e538eefc0376aeeefa62b0c8273ca2ac19fd3de0dc02d2e3ebe4922",
  "before": {
    "id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "revision": 2,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "work",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "revision": 3,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "work",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "5f7d92c6-d511-48e1-a7ce-00fc9ee5429d",
  "state_revision": 4,
  "recorded_at": "2026-09-09T13:37:57.752009Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "68da0444-8a77-4151-86ea-667deff57eeb",
    "workspace_id": "79808c51-1d22-4dad-a30a-5d5a6a87ba95",
    "work_id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "expected_revision": 3,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "5cd8f6cd-d081-44c2-8d11-26606f209cc6",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T13:37:57.748998Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-baseline-probe/batch/workspace",
    "request_sha256": "7a763e51eefc362e4ba6393f52050e9d7cda9c12477bf44f306f84fe6f9bdce7"
  },
  "fingerprint": "f68f833ff95826e8f6f4b2302d7041b771cc34393f7eed63b70b7d2c8225ba5e",
  "before": {
    "id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "revision": 3,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "work",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "revision": 4,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "work",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "bfbd77cd-398a-4f72-9ecb-ab5b4754bbe9",
  "state_revision": 5,
  "recorded_at": "2026-09-09T13:37:57.782452Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "8e662996-f459-4d98-a9c0-ca2a300c0b32",
    "workspace_id": "79808c51-1d22-4dad-a30a-5d5a6a87ba95",
    "work_id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "expected_revision": 4,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "5cd8f6cd-d081-44c2-8d11-26606f209cc6",
    "artifact_revision": 1,
    "content_sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568",
    "content_size": 38,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T13:37:57.778721Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-baseline-probe/batch/workspace",
    "request_sha256": "c52d562e365ea16089bedc396401a33cc3aff7d2415ec576c9784c33921f5d40"
  },
  "fingerprint": "29587d6a3fe578d208eb17518bd8ef089da70ee092f097fab8b21213799e15f5",
  "before": {
    "id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "revision": 4,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "work",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "revision": 5,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "work",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "5cd8f6cd-d081-44c2-8d11-26606f209cc6",
    "revision": 1,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "artifact",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "work_id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "title": "Fictional observation",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "5cd8f6cd-d081-44c2-8d11-26606f209cc6",
    "revision": 2,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "artifact",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "work_id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "title": "Fictional observation",
    "status": "registered",
    "active_version": "8e662996-f459-4d98-a9c0-ca2a300c0b32"
  },
  "artifact_version": {
    "id": "8e662996-f459-4d98-a9c0-ca2a300c0b32",
    "artifact_id": "5cd8f6cd-d081-44c2-8d11-26606f209cc6",
    "work_id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "artifact_revision": 2,
    "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568",
    "size": 38,
    "created_at": "2026-09-09T13:37:57.782452Z",
    "state_revision": 5
  }
}
```

```json
{
  "id": "9cb3f113-cb83-486d-a7b7-492544801902",
  "state_revision": 6,
  "recorded_at": "2026-09-09T13:37:57.826896Z",
  "product_version": "0.7.0",
  "request": {
    "version": 3,
    "operation_id": "03220507-756f-480b-a1e0-470cd38367ea",
    "workspace_id": "79808c51-1d22-4dad-a30a-5d5a6a87ba95",
    "work_id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "expected_revision": 5,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional observation, not owner product acceptance",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "5cd8f6cd-d081-44c2-8d11-26606f209cc6",
        "version_id": "8e662996-f459-4d98-a9c0-ca2a300c0b32",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "03220507-756f-480b-a1e0-470cd38367ea",
      "workspace_id": "79808c51-1d22-4dad-a30a-5d5a6a87ba95",
      "process": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
      "related_work": "d3e60b63-5569-4eec-b631-c217dace2472",
      "intent": "accepted_result",
      "source_revision": 5,
      "result": {
        "artifact_id": "5cd8f6cd-d081-44c2-8d11-26606f209cc6",
        "version_id": "8e662996-f459-4d98-a9c0-ca2a300c0b32",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      },
      "basis": [],
      "provenance": "Explicit fictional observation, not owner product acceptance",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T1 fictional adapter"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-probe-admission-20260909-exec",
      "input_sha256": "40b2d3a00655b0f9dd449b4cc061e285092ebe26db3f53e007af20f5c7607020"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T13:37:57.822790Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-baseline-probe/batch/workspace",
    "request_sha256": "0e4d22abe7f038b4196df14a32c2835021d51cebeb622cbba53c5fc390c70370"
  },
  "fingerprint": "f775224264dd9cb19f4e441a5e210eaede2c5a01239202338252cd0098c290bb",
  "before": {
    "id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "revision": 5,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "work",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "revision": 6,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "work",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "3a517e4d-34b6-4e29-9ed9-c08d020c0d52",
  "state_revision": 7,
  "recorded_at": "2026-09-09T13:37:57.924375Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "feaa180b-2f4d-437b-b936-7a2b47d0636b",
    "workspace_id": "79808c51-1d22-4dad-a30a-5d5a6a87ba95",
    "work_id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "expected_revision": 6,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "5cd8f6cd-d081-44c2-8d11-26606f209cc6",
    "artifact_revision": 2,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T13:37:57.920977Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-baseline-probe/batch/workspace",
    "request_sha256": "7fdc78b09bed30173989574b9b4f5ee0e327111bbf6c2964f4fd353a60bf5560"
  },
  "fingerprint": "cee3bf305b6540ce88975c8bd49038609a43f83805fcb57b8c561048f182653e",
  "before": {
    "id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "revision": 6,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "work",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "revision": 7,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "work",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "f7f30174-5e8d-4554-a424-67f8cba40c09",
  "state_revision": 8,
  "recorded_at": "2026-09-09T13:37:57.956847Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "162287df-92c3-4649-b8d6-04da6365c796",
    "workspace_id": "79808c51-1d22-4dad-a30a-5d5a6a87ba95",
    "work_id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "expected_revision": 7,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "5cd8f6cd-d081-44c2-8d11-26606f209cc6",
    "artifact_revision": 2,
    "content_sha256": "662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35",
    "content_size": 37,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T13:37:57.952333Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-baseline-probe/batch/workspace",
    "request_sha256": "5d7e3091fac8837e52932396b12aa25fd3f88828bc0425981ca7abea455b83d1"
  },
  "fingerprint": "3e7a3ddcc59fa34cc171f0070b11535d538731ce895b7abd787ace222c963caf",
  "before": {
    "id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "revision": 7,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "work",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "revision": 8,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "work",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "5cd8f6cd-d081-44c2-8d11-26606f209cc6",
    "revision": 2,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "artifact",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "work_id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "title": "Fictional observation",
    "status": "registered",
    "active_version": "8e662996-f459-4d98-a9c0-ca2a300c0b32"
  },
  "artifact_after": {
    "id": "5cd8f6cd-d081-44c2-8d11-26606f209cc6",
    "revision": 3,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "artifact",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "work_id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "title": "Fictional observation",
    "status": "registered",
    "active_version": "162287df-92c3-4649-b8d6-04da6365c796"
  },
  "artifact_version": {
    "id": "162287df-92c3-4649-b8d6-04da6365c796",
    "artifact_id": "5cd8f6cd-d081-44c2-8d11-26606f209cc6",
    "work_id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "artifact_revision": 3,
    "sha256": "662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35",
    "size": 37,
    "created_at": "2026-09-09T13:37:57.956847Z",
    "state_revision": 8
  }
}
```

```json
{
  "id": "41611289-6dd8-4042-89a4-53532ad9927a",
  "state_revision": 9,
  "recorded_at": "2026-09-09T13:37:58.000987Z",
  "product_version": "0.7.0",
  "request": {
    "version": 3,
    "operation_id": "c6429e07-f6dd-4ccc-845e-16d5649d0a00",
    "workspace_id": "79808c51-1d22-4dad-a30a-5d5a6a87ba95",
    "work_id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "expected_revision": 8,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional observation, not owner product acceptance",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "5cd8f6cd-d081-44c2-8d11-26606f209cc6",
        "version_id": "162287df-92c3-4649-b8d6-04da6365c796",
        "sha256": "662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "c6429e07-f6dd-4ccc-845e-16d5649d0a00",
      "workspace_id": "79808c51-1d22-4dad-a30a-5d5a6a87ba95",
      "process": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
      "related_work": "d3e60b63-5569-4eec-b631-c217dace2472",
      "intent": "accepted_result",
      "source_revision": 8,
      "result": {
        "artifact_id": "5cd8f6cd-d081-44c2-8d11-26606f209cc6",
        "version_id": "162287df-92c3-4649-b8d6-04da6365c796",
        "sha256": "662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35"
      },
      "basis": [],
      "provenance": "Explicit fictional observation, not owner product acceptance",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T1 fictional adapter"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-probe-admission-20260909-exec",
      "input_sha256": "8758fb544e2e15ad8138833147a0b7e1143b1ed544fd5aff4f0a4349d1143b31"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T13:37:57.996451Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-baseline-probe/batch/workspace",
    "request_sha256": "d646d22e09793daa70a1e7c45350e293c7afbccabd49a05eb8441d6728f87f38"
  },
  "fingerprint": "6e09c894f16a6d7bd3e5a30544348a21b3b9d975e7d70fa9464bfbc54f937102",
  "before": {
    "id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "revision": 8,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "work",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "revision": 9,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "work",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "add860db-e7ae-462d-ba01-cb3408ff49ef",
  "state_revision": 10,
  "recorded_at": "2026-09-09T14:50:01.106531Z",
  "product_version": "0.7.0",
  "request": {
    "version": 4,
    "operation_id": "8469b776-a88f-4c44-afa3-39f714cd6970",
    "workspace_id": "79808c51-1d22-4dad-a30a-5d5a6a87ba95",
    "work_id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "expected_revision": 9,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "M1 T1 fictional rule proposal; authority supplied separately",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "5cd8f6cd-d081-44c2-8d11-26606f209cc6",
        "version_id": "162287df-92c3-4649-b8d6-04da6365c796",
        "sha256": "662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 9,
      "result": {
        "artifact_id": "5cd8f6cd-d081-44c2-8d11-26606f209cc6",
        "version_id": "162287df-92c3-4649-b8d6-04da6365c796",
        "sha256": "662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35"
      },
      "acceptance_ids": [
        "03220507-756f-480b-a1e0-470cd38367ea",
        "c6429e07-f6dd-4ccc-845e-16d5649d0a00"
      ],
      "next_work": {
        "work_id": "0c7e94d8-1fe3-4ded-878f-4bcd2403b54a",
        "artifact_id": "c4fbe44c-beba-413a-a808-4b8d15964da7",
        "goal": "Inspect the next fictional batch",
        "expected_result": "Both independent marks",
        "acceptance": [
          "Observation and recording marks are both present"
        ],
        "boundaries": [
          "Local fictional workspace only"
        ],
        "budget": "One minimal rule contrast",
        "executor_requirements": [
          "probe.batch/v1"
        ],
        "artifact_title": "Next fictional batch observation",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "fresh-G5-retained-old-wheel",
    "source_ref": "Explicit owner G5 authorization; review 01a0869b-59b5-7b62-9e19-e2f8056f4341; new restored fictional workspace; acceptance pending",
    "confirmed_at": "2026-09-09T14:50:01.101936Z",
    "workspace_path": "C:/my_global_workflow/fa61/zaratustra/_scratch/g5-m1-packs-20260909/provenance-01/old-wheel-restored",
    "request_sha256": "e7f4c91137b3673c9460f74736e4dc552b89573ecc220944a515f827cca6d50c"
  },
  "fingerprint": "6d59e81746d76f979af9a886a6e10c7022fe5af0cf0d787f41f17545ed2894e8",
  "before": {
    "id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "revision": 9,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "work",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "revision": 10,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "work",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "completion_id": "8469b776-a88f-4c44-afa3-39f714cd6970"
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "0c7e94d8-1fe3-4ded-878f-4bcd2403b54a",
    "revision": 10,
    "created_at": "2026-09-09T14:50:01.106531Z",
    "kind": "work",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "goal": "Inspect the next fictional batch",
    "expected_result": "Both independent marks",
    "acceptance": [
      "Observation and recording marks are both present"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "next_artifact": {
    "id": "c4fbe44c-beba-413a-a808-4b8d15964da7",
    "revision": 1,
    "created_at": "2026-09-09T14:50:01.106531Z",
    "kind": "artifact",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "work_id": "0c7e94d8-1fe3-4ded-878f-4bcd2403b54a",
    "title": "Next fictional batch observation",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "5cd8f6cd-d081-44c2-8d11-26606f209cc6",
    "revision": 3,
    "created_at": "2026-09-09T13:37:57.658036Z",
    "kind": "artifact",
    "process_id": "cc8299ec-3f8f-419b-a4a8-50abbf7b24a8",
    "work_id": "d3e60b63-5569-4eec-b631-c217dace2472",
    "title": "Fictional observation",
    "status": "registered",
    "active_version": "162287df-92c3-4649-b8d6-04da6365c796"
  },
  "result_references": [
    {
      "artifact_id": "5cd8f6cd-d081-44c2-8d11-26606f209cc6",
      "version_id": "162287df-92c3-4649-b8d6-04da6365c796",
      "sha256": "662bceb686b3e1f39c05d45694f0eaa42723aa2b2d00b98e0935fd2a41c73a35"
    },
    {
      "artifact_id": "5cd8f6cd-d081-44c2-8d11-26606f209cc6",
      "version_id": "8e662996-f459-4d98-a9c0-ca2a300c0b32",
      "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
    }
  ]
}
```

