# Zaratustra — generated overview

generated_from_revision: 14
generated_at: 2026-09-09T13:37:59.255474+00:00
workspace_id: 11cfa8b4-3f1c-4aa0-a54e-48d090c4a787

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "a78a0b6c-8c93-4e7a-a8f6-40991a8e21be",
  "revision": 2,
  "created_at": "2026-09-09T13:37:58.484540Z",
  "kind": "artifact",
  "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
  "work_id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
  "title": "Fictional observation",
  "status": "registered",
  "active_version": "a98a24f7-aeb6-43cb-94c1-99f5b54e3fe0"
}
```

## artifact

```json
{
  "id": "edc2496c-9ffa-4cac-8dd0-0e944778ccde",
  "revision": 1,
  "created_at": "2026-09-09T13:37:59.255474Z",
  "kind": "artifact",
  "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
  "work_id": "b8eb7327-31d0-4d6e-b14a-e63ffb6257fc",
  "title": "Fictional observe observation",
  "status": "declared",
  "active_version": null
}
```

## artifact

```json
{
  "id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
  "revision": 3,
  "created_at": "2026-09-09T13:37:58.701555Z",
  "kind": "artifact",
  "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
  "work_id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
  "title": "Fictional record observation",
  "status": "registered",
  "active_version": "cb8166e2-bd13-43d4-94e4-5e9610e697a9"
}
```

## event

```json
{
  "id": "3590a22d-8aaf-4f6a-8306-ac978c0ad67f",
  "revision": 1,
  "created_at": "2026-09-09T13:37:58.484540Z",
  "kind": "event",
  "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
  "work_id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.7.0",
  "state_revision": 1,
  "affected_ids": [
    "cb7955ef-2cee-402d-903d-c636507a9506",
    "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "a78a0b6c-8c93-4e7a-a8f6-40991a8e21be"
  ]
}
```

## process

```json
{
  "id": "cb7955ef-2cee-402d-903d-c636507a9506",
  "revision": 1,
  "created_at": "2026-09-09T13:37:58.484540Z",
  "kind": "process",
  "title": "Fictional probe.cycle/v1:observe"
}
```

## work

```json
{
  "id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
  "revision": 14,
  "created_at": "2026-09-09T13:37:58.701555Z",
  "kind": "work",
  "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
  "goal": "Perform the fictional record phase",
  "expected_result": "The record mark",
  "acceptance": [
    "The current record phase has its own mark"
  ],
  "boundaries": [
    "Local fictional workspace only"
  ],
  "budget": "One minimal rule contrast",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.cycle/v1:record"
  ],
  "completion_id": "cc5fea96-fd52-45b1-9407-7df238d32c94"
}
```

## work

```json
{
  "id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
  "revision": 7,
  "created_at": "2026-09-09T13:37:58.484540Z",
  "kind": "work",
  "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
  "goal": "Evaluate the selected fictional rule",
  "expected_result": "Exact recorded observation and permitted continuation",
  "acceptance": [
    "Only explicitly selected fictional inputs"
  ],
  "boundaries": [
    "Local fictional workspace only"
  ],
  "budget": "One minimal rule contrast",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.cycle/v1:observe"
  ],
  "completion_id": "12f2c1f5-db22-4404-b962-885e4444171b"
}
```

## work

```json
{
  "id": "b8eb7327-31d0-4d6e-b14a-e63ffb6257fc",
  "revision": 14,
  "created_at": "2026-09-09T13:37:59.255474Z",
  "kind": "work",
  "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
  "goal": "Perform the fictional observe phase",
  "expected_result": "The observe mark",
  "acceptance": [
    "The current observe phase has its own mark"
  ],
  "boundaries": [
    "Local fictional workspace only"
  ],
  "budget": "One minimal rule contrast",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.cycle/v1:observe"
  ]
}
```

## Registered versions

- Version: a98a24f7-aeb6-43cb-94c1-99f5b54e3fe0; Artifact revision: 2
  SHA-256: 1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568; bytes: 38
  File: artifacts/a78a0b6c-8c93-4e7a-a8f6-40991a8e21be/a98a24f7-aeb6-43cb-94c1-99f5b54e3fe0.blob

- Version: c8c0f5be-01df-4cd5-b083-41b43139cc93; Artifact revision: 2
  SHA-256: 1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568; bytes: 38
  File: artifacts/f90ad0c1-8bf2-4eee-b91c-0376abf0430c/c8c0f5be-01df-4cd5-b083-41b43139cc93.blob

- Version: cb8166e2-bd13-43d4-94e4-5e9610e697a9; Artifact revision: 3
  SHA-256: a5748ed97ee6d8b0315eed30f85918597e0dded61f5277f290f789872c537741; bytes: 38
  File: artifacts/f90ad0c1-8bf2-4eee-b91c-0376abf0430c/cb8166e2-bd13-43d4-94e4-5e9610e697a9.blob

## Mutation provenance

```json
{
  "id": "51fdb3ec-d664-4d75-9c78-387c2e1fae79",
  "state_revision": 2,
  "recorded_at": "2026-09-09T13:37:58.500936Z",
  "product_version": "0.7.0",
  "request": {
    "version": 1,
    "operation_id": "f5841b74-ad70-4c06-b5fb-bcabe3f076b0",
    "workspace_id": "11cfa8b4-3f1c-4aa0-a54e-48d090c4a787",
    "work_id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T13:37:58.498310Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-baseline-probe/cycle/workspace",
    "request_sha256": "c7563d146a3a9fb119bfc5423064acd0c2ca5cc5762c4629d14a92fa62649f3a"
  },
  "fingerprint": "b82f8c7f9a6d84fa06067357b23f2a9abc5a1a3a7b26d86a59b427a4186debad",
  "before": {
    "id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "revision": 1,
    "created_at": "2026-09-09T13:37:58.484540Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "revision": 2,
    "created_at": "2026-09-09T13:37:58.484540Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "779a0c1b-7b7e-4a41-a68f-158dd45eea0f",
  "state_revision": 3,
  "recorded_at": "2026-09-09T13:37:58.527115Z",
  "product_version": "0.7.0",
  "request": {
    "version": 1,
    "operation_id": "d96b85bf-c8c9-436d-a941-b960e2871b15",
    "workspace_id": "11cfa8b4-3f1c-4aa0-a54e-48d090c4a787",
    "work_id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "probe.cycle/v1:observe"
    ],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T13:37:58.523832Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-baseline-probe/cycle/workspace",
    "request_sha256": "67881632509e884febdc4e5e2ad627a1e3cd50469d0b1840272386ae63f8eced"
  },
  "fingerprint": "b6e483e46457a2b3293886ebf0eb31b8fa29698c4587a5af125772c39d54b4de",
  "before": {
    "id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "revision": 2,
    "created_at": "2026-09-09T13:37:58.484540Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "revision": 3,
    "created_at": "2026-09-09T13:37:58.484540Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "8e56d3e9-2f02-4539-be31-97318f3a37fa",
  "state_revision": 4,
  "recorded_at": "2026-09-09T13:37:58.555146Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "23291222-e224-4f64-9bc0-8caaa4a9ffa5",
    "workspace_id": "11cfa8b4-3f1c-4aa0-a54e-48d090c4a787",
    "work_id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "expected_revision": 3,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "a78a0b6c-8c93-4e7a-a8f6-40991a8e21be",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T13:37:58.552239Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-baseline-probe/cycle/workspace",
    "request_sha256": "1f840db9e20252d5b5cc031c6b7d2490ce82276d23dbb2ad32575e201b40a612"
  },
  "fingerprint": "61f35e4a8a167747566570ae04dc3868e5340dbe6db137dda61c7543cda5feb6",
  "before": {
    "id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "revision": 3,
    "created_at": "2026-09-09T13:37:58.484540Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "after": {
    "id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "revision": 4,
    "created_at": "2026-09-09T13:37:58.484540Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "c697e869-4761-411e-b046-afde1abd728d",
  "state_revision": 5,
  "recorded_at": "2026-09-09T13:37:58.584631Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "a98a24f7-aeb6-43cb-94c1-99f5b54e3fe0",
    "workspace_id": "11cfa8b4-3f1c-4aa0-a54e-48d090c4a787",
    "work_id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "expected_revision": 4,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "a78a0b6c-8c93-4e7a-a8f6-40991a8e21be",
    "artifact_revision": 1,
    "content_sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568",
    "content_size": 38,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T13:37:58.581330Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-baseline-probe/cycle/workspace",
    "request_sha256": "a40bc4f88c4a1815f8dd96ab41f328baa55b558b76eb1a8ec48f1430b7be6673"
  },
  "fingerprint": "09a4165b409214fc4a807241403407e45e97253702123edb70579af95efd70b3",
  "before": {
    "id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "revision": 4,
    "created_at": "2026-09-09T13:37:58.484540Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "after": {
    "id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "revision": 5,
    "created_at": "2026-09-09T13:37:58.484540Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "a78a0b6c-8c93-4e7a-a8f6-40991a8e21be",
    "revision": 1,
    "created_at": "2026-09-09T13:37:58.484540Z",
    "kind": "artifact",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "work_id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "title": "Fictional observation",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "a78a0b6c-8c93-4e7a-a8f6-40991a8e21be",
    "revision": 2,
    "created_at": "2026-09-09T13:37:58.484540Z",
    "kind": "artifact",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "work_id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "title": "Fictional observation",
    "status": "registered",
    "active_version": "a98a24f7-aeb6-43cb-94c1-99f5b54e3fe0"
  },
  "artifact_version": {
    "id": "a98a24f7-aeb6-43cb-94c1-99f5b54e3fe0",
    "artifact_id": "a78a0b6c-8c93-4e7a-a8f6-40991a8e21be",
    "work_id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "artifact_revision": 2,
    "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568",
    "size": 38,
    "created_at": "2026-09-09T13:37:58.584631Z",
    "state_revision": 5
  }
}
```

```json
{
  "id": "5aadc0df-eb5f-4cdf-a73b-b90a3ef9871b",
  "state_revision": 6,
  "recorded_at": "2026-09-09T13:37:58.623511Z",
  "product_version": "0.7.0",
  "request": {
    "version": 3,
    "operation_id": "c6d8acc7-f93b-4a41-ab0b-846b750e9386",
    "workspace_id": "11cfa8b4-3f1c-4aa0-a54e-48d090c4a787",
    "work_id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "expected_revision": 5,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional observation, not owner product acceptance",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "a78a0b6c-8c93-4e7a-a8f6-40991a8e21be",
        "version_id": "a98a24f7-aeb6-43cb-94c1-99f5b54e3fe0",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "c6d8acc7-f93b-4a41-ab0b-846b750e9386",
      "workspace_id": "11cfa8b4-3f1c-4aa0-a54e-48d090c4a787",
      "process": "cb7955ef-2cee-402d-903d-c636507a9506",
      "related_work": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
      "intent": "accepted_result",
      "source_revision": 5,
      "result": {
        "artifact_id": "a78a0b6c-8c93-4e7a-a8f6-40991a8e21be",
        "version_id": "a98a24f7-aeb6-43cb-94c1-99f5b54e3fe0",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      },
      "basis": [],
      "provenance": "Explicit fictional observation, not owner product acceptance",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T1 fictional adapter"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-probe-admission-20260909-exec",
      "input_sha256": "a1cbce3e3442e04ae3639f2a0aceffcf9c518f0de4451482f74c3da4c5f7632f"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T13:37:58.619379Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-baseline-probe/cycle/workspace",
    "request_sha256": "0b311e19f746d1f65a3b13f04de27c6b55dfb64b91f6886dd83b86894a21ac31"
  },
  "fingerprint": "a69751f7d51d68f7601d2f64b2991acfb0de851502def06d6acd970bf7092dbb",
  "before": {
    "id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "revision": 5,
    "created_at": "2026-09-09T13:37:58.484540Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "after": {
    "id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "revision": 6,
    "created_at": "2026-09-09T13:37:58.484540Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "04575f1c-a9ca-4585-9beb-e76be109ebc5",
  "state_revision": 7,
  "recorded_at": "2026-09-09T13:37:58.701555Z",
  "product_version": "0.7.0",
  "request": {
    "version": 4,
    "operation_id": "12f2c1f5-db22-4404-b962-885e4444171b",
    "workspace_id": "11cfa8b4-3f1c-4aa0-a54e-48d090c4a787",
    "work_id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "expected_revision": 6,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "M1 T1 fictional rule proposal; authority supplied separately",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "a78a0b6c-8c93-4e7a-a8f6-40991a8e21be",
        "version_id": "a98a24f7-aeb6-43cb-94c1-99f5b54e3fe0",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 6,
      "result": {
        "artifact_id": "a78a0b6c-8c93-4e7a-a8f6-40991a8e21be",
        "version_id": "a98a24f7-aeb6-43cb-94c1-99f5b54e3fe0",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      },
      "acceptance_ids": [
        "c6d8acc7-f93b-4a41-ab0b-846b750e9386"
      ],
      "next_work": {
        "work_id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
        "artifact_id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
        "goal": "Perform the fictional record phase",
        "expected_result": "The record mark",
        "acceptance": [
          "The current record phase has its own mark"
        ],
        "boundaries": [
          "Local fictional workspace only"
        ],
        "budget": "One minimal rule contrast",
        "executor_requirements": [
          "probe.cycle/v1:record"
        ],
        "artifact_title": "Fictional record observation",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T13:37:58.696592Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-baseline-probe/cycle/workspace",
    "request_sha256": "3d1dc4e52f31fc85233463e2af9dd4cf0473c8e0b96a4234da3f507dd4696f1f"
  },
  "fingerprint": "340338671894acd139e4b93ee2cbb7a52fe968e7d561d9fefd02177e7c0b40dd",
  "before": {
    "id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "revision": 6,
    "created_at": "2026-09-09T13:37:58.484540Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "after": {
    "id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "revision": 7,
    "created_at": "2026-09-09T13:37:58.484540Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Evaluate the selected fictional rule",
    "expected_result": "Exact recorded observation and permitted continuation",
    "acceptance": [
      "Only explicitly selected fictional inputs"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ],
    "completion_id": "12f2c1f5-db22-4404-b962-885e4444171b"
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "revision": 7,
    "created_at": "2026-09-09T13:37:58.701555Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "next_artifact": {
    "id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
    "revision": 1,
    "created_at": "2026-09-09T13:37:58.701555Z",
    "kind": "artifact",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "work_id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "title": "Fictional record observation",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "a78a0b6c-8c93-4e7a-a8f6-40991a8e21be",
    "revision": 2,
    "created_at": "2026-09-09T13:37:58.484540Z",
    "kind": "artifact",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "work_id": "94d0a808-8e1f-4858-87c0-ec3a44a0791d",
    "title": "Fictional observation",
    "status": "registered",
    "active_version": "a98a24f7-aeb6-43cb-94c1-99f5b54e3fe0"
  },
  "result_references": [
    {
      "artifact_id": "a78a0b6c-8c93-4e7a-a8f6-40991a8e21be",
      "version_id": "a98a24f7-aeb6-43cb-94c1-99f5b54e3fe0",
      "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
    }
  ]
}
```

```json
{
  "id": "04248ef7-e5b2-4349-929f-6c950f78c4af",
  "state_revision": 8,
  "recorded_at": "2026-09-09T13:37:58.850550Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "a21e2745-0b58-4ba1-881b-6e2202a76488",
    "workspace_id": "11cfa8b4-3f1c-4aa0-a54e-48d090c4a787",
    "work_id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "expected_revision": 7,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T13:37:58.845931Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-baseline-probe/cycle/workspace",
    "request_sha256": "eb441bc4adbe8a5cf9ea21411da4ba52c7bcd6d6f5dc656917bd99231ab353e0"
  },
  "fingerprint": "b9f009b40dfb27c2911d930f1ec513cbc88129be8b495d74d637ca08ec5fec2e",
  "before": {
    "id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "revision": 7,
    "created_at": "2026-09-09T13:37:58.701555Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "after": {
    "id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "revision": 8,
    "created_at": "2026-09-09T13:37:58.701555Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "4932f9c5-a56f-495e-a65e-437725bfd6f2",
  "state_revision": 9,
  "recorded_at": "2026-09-09T13:37:58.885744Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "c8c0f5be-01df-4cd5-b083-41b43139cc93",
    "workspace_id": "11cfa8b4-3f1c-4aa0-a54e-48d090c4a787",
    "work_id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "expected_revision": 8,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
    "artifact_revision": 1,
    "content_sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568",
    "content_size": 38,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T13:37:58.881046Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-baseline-probe/cycle/workspace",
    "request_sha256": "da4b10ba798caf217f5dd3a4e16cf8a71d8ed3fc51ad38eb9fca1b079e350339"
  },
  "fingerprint": "1df8045e2bbfb02712768da09974c3b15139ac1a30c113aeba99e9a6c0fe12d9",
  "before": {
    "id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "revision": 8,
    "created_at": "2026-09-09T13:37:58.701555Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "after": {
    "id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "revision": 9,
    "created_at": "2026-09-09T13:37:58.701555Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
    "revision": 1,
    "created_at": "2026-09-09T13:37:58.701555Z",
    "kind": "artifact",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "work_id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "title": "Fictional record observation",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
    "revision": 2,
    "created_at": "2026-09-09T13:37:58.701555Z",
    "kind": "artifact",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "work_id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "title": "Fictional record observation",
    "status": "registered",
    "active_version": "c8c0f5be-01df-4cd5-b083-41b43139cc93"
  },
  "artifact_version": {
    "id": "c8c0f5be-01df-4cd5-b083-41b43139cc93",
    "artifact_id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
    "work_id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "artifact_revision": 2,
    "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568",
    "size": 38,
    "created_at": "2026-09-09T13:37:58.885744Z",
    "state_revision": 9
  }
}
```

```json
{
  "id": "70013b02-e066-41a5-a752-cea3c39d2d28",
  "state_revision": 10,
  "recorded_at": "2026-09-09T13:37:58.932380Z",
  "product_version": "0.7.0",
  "request": {
    "version": 3,
    "operation_id": "0b9ef565-3e3f-4c1e-a238-1c8a6bd1260e",
    "workspace_id": "11cfa8b4-3f1c-4aa0-a54e-48d090c4a787",
    "work_id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "expected_revision": 9,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional observation, not owner product acceptance",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
        "version_id": "c8c0f5be-01df-4cd5-b083-41b43139cc93",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "0b9ef565-3e3f-4c1e-a238-1c8a6bd1260e",
      "workspace_id": "11cfa8b4-3f1c-4aa0-a54e-48d090c4a787",
      "process": "cb7955ef-2cee-402d-903d-c636507a9506",
      "related_work": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
      "intent": "accepted_result",
      "source_revision": 9,
      "result": {
        "artifact_id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
        "version_id": "c8c0f5be-01df-4cd5-b083-41b43139cc93",
        "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
      },
      "basis": [],
      "provenance": "Explicit fictional observation, not owner product acceptance",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T1 fictional adapter"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-probe-admission-20260909-exec",
      "input_sha256": "8cf2ee46800a985f70e97dae1ef04264a8a771685eacea0b0a97b90138b2cb7b"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T13:37:58.927286Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-baseline-probe/cycle/workspace",
    "request_sha256": "6fc8da702191019f6231fb470e8f3558a3eed5f30a7818f8a01e881f063aa5cc"
  },
  "fingerprint": "547005fe352b9a91278822bd840d63444d51aa336a0a8bfead01a154b9743362",
  "before": {
    "id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "revision": 9,
    "created_at": "2026-09-09T13:37:58.701555Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "after": {
    "id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "revision": 10,
    "created_at": "2026-09-09T13:37:58.701555Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "d304eff8-dfc7-456f-8abb-e301b1adf099",
  "state_revision": 11,
  "recorded_at": "2026-09-09T13:37:59.051176Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "c75f00a0-425a-4d16-b641-f9978ca9fab6",
    "workspace_id": "11cfa8b4-3f1c-4aa0-a54e-48d090c4a787",
    "work_id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "expected_revision": 10,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
    "artifact_revision": 2,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T13:37:59.046753Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-baseline-probe/cycle/workspace",
    "request_sha256": "e8cea5848b6f1adc1576584534b0cc290f3db33dc5a3f9f18cc9a70aea99a176"
  },
  "fingerprint": "fe5a0060ef223569d812b1ab317cb6d2def200521cb61e7c923584517c729172",
  "before": {
    "id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "revision": 10,
    "created_at": "2026-09-09T13:37:58.701555Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "after": {
    "id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "revision": 11,
    "created_at": "2026-09-09T13:37:58.701555Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "e21827e8-9546-4921-bfc7-05123bf57ba4",
  "state_revision": 12,
  "recorded_at": "2026-09-09T13:37:59.089753Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "cb8166e2-bd13-43d4-94e4-5e9610e697a9",
    "workspace_id": "11cfa8b4-3f1c-4aa0-a54e-48d090c4a787",
    "work_id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "expected_revision": 11,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T1 fixture authorized by RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec",
    "artifact_id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
    "artifact_revision": 2,
    "content_sha256": "a5748ed97ee6d8b0315eed30f85918597e0dded61f5277f290f789872c537741",
    "content_size": 38,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T13:37:59.083949Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-baseline-probe/cycle/workspace",
    "request_sha256": "ac2c9ffd826fe86e8cb6389160bb9cc8dcf77be1c1519ae5ba449286afb429cd"
  },
  "fingerprint": "126c8ffce002dbf9b3b61328411b7cc8d0701c2c844f22ffb7c7299ffb617d81",
  "before": {
    "id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "revision": 11,
    "created_at": "2026-09-09T13:37:58.701555Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "after": {
    "id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "revision": 12,
    "created_at": "2026-09-09T13:37:58.701555Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
    "revision": 2,
    "created_at": "2026-09-09T13:37:58.701555Z",
    "kind": "artifact",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "work_id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "title": "Fictional record observation",
    "status": "registered",
    "active_version": "c8c0f5be-01df-4cd5-b083-41b43139cc93"
  },
  "artifact_after": {
    "id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
    "revision": 3,
    "created_at": "2026-09-09T13:37:58.701555Z",
    "kind": "artifact",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "work_id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "title": "Fictional record observation",
    "status": "registered",
    "active_version": "cb8166e2-bd13-43d4-94e4-5e9610e697a9"
  },
  "artifact_version": {
    "id": "cb8166e2-bd13-43d4-94e4-5e9610e697a9",
    "artifact_id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
    "work_id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "artifact_revision": 3,
    "sha256": "a5748ed97ee6d8b0315eed30f85918597e0dded61f5277f290f789872c537741",
    "size": 38,
    "created_at": "2026-09-09T13:37:59.089753Z",
    "state_revision": 12
  }
}
```

```json
{
  "id": "8dfb265b-acd1-42d8-b92d-4e01d137b049",
  "state_revision": 13,
  "recorded_at": "2026-09-09T13:37:59.141260Z",
  "product_version": "0.7.0",
  "request": {
    "version": 3,
    "operation_id": "21948e24-a73e-4b76-954e-5952d5a90a92",
    "workspace_id": "11cfa8b4-3f1c-4aa0-a54e-48d090c4a787",
    "work_id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "expected_revision": 12,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional observation, not owner product acceptance",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
        "version_id": "cb8166e2-bd13-43d4-94e4-5e9610e697a9",
        "sha256": "a5748ed97ee6d8b0315eed30f85918597e0dded61f5277f290f789872c537741"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "21948e24-a73e-4b76-954e-5952d5a90a92",
      "workspace_id": "11cfa8b4-3f1c-4aa0-a54e-48d090c4a787",
      "process": "cb7955ef-2cee-402d-903d-c636507a9506",
      "related_work": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
      "intent": "accepted_result",
      "source_revision": 12,
      "result": {
        "artifact_id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
        "version_id": "cb8166e2-bd13-43d4-94e4-5e9610e697a9",
        "sha256": "a5748ed97ee6d8b0315eed30f85918597e0dded61f5277f290f789872c537741"
      },
      "basis": [],
      "provenance": "Explicit fictional observation, not owner product acceptance",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T1 fictional adapter"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-probe-admission-20260909-exec",
      "input_sha256": "9838a6c846a95d2d9401bfa7e73eb265504b7c39f87a419cc7c32db07d1fb2d7"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T13:37:59.134898Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-baseline-probe/cycle/workspace",
    "request_sha256": "5357f256330d14027bee6bb421461f8f3101e832517a05b7a6a34ce9ec6741d3"
  },
  "fingerprint": "25eabcf439d968461547b2b8efd1336db94ce85c187cd59472d151ad79fa2be6",
  "before": {
    "id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "revision": 12,
    "created_at": "2026-09-09T13:37:58.701555Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "after": {
    "id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "revision": 13,
    "created_at": "2026-09-09T13:37:58.701555Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "426edb85-d034-4dcd-a13f-05a26d1c6e83",
  "state_revision": 14,
  "recorded_at": "2026-09-09T13:37:59.255474Z",
  "product_version": "0.7.0",
  "request": {
    "version": 4,
    "operation_id": "cc5fea96-fd52-45b1-9407-7df238d32c94",
    "workspace_id": "11cfa8b4-3f1c-4aa0-a54e-48d090c4a787",
    "work_id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "expected_revision": 13,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "M1 T1 fictional rule proposal; authority supplied separately",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
        "version_id": "cb8166e2-bd13-43d4-94e4-5e9610e697a9",
        "sha256": "a5748ed97ee6d8b0315eed30f85918597e0dded61f5277f290f789872c537741"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 13,
      "result": {
        "artifact_id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
        "version_id": "cb8166e2-bd13-43d4-94e4-5e9610e697a9",
        "sha256": "a5748ed97ee6d8b0315eed30f85918597e0dded61f5277f290f789872c537741"
      },
      "acceptance_ids": [
        "0b9ef565-3e3f-4c1e-a238-1c8a6bd1260e",
        "21948e24-a73e-4b76-954e-5952d5a90a92"
      ],
      "next_work": {
        "work_id": "b8eb7327-31d0-4d6e-b14a-e63ffb6257fc",
        "artifact_id": "edc2496c-9ffa-4cac-8dd0-0e944778ccde",
        "goal": "Perform the fictional observe phase",
        "expected_result": "The observe mark",
        "acceptance": [
          "The current observe phase has its own mark"
        ],
        "boundaries": [
          "Local fictional workspace only"
        ],
        "budget": "One minimal rule contrast",
        "executor_requirements": [
          "probe.cycle/v1:observe"
        ],
        "artifact_title": "Fictional observe observation",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T1-fictional-probe-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-probe-admission-20260909-exec; only newly selected fictional probe workspace",
    "confirmed_at": "2026-09-09T13:37:59.248727Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-packs-20260909/_scratch/t2-baseline-probe/cycle/workspace",
    "request_sha256": "71231c129664a04bc1bcb42231d469ee5445bc94722e0461e6ae68cdd9fb67f3"
  },
  "fingerprint": "b71d612327c991ca202ad759133eea0b7b849426f015c130a4bd321e7da6d3e3",
  "before": {
    "id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "revision": 13,
    "created_at": "2026-09-09T13:37:58.701555Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ]
  },
  "after": {
    "id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "revision": 14,
    "created_at": "2026-09-09T13:37:58.701555Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Perform the fictional record phase",
    "expected_result": "The record mark",
    "acceptance": [
      "The current record phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:record"
    ],
    "completion_id": "cc5fea96-fd52-45b1-9407-7df238d32c94"
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "b8eb7327-31d0-4d6e-b14a-e63ffb6257fc",
    "revision": 14,
    "created_at": "2026-09-09T13:37:59.255474Z",
    "kind": "work",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "goal": "Perform the fictional observe phase",
    "expected_result": "The observe mark",
    "acceptance": [
      "The current observe phase has its own mark"
    ],
    "boundaries": [
      "Local fictional workspace only"
    ],
    "budget": "One minimal rule contrast",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.cycle/v1:observe"
    ]
  },
  "next_artifact": {
    "id": "edc2496c-9ffa-4cac-8dd0-0e944778ccde",
    "revision": 1,
    "created_at": "2026-09-09T13:37:59.255474Z",
    "kind": "artifact",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "work_id": "b8eb7327-31d0-4d6e-b14a-e63ffb6257fc",
    "title": "Fictional observe observation",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
    "revision": 3,
    "created_at": "2026-09-09T13:37:58.701555Z",
    "kind": "artifact",
    "process_id": "cb7955ef-2cee-402d-903d-c636507a9506",
    "work_id": "7494120f-455d-49a7-8efd-c9b6b41fdf57",
    "title": "Fictional record observation",
    "status": "registered",
    "active_version": "cb8166e2-bd13-43d4-94e4-5e9610e697a9"
  },
  "result_references": [
    {
      "artifact_id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
      "version_id": "cb8166e2-bd13-43d4-94e4-5e9610e697a9",
      "sha256": "a5748ed97ee6d8b0315eed30f85918597e0dded61f5277f290f789872c537741"
    },
    {
      "artifact_id": "a78a0b6c-8c93-4e7a-a8f6-40991a8e21be",
      "version_id": "a98a24f7-aeb6-43cb-94c1-99f5b54e3fe0",
      "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
    },
    {
      "artifact_id": "f90ad0c1-8bf2-4eee-b91c-0376abf0430c",
      "version_id": "c8c0f5be-01df-4cd5-b083-41b43139cc93",
      "sha256": "1c29ddea8222acebc6150ed6218d850a5a26e91fc38eb0ed336d2c1f6ce5b568"
    }
  ]
}
```

