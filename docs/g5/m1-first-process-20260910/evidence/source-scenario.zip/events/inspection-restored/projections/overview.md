# Zaratustra — generated overview

generated_from_revision: 11
generated_at: 2026-09-10T07:58:00.123149+00:00
workspace_id: c3dc3e6d-39ec-4689-ac89-31cb62dc012c

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "64acc893-cbf3-4011-a93e-9aaec11b5f44",
  "revision": 1,
  "created_at": "2026-09-10T07:58:00.123149Z",
  "kind": "artifact",
  "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
  "work_id": "5531899c-c993-4d83-84c6-83b98b506315",
  "title": "KITE disposition",
  "status": "declared",
  "active_version": null
}
```

## artifact

```json
{
  "id": "cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be",
  "revision": 3,
  "created_at": "2026-09-10T07:57:59.414315Z",
  "kind": "artifact",
  "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
  "work_id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
  "title": "KITE inspection",
  "status": "registered",
  "active_version": "80314889-44d7-4c91-869b-61ee19cce764"
}
```

## event

```json
{
  "id": "58372000-0b0a-4d07-a43c-3b81d772cabe",
  "revision": 1,
  "created_at": "2026-09-10T07:57:59.414315Z",
  "kind": "event",
  "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
  "work_id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.0",
  "state_revision": 1,
  "affected_ids": [
    "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be"
  ]
}
```

## process

```json
{
  "id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
  "revision": 4,
  "created_at": "2026-09-10T07:57:59.414315Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "5531899c-c993-4d83-84c6-83b98b506315",
  "revision": 11,
  "created_at": "2026-09-10T07:58:00.123149Z",
  "kind": "work",
  "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
  "goal": "Choose release or discard for inspected fictional KITE",
  "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
  "acceptance": [
    "Explicit disposition naming the exact accepted inspection SHA256"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:decide",
    "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
  "revision": 11,
  "created_at": "2026-09-10T07:57:59.414315Z",
  "kind": "work",
  "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "completion_id": "a53cb7f3-9c73-45fd-865e-fcdb9ff15e4e",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 24d435de-14f5-4db6-a3bf-bd64288e7c6a; Artifact revision: 2
  SHA-256: 79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f; bytes: 148
  File: artifacts/cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be/24d435de-14f5-4db6-a3bf-bd64288e7c6a.blob

- Version: 80314889-44d7-4c91-869b-61ee19cce764; Artifact revision: 3
  SHA-256: e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312; bytes: 147
  File: artifacts/cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be/80314889-44d7-4c91-869b-61ee19cce764.blob

## Mutation provenance

```json
{
  "id": "a1ec0051-f12d-4ab7-a9e9-b6a4b31af45a",
  "state_revision": 2,
  "recorded_at": "2026-09-10T07:57:59.461328Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "a6e1b1a5-60a2-4894-9f8a-367b1ccf50df",
    "workspace_id": "c3dc3e6d-39ec-4689-ac89-31cb62dc012c",
    "work_id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:57:59.447691Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-source-01/workspace",
    "request_sha256": "32e0b2d677f9c0cdfa472f3c0c79ccce542090014d933f4d43dfff7f613f084e"
  },
  "fingerprint": "f71e9671e04553f9632676c6f39135b0520317391a47f984c26fa54a5c500430",
  "before": {
    "id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "revision": 1,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "work",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "revision": 2,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "work",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "506e55de-7f04-42b1-b4b5-e0f6ce59aba0",
  "state_revision": 3,
  "recorded_at": "2026-09-10T07:57:59.497944Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "b0088f33-4d8b-43a6-b469-f398a62c1334",
    "workspace_id": "c3dc3e6d-39ec-4689-ac89-31cb62dc012c",
    "work_id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:57:59.485061Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-source-01/workspace",
    "request_sha256": "91b93ce9004452cd9936418d431e8822521f725108e160bfed1c58e1a17c5093"
  },
  "fingerprint": "105df337a597e3cf4aa9e7c6a62065853ccf3ccaa8cab1824736ff4f1f9a08f2",
  "before": {
    "id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "revision": 2,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "work",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "revision": 3,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "work",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "83d959b9-95ac-4091-8379-89dd69449bc8",
  "state_revision": 4,
  "recorded_at": "2026-09-10T07:57:59.535529Z",
  "product_version": "0.10.0",
  "request": {
    "version": 5,
    "operation_id": "5fafe894-de28-4db8-a1f8-41b57ba3644f",
    "workspace_id": "c3dc3e6d-39ec-4689-ac89-31cb62dc012c",
    "work_id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional lot binding under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:57:59.522867Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-source-01/workspace",
    "request_sha256": "340ad450fb907aca2f83de33e5ff2d53f124668018dbfe293a6350c27bb496ee"
  },
  "fingerprint": "9de9b8f1d93fcba3044d8a6ccbbc0984471f60d09cf8dd59dbe9b8f1d66ac9cc",
  "before": {
    "id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "revision": 3,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "work",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "revision": 4,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "work",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "revision": 1,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "revision": 4,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "33167adb-7e7a-42f6-892d-22ba43a91909",
  "state_revision": 5,
  "recorded_at": "2026-09-10T07:57:59.596512Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "4eca3a28-e651-48ff-965d-4526b99b71d8",
    "workspace_id": "c3dc3e6d-39ec-4689-ac89-31cb62dc012c",
    "work_id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:57:59.583628Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-source-01/workspace",
    "request_sha256": "595c4f999e4b9ffa556efe0588150a3ab3497f625c6677a7c2482b209dd01d58"
  },
  "fingerprint": "2be0079b1e786555f6abca0ce34a8e6e5b5ab75fe77eec02ba332789017012b6",
  "before": {
    "id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "revision": 4,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "work",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "revision": 5,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "work",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "24337115-85dc-477f-b42c-9d6637401682",
  "state_revision": 6,
  "recorded_at": "2026-09-10T07:57:59.633983Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "24d435de-14f5-4db6-a3bf-bd64288e7c6a",
    "workspace_id": "c3dc3e6d-39ec-4689-ac89-31cb62dc012c",
    "work_id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be",
    "artifact_revision": 1,
    "content_sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f",
    "content_size": 148,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:57:59.620954Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-source-01/workspace",
    "request_sha256": "e2df63e2399492f6e500be45339f3610576c3393830ff924fd29aaad1ec3fc13"
  },
  "fingerprint": "090928b5335a6b139b4bfbed408d788275f99872df0b44d8c2240a349481a3d1",
  "before": {
    "id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "revision": 5,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "work",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "revision": 6,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "work",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be",
    "revision": 1,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "artifact",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "work_id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "title": "KITE inspection",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be",
    "revision": 2,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "artifact",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "work_id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "24d435de-14f5-4db6-a3bf-bd64288e7c6a"
  },
  "artifact_version": {
    "id": "24d435de-14f5-4db6-a3bf-bd64288e7c6a",
    "artifact_id": "cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be",
    "work_id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "artifact_revision": 2,
    "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f",
    "size": 148,
    "created_at": "2026-09-10T07:57:59.633983Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "93a85560-19b1-497f-b0de-1551fb7ad5cd",
  "state_revision": 7,
  "recorded_at": "2026-09-10T07:57:59.687494Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "36c976c8-43c2-4eca-92ba-3e78022ed4ea",
    "workspace_id": "c3dc3e6d-39ec-4689-ac89-31cb62dc012c",
    "work_id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be",
        "version_id": "24d435de-14f5-4db6-a3bf-bd64288e7c6a",
        "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "36c976c8-43c2-4eca-92ba-3e78022ed4ea",
      "workspace_id": "c3dc3e6d-39ec-4689-ac89-31cb62dc012c",
      "process": "66117c83-6d1e-4f27-976d-81330c5c1a10",
      "related_work": "d754bb30-3054-47a3-9820-75aa21c2d78d",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be",
        "version_id": "24d435de-14f5-4db6-a3bf-bd64288e7c6a",
        "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "42c008b8a78ba61a31735281491d9baaad8e00cd314aae08a1cec519b2839bf1"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:57:59.672648Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-source-01/workspace",
    "request_sha256": "d6516aef86b1a8080b0b33a0fcffb1b83a5ec76c67f1437e2b489cd1784ca1cf"
  },
  "fingerprint": "cd107b3882792c386cce18cd7ab5057d189971380ee00bdbcc99c7826f2b6629",
  "before": {
    "id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "revision": 6,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "work",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "revision": 7,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "work",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "3ef68316-310b-4867-8480-86d83900b30c",
  "state_revision": 8,
  "recorded_at": "2026-09-10T07:57:59.752289Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "c8b63d85-7ef9-4ae3-b92d-1147ec813b54",
    "workspace_id": "c3dc3e6d-39ec-4689-ac89-31cb62dc012c",
    "work_id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "expected_revision": 7,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be",
    "artifact_revision": 2,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:57:59.737851Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-source-01/workspace",
    "request_sha256": "8254e1bd7d0b6c1755839294142794f4a0ed327d0643e56c4cbf9fa9ccb8696e"
  },
  "fingerprint": "d7576296de6d37c8e21195ff9a938002e76679a25230a92db168b10bbd4f83e1",
  "before": {
    "id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "revision": 7,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "work",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "revision": 8,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "work",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "f0e9d89e-ef41-48b4-aa06-b582b36e7f43",
  "state_revision": 9,
  "recorded_at": "2026-09-10T07:57:59.861038Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "80314889-44d7-4c91-869b-61ee19cce764",
    "workspace_id": "c3dc3e6d-39ec-4689-ac89-31cb62dc012c",
    "work_id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "expected_revision": 8,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be",
    "artifact_revision": 2,
    "content_sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312",
    "content_size": 147,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:57:59.844504Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-source-01/workspace",
    "request_sha256": "70a6151081308f067146b1854ea8786a80a3872a550d5a3539cf3d9e071511b2"
  },
  "fingerprint": "b16ca5126b98e7c51255540b470c5d1299f3a07968bbdf22bbf486695cad51f5",
  "before": {
    "id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "revision": 8,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "work",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "revision": 9,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "work",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be",
    "revision": 2,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "artifact",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "work_id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "24d435de-14f5-4db6-a3bf-bd64288e7c6a"
  },
  "artifact_after": {
    "id": "cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be",
    "revision": 3,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "artifact",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "work_id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "80314889-44d7-4c91-869b-61ee19cce764"
  },
  "artifact_version": {
    "id": "80314889-44d7-4c91-869b-61ee19cce764",
    "artifact_id": "cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be",
    "work_id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "artifact_revision": 3,
    "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312",
    "size": 147,
    "created_at": "2026-09-10T07:57:59.861038Z",
    "state_revision": 9
  }
}
```

```json
{
  "id": "a1e97139-0d52-40d5-843e-5ea0d67994b9",
  "state_revision": 10,
  "recorded_at": "2026-09-10T07:57:59.916719Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "93d731d6-6fe5-40f2-aed2-85138fe953d3",
    "workspace_id": "c3dc3e6d-39ec-4689-ac89-31cb62dc012c",
    "work_id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "expected_revision": 9,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be",
        "version_id": "80314889-44d7-4c91-869b-61ee19cce764",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "93d731d6-6fe5-40f2-aed2-85138fe953d3",
      "workspace_id": "c3dc3e6d-39ec-4689-ac89-31cb62dc012c",
      "process": "66117c83-6d1e-4f27-976d-81330c5c1a10",
      "related_work": "d754bb30-3054-47a3-9820-75aa21c2d78d",
      "intent": "accepted_result",
      "source_revision": 9,
      "result": {
        "artifact_id": "cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be",
        "version_id": "80314889-44d7-4c91-869b-61ee19cce764",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "2d6c0969fe80e7ffe6904da6b5ddc5af9c6f3e156a4c43c076a98130660fe6da"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:57:59.900584Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-source-01/workspace",
    "request_sha256": "0a795e36e63c61b2a20011ba3ff03ad51ddb6ef55b01971ec121e4824295cf4a"
  },
  "fingerprint": "81bac5364b4b646f2df6aed16c89e2073d2df415528e75dcc5bc1ccc6521cc4d",
  "before": {
    "id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "revision": 9,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "work",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "revision": 10,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "work",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "597eda9e-877f-4ff1-ab2d-fb8f79891c1e",
  "state_revision": 11,
  "recorded_at": "2026-09-10T07:58:00.123149Z",
  "product_version": "0.10.0",
  "request": {
    "version": 4,
    "operation_id": "a53cb7f3-9c73-45fd-865e-fcdb9ff15e4e",
    "workspace_id": "c3dc3e6d-39ec-4689-ac89-31cb62dc012c",
    "work_id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "expected_revision": 10,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.lot\",\"pack_version\":\"1.0.0\",\"process_type\":\"fictional.lot-release\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be",
        "version_id": "80314889-44d7-4c91-869b-61ee19cce764",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 10,
      "result": {
        "artifact_id": "cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be",
        "version_id": "80314889-44d7-4c91-869b-61ee19cce764",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      },
      "acceptance_ids": [
        "36c976c8-43c2-4eca-92ba-3e78022ed4ea",
        "93d731d6-6fe5-40f2-aed2-85138fe953d3"
      ],
      "next_work": {
        "work_id": "5531899c-c993-4d83-84c6-83b98b506315",
        "artifact_id": "64acc893-cbf3-4011-a93e-9aaec11b5f44",
        "goal": "Choose release or discard for inspected fictional KITE",
        "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
        "acceptance": [
          "Explicit disposition naming the exact accepted inspection SHA256"
        ],
        "boundaries": [
          "Fictional local evidence only; no real release or external action"
        ],
        "budget": "One finite fictional lot",
        "executor_requirements": [
          "fictional.lot/v1:decide",
          "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
        ],
        "artifact_title": "KITE disposition",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:58:00.118500Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-source-01/events/inspection-restored",
    "request_sha256": "5526f546cbc56b1b08aa2c1570098a55ffe5682af35ed16c1ce95fc0409b9f63"
  },
  "fingerprint": "4502deb3a88b523322ea14f98959b1027e02f8f6a078880a99888fc34f67c172",
  "before": {
    "id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "revision": 10,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "work",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "revision": 11,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "work",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "completion_id": "a53cb7f3-9c73-45fd-865e-fcdb9ff15e4e",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "5531899c-c993-4d83-84c6-83b98b506315",
    "revision": 11,
    "created_at": "2026-09-10T07:58:00.123149Z",
    "kind": "work",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "64acc893-cbf3-4011-a93e-9aaec11b5f44",
    "revision": 1,
    "created_at": "2026-09-10T07:58:00.123149Z",
    "kind": "artifact",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "work_id": "5531899c-c993-4d83-84c6-83b98b506315",
    "title": "KITE disposition",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be",
    "revision": 3,
    "created_at": "2026-09-10T07:57:59.414315Z",
    "kind": "artifact",
    "process_id": "66117c83-6d1e-4f27-976d-81330c5c1a10",
    "work_id": "d754bb30-3054-47a3-9820-75aa21c2d78d",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "80314889-44d7-4c91-869b-61ee19cce764"
  },
  "result_references": [
    {
      "artifact_id": "cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be",
      "version_id": "80314889-44d7-4c91-869b-61ee19cce764",
      "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    },
    {
      "artifact_id": "cbe90a0a-63c0-4f83-8ac9-fc1f0ef9d6be",
      "version_id": "24d435de-14f5-4db6-a3bf-bd64288e7c6a",
      "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
    }
  ]
}
```

