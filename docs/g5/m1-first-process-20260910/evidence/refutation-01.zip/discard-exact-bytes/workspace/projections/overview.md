# Zaratustra — generated overview

generated_from_revision: 19
generated_at: 2026-09-10T08:01:49.478691+00:00
workspace_id: 8b3976d8-8119-4ff0-b14d-ab33c3933f89

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "8868f647-0f46-41a3-8e70-55ee938ac472",
  "revision": 3,
  "created_at": "2026-09-10T08:01:48.845967Z",
  "kind": "artifact",
  "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
  "work_id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
  "title": "KITE disposition",
  "status": "registered",
  "active_version": "9a8ae97d-a81a-49e8-b7aa-30f75df85010"
}
```

## artifact

```json
{
  "id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
  "revision": 3,
  "created_at": "2026-09-10T08:01:48.349694Z",
  "kind": "artifact",
  "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
  "work_id": "15c61f52-21c3-4476-ba5b-4388f6224651",
  "title": "KITE inspection",
  "status": "registered",
  "active_version": "cfe2a7b3-5ede-4ce8-bbb7-861dfab4979e"
}
```

## artifact

```json
{
  "id": "fb8d688f-c77f-48cf-9378-105696d41ba3",
  "revision": 1,
  "created_at": "2026-09-10T08:01:49.363099Z",
  "kind": "artifact",
  "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
  "work_id": "112d9296-6ae3-475a-9266-7543fca60b40",
  "title": "Unused closed continuation (no Result claimed)",
  "status": "declared",
  "active_version": null
}
```

## event

```json
{
  "id": "eb85d55c-310c-49f5-b6c7-b3a4d6aeef46",
  "revision": 1,
  "created_at": "2026-09-10T08:01:48.349694Z",
  "kind": "event",
  "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
  "work_id": "15c61f52-21c3-4476-ba5b-4388f6224651",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.0",
  "state_revision": 1,
  "affected_ids": [
    "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "15c61f52-21c3-4476-ba5b-4388f6224651",
    "be8d04cc-102c-4af2-b9c6-d2931233032f"
  ]
}
```

## process

```json
{
  "id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
  "revision": 4,
  "created_at": "2026-09-10T08:01:48.349694Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "112d9296-6ae3-475a-9266-7543fca60b40",
  "revision": 19,
  "created_at": "2026-09-10T08:01:49.363099Z",
  "kind": "work",
  "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
  "goal": "Fictional KITE discard; cancel unused continuation",
  "expected_result": "No further package work; trusted host explicitly cancels this Work",
  "acceptance": [
    "No further package work; trusted host explicitly cancels this Work"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "cancelled",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:closed",
    "discard"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "15c61f52-21c3-4476-ba5b-4388f6224651",
  "revision": 11,
  "created_at": "2026-09-10T08:01:48.349694Z",
  "kind": "work",
  "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "completion_id": "2a9aeb29-3dc4-409c-81b8-dee9231b56fe",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
  "revision": 18,
  "created_at": "2026-09-10T08:01:48.845967Z",
  "kind": "work",
  "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
  "goal": "Choose release or discard for inspected fictional KITE",
  "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
  "acceptance": [
    "Explicit disposition naming the exact accepted inspection SHA256"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:decide",
    "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
  ],
  "completion_id": "74abe4d8-256b-4967-92cb-886c3e5a8f82",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 41b38f46-beaa-4c27-bae8-2eb24b0e697b; Artifact revision: 2
  SHA-256: 07bce5e92d24265f070ca928548aaadc38de8c097ca5950f10bb681a9cf62e7c; bytes: 163
  File: artifacts/be8d04cc-102c-4af2-b9c6-d2931233032f/41b38f46-beaa-4c27-bae8-2eb24b0e697b.blob

- Version: ed371d31-68d2-492c-87b5-58ceff119b57; Artifact revision: 2
  SHA-256: 7a7cad6edad363bd42b263f58be892ad549e146b2ea538daa958144b28255d12; bytes: 152
  File: artifacts/8868f647-0f46-41a3-8e70-55ee938ac472/ed371d31-68d2-492c-87b5-58ceff119b57.blob

- Version: 9a8ae97d-a81a-49e8-b7aa-30f75df85010; Artifact revision: 3
  SHA-256: 4e7324a0ead1005489f1cc620b3b9790fb42b4932cbba6aae7e8e17f071edf75; bytes: 152
  File: artifacts/8868f647-0f46-41a3-8e70-55ee938ac472/9a8ae97d-a81a-49e8-b7aa-30f75df85010.blob

- Version: cfe2a7b3-5ede-4ce8-bbb7-861dfab4979e; Artifact revision: 3
  SHA-256: 4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d; bytes: 262
  File: artifacts/be8d04cc-102c-4af2-b9c6-d2931233032f/cfe2a7b3-5ede-4ce8-bbb7-861dfab4979e.blob

## Mutation provenance

```json
{
  "id": "6a6b5fd1-f43f-4843-ba08-ac8c0863fe1e",
  "state_revision": 2,
  "recorded_at": "2026-09-10T08:01:48.386973Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "d545232e-d016-4544-a296-a38577ec0f1b",
    "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
    "work_id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:01:48.382731Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-01/discard-exact-bytes/workspace",
    "request_sha256": "ac1dd71bc8cc6e120a1644ab2167d266fb3fed67af6a6528fd51766451f42851"
  },
  "fingerprint": "e5780d89b49890597dbb5f6e023f3db5ebd055cd3ea1547ad5627bd388ca5c42",
  "before": {
    "id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "revision": 1,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "revision": 2,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "574a014c-d249-4ed8-808c-d967faf9cae0",
  "state_revision": 3,
  "recorded_at": "2026-09-10T08:01:48.415958Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "21f2b866-e32d-47a1-a1f4-09fc8fb05a99",
    "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
    "work_id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:01:48.411831Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-01/discard-exact-bytes/workspace",
    "request_sha256": "995323760291d58f997941d82246b8fba43f67ea5e7e84c64da06c3c30d5cc25"
  },
  "fingerprint": "47319608ef6cfab3aaa721d30c047e51995c4dcfc80088143babbbbbf13bb9ca",
  "before": {
    "id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "revision": 2,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "revision": 3,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "3431ab57-4c77-4239-b454-0593c1881107",
  "state_revision": 4,
  "recorded_at": "2026-09-10T08:01:48.447283Z",
  "product_version": "0.10.0",
  "request": {
    "version": 5,
    "operation_id": "621c0969-aa1f-429b-910d-ebe8f4b3591e",
    "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
    "work_id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:01:48.442123Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-01/discard-exact-bytes/workspace",
    "request_sha256": "38e3ce0f255df6a99a2559d8cbc32ffc5662c38125063c50e1cb56515680d2d2"
  },
  "fingerprint": "838ac85994a9da23893f7e04f7215f5b3b36a2f20762044aaaf59aba214c3468",
  "before": {
    "id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "revision": 3,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "revision": 4,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "revision": 1,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "revision": 4,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "812e8a77-676e-4dfe-adfb-62b0ddad5246",
  "state_revision": 5,
  "recorded_at": "2026-09-10T08:01:48.478478Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "5c9e6bfc-316d-417f-8073-31e7b757e038",
    "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
    "work_id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:01:48.473818Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-01/discard-exact-bytes/workspace",
    "request_sha256": "6d9bd6b749747c628fc32b1e5f660756b1dc7f6a4db4148f0fb6819c91ed6fc6"
  },
  "fingerprint": "bdc7d61a208059173a5c54804656f78a440fee456db1d038b04ca4e181a2ac1a",
  "before": {
    "id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "revision": 4,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "revision": 5,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "e59e8cb4-8e77-4d23-91b2-9bda71fb0aff",
  "state_revision": 6,
  "recorded_at": "2026-09-10T08:01:48.510535Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "41b38f46-beaa-4c27-bae8-2eb24b0e697b",
    "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
    "work_id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
    "artifact_revision": 1,
    "content_sha256": "07bce5e92d24265f070ca928548aaadc38de8c097ca5950f10bb681a9cf62e7c",
    "content_size": 163,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:01:48.505655Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-01/discard-exact-bytes/workspace",
    "request_sha256": "3e3bc1c94aa493a965c7e6fcaa7b6b21b95ba972466bec12ed10c62e6d11befa"
  },
  "fingerprint": "1a569b9feb0070eae7e8626c4409918dc00e87655fef0bf8711da93ec28fc102",
  "before": {
    "id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "revision": 5,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "revision": 6,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
    "revision": 1,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "artifact",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "work_id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "title": "KITE inspection",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
    "revision": 2,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "artifact",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "work_id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "41b38f46-beaa-4c27-bae8-2eb24b0e697b"
  },
  "artifact_version": {
    "id": "41b38f46-beaa-4c27-bae8-2eb24b0e697b",
    "artifact_id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
    "work_id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "artifact_revision": 2,
    "sha256": "07bce5e92d24265f070ca928548aaadc38de8c097ca5950f10bb681a9cf62e7c",
    "size": 163,
    "created_at": "2026-09-10T08:01:48.510535Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "42141f99-5f2e-455b-90e2-b3af076e9a4d",
  "state_revision": 7,
  "recorded_at": "2026-09-10T08:01:48.559523Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "bb5c0eec-c9cc-4d27-bb5e-89528766018b",
    "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
    "work_id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
        "version_id": "41b38f46-beaa-4c27-bae8-2eb24b0e697b",
        "sha256": "07bce5e92d24265f070ca928548aaadc38de8c097ca5950f10bb681a9cf62e7c"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "bb5c0eec-c9cc-4d27-bb5e-89528766018b",
      "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
      "process": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
      "related_work": "15c61f52-21c3-4476-ba5b-4388f6224651",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
        "version_id": "41b38f46-beaa-4c27-bae8-2eb24b0e697b",
        "sha256": "07bce5e92d24265f070ca928548aaadc38de8c097ca5950f10bb681a9cf62e7c"
      },
      "basis": [],
      "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "G5 fictional host"
    },
    "delivery": {
      "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
      "input_sha256": "833ded438c5325dbd863e68a63ffdc1fd7754672fa30e2a282c0530c5e140d35"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:01:48.554094Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-01/discard-exact-bytes/workspace",
    "request_sha256": "d5d3afba763ba700e8efbb0a534410ca9e0f3c2016c637aa14b5ed25fd06323b"
  },
  "fingerprint": "cfc7ed7f931ce884d953e5cc30de4c32db473162b070ed76e13bf7a1cc7c88d5",
  "before": {
    "id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "revision": 6,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "revision": 7,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "099f7671-d828-4c54-9e4e-ec1041d7a982",
  "state_revision": 8,
  "recorded_at": "2026-09-10T08:01:48.617986Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "4087c2e8-de25-4f60-801d-1a3926cc3676",
    "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
    "work_id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "expected_revision": 7,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
    "artifact_revision": 2,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:01:48.612590Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-01/discard-exact-bytes/workspace",
    "request_sha256": "405c4f2da8cbb44005e525ea37c48fc707572edc6723e3b12a986f5473664b1b"
  },
  "fingerprint": "c47666d47746ded3b63b39a3debbf55cd5253d375acd460fc19f1032ddbb6d33",
  "before": {
    "id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "revision": 7,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "revision": 8,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "ba6836d0-2b04-4d5b-9c91-575ee7b0f7b0",
  "state_revision": 9,
  "recorded_at": "2026-09-10T08:01:48.655086Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "cfe2a7b3-5ede-4ce8-bbb7-861dfab4979e",
    "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
    "work_id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "expected_revision": 8,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
    "artifact_revision": 2,
    "content_sha256": "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d",
    "content_size": 262,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:01:48.648632Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-01/discard-exact-bytes/workspace",
    "request_sha256": "e2f366a263a5fa2944ca430f847419f40f89a38b0f4590775422964c2a0574d0"
  },
  "fingerprint": "a2d78c4295b6734b29a3f1ccadd9e1b4f43d2774649cec2955ca34676676a9c5",
  "before": {
    "id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "revision": 8,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "revision": 9,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
    "revision": 2,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "artifact",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "work_id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "41b38f46-beaa-4c27-bae8-2eb24b0e697b"
  },
  "artifact_after": {
    "id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
    "revision": 3,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "artifact",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "work_id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "cfe2a7b3-5ede-4ce8-bbb7-861dfab4979e"
  },
  "artifact_version": {
    "id": "cfe2a7b3-5ede-4ce8-bbb7-861dfab4979e",
    "artifact_id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
    "work_id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "artifact_revision": 3,
    "sha256": "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d",
    "size": 262,
    "created_at": "2026-09-10T08:01:48.655086Z",
    "state_revision": 9
  }
}
```

```json
{
  "id": "3e74a53d-0c6b-413d-9729-317dc559c351",
  "state_revision": 10,
  "recorded_at": "2026-09-10T08:01:48.706675Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "52f4ebaf-fd77-4616-a401-415f0536f597",
    "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
    "work_id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "expected_revision": 9,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
        "version_id": "cfe2a7b3-5ede-4ce8-bbb7-861dfab4979e",
        "sha256": "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "52f4ebaf-fd77-4616-a401-415f0536f597",
      "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
      "process": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
      "related_work": "15c61f52-21c3-4476-ba5b-4388f6224651",
      "intent": "accepted_result",
      "source_revision": 9,
      "result": {
        "artifact_id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
        "version_id": "cfe2a7b3-5ede-4ce8-bbb7-861dfab4979e",
        "sha256": "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
      },
      "basis": [],
      "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "G5 fictional host"
    },
    "delivery": {
      "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
      "input_sha256": "621d4aab3926112bd8696db5771f9fa702b6de7fdb6871bc6ae15c6cbf61efbe"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:01:48.700302Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-01/discard-exact-bytes/workspace",
    "request_sha256": "db649c9e5433d353e306e7d12d9822a5489f0dc6c8ab73bc84e3e5e0a65b9179"
  },
  "fingerprint": "71914e790eed4692394d92dbe4df46136b9191bdf379904a7566990beefb78e0",
  "before": {
    "id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "revision": 9,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "revision": 10,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "b1013ab6-c324-4539-8ac2-f31ce2b237f6",
  "state_revision": 11,
  "recorded_at": "2026-09-10T08:01:48.845967Z",
  "product_version": "0.10.0",
  "request": {
    "version": 4,
    "operation_id": "2a9aeb29-3dc4-409c-81b8-dee9231b56fe",
    "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
    "work_id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "expected_revision": 10,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.lot\",\"pack_version\":\"1.0.0\",\"process_type\":\"fictional.lot-release\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
        "version_id": "cfe2a7b3-5ede-4ce8-bbb7-861dfab4979e",
        "sha256": "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 10,
      "result": {
        "artifact_id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
        "version_id": "cfe2a7b3-5ede-4ce8-bbb7-861dfab4979e",
        "sha256": "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
      },
      "acceptance_ids": [
        "bb5c0eec-c9cc-4d27-bb5e-89528766018b",
        "52f4ebaf-fd77-4616-a401-415f0536f597"
      ],
      "next_work": {
        "work_id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
        "artifact_id": "8868f647-0f46-41a3-8e70-55ee938ac472",
        "goal": "Choose release or discard for inspected fictional KITE",
        "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
        "acceptance": [
          "Explicit disposition naming the exact accepted inspection SHA256"
        ],
        "boundaries": [
          "Fictional local evidence only; no real release or external action"
        ],
        "budget": "One finite fictional lot",
        "executor_requirements": [
          "fictional.lot/v1:decide",
          "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
        ],
        "artifact_title": "KITE disposition",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:01:48.838852Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-01/discard-exact-bytes/workspace",
    "request_sha256": "fb1226a1a9560635ef8d2e48755f4d6d8d0238797cd81135fd3c3f45c7ab491b"
  },
  "fingerprint": "0e1b035f28f3b5953435e45cf15916e3013f69a7cbc312ee28f9cd1003fd0ad3",
  "before": {
    "id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "revision": 10,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "revision": 11,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "completion_id": "2a9aeb29-3dc4-409c-81b8-dee9231b56fe",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "revision": 11,
    "created_at": "2026-09-10T08:01:48.845967Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "8868f647-0f46-41a3-8e70-55ee938ac472",
    "revision": 1,
    "created_at": "2026-09-10T08:01:48.845967Z",
    "kind": "artifact",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "work_id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "title": "KITE disposition",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
    "revision": 3,
    "created_at": "2026-09-10T08:01:48.349694Z",
    "kind": "artifact",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "work_id": "15c61f52-21c3-4476-ba5b-4388f6224651",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "cfe2a7b3-5ede-4ce8-bbb7-861dfab4979e"
  },
  "result_references": [
    {
      "artifact_id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
      "version_id": "cfe2a7b3-5ede-4ce8-bbb7-861dfab4979e",
      "sha256": "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    },
    {
      "artifact_id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
      "version_id": "41b38f46-beaa-4c27-bae8-2eb24b0e697b",
      "sha256": "07bce5e92d24265f070ca928548aaadc38de8c097ca5950f10bb681a9cf62e7c"
    }
  ]
}
```

```json
{
  "id": "515b8686-55a8-4832-8a8a-c639426ded20",
  "state_revision": 12,
  "recorded_at": "2026-09-10T08:01:48.982549Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "3c4fe2e5-d00f-44b6-8e22-8115f877c6e8",
    "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
    "work_id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "expected_revision": 11,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": "8868f647-0f46-41a3-8e70-55ee938ac472",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:01:48.974945Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-01/discard-exact-bytes/workspace",
    "request_sha256": "f82d2a9150a2e03b4740618c8271fbe1bc17ae0d1211b9abb87d8825d96f5644"
  },
  "fingerprint": "58b628f61e45f4d77f4c034630fa3c9dd8b29951546f986f40078f573e3c3185",
  "before": {
    "id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "revision": 11,
    "created_at": "2026-09-10T08:01:48.845967Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "revision": 12,
    "created_at": "2026-09-10T08:01:48.845967Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "e60b736c-1ccb-4906-a28f-d1ece0dc0edb",
  "state_revision": 13,
  "recorded_at": "2026-09-10T08:01:49.026342Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "ed371d31-68d2-492c-87b5-58ceff119b57",
    "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
    "work_id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "expected_revision": 12,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": "8868f647-0f46-41a3-8e70-55ee938ac472",
    "artifact_revision": 1,
    "content_sha256": "7a7cad6edad363bd42b263f58be892ad549e146b2ea538daa958144b28255d12",
    "content_size": 152,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:01:49.018330Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-01/discard-exact-bytes/workspace",
    "request_sha256": "d07c27dd209503aacb123b25eb64e49741dc0fa2d111e4ed67976cc2dea3b1f1"
  },
  "fingerprint": "3676b24beb0ced5ef2a6fdc403e78aca82e09621589339af956aafca40c1dcd1",
  "before": {
    "id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "revision": 12,
    "created_at": "2026-09-10T08:01:48.845967Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "revision": 13,
    "created_at": "2026-09-10T08:01:48.845967Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "8868f647-0f46-41a3-8e70-55ee938ac472",
    "revision": 1,
    "created_at": "2026-09-10T08:01:48.845967Z",
    "kind": "artifact",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "work_id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "title": "KITE disposition",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "8868f647-0f46-41a3-8e70-55ee938ac472",
    "revision": 2,
    "created_at": "2026-09-10T08:01:48.845967Z",
    "kind": "artifact",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "work_id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "title": "KITE disposition",
    "status": "registered",
    "active_version": "ed371d31-68d2-492c-87b5-58ceff119b57"
  },
  "artifact_version": {
    "id": "ed371d31-68d2-492c-87b5-58ceff119b57",
    "artifact_id": "8868f647-0f46-41a3-8e70-55ee938ac472",
    "work_id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "artifact_revision": 2,
    "sha256": "7a7cad6edad363bd42b263f58be892ad549e146b2ea538daa958144b28255d12",
    "size": 152,
    "created_at": "2026-09-10T08:01:49.026342Z",
    "state_revision": 13
  }
}
```

```json
{
  "id": "f6f650a2-3a16-4f5f-a2aa-6b03a1ff1366",
  "state_revision": 14,
  "recorded_at": "2026-09-10T08:01:49.088872Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "63a9a0da-857e-4076-9222-f5ee4d7ddf24",
    "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
    "work_id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "expected_revision": 13,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "8868f647-0f46-41a3-8e70-55ee938ac472",
        "version_id": "ed371d31-68d2-492c-87b5-58ceff119b57",
        "sha256": "7a7cad6edad363bd42b263f58be892ad549e146b2ea538daa958144b28255d12"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "63a9a0da-857e-4076-9222-f5ee4d7ddf24",
      "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
      "process": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
      "related_work": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
      "intent": "accepted_result",
      "source_revision": 13,
      "result": {
        "artifact_id": "8868f647-0f46-41a3-8e70-55ee938ac472",
        "version_id": "ed371d31-68d2-492c-87b5-58ceff119b57",
        "sha256": "7a7cad6edad363bd42b263f58be892ad549e146b2ea538daa958144b28255d12"
      },
      "basis": [],
      "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "G5 fictional host"
    },
    "delivery": {
      "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
      "input_sha256": "29706f096daa5d014de18292c0d87d85aa76889cc743c2f3735776e9e5f0250b"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:01:49.080377Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-01/discard-exact-bytes/workspace",
    "request_sha256": "5df855f67e94aa113eb05e6d139f65054f9c82d2b55981494f5b254097139dc1"
  },
  "fingerprint": "9ae3037aa2ba24e2f1ecaf70478e09be190d978c1eec8c831ccc22ea17cc3b3c",
  "before": {
    "id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "revision": 13,
    "created_at": "2026-09-10T08:01:48.845967Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "revision": 14,
    "created_at": "2026-09-10T08:01:48.845967Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "0f1f9b9c-51eb-4cc6-908d-ce00e8c9d528",
  "state_revision": 15,
  "recorded_at": "2026-09-10T08:01:49.166270Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "d5676bc0-83e7-4207-9d47-1861c51eb3b9",
    "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
    "work_id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "expected_revision": 14,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": "8868f647-0f46-41a3-8e70-55ee938ac472",
    "artifact_revision": 2,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:01:49.157903Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-01/discard-exact-bytes/workspace",
    "request_sha256": "5ad7ada014cdbbdc843ff57ec94000b7eb2ee3ba9ea002b8a8cfa19d579102c5"
  },
  "fingerprint": "1ab3e0990c67fef8ea5becbfe4b37f1d6a4898e5f038c8b378275dd867632649",
  "before": {
    "id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "revision": 14,
    "created_at": "2026-09-10T08:01:48.845967Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "revision": 15,
    "created_at": "2026-09-10T08:01:48.845967Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "4b850327-187f-4f5f-9bf1-a5d1aecf7dea",
  "state_revision": 16,
  "recorded_at": "2026-09-10T08:01:49.209879Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "9a8ae97d-a81a-49e8-b7aa-30f75df85010",
    "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
    "work_id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "expected_revision": 15,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": "8868f647-0f46-41a3-8e70-55ee938ac472",
    "artifact_revision": 2,
    "content_sha256": "4e7324a0ead1005489f1cc620b3b9790fb42b4932cbba6aae7e8e17f071edf75",
    "content_size": 152,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:01:49.201855Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-01/discard-exact-bytes/workspace",
    "request_sha256": "abf6a59f852b9ed7aefc88c4e631e8a0ade90f882dff101baac7dfd874ee0d99"
  },
  "fingerprint": "153e82549d11c367fd4db5e6b1ac3380cce628f85ed55127beb0c4377c5fa6b5",
  "before": {
    "id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "revision": 15,
    "created_at": "2026-09-10T08:01:48.845967Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "revision": 16,
    "created_at": "2026-09-10T08:01:48.845967Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "8868f647-0f46-41a3-8e70-55ee938ac472",
    "revision": 2,
    "created_at": "2026-09-10T08:01:48.845967Z",
    "kind": "artifact",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "work_id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "title": "KITE disposition",
    "status": "registered",
    "active_version": "ed371d31-68d2-492c-87b5-58ceff119b57"
  },
  "artifact_after": {
    "id": "8868f647-0f46-41a3-8e70-55ee938ac472",
    "revision": 3,
    "created_at": "2026-09-10T08:01:48.845967Z",
    "kind": "artifact",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "work_id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "title": "KITE disposition",
    "status": "registered",
    "active_version": "9a8ae97d-a81a-49e8-b7aa-30f75df85010"
  },
  "artifact_version": {
    "id": "9a8ae97d-a81a-49e8-b7aa-30f75df85010",
    "artifact_id": "8868f647-0f46-41a3-8e70-55ee938ac472",
    "work_id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "artifact_revision": 3,
    "sha256": "4e7324a0ead1005489f1cc620b3b9790fb42b4932cbba6aae7e8e17f071edf75",
    "size": 152,
    "created_at": "2026-09-10T08:01:49.209879Z",
    "state_revision": 16
  }
}
```

```json
{
  "id": "c6900935-f044-466b-b102-316fdf9e6c3a",
  "state_revision": 17,
  "recorded_at": "2026-09-10T08:01:49.271056Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "a81cf3c3-f123-40a4-abe0-c6f5dcf44228",
    "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
    "work_id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "expected_revision": 16,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "8868f647-0f46-41a3-8e70-55ee938ac472",
        "version_id": "9a8ae97d-a81a-49e8-b7aa-30f75df85010",
        "sha256": "4e7324a0ead1005489f1cc620b3b9790fb42b4932cbba6aae7e8e17f071edf75"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "a81cf3c3-f123-40a4-abe0-c6f5dcf44228",
      "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
      "process": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
      "related_work": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
      "intent": "accepted_result",
      "source_revision": 16,
      "result": {
        "artifact_id": "8868f647-0f46-41a3-8e70-55ee938ac472",
        "version_id": "9a8ae97d-a81a-49e8-b7aa-30f75df85010",
        "sha256": "4e7324a0ead1005489f1cc620b3b9790fb42b4932cbba6aae7e8e17f071edf75"
      },
      "basis": [],
      "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "G5 fictional host"
    },
    "delivery": {
      "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
      "input_sha256": "e39ed03d10334a386708d55faa6771df4e7d0f9b3250ef89920a189adb0fb379"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:01:49.261350Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-01/discard-exact-bytes/workspace",
    "request_sha256": "5943c58f231b2da83dc2211babf8c13819e5c7b5c94611b89aea83a992766f7d"
  },
  "fingerprint": "325cf903a9df3ea32267f9f80e02e81f409f56d0afb268b04c562d4f830f75e5",
  "before": {
    "id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "revision": 16,
    "created_at": "2026-09-10T08:01:48.845967Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "revision": 17,
    "created_at": "2026-09-10T08:01:48.845967Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "f9706e30-8b44-4fc8-b6ce-1ec4c871daf7",
  "state_revision": 18,
  "recorded_at": "2026-09-10T08:01:49.363099Z",
  "product_version": "0.10.0",
  "request": {
    "version": 4,
    "operation_id": "74abe4d8-256b-4967-92cb-886c3e5a8f82",
    "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
    "work_id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "expected_revision": 17,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.lot\",\"pack_version\":\"1.0.0\",\"process_type\":\"fictional.lot-release\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "8868f647-0f46-41a3-8e70-55ee938ac472",
        "version_id": "9a8ae97d-a81a-49e8-b7aa-30f75df85010",
        "sha256": "4e7324a0ead1005489f1cc620b3b9790fb42b4932cbba6aae7e8e17f071edf75"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 17,
      "result": {
        "artifact_id": "8868f647-0f46-41a3-8e70-55ee938ac472",
        "version_id": "9a8ae97d-a81a-49e8-b7aa-30f75df85010",
        "sha256": "4e7324a0ead1005489f1cc620b3b9790fb42b4932cbba6aae7e8e17f071edf75"
      },
      "acceptance_ids": [
        "63a9a0da-857e-4076-9222-f5ee4d7ddf24",
        "a81cf3c3-f123-40a4-abe0-c6f5dcf44228"
      ],
      "next_work": {
        "work_id": "112d9296-6ae3-475a-9266-7543fca60b40",
        "artifact_id": "fb8d688f-c77f-48cf-9378-105696d41ba3",
        "goal": "Fictional KITE discard; cancel unused continuation",
        "expected_result": "No further package work; trusted host explicitly cancels this Work",
        "acceptance": [
          "No further package work; trusted host explicitly cancels this Work"
        ],
        "boundaries": [
          "Fictional local evidence only; no real release or external action"
        ],
        "budget": "One finite fictional lot",
        "executor_requirements": [
          "fictional.lot/v1:closed",
          "discard"
        ],
        "artifact_title": "Unused closed continuation (no Result claimed)",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:01:49.352418Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-01/discard-exact-bytes/workspace",
    "request_sha256": "eec6136c7a6961017385c27cd105918f1ef313e705ada6f85ff752abd71a87a2"
  },
  "fingerprint": "dc6e30ad611ed9930287adda8b5f27bd774e89fa43df77074b90bd1a32af6cc9",
  "before": {
    "id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "revision": 17,
    "created_at": "2026-09-10T08:01:48.845967Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "revision": 18,
    "created_at": "2026-09-10T08:01:48.845967Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "completion_id": "74abe4d8-256b-4967-92cb-886c3e5a8f82",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "112d9296-6ae3-475a-9266-7543fca60b40",
    "revision": 18,
    "created_at": "2026-09-10T08:01:49.363099Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Fictional KITE discard; cancel unused continuation",
    "expected_result": "No further package work; trusted host explicitly cancels this Work",
    "acceptance": [
      "No further package work; trusted host explicitly cancels this Work"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:closed",
      "discard"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "fb8d688f-c77f-48cf-9378-105696d41ba3",
    "revision": 1,
    "created_at": "2026-09-10T08:01:49.363099Z",
    "kind": "artifact",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "work_id": "112d9296-6ae3-475a-9266-7543fca60b40",
    "title": "Unused closed continuation (no Result claimed)",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "8868f647-0f46-41a3-8e70-55ee938ac472",
    "revision": 3,
    "created_at": "2026-09-10T08:01:48.845967Z",
    "kind": "artifact",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "work_id": "3f2b195e-53cd-47d8-9cd4-07bef1b699f2",
    "title": "KITE disposition",
    "status": "registered",
    "active_version": "9a8ae97d-a81a-49e8-b7aa-30f75df85010"
  },
  "result_references": [
    {
      "artifact_id": "8868f647-0f46-41a3-8e70-55ee938ac472",
      "version_id": "9a8ae97d-a81a-49e8-b7aa-30f75df85010",
      "sha256": "4e7324a0ead1005489f1cc620b3b9790fb42b4932cbba6aae7e8e17f071edf75"
    },
    {
      "artifact_id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
      "version_id": "cfe2a7b3-5ede-4ce8-bbb7-861dfab4979e",
      "sha256": "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    },
    {
      "artifact_id": "be8d04cc-102c-4af2-b9c6-d2931233032f",
      "version_id": "41b38f46-beaa-4c27-bae8-2eb24b0e697b",
      "sha256": "07bce5e92d24265f070ca928548aaadc38de8c097ca5950f10bb681a9cf62e7c"
    },
    {
      "artifact_id": "8868f647-0f46-41a3-8e70-55ee938ac472",
      "version_id": "ed371d31-68d2-492c-87b5-58ceff119b57",
      "sha256": "7a7cad6edad363bd42b263f58be892ad549e146b2ea538daa958144b28255d12"
    }
  ]
}
```

```json
{
  "id": "6067b3ba-5171-48ba-a11e-7c8bd4968572",
  "state_revision": 19,
  "recorded_at": "2026-09-10T08:01:49.478691Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "d340d287-63b5-42c9-a3e4-ee895b4967c2",
    "workspace_id": "8b3976d8-8119-4ff0-b14d-ab33c3933f89",
    "work_id": "112d9296-6ae3-475a-9266-7543fca60b40",
    "expected_revision": 18,
    "operation": "cancel_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:01:49.468974Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-01/discard-exact-bytes/workspace",
    "request_sha256": "532556f3e909fd778858e0bbb90a1036edc8a76572b2a1378af6a3744f29b9cc"
  },
  "fingerprint": "a9accdf89981437871a384cd3d62f7714750e5f48f0dff83a34b5a13fe48a0d7",
  "before": {
    "id": "112d9296-6ae3-475a-9266-7543fca60b40",
    "revision": 18,
    "created_at": "2026-09-10T08:01:49.363099Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Fictional KITE discard; cancel unused continuation",
    "expected_result": "No further package work; trusted host explicitly cancels this Work",
    "acceptance": [
      "No further package work; trusted host explicitly cancels this Work"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:closed",
      "discard"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "112d9296-6ae3-475a-9266-7543fca60b40",
    "revision": 19,
    "created_at": "2026-09-10T08:01:49.363099Z",
    "kind": "work",
    "process_id": "43bef2b4-033c-45ae-8963-1e5c3d6b1bc0",
    "goal": "Fictional KITE discard; cancel unused continuation",
    "expected_result": "No further package work; trusted host explicitly cancels this Work",
    "acceptance": [
      "No further package work; trusted host explicitly cancels this Work"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "cancelled",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:closed",
      "discard"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

