# Zaratustra — generated overview

generated_from_revision: 19
generated_at: 2026-09-10T08:02:30.695650+00:00
workspace_id: b7e6f5d6-3c45-42df-a42b-51ff59d1812a

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
  "revision": 3,
  "created_at": "2026-09-10T08:02:30.073937Z",
  "kind": "artifact",
  "process_id": "afd5911e-e8a0-4632-971d-007908417199",
  "work_id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
  "title": "KITE disposition",
  "status": "registered",
  "active_version": "540d98ee-ef50-40f2-be0c-530d84544675"
}
```

## artifact

```json
{
  "id": "b239e8b7-a745-4cc1-8355-03b508de78f1",
  "revision": 1,
  "created_at": "2026-09-10T08:02:30.583655Z",
  "kind": "artifact",
  "process_id": "afd5911e-e8a0-4632-971d-007908417199",
  "work_id": "2366fe9e-42a2-4e5f-8751-284c954a83b4",
  "title": "Unused closed continuation (no Result claimed)",
  "status": "declared",
  "active_version": null
}
```

## artifact

```json
{
  "id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
  "revision": 3,
  "created_at": "2026-09-10T08:02:29.591522Z",
  "kind": "artifact",
  "process_id": "afd5911e-e8a0-4632-971d-007908417199",
  "work_id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
  "title": "KITE inspection",
  "status": "registered",
  "active_version": "f03d3956-94ea-41ec-9660-0260170adfe1"
}
```

## event

```json
{
  "id": "5fa54f66-6e0a-454e-95f2-cd1dec74b93d",
  "revision": 1,
  "created_at": "2026-09-10T08:02:29.591522Z",
  "kind": "event",
  "process_id": "afd5911e-e8a0-4632-971d-007908417199",
  "work_id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.0",
  "state_revision": 1,
  "affected_ids": [
    "afd5911e-e8a0-4632-971d-007908417199",
    "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "c313e8ff-d400-4bb4-a094-d745bbf4a9b4"
  ]
}
```

## process

```json
{
  "id": "afd5911e-e8a0-4632-971d-007908417199",
  "revision": 4,
  "created_at": "2026-09-10T08:02:29.591522Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
  "revision": 11,
  "created_at": "2026-09-10T08:02:29.591522Z",
  "kind": "work",
  "process_id": "afd5911e-e8a0-4632-971d-007908417199",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "completion_id": "99d1e2a3-5b1a-45ca-bd2c-90fea3b42d08",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "2366fe9e-42a2-4e5f-8751-284c954a83b4",
  "revision": 19,
  "created_at": "2026-09-10T08:02:30.583655Z",
  "kind": "work",
  "process_id": "afd5911e-e8a0-4632-971d-007908417199",
  "goal": "Fictional KITE discard; cancel unused continuation",
  "expected_result": "No further package work; trusted host explicitly cancels this Work",
  "acceptance": [
    "No further package work; trusted host explicitly cancels this Work"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "cancelled",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:closed",
    "discard"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
  "revision": 18,
  "created_at": "2026-09-10T08:02:30.073937Z",
  "kind": "work",
  "process_id": "afd5911e-e8a0-4632-971d-007908417199",
  "goal": "Choose release or discard for inspected fictional KITE",
  "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
  "acceptance": [
    "Explicit disposition naming the exact accepted inspection SHA256"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:decide",
    "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
  ],
  "completion_id": "45dc9549-f86d-4efe-be87-39ec7565b127",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 787780d6-facc-472a-9ed0-076f8a082251; Artifact revision: 2
  SHA-256: 07bce5e92d24265f070ca928548aaadc38de8c097ca5950f10bb681a9cf62e7c; bytes: 163
  File: artifacts/c313e8ff-d400-4bb4-a094-d745bbf4a9b4/787780d6-facc-472a-9ed0-076f8a082251.blob

- Version: 99b83dfd-f586-45ba-a5ea-18aa95baa4b4; Artifact revision: 2
  SHA-256: 7a7cad6edad363bd42b263f58be892ad549e146b2ea538daa958144b28255d12; bytes: 152
  File: artifacts/a3046ecb-ee8e-46d3-b463-e9d956f545f6/99b83dfd-f586-45ba-a5ea-18aa95baa4b4.blob

- Version: 540d98ee-ef50-40f2-be0c-530d84544675; Artifact revision: 3
  SHA-256: 4e7324a0ead1005489f1cc620b3b9790fb42b4932cbba6aae7e8e17f071edf75; bytes: 152
  File: artifacts/a3046ecb-ee8e-46d3-b463-e9d956f545f6/540d98ee-ef50-40f2-be0c-530d84544675.blob

- Version: f03d3956-94ea-41ec-9660-0260170adfe1; Artifact revision: 3
  SHA-256: 4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d; bytes: 262
  File: artifacts/c313e8ff-d400-4bb4-a094-d745bbf4a9b4/f03d3956-94ea-41ec-9660-0260170adfe1.blob

## Mutation provenance

```json
{
  "id": "dc907460-530d-4a8e-aa2c-b89e5bf8a559",
  "state_revision": 2,
  "recorded_at": "2026-09-10T08:02:29.627472Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "c81d9ee7-3f3d-402d-a9ab-a27bd644665e",
    "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
    "work_id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:29.624074Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/discard-exact-bytes/workspace",
    "request_sha256": "0f7a024ec39319f65aa022a33f8ddb62e6b73029fcc66338507228352db6607b"
  },
  "fingerprint": "aa90f3aa3f79cf8b910422bc4ac588aab310748c0ab612f0851cc3cef4886ac1",
  "before": {
    "id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "revision": 1,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "revision": 2,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "b94d6354-1d02-4159-b0cf-f085434fb7b8",
  "state_revision": 3,
  "recorded_at": "2026-09-10T08:02:29.655350Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "65bc5118-e938-46a0-87f4-930f8afcd5ff",
    "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
    "work_id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:29.651823Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/discard-exact-bytes/workspace",
    "request_sha256": "4e678a91fa14b1a83ddbc38003909bfe53fbff975d7524f585d8b5378b2a1a71"
  },
  "fingerprint": "f7bde3760f48dba83762a9a5d7fa2770c838322b7f65a4ab87766f26b99200d1",
  "before": {
    "id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "revision": 2,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "revision": 3,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "b6653ca4-39a7-42db-a880-36105c4f1173",
  "state_revision": 4,
  "recorded_at": "2026-09-10T08:02:29.685249Z",
  "product_version": "0.10.0",
  "request": {
    "version": 5,
    "operation_id": "f7a28f9a-82a0-4c74-aa3b-0b3cb90b7640",
    "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
    "work_id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:29.681248Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/discard-exact-bytes/workspace",
    "request_sha256": "73c936e9b78a7b69da714e65030239cd859ab28cfd23a9025b7f18cbab6202e6"
  },
  "fingerprint": "dcbf42240145e3c95a88ac0751e51efafbd9bf516b92424e6056457a36b7db3b",
  "before": {
    "id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "revision": 3,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "revision": 4,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "afd5911e-e8a0-4632-971d-007908417199",
    "revision": 1,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "afd5911e-e8a0-4632-971d-007908417199",
    "revision": 4,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "24788aa4-af48-4891-9658-03504e528edc",
  "state_revision": 5,
  "recorded_at": "2026-09-10T08:02:29.715952Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "7b52e0e1-bad4-4787-a3b3-4740460df8a1",
    "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
    "work_id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:29.711786Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/discard-exact-bytes/workspace",
    "request_sha256": "79f30e4de52d08ce0efd066554543c9279631123676a64d31d0dea0d37ce18f7"
  },
  "fingerprint": "d62518320e0157709a94c77ecdda55982b541bd9a99aaaa6451379274345a456",
  "before": {
    "id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "revision": 4,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "revision": 5,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "b6613038-b70b-499a-a7ed-2fff1dac51ec",
  "state_revision": 6,
  "recorded_at": "2026-09-10T08:02:29.746948Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "787780d6-facc-472a-9ed0-076f8a082251",
    "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
    "work_id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
    "artifact_revision": 1,
    "content_sha256": "07bce5e92d24265f070ca928548aaadc38de8c097ca5950f10bb681a9cf62e7c",
    "content_size": 163,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:29.742281Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/discard-exact-bytes/workspace",
    "request_sha256": "9d857fbfdede1987b5155a0560acf93a02fb2d81d2b24eaeaea66dae90bc151a"
  },
  "fingerprint": "d83030b0fcb1730ab978695a0012388fa3d75aa386291f42228185da9daeac10",
  "before": {
    "id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "revision": 5,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "revision": 6,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
    "revision": 1,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "artifact",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "work_id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "title": "KITE inspection",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
    "revision": 2,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "artifact",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "work_id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "787780d6-facc-472a-9ed0-076f8a082251"
  },
  "artifact_version": {
    "id": "787780d6-facc-472a-9ed0-076f8a082251",
    "artifact_id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
    "work_id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "artifact_revision": 2,
    "sha256": "07bce5e92d24265f070ca928548aaadc38de8c097ca5950f10bb681a9cf62e7c",
    "size": 163,
    "created_at": "2026-09-10T08:02:29.746948Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "0c0ece65-8b39-493a-9da5-576acbd53f73",
  "state_revision": 7,
  "recorded_at": "2026-09-10T08:02:29.791184Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "2c149214-21f7-43b5-8b64-2967493a4b70",
    "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
    "work_id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
        "version_id": "787780d6-facc-472a-9ed0-076f8a082251",
        "sha256": "07bce5e92d24265f070ca928548aaadc38de8c097ca5950f10bb681a9cf62e7c"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "2c149214-21f7-43b5-8b64-2967493a4b70",
      "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
      "process": "afd5911e-e8a0-4632-971d-007908417199",
      "related_work": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
        "version_id": "787780d6-facc-472a-9ed0-076f8a082251",
        "sha256": "07bce5e92d24265f070ca928548aaadc38de8c097ca5950f10bb681a9cf62e7c"
      },
      "basis": [],
      "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "G5 fictional host"
    },
    "delivery": {
      "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
      "input_sha256": "b88bdbb7d78d98555f45469e69a9c904392426bd432ed95b2932a5890bad66b6"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:29.785281Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/discard-exact-bytes/workspace",
    "request_sha256": "10d6e2c66741b042a4ea68cc00b588e75a919ee748acdfab82740478c5f98849"
  },
  "fingerprint": "1e5e0c2a65833103767a79ebd7aae12cbf52411fdbf001ef739c3b5aef480ac2",
  "before": {
    "id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "revision": 6,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "revision": 7,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "87bc0425-ea98-40b4-bbec-29ebc393073e",
  "state_revision": 8,
  "recorded_at": "2026-09-10T08:02:29.850751Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "ecb728cb-0549-4e0d-b8c6-0cd702e3f8e0",
    "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
    "work_id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "expected_revision": 7,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
    "artifact_revision": 2,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:29.845221Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/discard-exact-bytes/workspace",
    "request_sha256": "45958b510fac0352693d9cb7d9e615d42a48f8c6d1e18a7be3fadb4a42c95aaf"
  },
  "fingerprint": "efa9a39d086bdda31584d4e901a46072b19c3d92e4083c11ebaf3134626b02c0",
  "before": {
    "id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "revision": 7,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "revision": 8,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "7cdd86e9-1b3b-4e44-b8b8-8005ad32e2e2",
  "state_revision": 9,
  "recorded_at": "2026-09-10T08:02:29.888830Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "f03d3956-94ea-41ec-9660-0260170adfe1",
    "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
    "work_id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "expected_revision": 8,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
    "artifact_revision": 2,
    "content_sha256": "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d",
    "content_size": 262,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:29.882414Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/discard-exact-bytes/workspace",
    "request_sha256": "db391b0feb78b232f81bd8473bed61c34db7ed029609d869890afc060985920f"
  },
  "fingerprint": "99af96ef946a160179bae25cee631525b52e794c57e518bfd0ef1f5fa99cc801",
  "before": {
    "id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "revision": 8,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "revision": 9,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
    "revision": 2,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "artifact",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "work_id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "787780d6-facc-472a-9ed0-076f8a082251"
  },
  "artifact_after": {
    "id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
    "revision": 3,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "artifact",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "work_id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "f03d3956-94ea-41ec-9660-0260170adfe1"
  },
  "artifact_version": {
    "id": "f03d3956-94ea-41ec-9660-0260170adfe1",
    "artifact_id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
    "work_id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "artifact_revision": 3,
    "sha256": "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d",
    "size": 262,
    "created_at": "2026-09-10T08:02:29.888830Z",
    "state_revision": 9
  }
}
```

```json
{
  "id": "cfcb1031-d4a7-4d08-9b1c-f7797d03d3e7",
  "state_revision": 10,
  "recorded_at": "2026-09-10T08:02:29.936152Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "9fc13e38-a879-4835-b315-4e5606d2db71",
    "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
    "work_id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "expected_revision": 9,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
        "version_id": "f03d3956-94ea-41ec-9660-0260170adfe1",
        "sha256": "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "9fc13e38-a879-4835-b315-4e5606d2db71",
      "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
      "process": "afd5911e-e8a0-4632-971d-007908417199",
      "related_work": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
      "intent": "accepted_result",
      "source_revision": 9,
      "result": {
        "artifact_id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
        "version_id": "f03d3956-94ea-41ec-9660-0260170adfe1",
        "sha256": "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
      },
      "basis": [],
      "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "G5 fictional host"
    },
    "delivery": {
      "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
      "input_sha256": "5fdbd118448a3cc198d7ef95e470c89d0afaeb26142e0a5ec115a6944fd5bfa7"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:29.930037Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/discard-exact-bytes/workspace",
    "request_sha256": "a85f4b021a065fbb5251871f5ea69b44c07150506c1001d118e621747d68de93"
  },
  "fingerprint": "0f7bd15520d4860a901b4c83e8fbfe9ab32b1fb46158a3706402a6f6ee0b99ab",
  "before": {
    "id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "revision": 9,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "revision": 10,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "7d64680b-6c6e-4262-a41b-d32e656ca3b7",
  "state_revision": 11,
  "recorded_at": "2026-09-10T08:02:30.073937Z",
  "product_version": "0.10.0",
  "request": {
    "version": 4,
    "operation_id": "99d1e2a3-5b1a-45ca-bd2c-90fea3b42d08",
    "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
    "work_id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "expected_revision": 10,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.lot\",\"pack_version\":\"1.0.0\",\"process_type\":\"fictional.lot-release\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
        "version_id": "f03d3956-94ea-41ec-9660-0260170adfe1",
        "sha256": "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 10,
      "result": {
        "artifact_id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
        "version_id": "f03d3956-94ea-41ec-9660-0260170adfe1",
        "sha256": "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
      },
      "acceptance_ids": [
        "2c149214-21f7-43b5-8b64-2967493a4b70",
        "9fc13e38-a879-4835-b315-4e5606d2db71"
      ],
      "next_work": {
        "work_id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
        "artifact_id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
        "goal": "Choose release or discard for inspected fictional KITE",
        "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
        "acceptance": [
          "Explicit disposition naming the exact accepted inspection SHA256"
        ],
        "boundaries": [
          "Fictional local evidence only; no real release or external action"
        ],
        "budget": "One finite fictional lot",
        "executor_requirements": [
          "fictional.lot/v1:decide",
          "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
        ],
        "artifact_title": "KITE disposition",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:30.066529Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/discard-exact-bytes/workspace",
    "request_sha256": "9f7fe5bb36b7d0461fa5a410bd221e807d238435b475a6005464dc1eac56d522"
  },
  "fingerprint": "ad41265750a8342e70b8295259631c8962f5f436ce7575f3ee6f4650ae8680d5",
  "before": {
    "id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "revision": 10,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "revision": 11,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "completion_id": "99d1e2a3-5b1a-45ca-bd2c-90fea3b42d08",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "revision": 11,
    "created_at": "2026-09-10T08:02:30.073937Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
    "revision": 1,
    "created_at": "2026-09-10T08:02:30.073937Z",
    "kind": "artifact",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "work_id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "title": "KITE disposition",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
    "revision": 3,
    "created_at": "2026-09-10T08:02:29.591522Z",
    "kind": "artifact",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "work_id": "167b4cde-70fd-4bfd-824e-ddc2a14234a2",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "f03d3956-94ea-41ec-9660-0260170adfe1"
  },
  "result_references": [
    {
      "artifact_id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
      "version_id": "f03d3956-94ea-41ec-9660-0260170adfe1",
      "sha256": "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    },
    {
      "artifact_id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
      "version_id": "787780d6-facc-472a-9ed0-076f8a082251",
      "sha256": "07bce5e92d24265f070ca928548aaadc38de8c097ca5950f10bb681a9cf62e7c"
    }
  ]
}
```

```json
{
  "id": "93b8b36f-d65e-41eb-b7ae-e29d5f7d078a",
  "state_revision": 12,
  "recorded_at": "2026-09-10T08:02:30.206462Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "2efcb88f-0f8c-4cbc-b678-5d9c98dfc820",
    "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
    "work_id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "expected_revision": 11,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:30.199480Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/discard-exact-bytes/workspace",
    "request_sha256": "b77ca2b929a61695f8ea28234326a096cab8cc44e9cddd7f0f927b73cb4f2578"
  },
  "fingerprint": "885ba83658a8a0dd6f75be713990340566159fdfdaabe370b73974211f259859",
  "before": {
    "id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "revision": 11,
    "created_at": "2026-09-10T08:02:30.073937Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "revision": 12,
    "created_at": "2026-09-10T08:02:30.073937Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "a929d19e-7d4b-4ec1-8e02-231c359e908a",
  "state_revision": 13,
  "recorded_at": "2026-09-10T08:02:30.249069Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "99b83dfd-f586-45ba-a5ea-18aa95baa4b4",
    "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
    "work_id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "expected_revision": 12,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
    "artifact_revision": 1,
    "content_sha256": "7a7cad6edad363bd42b263f58be892ad549e146b2ea538daa958144b28255d12",
    "content_size": 152,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:30.241807Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/discard-exact-bytes/workspace",
    "request_sha256": "65e4e5bdac06715488ffd815ba3340781b1816551417b854c6c071751adbd995"
  },
  "fingerprint": "438168f924e442debe8c579ac100a29153f993ee9df59704d4b8702a8c90e87d",
  "before": {
    "id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "revision": 12,
    "created_at": "2026-09-10T08:02:30.073937Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "revision": 13,
    "created_at": "2026-09-10T08:02:30.073937Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
    "revision": 1,
    "created_at": "2026-09-10T08:02:30.073937Z",
    "kind": "artifact",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "work_id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "title": "KITE disposition",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
    "revision": 2,
    "created_at": "2026-09-10T08:02:30.073937Z",
    "kind": "artifact",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "work_id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "title": "KITE disposition",
    "status": "registered",
    "active_version": "99b83dfd-f586-45ba-a5ea-18aa95baa4b4"
  },
  "artifact_version": {
    "id": "99b83dfd-f586-45ba-a5ea-18aa95baa4b4",
    "artifact_id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
    "work_id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "artifact_revision": 2,
    "sha256": "7a7cad6edad363bd42b263f58be892ad549e146b2ea538daa958144b28255d12",
    "size": 152,
    "created_at": "2026-09-10T08:02:30.249069Z",
    "state_revision": 13
  }
}
```

```json
{
  "id": "03a515cd-f1d3-4457-a0b2-225ae9c44262",
  "state_revision": 14,
  "recorded_at": "2026-09-10T08:02:30.305135Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "dab0e17a-9a9d-44c2-bfb3-8d95f78c7350",
    "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
    "work_id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "expected_revision": 13,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
        "version_id": "99b83dfd-f586-45ba-a5ea-18aa95baa4b4",
        "sha256": "7a7cad6edad363bd42b263f58be892ad549e146b2ea538daa958144b28255d12"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "dab0e17a-9a9d-44c2-bfb3-8d95f78c7350",
      "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
      "process": "afd5911e-e8a0-4632-971d-007908417199",
      "related_work": "448b3b51-233d-478e-b93a-7d29e695d0b7",
      "intent": "accepted_result",
      "source_revision": 13,
      "result": {
        "artifact_id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
        "version_id": "99b83dfd-f586-45ba-a5ea-18aa95baa4b4",
        "sha256": "7a7cad6edad363bd42b263f58be892ad549e146b2ea538daa958144b28255d12"
      },
      "basis": [],
      "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "G5 fictional host"
    },
    "delivery": {
      "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
      "input_sha256": "4b0ec0188677b1f35f282d175da6f3627df4b15e73706dea9bf81ae31c66051a"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:30.295870Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/discard-exact-bytes/workspace",
    "request_sha256": "3b2196ae0e301aa40ade48b9c10ce3b0c99e9490b508ac4b6212b024b6fb6621"
  },
  "fingerprint": "baccf2d8f1d7c903d13b922c9bb395f1c6e3c7333f61066ba5e4fbae4a7068ef",
  "before": {
    "id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "revision": 13,
    "created_at": "2026-09-10T08:02:30.073937Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "revision": 14,
    "created_at": "2026-09-10T08:02:30.073937Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "b4f48f54-afce-4e79-b0a2-04a467cb1565",
  "state_revision": 15,
  "recorded_at": "2026-09-10T08:02:30.386022Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "4d5ca30c-f50d-4068-8301-3bcf286d4b0a",
    "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
    "work_id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "expected_revision": 14,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
    "artifact_revision": 2,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:30.378154Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/discard-exact-bytes/workspace",
    "request_sha256": "8b18d131f1d1561ec906e0b55ef733223a210ee751ecc189097ef2f2032f734d"
  },
  "fingerprint": "494549d0f15236dc3c5de38c2750fbdee1935058d3814b79e7d5e77e1f0f16c7",
  "before": {
    "id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "revision": 14,
    "created_at": "2026-09-10T08:02:30.073937Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "revision": 15,
    "created_at": "2026-09-10T08:02:30.073937Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "5db4e512-bec8-4b9d-b8e3-1ed0d485b664",
  "state_revision": 16,
  "recorded_at": "2026-09-10T08:02:30.433594Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "540d98ee-ef50-40f2-be0c-530d84544675",
    "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
    "work_id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "expected_revision": 15,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
    "artifact_revision": 2,
    "content_sha256": "4e7324a0ead1005489f1cc620b3b9790fb42b4932cbba6aae7e8e17f071edf75",
    "content_size": 152,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:30.424682Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/discard-exact-bytes/workspace",
    "request_sha256": "a1bbfad46bdac24bdf7ea0a9d9017fed80d85210351be61efb1bb565eb728e53"
  },
  "fingerprint": "1a15780971eecc8d70687bf1765ac6ef8009427458ac1067014e5c91e4b92ac8",
  "before": {
    "id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "revision": 15,
    "created_at": "2026-09-10T08:02:30.073937Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "revision": 16,
    "created_at": "2026-09-10T08:02:30.073937Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
    "revision": 2,
    "created_at": "2026-09-10T08:02:30.073937Z",
    "kind": "artifact",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "work_id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "title": "KITE disposition",
    "status": "registered",
    "active_version": "99b83dfd-f586-45ba-a5ea-18aa95baa4b4"
  },
  "artifact_after": {
    "id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
    "revision": 3,
    "created_at": "2026-09-10T08:02:30.073937Z",
    "kind": "artifact",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "work_id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "title": "KITE disposition",
    "status": "registered",
    "active_version": "540d98ee-ef50-40f2-be0c-530d84544675"
  },
  "artifact_version": {
    "id": "540d98ee-ef50-40f2-be0c-530d84544675",
    "artifact_id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
    "work_id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "artifact_revision": 3,
    "sha256": "4e7324a0ead1005489f1cc620b3b9790fb42b4932cbba6aae7e8e17f071edf75",
    "size": 152,
    "created_at": "2026-09-10T08:02:30.433594Z",
    "state_revision": 16
  }
}
```

```json
{
  "id": "4596b003-674e-4922-8976-3a87713ec438",
  "state_revision": 17,
  "recorded_at": "2026-09-10T08:02:30.492601Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "4d84abce-24d0-4061-a3ee-6a24d3502a93",
    "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
    "work_id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "expected_revision": 16,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
        "version_id": "540d98ee-ef50-40f2-be0c-530d84544675",
        "sha256": "4e7324a0ead1005489f1cc620b3b9790fb42b4932cbba6aae7e8e17f071edf75"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "4d84abce-24d0-4061-a3ee-6a24d3502a93",
      "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
      "process": "afd5911e-e8a0-4632-971d-007908417199",
      "related_work": "448b3b51-233d-478e-b93a-7d29e695d0b7",
      "intent": "accepted_result",
      "source_revision": 16,
      "result": {
        "artifact_id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
        "version_id": "540d98ee-ef50-40f2-be0c-530d84544675",
        "sha256": "4e7324a0ead1005489f1cc620b3b9790fb42b4932cbba6aae7e8e17f071edf75"
      },
      "basis": [],
      "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "G5 fictional host"
    },
    "delivery": {
      "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
      "input_sha256": "7fa67f8540fb1947897e53281766e7582a81b9729847807bb8057be874fc6653"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:30.484102Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/discard-exact-bytes/workspace",
    "request_sha256": "433b1eeb4bb2169889e0e91338cf8d2533ca28bb2b0bcd4c730b4c9708ec0f2a"
  },
  "fingerprint": "91a2dd6e44419d5d8776900cf478031365cce9198e55dcca1364042b07625f0f",
  "before": {
    "id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "revision": 16,
    "created_at": "2026-09-10T08:02:30.073937Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "revision": 17,
    "created_at": "2026-09-10T08:02:30.073937Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "65d52117-315a-47d7-8c61-07a066e43814",
  "state_revision": 18,
  "recorded_at": "2026-09-10T08:02:30.583655Z",
  "product_version": "0.10.0",
  "request": {
    "version": 4,
    "operation_id": "45dc9549-f86d-4efe-be87-39ec7565b127",
    "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
    "work_id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "expected_revision": 17,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.lot\",\"pack_version\":\"1.0.0\",\"process_type\":\"fictional.lot-release\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
        "version_id": "540d98ee-ef50-40f2-be0c-530d84544675",
        "sha256": "4e7324a0ead1005489f1cc620b3b9790fb42b4932cbba6aae7e8e17f071edf75"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 17,
      "result": {
        "artifact_id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
        "version_id": "540d98ee-ef50-40f2-be0c-530d84544675",
        "sha256": "4e7324a0ead1005489f1cc620b3b9790fb42b4932cbba6aae7e8e17f071edf75"
      },
      "acceptance_ids": [
        "dab0e17a-9a9d-44c2-bfb3-8d95f78c7350",
        "4d84abce-24d0-4061-a3ee-6a24d3502a93"
      ],
      "next_work": {
        "work_id": "2366fe9e-42a2-4e5f-8751-284c954a83b4",
        "artifact_id": "b239e8b7-a745-4cc1-8355-03b508de78f1",
        "goal": "Fictional KITE discard; cancel unused continuation",
        "expected_result": "No further package work; trusted host explicitly cancels this Work",
        "acceptance": [
          "No further package work; trusted host explicitly cancels this Work"
        ],
        "boundaries": [
          "Fictional local evidence only; no real release or external action"
        ],
        "budget": "One finite fictional lot",
        "executor_requirements": [
          "fictional.lot/v1:closed",
          "discard"
        ],
        "artifact_title": "Unused closed continuation (no Result claimed)",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:30.573078Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/discard-exact-bytes/workspace",
    "request_sha256": "700c422561d2ca4f67a0bb1307440932b9a6e2efdff30988638bb448b47d7195"
  },
  "fingerprint": "3be0221fed71c8b25f04c333936dedd0cb5a60a5ee5a413b98b2fd4ca9248f93",
  "before": {
    "id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "revision": 17,
    "created_at": "2026-09-10T08:02:30.073937Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "revision": 18,
    "created_at": "2026-09-10T08:02:30.073937Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    ],
    "completion_id": "45dc9549-f86d-4efe-be87-39ec7565b127",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "2366fe9e-42a2-4e5f-8751-284c954a83b4",
    "revision": 18,
    "created_at": "2026-09-10T08:02:30.583655Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Fictional KITE discard; cancel unused continuation",
    "expected_result": "No further package work; trusted host explicitly cancels this Work",
    "acceptance": [
      "No further package work; trusted host explicitly cancels this Work"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:closed",
      "discard"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "b239e8b7-a745-4cc1-8355-03b508de78f1",
    "revision": 1,
    "created_at": "2026-09-10T08:02:30.583655Z",
    "kind": "artifact",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "work_id": "2366fe9e-42a2-4e5f-8751-284c954a83b4",
    "title": "Unused closed continuation (no Result claimed)",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
    "revision": 3,
    "created_at": "2026-09-10T08:02:30.073937Z",
    "kind": "artifact",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "work_id": "448b3b51-233d-478e-b93a-7d29e695d0b7",
    "title": "KITE disposition",
    "status": "registered",
    "active_version": "540d98ee-ef50-40f2-be0c-530d84544675"
  },
  "result_references": [
    {
      "artifact_id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
      "version_id": "540d98ee-ef50-40f2-be0c-530d84544675",
      "sha256": "4e7324a0ead1005489f1cc620b3b9790fb42b4932cbba6aae7e8e17f071edf75"
    },
    {
      "artifact_id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
      "version_id": "f03d3956-94ea-41ec-9660-0260170adfe1",
      "sha256": "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
    },
    {
      "artifact_id": "c313e8ff-d400-4bb4-a094-d745bbf4a9b4",
      "version_id": "787780d6-facc-472a-9ed0-076f8a082251",
      "sha256": "07bce5e92d24265f070ca928548aaadc38de8c097ca5950f10bb681a9cf62e7c"
    },
    {
      "artifact_id": "a3046ecb-ee8e-46d3-b463-e9d956f545f6",
      "version_id": "99b83dfd-f586-45ba-a5ea-18aa95baa4b4",
      "sha256": "7a7cad6edad363bd42b263f58be892ad549e146b2ea538daa958144b28255d12"
    }
  ]
}
```

```json
{
  "id": "25e9b256-d20e-493b-9d62-38f483a2281a",
  "state_revision": 19,
  "recorded_at": "2026-09-10T08:02:30.695650Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "d64ab949-7091-4f59-970b-6bb230dfb811",
    "workspace_id": "b7e6f5d6-3c45-42df-a42b-51ff59d1812a",
    "work_id": "2366fe9e-42a2-4e5f-8751-284c954a83b4",
    "expected_revision": 18,
    "operation": "cancel_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:30.686380Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/discard-exact-bytes/workspace",
    "request_sha256": "9f00e0a038ed7244e5451a0ef258d0f294334b07fa75e2bea29bd1c1c6ad9f39"
  },
  "fingerprint": "133861176fee3d28b539e1dc79fa86cc6031dcf921401c263a7c5f3528449a12",
  "before": {
    "id": "2366fe9e-42a2-4e5f-8751-284c954a83b4",
    "revision": 18,
    "created_at": "2026-09-10T08:02:30.583655Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Fictional KITE discard; cancel unused continuation",
    "expected_result": "No further package work; trusted host explicitly cancels this Work",
    "acceptance": [
      "No further package work; trusted host explicitly cancels this Work"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:closed",
      "discard"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "2366fe9e-42a2-4e5f-8751-284c954a83b4",
    "revision": 19,
    "created_at": "2026-09-10T08:02:30.583655Z",
    "kind": "work",
    "process_id": "afd5911e-e8a0-4632-971d-007908417199",
    "goal": "Fictional KITE discard; cancel unused continuation",
    "expected_result": "No further package work; trusted host explicitly cancels this Work",
    "acceptance": [
      "No further package work; trusted host explicitly cancels this Work"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "cancelled",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:closed",
      "discard"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

