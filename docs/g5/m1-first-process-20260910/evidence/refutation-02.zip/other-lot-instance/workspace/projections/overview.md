# Zaratustra — generated overview

generated_from_revision: 10
generated_at: 2026-09-10T08:02:31.496638+00:00
workspace_id: 90d2c96b-59cd-49e0-9078-ed44b5f0d450

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "09e914da-e0fb-4e78-872a-c8c957a88f76",
  "revision": 2,
  "created_at": "2026-09-10T08:02:31.088952Z",
  "kind": "artifact",
  "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
  "work_id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
  "title": "KITE inspection",
  "status": "registered",
  "active_version": "42d83090-26f7-4e4a-acbd-a8a012d87e28"
}
```

## event

```json
{
  "id": "1f4588e4-be9f-4854-987c-feebd66122ba",
  "revision": 1,
  "created_at": "2026-09-10T08:02:31.088952Z",
  "kind": "event",
  "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
  "work_id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.0",
  "state_revision": 1,
  "affected_ids": [
    "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "09e914da-e0fb-4e78-872a-c8c957a88f76"
  ]
}
```

## process

```json
{
  "id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
  "revision": 4,
  "created_at": "2026-09-10T08:02:31.088952Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
  "revision": 10,
  "created_at": "2026-09-10T08:02:31.088952Z",
  "kind": "work",
  "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "ready",
  "authority_scope": "none",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:unknown"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 42d83090-26f7-4e4a-acbd-a8a012d87e28; Artifact revision: 2
  SHA-256: 4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d; bytes: 262
  File: artifacts/09e914da-e0fb-4e78-872a-c8c957a88f76/42d83090-26f7-4e4a-acbd-a8a012d87e28.blob

## Mutation provenance

```json
{
  "id": "e4777e42-aa8f-4c5b-9610-85a6003bf4c5",
  "state_revision": 2,
  "recorded_at": "2026-09-10T08:02:31.105306Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "a0dd351c-8b3a-4444-bb1b-840568658f37",
    "workspace_id": "90d2c96b-59cd-49e0-9078-ed44b5f0d450",
    "work_id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:31.101770Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/other-lot-instance/workspace",
    "request_sha256": "fd8fdf23610987e7e850b5113eb02aca2793948bed2fa2faa37a8d0b2b41b6f8"
  },
  "fingerprint": "ec40ff627a8431a75cb0f66e38b1114f062e8c4a39802dd5bdc4ec8a3762f67e",
  "before": {
    "id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "revision": 1,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "work",
    "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "revision": 2,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "work",
    "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "4f866ba1-a26f-4703-a54b-2388d0a4f5ba",
  "state_revision": 3,
  "recorded_at": "2026-09-10T08:02:31.131969Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "74af4377-a638-43ac-ab03-9d15060ee9a2",
    "workspace_id": "90d2c96b-59cd-49e0-9078-ed44b5f0d450",
    "work_id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:31.128666Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/other-lot-instance/workspace",
    "request_sha256": "3692d748b5ec64ad25ba27af338fa4ebc309d0e3c5136f311448dfba520777bd"
  },
  "fingerprint": "e5fcc19d1ee4bbea0bc320c7e2d076b13a4c124b8aef9351c23f2149592afa3f",
  "before": {
    "id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "revision": 2,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "work",
    "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "revision": 3,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "work",
    "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "09d06b7d-28d2-48ef-978a-6b13bb6d0239",
  "state_revision": 4,
  "recorded_at": "2026-09-10T08:02:31.161807Z",
  "product_version": "0.10.0",
  "request": {
    "version": 5,
    "operation_id": "1fe4ef64-736a-42e1-8174-f9633c0c029a",
    "workspace_id": "90d2c96b-59cd-49e0-9078-ed44b5f0d450",
    "work_id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:31.157106Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/other-lot-instance/workspace",
    "request_sha256": "bd24b73ad4c2fb5775c9113470eadf36c0a78f05310bd0517d33405e74391b7b"
  },
  "fingerprint": "6c15c1766d0f8f5a273ef75953b3f10925dc98bbf04dad63977b9f9af8613b37",
  "before": {
    "id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "revision": 3,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "work",
    "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "revision": 4,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "work",
    "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "revision": 1,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "revision": 4,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "865370d0-630d-4c55-8639-8d1af43d49a6",
  "state_revision": 5,
  "recorded_at": "2026-09-10T08:02:31.222671Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "7f6c8c6c-60ab-454f-b3ca-f7aeee6a7bf0",
    "workspace_id": "90d2c96b-59cd-49e0-9078-ed44b5f0d450",
    "work_id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": "09e914da-e0fb-4e78-872a-c8c957a88f76",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:31.218801Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/other-lot-instance/workspace",
    "request_sha256": "7b3de40befa137a46a7dbb9a54b86b3ef1e53229475650b33ceb6b7063801bce"
  },
  "fingerprint": "ddf6310904870deb16504c2688d1360c5c36ac37c99176f7ac1a9585a1a559a8",
  "before": {
    "id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "revision": 4,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "work",
    "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "revision": 5,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "work",
    "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "77dcd2aa-7d72-4e99-a617-1e8fdc376c37",
  "state_revision": 6,
  "recorded_at": "2026-09-10T08:02:31.253590Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "42d83090-26f7-4e4a-acbd-a8a012d87e28",
    "workspace_id": "90d2c96b-59cd-49e0-9078-ed44b5f0d450",
    "work_id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": "09e914da-e0fb-4e78-872a-c8c957a88f76",
    "artifact_revision": 1,
    "content_sha256": "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d",
    "content_size": 262,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:31.248841Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/other-lot-instance/workspace",
    "request_sha256": "83c0b1b5cc9605c38850cd9dfdb46799051b4428e978d99627623d2808449b0b"
  },
  "fingerprint": "27e04cbdb23149b313d6773677f2fe870de45e9156b0a70fd679e54f55cd06d2",
  "before": {
    "id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "revision": 5,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "work",
    "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "revision": 6,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "work",
    "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "09e914da-e0fb-4e78-872a-c8c957a88f76",
    "revision": 1,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "artifact",
    "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "work_id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "title": "KITE inspection",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "09e914da-e0fb-4e78-872a-c8c957a88f76",
    "revision": 2,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "artifact",
    "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "work_id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "42d83090-26f7-4e4a-acbd-a8a012d87e28"
  },
  "artifact_version": {
    "id": "42d83090-26f7-4e4a-acbd-a8a012d87e28",
    "artifact_id": "09e914da-e0fb-4e78-872a-c8c957a88f76",
    "work_id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "artifact_revision": 2,
    "sha256": "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d",
    "size": 262,
    "created_at": "2026-09-10T08:02:31.253590Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "5c0d49e2-ccc4-482f-b993-d549560bfef8",
  "state_revision": 7,
  "recorded_at": "2026-09-10T08:02:31.297389Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "e3021da1-eb85-4bf9-aa25-efb73cefe9da",
    "workspace_id": "90d2c96b-59cd-49e0-9078-ed44b5f0d450",
    "work_id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "09e914da-e0fb-4e78-872a-c8c957a88f76",
        "version_id": "42d83090-26f7-4e4a-acbd-a8a012d87e28",
        "sha256": "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "e3021da1-eb85-4bf9-aa25-efb73cefe9da",
      "workspace_id": "90d2c96b-59cd-49e0-9078-ed44b5f0d450",
      "process": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
      "related_work": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "09e914da-e0fb-4e78-872a-c8c957a88f76",
        "version_id": "42d83090-26f7-4e4a-acbd-a8a012d87e28",
        "sha256": "4c1119dfc48d9e2fe712e0bc7b1e63389930279129ffc0fc4b0409f1e964904d"
      },
      "basis": [],
      "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "G5 fictional host"
    },
    "delivery": {
      "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
      "input_sha256": "fdcf576a547c28145b3535d7dac1b4d7db26b9551457e291d46de1a05d0dba48"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:31.290777Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/other-lot-instance/workspace",
    "request_sha256": "2944cf52844fb9e9379674c2cb1b9e9e4214fc65ec7b2e4868c45c4a48f3bb22"
  },
  "fingerprint": "371e48e643278191fe44876c298440b246329d54e1be714f63dcf0e8743e0129",
  "before": {
    "id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "revision": 6,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "work",
    "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "revision": 7,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "work",
    "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "f83e1267-1f56-4e86-bd20-070d4d7bbf13",
  "state_revision": 8,
  "recorded_at": "2026-09-10T08:02:31.359323Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "63347a14-b798-4f35-b2b8-b4d5dcbb162b",
    "workspace_id": "90d2c96b-59cd-49e0-9078-ed44b5f0d450",
    "work_id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "expected_revision": 7,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "artifact_id": "09e914da-e0fb-4e78-872a-c8c957a88f76",
    "artifact_revision": 2,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:31.353997Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/other-lot-instance/workspace",
    "request_sha256": "ff5f677381bd141b68c10bc6d8ade17ea1c0f8fecb3ec6b3134b286f874da291"
  },
  "fingerprint": "0a2bfb5942c5d0d3b9417095ff4048ecabded5d6d368c26a7b724f1cf6fc0bd0",
  "before": {
    "id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "revision": 7,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "work",
    "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "revision": 8,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "work",
    "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "55135dc2-d8c2-4c7d-bb63-39662530dba6",
  "state_revision": 9,
  "recorded_at": "2026-09-10T08:02:31.422692Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "23d1c412-b76d-497f-bfaa-c6d708344306",
    "workspace_id": "90d2c96b-59cd-49e0-9078-ed44b5f0d450",
    "work_id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "expected_revision": 8,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:unknown"
    ],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:31.417402Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/other-lot-instance/workspace",
    "request_sha256": "23db25ebfccc48f6d2891551c6f189a59fa322d2fa7374fea093355afd5a6ee9"
  },
  "fingerprint": "fb86e7d1327d590ec302e780dfb801e034697d74cccab4499ac54f0b83f1d42a",
  "before": {
    "id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "revision": 8,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "work",
    "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "revision": 9,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "work",
    "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:unknown"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "29a4566d-1d96-4bbb-b541-83c2d30d25da",
  "state_revision": 10,
  "recorded_at": "2026-09-10T08:02:31.496638Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "912a0204-bea7-4096-ad9c-ca08007999c2",
    "workspace_id": "90d2c96b-59cd-49e0-9078-ed44b5f0d450",
    "work_id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "expected_revision": 9,
    "operation": "revoke_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "independent-G5-reviewer",
    "source_ref": "G5 separate physical task 01a08a4d-cc87-7be2-929a-1b28d577bc63; owner said zapusti g5; fictional review workspaces only",
    "confirmed_at": "2026-09-10T08:02:31.491115Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-refutation-02/other-lot-instance/workspace",
    "request_sha256": "ea226274afc73e541e0a8afa8b6ed0296cfef38aec0a7226542eb917b97814fa"
  },
  "fingerprint": "82b56bc19eb7245ec6d3986433ed58514c23271ac83a7f16d4cb871ffb9b95f9",
  "before": {
    "id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "revision": 9,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "work",
    "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:unknown"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "72eea457-4dd2-4559-bbbb-2ab167f39b4e",
    "revision": 10,
    "created_at": "2026-09-10T08:02:31.088952Z",
    "kind": "work",
    "process_id": "b5709001-2018-4da4-abe2-9f9c23ee5a6a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:unknown"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

