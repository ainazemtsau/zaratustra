# Zaratustra — generated overview

generated_from_revision: 18
generated_at: 2026-09-10T07:31:32.123766+00:00
workspace_id: fed46f99-5c3a-49c0-922b-d3712721da79

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
  "revision": 3,
  "created_at": "2026-09-10T07:31:30.629596Z",
  "kind": "artifact",
  "process_id": "b6147d03-044c-4fff-958c-66a010551571",
  "work_id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
  "title": "KITE inspection",
  "status": "registered",
  "active_version": "d3cdfe2e-8bc8-49b8-aa0e-30a661c131df"
}
```

## artifact

```json
{
  "id": "9a14c34e-3334-47ff-be4b-205877a14231",
  "revision": 3,
  "created_at": "2026-09-10T07:31:31.254426Z",
  "kind": "artifact",
  "process_id": "b6147d03-044c-4fff-958c-66a010551571",
  "work_id": "503b50d4-3e78-4144-b65c-45378cd76b27",
  "title": "KITE disposition",
  "status": "registered",
  "active_version": "609c12a6-88e6-421e-a0f7-7b39cd53b452"
}
```

## artifact

```json
{
  "id": "c9731c7d-9a02-44de-8952-132d05be280d",
  "revision": 1,
  "created_at": "2026-09-10T07:31:32.123766Z",
  "kind": "artifact",
  "process_id": "b6147d03-044c-4fff-958c-66a010551571",
  "work_id": "748006fe-13f2-4460-a9ed-5c8fc3d366b4",
  "title": "Unused closed continuation (no Result claimed)",
  "status": "declared",
  "active_version": null
}
```

## event

```json
{
  "id": "b6488828-ddc0-4ac7-8a68-d4a52f779e63",
  "revision": 1,
  "created_at": "2026-09-10T07:31:30.629596Z",
  "kind": "event",
  "process_id": "b6147d03-044c-4fff-958c-66a010551571",
  "work_id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.0",
  "state_revision": 1,
  "affected_ids": [
    "b6147d03-044c-4fff-958c-66a010551571",
    "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "7c1b8c06-99ec-40ea-a680-c46a13e73344"
  ]
}
```

## process

```json
{
  "id": "b6147d03-044c-4fff-958c-66a010551571",
  "revision": 4,
  "created_at": "2026-09-10T07:31:30.629596Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "503b50d4-3e78-4144-b65c-45378cd76b27",
  "revision": 18,
  "created_at": "2026-09-10T07:31:31.254426Z",
  "kind": "work",
  "process_id": "b6147d03-044c-4fff-958c-66a010551571",
  "goal": "Choose release or discard for inspected fictional KITE",
  "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
  "acceptance": [
    "Explicit disposition naming the exact accepted inspection SHA256"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:decide",
    "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
  ],
  "completion_id": "5c916a50-efa3-4537-b752-b3eb8b867143",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
  "revision": 11,
  "created_at": "2026-09-10T07:31:30.629596Z",
  "kind": "work",
  "process_id": "b6147d03-044c-4fff-958c-66a010551571",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "completion_id": "8dcea001-7bbc-46ed-8f10-47218866b011",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "748006fe-13f2-4460-a9ed-5c8fc3d366b4",
  "revision": 18,
  "created_at": "2026-09-10T07:31:32.123766Z",
  "kind": "work",
  "process_id": "b6147d03-044c-4fff-958c-66a010551571",
  "goal": "Fictional KITE release; cancel unused continuation",
  "expected_result": "No further package work; trusted host explicitly cancels this Work",
  "acceptance": [
    "No further package work; trusted host explicitly cancels this Work"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:closed",
    "release"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 17dd7de9-7da0-45a1-a33e-30ec75529b0f; Artifact revision: 2
  SHA-256: 0a88c782503024ac3e5215ee2753a37916971d318146fa46878cc561314e68c9; bytes: 146
  File: artifacts/9a14c34e-3334-47ff-be4b-205877a14231/17dd7de9-7da0-45a1-a33e-30ec75529b0f.blob

- Version: 902acc93-d1d1-4920-9372-088e7f13b798; Artifact revision: 2
  SHA-256: 79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f; bytes: 148
  File: artifacts/7c1b8c06-99ec-40ea-a680-c46a13e73344/902acc93-d1d1-4920-9372-088e7f13b798.blob

- Version: 609c12a6-88e6-421e-a0f7-7b39cd53b452; Artifact revision: 3
  SHA-256: baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb; bytes: 146
  File: artifacts/9a14c34e-3334-47ff-be4b-205877a14231/609c12a6-88e6-421e-a0f7-7b39cd53b452.blob

- Version: d3cdfe2e-8bc8-49b8-aa0e-30a661c131df; Artifact revision: 3
  SHA-256: e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312; bytes: 147
  File: artifacts/7c1b8c06-99ec-40ea-a680-c46a13e73344/d3cdfe2e-8bc8-49b8-aa0e-30a661c131df.blob

## Mutation provenance

```json
{
  "id": "a216341b-8187-4b06-b2fd-33a0b581c4e4",
  "state_revision": 2,
  "recorded_at": "2026-09-10T07:31:30.687238Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "7b68531f-9082-4d20-8f78-fa4151f5fed5",
    "workspace_id": "fed46f99-5c3a-49c0-922b-d3712721da79",
    "work_id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:31:30.671899Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-scenario-01/workspace",
    "request_sha256": "21812e260991cd04a57f1e952786dca43e4f2004c2b07a6aff4e87a6cff79d59"
  },
  "fingerprint": "35af374526ac41f22b12249c05b0e44cdad230fe0baebf2d6dcbbcd86399bcc9",
  "before": {
    "id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "revision": 1,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "revision": 2,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "3633b122-8226-4fe9-ae0b-fe41343f5bbb",
  "state_revision": 3,
  "recorded_at": "2026-09-10T07:31:30.726386Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "75596723-6841-49c7-969f-48c55ba71b28",
    "workspace_id": "fed46f99-5c3a-49c0-922b-d3712721da79",
    "work_id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:31:30.712981Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-scenario-01/workspace",
    "request_sha256": "7774a77d009772d8fd496d8a3d072b8c1be1608738969419825c7ec81d429237"
  },
  "fingerprint": "e3f78e0c14af527897ed7f5f05e18a1bf290c815f07f1adc21b3262c4826059c",
  "before": {
    "id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "revision": 2,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "revision": 3,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "d17d1e3a-ecf5-4292-9240-d73e0659fcad",
  "state_revision": 4,
  "recorded_at": "2026-09-10T07:31:30.769434Z",
  "product_version": "0.10.0",
  "request": {
    "version": 5,
    "operation_id": "78b9f611-5bfa-47bf-a27c-d368b771ad3f",
    "workspace_id": "fed46f99-5c3a-49c0-922b-d3712721da79",
    "work_id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional lot binding under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:31:30.755491Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-scenario-01/workspace",
    "request_sha256": "ff7200fc5973ad2caba47a451fe653637fcfef5a231878e0ed59f1cacd980a65"
  },
  "fingerprint": "66aeeeb35bc4a50d04747fbc831036f767d3b225a3a92f41160a3a73bce6956e",
  "before": {
    "id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "revision": 3,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "revision": 4,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "b6147d03-044c-4fff-958c-66a010551571",
    "revision": 1,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "b6147d03-044c-4fff-958c-66a010551571",
    "revision": 4,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "1bf86589-53c5-4773-ab8a-f5b34b400efc",
  "state_revision": 5,
  "recorded_at": "2026-09-10T07:31:30.840391Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "70f0506e-0752-40db-9be1-6f294ba33fe6",
    "workspace_id": "fed46f99-5c3a-49c0-922b-d3712721da79",
    "work_id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:31:30.826437Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-scenario-01/workspace",
    "request_sha256": "e1b1b2ab5470a56f5efe9702c0f768cb74aa8f33c2c39f09f68a81a9f75fcf9b"
  },
  "fingerprint": "f4c07bf4521879868cdb4b2bc992910688b7e65a76d875912986c5e446e10dab",
  "before": {
    "id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "revision": 4,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "revision": 5,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "d07c4c27-7602-4f91-9063-13634ca20fd4",
  "state_revision": 6,
  "recorded_at": "2026-09-10T07:31:30.879521Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "902acc93-d1d1-4920-9372-088e7f13b798",
    "workspace_id": "fed46f99-5c3a-49c0-922b-d3712721da79",
    "work_id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
    "artifact_revision": 1,
    "content_sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f",
    "content_size": 148,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:31:30.865653Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-scenario-01/workspace",
    "request_sha256": "eb079825d7fd926efa4b3aed81cd46639c72d72cc7af41d7b44dbe6311ad0e08"
  },
  "fingerprint": "ea591962c6fa3709bc1e06443f51bd641ec725d0544f1d594ded38bdd4e7c446",
  "before": {
    "id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "revision": 5,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "revision": 6,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
    "revision": 1,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "artifact",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "work_id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "title": "KITE inspection",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
    "revision": 2,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "artifact",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "work_id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "902acc93-d1d1-4920-9372-088e7f13b798"
  },
  "artifact_version": {
    "id": "902acc93-d1d1-4920-9372-088e7f13b798",
    "artifact_id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
    "work_id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "artifact_revision": 2,
    "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f",
    "size": 148,
    "created_at": "2026-09-10T07:31:30.879521Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "4e919e19-8478-4f09-b1ec-3be703df0a98",
  "state_revision": 7,
  "recorded_at": "2026-09-10T07:31:30.939854Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "a93a738a-0e62-48e3-a9be-5daafb60aab5",
    "workspace_id": "fed46f99-5c3a-49c0-922b-d3712721da79",
    "work_id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
        "version_id": "902acc93-d1d1-4920-9372-088e7f13b798",
        "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "a93a738a-0e62-48e3-a9be-5daafb60aab5",
      "workspace_id": "fed46f99-5c3a-49c0-922b-d3712721da79",
      "process": "b6147d03-044c-4fff-958c-66a010551571",
      "related_work": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
        "version_id": "902acc93-d1d1-4920-9372-088e7f13b798",
        "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "23db9381d4f9069600fcec10c49c54a1599d89a0fa09b6256f8246d5b3d38169"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:31:30.923288Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-scenario-01/workspace",
    "request_sha256": "234008df167c7ac5c42a6d067b3bf1c82789e11fff5ab18b26edce0052cd6a14"
  },
  "fingerprint": "305aeda1ecf0506b0844fb3496b4e9872d06b596cb3da1a9585d75bfad835595",
  "before": {
    "id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "revision": 6,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "revision": 7,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "3e5dae39-c41b-45d6-8c43-4042f8b89b03",
  "state_revision": 8,
  "recorded_at": "2026-09-10T07:31:31.014883Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "f78fe326-28de-4062-a760-54c95e306951",
    "workspace_id": "fed46f99-5c3a-49c0-922b-d3712721da79",
    "work_id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "expected_revision": 7,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
    "artifact_revision": 2,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:31:30.999665Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-scenario-01/workspace",
    "request_sha256": "12031fa96da9db82905c8ce253edfa072b468ded8b8f1e985e2ce83c409d2710"
  },
  "fingerprint": "c5017e93dcd5b896691dc32db28b6ab491a52780ae0cfdcde048d29822473317",
  "before": {
    "id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "revision": 7,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "revision": 8,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "7901d5d2-8f65-4db5-8acd-fb20f4633e02",
  "state_revision": 9,
  "recorded_at": "2026-09-10T07:31:31.059709Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "d3cdfe2e-8bc8-49b8-aa0e-30a661c131df",
    "workspace_id": "fed46f99-5c3a-49c0-922b-d3712721da79",
    "work_id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "expected_revision": 8,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
    "artifact_revision": 2,
    "content_sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312",
    "content_size": 147,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:31:31.043689Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-scenario-01/workspace",
    "request_sha256": "b0034e67c83194395b352e5e2f99dd3502725ce22f4b1d9f2600a40f5fb22642"
  },
  "fingerprint": "c0beca586ac65428e64ed4122d13acb725a13fbf5f44dacdc81e91bd728a59db",
  "before": {
    "id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "revision": 8,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "revision": 9,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
    "revision": 2,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "artifact",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "work_id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "902acc93-d1d1-4920-9372-088e7f13b798"
  },
  "artifact_after": {
    "id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
    "revision": 3,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "artifact",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "work_id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "d3cdfe2e-8bc8-49b8-aa0e-30a661c131df"
  },
  "artifact_version": {
    "id": "d3cdfe2e-8bc8-49b8-aa0e-30a661c131df",
    "artifact_id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
    "work_id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "artifact_revision": 3,
    "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312",
    "size": 147,
    "created_at": "2026-09-10T07:31:31.059709Z",
    "state_revision": 9
  }
}
```

```json
{
  "id": "a7c0c7a0-35ea-4f15-89ce-4455c52b0839",
  "state_revision": 10,
  "recorded_at": "2026-09-10T07:31:31.116423Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "6fc280f0-c525-490c-9b3b-3bd73a50e34b",
    "workspace_id": "fed46f99-5c3a-49c0-922b-d3712721da79",
    "work_id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "expected_revision": 9,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
        "version_id": "d3cdfe2e-8bc8-49b8-aa0e-30a661c131df",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "6fc280f0-c525-490c-9b3b-3bd73a50e34b",
      "workspace_id": "fed46f99-5c3a-49c0-922b-d3712721da79",
      "process": "b6147d03-044c-4fff-958c-66a010551571",
      "related_work": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
      "intent": "accepted_result",
      "source_revision": 9,
      "result": {
        "artifact_id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
        "version_id": "d3cdfe2e-8bc8-49b8-aa0e-30a661c131df",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "550f12b21e8f3a7184b55cc97d0619ce4b7da96bf1627e43603892b16f83bdbb"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:31:31.099029Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-scenario-01/workspace",
    "request_sha256": "17df910a7693e426bf6a0ab32dc5988fd78aeab64f5df5d05de46ce2d92f2534"
  },
  "fingerprint": "4025f7914944ab9f2116d51a9968c781714cba56ab21acaacae652fb06dcb679",
  "before": {
    "id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "revision": 9,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "revision": 10,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "7cdeb281-49b1-4093-a7bd-b74940c34818",
  "state_revision": 11,
  "recorded_at": "2026-09-10T07:31:31.254426Z",
  "product_version": "0.10.0",
  "request": {
    "version": 4,
    "operation_id": "8dcea001-7bbc-46ed-8f10-47218866b011",
    "workspace_id": "fed46f99-5c3a-49c0-922b-d3712721da79",
    "work_id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "expected_revision": 10,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.lot\",\"pack_version\":\"1.0.0\",\"process_type\":\"fictional.lot-release\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
        "version_id": "d3cdfe2e-8bc8-49b8-aa0e-30a661c131df",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 10,
      "result": {
        "artifact_id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
        "version_id": "d3cdfe2e-8bc8-49b8-aa0e-30a661c131df",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      },
      "acceptance_ids": [
        "a93a738a-0e62-48e3-a9be-5daafb60aab5",
        "6fc280f0-c525-490c-9b3b-3bd73a50e34b"
      ],
      "next_work": {
        "work_id": "503b50d4-3e78-4144-b65c-45378cd76b27",
        "artifact_id": "9a14c34e-3334-47ff-be4b-205877a14231",
        "goal": "Choose release or discard for inspected fictional KITE",
        "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
        "acceptance": [
          "Explicit disposition naming the exact accepted inspection SHA256"
        ],
        "boundaries": [
          "Fictional local evidence only; no real release or external action"
        ],
        "budget": "One finite fictional lot",
        "executor_requirements": [
          "fictional.lot/v1:decide",
          "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
        ],
        "artifact_title": "KITE disposition",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:31:31.234142Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-scenario-01/workspace",
    "request_sha256": "7ad3762156b1f6556c582d90a1a2d5007a5e274c90e6e5012e29fb474483b1a2"
  },
  "fingerprint": "547234cd4e9204d8a3a36659c1c157b8b84466d807928c4a1d4e0caf194b9e93",
  "before": {
    "id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "revision": 10,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "revision": 11,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "completion_id": "8dcea001-7bbc-46ed-8f10-47218866b011",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "revision": 11,
    "created_at": "2026-09-10T07:31:31.254426Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "9a14c34e-3334-47ff-be4b-205877a14231",
    "revision": 1,
    "created_at": "2026-09-10T07:31:31.254426Z",
    "kind": "artifact",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "work_id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "title": "KITE disposition",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
    "revision": 3,
    "created_at": "2026-09-10T07:31:30.629596Z",
    "kind": "artifact",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "work_id": "6864e09e-8ce3-4174-862e-7d6655f18ebc",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "d3cdfe2e-8bc8-49b8-aa0e-30a661c131df"
  },
  "result_references": [
    {
      "artifact_id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
      "version_id": "d3cdfe2e-8bc8-49b8-aa0e-30a661c131df",
      "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    },
    {
      "artifact_id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
      "version_id": "902acc93-d1d1-4920-9372-088e7f13b798",
      "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
    }
  ]
}
```

```json
{
  "id": "c3c18ad6-de01-4803-8e4a-2bc413d4c870",
  "state_revision": 12,
  "recorded_at": "2026-09-10T07:31:31.517087Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "e8ab2709-39e5-491b-9a26-97f0dbf905e8",
    "workspace_id": "fed46f99-5c3a-49c0-922b-d3712721da79",
    "work_id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "expected_revision": 11,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "9a14c34e-3334-47ff-be4b-205877a14231",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:31:31.497215Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-scenario-01/workspace",
    "request_sha256": "5b2986d2e0daf5a3f8d346e17e48923a66575a1e581f12c5310619db26012a6b"
  },
  "fingerprint": "c54a5b15e8af24c2b80448f37191e69ba15e881be741500ae784e56b63c08dc0",
  "before": {
    "id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "revision": 11,
    "created_at": "2026-09-10T07:31:31.254426Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "revision": 12,
    "created_at": "2026-09-10T07:31:31.254426Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "862f31b4-692a-4fad-901a-f915caaeb6d8",
  "state_revision": 13,
  "recorded_at": "2026-09-10T07:31:31.573959Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "17dd7de9-7da0-45a1-a33e-30ec75529b0f",
    "workspace_id": "fed46f99-5c3a-49c0-922b-d3712721da79",
    "work_id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "expected_revision": 12,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "9a14c34e-3334-47ff-be4b-205877a14231",
    "artifact_revision": 1,
    "content_sha256": "0a88c782503024ac3e5215ee2753a37916971d318146fa46878cc561314e68c9",
    "content_size": 146,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:31:31.553592Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-scenario-01/workspace",
    "request_sha256": "7eb204c248b866e5d35466052a55564734caddb0da899f58c160db74d8db1ab3"
  },
  "fingerprint": "8d08daba8e131129c3770af07e881a06652ba9fe41e32db696da5814f531d57d",
  "before": {
    "id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "revision": 12,
    "created_at": "2026-09-10T07:31:31.254426Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "revision": 13,
    "created_at": "2026-09-10T07:31:31.254426Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "9a14c34e-3334-47ff-be4b-205877a14231",
    "revision": 1,
    "created_at": "2026-09-10T07:31:31.254426Z",
    "kind": "artifact",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "work_id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "title": "KITE disposition",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "9a14c34e-3334-47ff-be4b-205877a14231",
    "revision": 2,
    "created_at": "2026-09-10T07:31:31.254426Z",
    "kind": "artifact",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "work_id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "title": "KITE disposition",
    "status": "registered",
    "active_version": "17dd7de9-7da0-45a1-a33e-30ec75529b0f"
  },
  "artifact_version": {
    "id": "17dd7de9-7da0-45a1-a33e-30ec75529b0f",
    "artifact_id": "9a14c34e-3334-47ff-be4b-205877a14231",
    "work_id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "artifact_revision": 2,
    "sha256": "0a88c782503024ac3e5215ee2753a37916971d318146fa46878cc561314e68c9",
    "size": 146,
    "created_at": "2026-09-10T07:31:31.573959Z",
    "state_revision": 13
  }
}
```

```json
{
  "id": "c0ca2f82-6ea8-4748-80a5-93dbcc0c71b0",
  "state_revision": 14,
  "recorded_at": "2026-09-10T07:31:31.652152Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "2d348d09-7c57-433b-83c3-dbb23d8dd862",
    "workspace_id": "fed46f99-5c3a-49c0-922b-d3712721da79",
    "work_id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "expected_revision": 13,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "9a14c34e-3334-47ff-be4b-205877a14231",
        "version_id": "17dd7de9-7da0-45a1-a33e-30ec75529b0f",
        "sha256": "0a88c782503024ac3e5215ee2753a37916971d318146fa46878cc561314e68c9"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "2d348d09-7c57-433b-83c3-dbb23d8dd862",
      "workspace_id": "fed46f99-5c3a-49c0-922b-d3712721da79",
      "process": "b6147d03-044c-4fff-958c-66a010551571",
      "related_work": "503b50d4-3e78-4144-b65c-45378cd76b27",
      "intent": "accepted_result",
      "source_revision": 13,
      "result": {
        "artifact_id": "9a14c34e-3334-47ff-be4b-205877a14231",
        "version_id": "17dd7de9-7da0-45a1-a33e-30ec75529b0f",
        "sha256": "0a88c782503024ac3e5215ee2753a37916971d318146fa46878cc561314e68c9"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "ec88104077b5fee1665b67d481ec69072c2bee26b3446cd6236a30135220dba1"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:31:31.631659Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-scenario-01/workspace",
    "request_sha256": "784448076355014aee1f7103106c65cdf3afc484d8a398933b97a2288a950f37"
  },
  "fingerprint": "a3ee2c59286d5cb3916b6f687a5dc7601839372d82fd440233c6b3da349e3fd1",
  "before": {
    "id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "revision": 13,
    "created_at": "2026-09-10T07:31:31.254426Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "revision": 14,
    "created_at": "2026-09-10T07:31:31.254426Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "7374247a-c1e6-49cf-a458-1516ec17a404",
  "state_revision": 15,
  "recorded_at": "2026-09-10T07:31:31.758149Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "3e08541b-8159-42bd-810c-3d2b1febb38b",
    "workspace_id": "fed46f99-5c3a-49c0-922b-d3712721da79",
    "work_id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "expected_revision": 14,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "9a14c34e-3334-47ff-be4b-205877a14231",
    "artifact_revision": 2,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:31:31.738990Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-scenario-01/workspace",
    "request_sha256": "ba8e30eb79a809f591062c8ef9f29e601e62dd6bcfe27429536d7c19425dadfd"
  },
  "fingerprint": "4b58e5e791c5927038dfa441d8dbdd2eba6cd50daf02904c6e5edb8454fffd5a",
  "before": {
    "id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "revision": 14,
    "created_at": "2026-09-10T07:31:31.254426Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "revision": 15,
    "created_at": "2026-09-10T07:31:31.254426Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "2c870ed6-9ca9-4d5e-a5ba-ef96582bf0cb",
  "state_revision": 16,
  "recorded_at": "2026-09-10T07:31:31.812494Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "609c12a6-88e6-421e-a0f7-7b39cd53b452",
    "workspace_id": "fed46f99-5c3a-49c0-922b-d3712721da79",
    "work_id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "expected_revision": 15,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "9a14c34e-3334-47ff-be4b-205877a14231",
    "artifact_revision": 2,
    "content_sha256": "baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb",
    "content_size": 146,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:31:31.793176Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-scenario-01/workspace",
    "request_sha256": "c00c120bd33653541f4167d5f19c439412692632e238976dc9976e534e21511f"
  },
  "fingerprint": "002b26fd8842948d96450bb9ca8f45c2477c23f831f641f541c2cb7569481494",
  "before": {
    "id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "revision": 15,
    "created_at": "2026-09-10T07:31:31.254426Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "revision": 16,
    "created_at": "2026-09-10T07:31:31.254426Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "9a14c34e-3334-47ff-be4b-205877a14231",
    "revision": 2,
    "created_at": "2026-09-10T07:31:31.254426Z",
    "kind": "artifact",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "work_id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "title": "KITE disposition",
    "status": "registered",
    "active_version": "17dd7de9-7da0-45a1-a33e-30ec75529b0f"
  },
  "artifact_after": {
    "id": "9a14c34e-3334-47ff-be4b-205877a14231",
    "revision": 3,
    "created_at": "2026-09-10T07:31:31.254426Z",
    "kind": "artifact",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "work_id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "title": "KITE disposition",
    "status": "registered",
    "active_version": "609c12a6-88e6-421e-a0f7-7b39cd53b452"
  },
  "artifact_version": {
    "id": "609c12a6-88e6-421e-a0f7-7b39cd53b452",
    "artifact_id": "9a14c34e-3334-47ff-be4b-205877a14231",
    "work_id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "artifact_revision": 3,
    "sha256": "baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb",
    "size": 146,
    "created_at": "2026-09-10T07:31:31.812494Z",
    "state_revision": 16
  }
}
```

```json
{
  "id": "207a6362-7fd7-4c87-92cf-1b4eaf25d17d",
  "state_revision": 17,
  "recorded_at": "2026-09-10T07:31:31.881013Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "5ac79d71-9f4a-44e9-9f23-bbf303ddd48a",
    "workspace_id": "fed46f99-5c3a-49c0-922b-d3712721da79",
    "work_id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "expected_revision": 16,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "9a14c34e-3334-47ff-be4b-205877a14231",
        "version_id": "609c12a6-88e6-421e-a0f7-7b39cd53b452",
        "sha256": "baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "5ac79d71-9f4a-44e9-9f23-bbf303ddd48a",
      "workspace_id": "fed46f99-5c3a-49c0-922b-d3712721da79",
      "process": "b6147d03-044c-4fff-958c-66a010551571",
      "related_work": "503b50d4-3e78-4144-b65c-45378cd76b27",
      "intent": "accepted_result",
      "source_revision": 16,
      "result": {
        "artifact_id": "9a14c34e-3334-47ff-be4b-205877a14231",
        "version_id": "609c12a6-88e6-421e-a0f7-7b39cd53b452",
        "sha256": "baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "a778d58a627bea01f652f1ebf9c6c03ff56d6fc60efe9354fa8ebb1b6e8cfddb"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:31:31.860536Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-scenario-01/workspace",
    "request_sha256": "28a829aeff2104f823bdfb50eba7443c33ce79a0b6e9e72d12cc0e6cf1e849df"
  },
  "fingerprint": "81cc15c83039a01789b78c250a575020d0091e900beeee80dbf8d0fdb7c28c15",
  "before": {
    "id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "revision": 16,
    "created_at": "2026-09-10T07:31:31.254426Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "revision": 17,
    "created_at": "2026-09-10T07:31:31.254426Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "cf3d1598-cf61-4581-9c5c-6d884afbab8a",
  "state_revision": 18,
  "recorded_at": "2026-09-10T07:31:32.123766Z",
  "product_version": "0.10.0",
  "request": {
    "version": 4,
    "operation_id": "5c916a50-efa3-4537-b752-b3eb8b867143",
    "workspace_id": "fed46f99-5c3a-49c0-922b-d3712721da79",
    "work_id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "expected_revision": 17,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.lot\",\"pack_version\":\"1.0.0\",\"process_type\":\"fictional.lot-release\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "9a14c34e-3334-47ff-be4b-205877a14231",
        "version_id": "609c12a6-88e6-421e-a0f7-7b39cd53b452",
        "sha256": "baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 17,
      "result": {
        "artifact_id": "9a14c34e-3334-47ff-be4b-205877a14231",
        "version_id": "609c12a6-88e6-421e-a0f7-7b39cd53b452",
        "sha256": "baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb"
      },
      "acceptance_ids": [
        "2d348d09-7c57-433b-83c3-dbb23d8dd862",
        "5ac79d71-9f4a-44e9-9f23-bbf303ddd48a"
      ],
      "next_work": {
        "work_id": "748006fe-13f2-4460-a9ed-5c8fc3d366b4",
        "artifact_id": "c9731c7d-9a02-44de-8952-132d05be280d",
        "goal": "Fictional KITE release; cancel unused continuation",
        "expected_result": "No further package work; trusted host explicitly cancels this Work",
        "acceptance": [
          "No further package work; trusted host explicitly cancels this Work"
        ],
        "boundaries": [
          "Fictional local evidence only; no real release or external action"
        ],
        "budget": "One finite fictional lot",
        "executor_requirements": [
          "fictional.lot/v1:closed",
          "release"
        ],
        "artifact_title": "Unused closed continuation (no Result claimed)",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T07:31:32.116077Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-first-process-20260910/_scratch/t4-scenario-01/events/disposition-restored",
    "request_sha256": "2d11532d4f2125837d29cadf245daae871da9d20fd8c359340f5fdebb2342efd"
  },
  "fingerprint": "b86e800519eeafc0ca77f6ca5a7337bd675cfc84914068eb31810096b2bbaf6a",
  "before": {
    "id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "revision": 17,
    "created_at": "2026-09-10T07:31:31.254426Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "revision": 18,
    "created_at": "2026-09-10T07:31:31.254426Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "completion_id": "5c916a50-efa3-4537-b752-b3eb8b867143",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "748006fe-13f2-4460-a9ed-5c8fc3d366b4",
    "revision": 18,
    "created_at": "2026-09-10T07:31:32.123766Z",
    "kind": "work",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "goal": "Fictional KITE release; cancel unused continuation",
    "expected_result": "No further package work; trusted host explicitly cancels this Work",
    "acceptance": [
      "No further package work; trusted host explicitly cancels this Work"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:closed",
      "release"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "c9731c7d-9a02-44de-8952-132d05be280d",
    "revision": 1,
    "created_at": "2026-09-10T07:31:32.123766Z",
    "kind": "artifact",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "work_id": "748006fe-13f2-4460-a9ed-5c8fc3d366b4",
    "title": "Unused closed continuation (no Result claimed)",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "9a14c34e-3334-47ff-be4b-205877a14231",
    "revision": 3,
    "created_at": "2026-09-10T07:31:31.254426Z",
    "kind": "artifact",
    "process_id": "b6147d03-044c-4fff-958c-66a010551571",
    "work_id": "503b50d4-3e78-4144-b65c-45378cd76b27",
    "title": "KITE disposition",
    "status": "registered",
    "active_version": "609c12a6-88e6-421e-a0f7-7b39cd53b452"
  },
  "result_references": [
    {
      "artifact_id": "9a14c34e-3334-47ff-be4b-205877a14231",
      "version_id": "609c12a6-88e6-421e-a0f7-7b39cd53b452",
      "sha256": "baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb"
    },
    {
      "artifact_id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
      "version_id": "d3cdfe2e-8bc8-49b8-aa0e-30a661c131df",
      "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    },
    {
      "artifact_id": "7c1b8c06-99ec-40ea-a680-c46a13e73344",
      "version_id": "902acc93-d1d1-4920-9372-088e7f13b798",
      "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
    },
    {
      "artifact_id": "9a14c34e-3334-47ff-be4b-205877a14231",
      "version_id": "17dd7de9-7da0-45a1-a33e-30ec75529b0f",
      "sha256": "0a88c782503024ac3e5215ee2753a37916971d318146fa46878cc561314e68c9"
    }
  ]
}
```

