# Zaratustra — generated overview

generated_from_revision: 11
generated_at: 2026-09-10T08:04:14.220486+00:00
workspace_id: 4512c513-60a7-44ef-88fc-1ec23fb42847

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "a5d547ae-6e07-4e4f-9771-3b6245505c4c",
  "revision": 1,
  "created_at": "2026-09-10T08:04:14.220486Z",
  "kind": "artifact",
  "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
  "work_id": "f2aca3a7-cd4c-4c7e-8221-b17a0ac6737b",
  "title": "KITE disposition",
  "status": "declared",
  "active_version": null
}
```

## artifact

```json
{
  "id": "e1717c86-f552-4448-bdad-51d2a643f714",
  "revision": 3,
  "created_at": "2026-09-10T08:04:13.487897Z",
  "kind": "artifact",
  "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
  "work_id": "811120c9-db20-4547-b94d-44b22a8aed3d",
  "title": "KITE inspection",
  "status": "registered",
  "active_version": "1aa747a4-f107-49e7-940c-d3f59fc6c25c"
}
```

## event

```json
{
  "id": "f9364618-94f5-4940-8dbe-23378276e4c3",
  "revision": 1,
  "created_at": "2026-09-10T08:04:13.487897Z",
  "kind": "event",
  "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
  "work_id": "811120c9-db20-4547-b94d-44b22a8aed3d",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.0",
  "state_revision": 1,
  "affected_ids": [
    "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "811120c9-db20-4547-b94d-44b22a8aed3d",
    "e1717c86-f552-4448-bdad-51d2a643f714"
  ]
}
```

## process

```json
{
  "id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
  "revision": 4,
  "created_at": "2026-09-10T08:04:13.487897Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "811120c9-db20-4547-b94d-44b22a8aed3d",
  "revision": 11,
  "created_at": "2026-09-10T08:04:13.487897Z",
  "kind": "work",
  "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "completion_id": "33677b04-6cee-47e7-a111-b08d87722b3c",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "f2aca3a7-cd4c-4c7e-8221-b17a0ac6737b",
  "revision": 11,
  "created_at": "2026-09-10T08:04:14.220486Z",
  "kind": "work",
  "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
  "goal": "Choose release or discard for inspected fictional KITE",
  "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
  "acceptance": [
    "Explicit disposition naming the exact accepted inspection SHA256"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:decide",
    "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 4b35a995-1673-4b04-9989-7cd3c4935e75; Artifact revision: 2
  SHA-256: 79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f; bytes: 148
  File: artifacts/e1717c86-f552-4448-bdad-51d2a643f714/4b35a995-1673-4b04-9989-7cd3c4935e75.blob

- Version: 1aa747a4-f107-49e7-940c-d3f59fc6c25c; Artifact revision: 3
  SHA-256: e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312; bytes: 147
  File: artifacts/e1717c86-f552-4448-bdad-51d2a643f714/1aa747a4-f107-49e7-940c-d3f59fc6c25c.blob

## Mutation provenance

```json
{
  "id": "59bb8f60-d83d-472f-96da-90a6312ad01e",
  "state_revision": 2,
  "recorded_at": "2026-09-10T08:04:13.511577Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "d596439d-0b5b-4dad-9ac6-a22807c692ec",
    "workspace_id": "4512c513-60a7-44ef-88fc-1ec23fb42847",
    "work_id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:04:13.500176Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-retained-01/wheel-scenario/workspace",
    "request_sha256": "1e71d4b34315be649c8a8ff6146297febdc4c37e1f06ae37b60c86faf7c42fbb"
  },
  "fingerprint": "0a91848b43eb6438430e2b3ebcdb310a6ab77607cedb21f3a2e598d55111040a",
  "before": {
    "id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "revision": 1,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "work",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "revision": 2,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "work",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "5deb592d-3e62-430f-97d6-ac171d93673a",
  "state_revision": 3,
  "recorded_at": "2026-09-10T08:04:13.548229Z",
  "product_version": "0.10.0",
  "request": {
    "version": 1,
    "operation_id": "ca62a9f8-9dab-4ee4-8b3c-9b69c9cdad81",
    "workspace_id": "4512c513-60a7-44ef-88fc-1ec23fb42847",
    "work_id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:04:13.534664Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-retained-01/wheel-scenario/workspace",
    "request_sha256": "980011add9bda90d162072e5d6053a692553532627812c8001792cec6edb4609"
  },
  "fingerprint": "779dcf29f9e22865adb05f42828281c5328fd056ede9d6bb9c26ced1e40793ca",
  "before": {
    "id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "revision": 2,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "work",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "revision": 3,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "work",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "538191e9-f8df-40d7-9392-fb901906591b",
  "state_revision": 4,
  "recorded_at": "2026-09-10T08:04:13.585448Z",
  "product_version": "0.10.0",
  "request": {
    "version": 5,
    "operation_id": "30a98ac5-948f-4771-9006-97eea0f75b5d",
    "workspace_id": "4512c513-60a7-44ef-88fc-1ec23fb42847",
    "work_id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional lot binding under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:04:13.572547Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-retained-01/wheel-scenario/workspace",
    "request_sha256": "60252a1dc9a8f88ae87f7b20330435f2448ce6d5451469c0d975e3e1817bba80"
  },
  "fingerprint": "49438bdbfa75d5e618e34a06641e22bf23f92cc4c309a8f74d6ce94a2511fe85",
  "before": {
    "id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "revision": 3,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "work",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "revision": 4,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "work",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "revision": 1,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "revision": 4,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "771494ce-1618-45c3-9ccd-3bed2b1b2c74",
  "state_revision": 5,
  "recorded_at": "2026-09-10T08:04:13.641751Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "b4b390c5-014f-4cbe-9e19-3074fde37042",
    "workspace_id": "4512c513-60a7-44ef-88fc-1ec23fb42847",
    "work_id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "e1717c86-f552-4448-bdad-51d2a643f714",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:04:13.630459Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-retained-01/wheel-scenario/workspace",
    "request_sha256": "fc0d3bc5501825a9672174c0f202143a8f355332af84a208dd23a327805700aa"
  },
  "fingerprint": "2813957ba5ab4c751b813518ee3cdab26a50ebeede4e71a5d92825abf19c5492",
  "before": {
    "id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "revision": 4,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "work",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "revision": 5,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "work",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "b266c991-7c94-48bf-b92e-a0a1cbb30509",
  "state_revision": 6,
  "recorded_at": "2026-09-10T08:04:13.677250Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "4b35a995-1673-4b04-9989-7cd3c4935e75",
    "workspace_id": "4512c513-60a7-44ef-88fc-1ec23fb42847",
    "work_id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "e1717c86-f552-4448-bdad-51d2a643f714",
    "artifact_revision": 1,
    "content_sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f",
    "content_size": 148,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:04:13.663943Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-retained-01/wheel-scenario/workspace",
    "request_sha256": "95088944f87a70df9551ea5eb51cdf24515089758d3d9db28cfd76958d276954"
  },
  "fingerprint": "831668d325b2093fe8faf2aebfc0fa66bf0eb479d1c4a1038a5b2a12e7a1c6fa",
  "before": {
    "id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "revision": 5,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "work",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "revision": 6,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "work",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "e1717c86-f552-4448-bdad-51d2a643f714",
    "revision": 1,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "artifact",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "work_id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "title": "KITE inspection",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "e1717c86-f552-4448-bdad-51d2a643f714",
    "revision": 2,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "artifact",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "work_id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "4b35a995-1673-4b04-9989-7cd3c4935e75"
  },
  "artifact_version": {
    "id": "4b35a995-1673-4b04-9989-7cd3c4935e75",
    "artifact_id": "e1717c86-f552-4448-bdad-51d2a643f714",
    "work_id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "artifact_revision": 2,
    "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f",
    "size": 148,
    "created_at": "2026-09-10T08:04:13.677250Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "ecc7fc16-3c3f-43b3-9bb1-0ff3fbc90f19",
  "state_revision": 7,
  "recorded_at": "2026-09-10T08:04:13.725811Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "7791be59-a26e-4e42-b855-35296a886fb5",
    "workspace_id": "4512c513-60a7-44ef-88fc-1ec23fb42847",
    "work_id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "e1717c86-f552-4448-bdad-51d2a643f714",
        "version_id": "4b35a995-1673-4b04-9989-7cd3c4935e75",
        "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "7791be59-a26e-4e42-b855-35296a886fb5",
      "workspace_id": "4512c513-60a7-44ef-88fc-1ec23fb42847",
      "process": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
      "related_work": "811120c9-db20-4547-b94d-44b22a8aed3d",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "e1717c86-f552-4448-bdad-51d2a643f714",
        "version_id": "4b35a995-1673-4b04-9989-7cd3c4935e75",
        "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "a81d6a40e262223d89bda280ee4d4a35949d4f077e89d34800767d7d0636ceb0"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:04:13.710892Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-retained-01/wheel-scenario/workspace",
    "request_sha256": "d7c154516e8038649966a1875be2e0759eee5c197f729d2c5bffaf895ca237e5"
  },
  "fingerprint": "943b460857ce9161e1e897a25e5aeab3c0e6f8435bdbf45354f86031a712ea38",
  "before": {
    "id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "revision": 6,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "work",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "revision": 7,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "work",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "9d6eb7fd-5a2c-4e03-afd7-45d7865413f9",
  "state_revision": 8,
  "recorded_at": "2026-09-10T08:04:13.931799Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "55ca3331-694f-4a3e-91c7-1ac69d32df78",
    "workspace_id": "4512c513-60a7-44ef-88fc-1ec23fb42847",
    "work_id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "expected_revision": 7,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "e1717c86-f552-4448-bdad-51d2a643f714",
    "artifact_revision": 2,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:04:13.917204Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-retained-01/wheel-scenario/workspace",
    "request_sha256": "c287dadaa7915a9b5866d141744f0aac16e9025e9f313be8330777755f478f3b"
  },
  "fingerprint": "331a70a497913424be7dc2c291035645ef39e8af8052aec6c599e339e14a93a4",
  "before": {
    "id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "revision": 7,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "work",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "revision": 8,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "work",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "c982284a-a853-40a3-9aba-4c6c89da9f34",
  "state_revision": 9,
  "recorded_at": "2026-09-10T08:04:13.972557Z",
  "product_version": "0.10.0",
  "request": {
    "version": 2,
    "operation_id": "1aa747a4-f107-49e7-940c-d3f59fc6c25c",
    "workspace_id": "4512c513-60a7-44ef-88fc-1ec23fb42847",
    "work_id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "expected_revision": 8,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "e1717c86-f552-4448-bdad-51d2a643f714",
    "artifact_revision": 2,
    "content_sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312",
    "content_size": 147,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:04:13.957973Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-retained-01/wheel-scenario/workspace",
    "request_sha256": "e701168af343bc2159c0d021360ef6be184ad9b9d7f5be71c7f9b7ea8e29a78d"
  },
  "fingerprint": "74dfb09dbd60e72e1f82c412d2e06ce5925f3fc7a67f09fc2b041f0539e2fb94",
  "before": {
    "id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "revision": 8,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "work",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "revision": 9,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "work",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "e1717c86-f552-4448-bdad-51d2a643f714",
    "revision": 2,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "artifact",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "work_id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "4b35a995-1673-4b04-9989-7cd3c4935e75"
  },
  "artifact_after": {
    "id": "e1717c86-f552-4448-bdad-51d2a643f714",
    "revision": 3,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "artifact",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "work_id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "1aa747a4-f107-49e7-940c-d3f59fc6c25c"
  },
  "artifact_version": {
    "id": "1aa747a4-f107-49e7-940c-d3f59fc6c25c",
    "artifact_id": "e1717c86-f552-4448-bdad-51d2a643f714",
    "work_id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "artifact_revision": 3,
    "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312",
    "size": 147,
    "created_at": "2026-09-10T08:04:13.972557Z",
    "state_revision": 9
  }
}
```

```json
{
  "id": "4d297bbd-97fa-4b6f-a81d-0e9eaea8009e",
  "state_revision": 10,
  "recorded_at": "2026-09-10T08:04:14.022506Z",
  "product_version": "0.10.0",
  "request": {
    "version": 3,
    "operation_id": "778ec79a-2656-41c0-a31c-dcc945c17c6f",
    "workspace_id": "4512c513-60a7-44ef-88fc-1ec23fb42847",
    "work_id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "expected_revision": 9,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "e1717c86-f552-4448-bdad-51d2a643f714",
        "version_id": "1aa747a4-f107-49e7-940c-d3f59fc6c25c",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "778ec79a-2656-41c0-a31c-dcc945c17c6f",
      "workspace_id": "4512c513-60a7-44ef-88fc-1ec23fb42847",
      "process": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
      "related_work": "811120c9-db20-4547-b94d-44b22a8aed3d",
      "intent": "accepted_result",
      "source_revision": 9,
      "result": {
        "artifact_id": "e1717c86-f552-4448-bdad-51d2a643f714",
        "version_id": "1aa747a4-f107-49e7-940c-d3f59fc6c25c",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "2b25d73eb07763dba56258eeff75580e5bba4beb05fd79e820ddf842dc4c0b0c"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:04:14.007251Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-retained-01/wheel-scenario/workspace",
    "request_sha256": "667a9fc89825331b10f7ac70b74b0287a1b912301306dfd37b60d087e199dec2"
  },
  "fingerprint": "cb6def96ada0c778102384cfe10e4a9befa4f1180afe268beedb61378b494c0c",
  "before": {
    "id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "revision": 9,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "work",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "revision": 10,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "work",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "116fdeaa-827e-4a25-ab23-9e6d762471d0",
  "state_revision": 11,
  "recorded_at": "2026-09-10T08:04:14.220486Z",
  "product_version": "0.10.0",
  "request": {
    "version": 4,
    "operation_id": "33677b04-6cee-47e7-a111-b08d87722b3c",
    "workspace_id": "4512c513-60a7-44ef-88fc-1ec23fb42847",
    "work_id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "expected_revision": 10,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.lot\",\"pack_version\":\"1.0.0\",\"process_type\":\"fictional.lot-release\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "e1717c86-f552-4448-bdad-51d2a643f714",
        "version_id": "1aa747a4-f107-49e7-940c-d3f59fc6c25c",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 10,
      "result": {
        "artifact_id": "e1717c86-f552-4448-bdad-51d2a643f714",
        "version_id": "1aa747a4-f107-49e7-940c-d3f59fc6c25c",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      },
      "acceptance_ids": [
        "7791be59-a26e-4e42-b855-35296a886fb5",
        "778ec79a-2656-41c0-a31c-dcc945c17c6f"
      ],
      "next_work": {
        "work_id": "f2aca3a7-cd4c-4c7e-8221-b17a0ac6737b",
        "artifact_id": "a5d547ae-6e07-4e4f-9771-3b6245505c4c",
        "goal": "Choose release or discard for inspected fictional KITE",
        "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
        "acceptance": [
          "Explicit disposition naming the exact accepted inspection SHA256"
        ],
        "boundaries": [
          "Fictional local evidence only; no real release or external action"
        ],
        "budget": "One finite fictional lot",
        "executor_requirements": [
          "fictional.lot/v1:decide",
          "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
        ],
        "artifact_title": "KITE disposition",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:04:14.215620Z",
    "workspace_path": "C:/my_global_workflow/ebf7/zaratustra/_scratch/g5-retained-01/wheel-scenario/events/inspection-restored",
    "request_sha256": "101b6a0a768e560b3f7d86b84912f9417a79c2bff3a1d4a3cc897c48ce839d5a"
  },
  "fingerprint": "0e581d48944b031c0a32ed1cb9ae22d4a24e1f9770740799a417862d8fce5ed3",
  "before": {
    "id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "revision": 10,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "work",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "revision": 11,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "work",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "completion_id": "33677b04-6cee-47e7-a111-b08d87722b3c",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "f2aca3a7-cd4c-4c7e-8221-b17a0ac6737b",
    "revision": 11,
    "created_at": "2026-09-10T08:04:14.220486Z",
    "kind": "work",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "a5d547ae-6e07-4e4f-9771-3b6245505c4c",
    "revision": 1,
    "created_at": "2026-09-10T08:04:14.220486Z",
    "kind": "artifact",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "work_id": "f2aca3a7-cd4c-4c7e-8221-b17a0ac6737b",
    "title": "KITE disposition",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "e1717c86-f552-4448-bdad-51d2a643f714",
    "revision": 3,
    "created_at": "2026-09-10T08:04:13.487897Z",
    "kind": "artifact",
    "process_id": "57cca60c-bc0f-4de7-aefd-9dafb3a06c6c",
    "work_id": "811120c9-db20-4547-b94d-44b22a8aed3d",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "1aa747a4-f107-49e7-940c-d3f59fc6c25c"
  },
  "result_references": [
    {
      "artifact_id": "e1717c86-f552-4448-bdad-51d2a643f714",
      "version_id": "1aa747a4-f107-49e7-940c-d3f59fc6c25c",
      "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    },
    {
      "artifact_id": "e1717c86-f552-4448-bdad-51d2a643f714",
      "version_id": "4b35a995-1673-4b04-9989-7cd3c4935e75",
      "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
    }
  ]
}
```

