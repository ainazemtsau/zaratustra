# Zaratustra — generated overview

generated_from_revision: 18
generated_at: 2026-09-10T08:41:10.745572+00:00
workspace_id: 13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
  "revision": 3,
  "created_at": "2026-09-10T08:41:09.388391Z",
  "kind": "artifact",
  "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
  "work_id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
  "title": "KITE inspection",
  "status": "registered",
  "active_version": "92a75f69-08a6-448b-a9a5-3f3f12fae297"
}
```

## artifact

```json
{
  "id": "6622013e-721e-4501-94b2-1e8656a5091c",
  "revision": 1,
  "created_at": "2026-09-10T08:41:10.745572Z",
  "kind": "artifact",
  "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
  "work_id": "c1346774-1960-49ca-bd3e-cd964eccc068",
  "title": "Unused closed continuation (no Result claimed)",
  "status": "declared",
  "active_version": null
}
```

## artifact

```json
{
  "id": "89c70965-7d61-4872-8328-2975772e2098",
  "revision": 3,
  "created_at": "2026-09-10T08:41:09.942224Z",
  "kind": "artifact",
  "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
  "work_id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
  "title": "KITE disposition",
  "status": "registered",
  "active_version": "1f3750d4-7a4a-43bc-a99e-f5a0a91aa0ba"
}
```

## event

```json
{
  "id": "da3a64c0-4aa7-4184-a5e2-3c61deb91dbc",
  "revision": 1,
  "created_at": "2026-09-10T08:41:09.388391Z",
  "kind": "event",
  "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
  "work_id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.1",
  "state_revision": 1,
  "affected_ids": [
    "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "0a96504a-a3ed-45a6-a31e-21f7d59158ee"
  ]
}
```

## process

```json
{
  "id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
  "revision": 4,
  "created_at": "2026-09-10T08:41:09.388391Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
  "revision": 11,
  "created_at": "2026-09-10T08:41:09.388391Z",
  "kind": "work",
  "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "completion_id": "77d10f91-0546-4145-893d-b3a84b0d3b5f",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
  "revision": 18,
  "created_at": "2026-09-10T08:41:09.942224Z",
  "kind": "work",
  "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
  "goal": "Choose release or discard for inspected fictional KITE",
  "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
  "acceptance": [
    "Explicit disposition naming the exact accepted inspection SHA256"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:decide",
    "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
  ],
  "completion_id": "2ef6a919-ad4b-45ed-b531-11a81aae3055",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "c1346774-1960-49ca-bd3e-cd964eccc068",
  "revision": 18,
  "created_at": "2026-09-10T08:41:10.745572Z",
  "kind": "work",
  "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
  "goal": "Fictional KITE release; cancel unused continuation",
  "expected_result": "No further package work; trusted host explicitly cancels this Work",
  "acceptance": [
    "No further package work; trusted host explicitly cancels this Work"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:closed",
    "release"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 2fdc8068-55b8-445a-b613-c07fd3e746de; Artifact revision: 2
  SHA-256: 0a88c782503024ac3e5215ee2753a37916971d318146fa46878cc561314e68c9; bytes: 146
  File: artifacts/89c70965-7d61-4872-8328-2975772e2098/2fdc8068-55b8-445a-b613-c07fd3e746de.blob

- Version: 878b9479-af67-4682-a06d-4d5d1cff3837; Artifact revision: 2
  SHA-256: 79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f; bytes: 148
  File: artifacts/0a96504a-a3ed-45a6-a31e-21f7d59158ee/878b9479-af67-4682-a06d-4d5d1cff3837.blob

- Version: 1f3750d4-7a4a-43bc-a99e-f5a0a91aa0ba; Artifact revision: 3
  SHA-256: baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb; bytes: 146
  File: artifacts/89c70965-7d61-4872-8328-2975772e2098/1f3750d4-7a4a-43bc-a99e-f5a0a91aa0ba.blob

- Version: 92a75f69-08a6-448b-a9a5-3f3f12fae297; Artifact revision: 3
  SHA-256: e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312; bytes: 147
  File: artifacts/0a96504a-a3ed-45a6-a31e-21f7d59158ee/92a75f69-08a6-448b-a9a5-3f3f12fae297.blob

## Mutation provenance

```json
{
  "id": "6f9bcf66-0c39-481c-8c5f-514be6c77aa1",
  "state_revision": 2,
  "recorded_at": "2026-09-10T08:41:09.416040Z",
  "product_version": "0.10.1",
  "request": {
    "version": 1,
    "operation_id": "7463bc53-af6e-4778-9242-4d32bafd8b81",
    "workspace_id": "13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030",
    "work_id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:41:09.402816Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-01/scenario/workspace",
    "request_sha256": "2e6f10c097374edc926d397e99023e7fd31ed48c3227f162776931c806b56675"
  },
  "fingerprint": "733f872c2b8752e7426fecceb8e4cb39c27a4f7109a4c080b811b514f9e6fe12",
  "before": {
    "id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "revision": 1,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "revision": 2,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "236262c0-6095-4083-bc54-51e9b3ee93ce",
  "state_revision": 3,
  "recorded_at": "2026-09-10T08:41:09.453404Z",
  "product_version": "0.10.1",
  "request": {
    "version": 1,
    "operation_id": "24dfabc1-15c8-4200-b170-c276798bf287",
    "workspace_id": "13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030",
    "work_id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:41:09.439564Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-01/scenario/workspace",
    "request_sha256": "0b3fa1d56a2bb821c49cf610b95df8030bed761fb032adf5059589ae8c1aaf1a"
  },
  "fingerprint": "dcc8b7c96ccd94fdb4737b9dc4e68ba2fce02e7049787fe69545de2166fbc109",
  "before": {
    "id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "revision": 2,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "revision": 3,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "ccd617f0-255d-43f9-8bbc-de18bc3f7b8b",
  "state_revision": 4,
  "recorded_at": "2026-09-10T08:41:09.493814Z",
  "product_version": "0.10.1",
  "request": {
    "version": 5,
    "operation_id": "c3f6c90b-a973-4a21-b10b-fce003976723",
    "workspace_id": "13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030",
    "work_id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional lot binding under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:41:09.480789Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-01/scenario/workspace",
    "request_sha256": "7ebe7e95f84c2bf306c07d1180d3a85b4710083b4306c196dec86e159c4fc32f"
  },
  "fingerprint": "95b534016fb015bd9ef5d850ffd21087eed0c685e331fb2597bddc1dbba5eead",
  "before": {
    "id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "revision": 3,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "revision": 4,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "revision": 1,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "revision": 4,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "7701e5cc-6694-4331-b6fb-e9c4f1b46662",
  "state_revision": 5,
  "recorded_at": "2026-09-10T08:41:09.554403Z",
  "product_version": "0.10.1",
  "request": {
    "version": 2,
    "operation_id": "51aa5df2-4e15-4cdd-957a-cdfb00c2a83a",
    "workspace_id": "13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030",
    "work_id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:41:09.542092Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-01/scenario/workspace",
    "request_sha256": "b0b5f9a9ae519b2051a5851ed2a1ec154c5087c9ad3eeada3f9ef04ac58f1f61"
  },
  "fingerprint": "d6b276fb2140988a13ae9729b38fcb0806d2078277d45dd3f005becc4a00521b",
  "before": {
    "id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "revision": 4,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "revision": 5,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "b5dcd33e-65a7-4d71-90d7-563f0b9fade0",
  "state_revision": 6,
  "recorded_at": "2026-09-10T08:41:09.591847Z",
  "product_version": "0.10.1",
  "request": {
    "version": 2,
    "operation_id": "878b9479-af67-4682-a06d-4d5d1cff3837",
    "workspace_id": "13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030",
    "work_id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
    "artifact_revision": 1,
    "content_sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f",
    "content_size": 148,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:41:09.578269Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-01/scenario/workspace",
    "request_sha256": "8a216cf56d431c8fee3b97f0b631c83106cfee2a752abf947bae46f3e30c7e5a"
  },
  "fingerprint": "97396ac9b817b9e82ed1f2fd88f2e697e956f1db1d0fe05e3f013d681d6b3226",
  "before": {
    "id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "revision": 5,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "revision": 6,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
    "revision": 1,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "artifact",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "work_id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "title": "KITE inspection",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
    "revision": 2,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "artifact",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "work_id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "878b9479-af67-4682-a06d-4d5d1cff3837"
  },
  "artifact_version": {
    "id": "878b9479-af67-4682-a06d-4d5d1cff3837",
    "artifact_id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
    "work_id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "artifact_revision": 2,
    "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f",
    "size": 148,
    "created_at": "2026-09-10T08:41:09.591847Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "a75f74ae-0cde-43e8-b90f-42e3d7500085",
  "state_revision": 7,
  "recorded_at": "2026-09-10T08:41:09.640117Z",
  "product_version": "0.10.1",
  "request": {
    "version": 3,
    "operation_id": "b1e37a06-e5f2-4bd1-925a-c2adff3ef0e4",
    "workspace_id": "13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030",
    "work_id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
        "version_id": "878b9479-af67-4682-a06d-4d5d1cff3837",
        "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "b1e37a06-e5f2-4bd1-925a-c2adff3ef0e4",
      "workspace_id": "13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030",
      "process": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
      "related_work": "a69f0565-3594-4805-8a26-9cc5f07ef562",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
        "version_id": "878b9479-af67-4682-a06d-4d5d1cff3837",
        "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "e310d4ae553eda948d11a52bdd24ef9ccfea47212fe391040400117a044abe12"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:41:09.626137Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-01/scenario/workspace",
    "request_sha256": "c7801ea43f8dc80eee6c9be89aae4e71701704cc570c26713dcfcc579ad84ed7"
  },
  "fingerprint": "01b0325f7e485ec96121592194295dfe946455ed486b2a4d6ed683c1dded1f9c",
  "before": {
    "id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "revision": 6,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "revision": 7,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "4ee88fb3-4bc7-49f9-9628-03f661a124cf",
  "state_revision": 8,
  "recorded_at": "2026-09-10T08:41:09.710439Z",
  "product_version": "0.10.1",
  "request": {
    "version": 2,
    "operation_id": "185bc714-2c07-48cb-8318-65a535439c14",
    "workspace_id": "13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030",
    "work_id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "expected_revision": 7,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
    "artifact_revision": 2,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:41:09.694532Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-01/scenario/workspace",
    "request_sha256": "46f0d882c125fc598438ec827e0a19bf0c04ee9b33ff8f39d16ad82411f3db75"
  },
  "fingerprint": "fc97d9908d46270b27e999c3f862bcd86a37f05f6183812a4e6e8b8ecc2352e2",
  "before": {
    "id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "revision": 7,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "revision": 8,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "351aa69d-da13-4641-937c-2ec5069f0d04",
  "state_revision": 9,
  "recorded_at": "2026-09-10T08:41:09.756507Z",
  "product_version": "0.10.1",
  "request": {
    "version": 2,
    "operation_id": "92a75f69-08a6-448b-a9a5-3f3f12fae297",
    "workspace_id": "13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030",
    "work_id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "expected_revision": 8,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
    "artifact_revision": 2,
    "content_sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312",
    "content_size": 147,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:41:09.738957Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-01/scenario/workspace",
    "request_sha256": "b811efd844b817b627b29b4525177bc715297894cf7c46a94c87168697800671"
  },
  "fingerprint": "8e4843a1cd25990d88692586774c957e990ea4e81c63f625597463c9a2e8731f",
  "before": {
    "id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "revision": 8,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "revision": 9,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
    "revision": 2,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "artifact",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "work_id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "878b9479-af67-4682-a06d-4d5d1cff3837"
  },
  "artifact_after": {
    "id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
    "revision": 3,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "artifact",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "work_id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "92a75f69-08a6-448b-a9a5-3f3f12fae297"
  },
  "artifact_version": {
    "id": "92a75f69-08a6-448b-a9a5-3f3f12fae297",
    "artifact_id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
    "work_id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "artifact_revision": 3,
    "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312",
    "size": 147,
    "created_at": "2026-09-10T08:41:09.756507Z",
    "state_revision": 9
  }
}
```

```json
{
  "id": "5ce9906b-8923-46b8-9e84-29bd155d8c8f",
  "state_revision": 10,
  "recorded_at": "2026-09-10T08:41:09.813113Z",
  "product_version": "0.10.1",
  "request": {
    "version": 3,
    "operation_id": "3947f383-cc67-4523-8fea-f5bf199e65c1",
    "workspace_id": "13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030",
    "work_id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "expected_revision": 9,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
        "version_id": "92a75f69-08a6-448b-a9a5-3f3f12fae297",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "3947f383-cc67-4523-8fea-f5bf199e65c1",
      "workspace_id": "13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030",
      "process": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
      "related_work": "a69f0565-3594-4805-8a26-9cc5f07ef562",
      "intent": "accepted_result",
      "source_revision": 9,
      "result": {
        "artifact_id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
        "version_id": "92a75f69-08a6-448b-a9a5-3f3f12fae297",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "bd3330f1a4f468937eef51f7c868bfd150595b3f8c103c2771f5903b57f7fa33"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:41:09.796359Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-01/scenario/workspace",
    "request_sha256": "616dd9cbab81bc62495090dc0ab5b3bfa09ecfa80fb9d05043b4540d858a0e02"
  },
  "fingerprint": "bb045c58d8ac0c66440fbc7aa67ad784b25f99128c8b10c6ba737161f047b71c",
  "before": {
    "id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "revision": 9,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "revision": 10,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "4d1dbbed-ae2e-4200-bb1f-d7bd6de59129",
  "state_revision": 11,
  "recorded_at": "2026-09-10T08:41:09.942224Z",
  "product_version": "0.10.1",
  "request": {
    "version": 4,
    "operation_id": "77d10f91-0546-4145-893d-b3a84b0d3b5f",
    "workspace_id": "13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030",
    "work_id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "expected_revision": 10,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.lot\",\"pack_version\":\"1.0.0\",\"process_type\":\"fictional.lot-release\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
        "version_id": "92a75f69-08a6-448b-a9a5-3f3f12fae297",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 10,
      "result": {
        "artifact_id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
        "version_id": "92a75f69-08a6-448b-a9a5-3f3f12fae297",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      },
      "acceptance_ids": [
        "b1e37a06-e5f2-4bd1-925a-c2adff3ef0e4",
        "3947f383-cc67-4523-8fea-f5bf199e65c1"
      ],
      "next_work": {
        "work_id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
        "artifact_id": "89c70965-7d61-4872-8328-2975772e2098",
        "goal": "Choose release or discard for inspected fictional KITE",
        "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
        "acceptance": [
          "Explicit disposition naming the exact accepted inspection SHA256"
        ],
        "boundaries": [
          "Fictional local evidence only; no real release or external action"
        ],
        "budget": "One finite fictional lot",
        "executor_requirements": [
          "fictional.lot/v1:decide",
          "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
        ],
        "artifact_title": "KITE disposition",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:41:09.923240Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-01/scenario/workspace",
    "request_sha256": "4f4b62c2a8cce087ed2ba852fd42c0c7d2db21925d5db48e82e7d14f8c21475d"
  },
  "fingerprint": "f5ece053d0f0d7af30d04b8c1dac1741986e233f879220ccff63a86d28c3c96f",
  "before": {
    "id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "revision": 10,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "revision": 11,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "completion_id": "77d10f91-0546-4145-893d-b3a84b0d3b5f",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "revision": 11,
    "created_at": "2026-09-10T08:41:09.942224Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "89c70965-7d61-4872-8328-2975772e2098",
    "revision": 1,
    "created_at": "2026-09-10T08:41:09.942224Z",
    "kind": "artifact",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "work_id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "title": "KITE disposition",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
    "revision": 3,
    "created_at": "2026-09-10T08:41:09.388391Z",
    "kind": "artifact",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "work_id": "a69f0565-3594-4805-8a26-9cc5f07ef562",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "92a75f69-08a6-448b-a9a5-3f3f12fae297"
  },
  "result_references": [
    {
      "artifact_id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
      "version_id": "92a75f69-08a6-448b-a9a5-3f3f12fae297",
      "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    },
    {
      "artifact_id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
      "version_id": "878b9479-af67-4682-a06d-4d5d1cff3837",
      "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
    }
  ]
}
```

```json
{
  "id": "123dc766-6b04-4de6-ad67-dd4fc441d371",
  "state_revision": 12,
  "recorded_at": "2026-09-10T08:41:10.187970Z",
  "product_version": "0.10.1",
  "request": {
    "version": 2,
    "operation_id": "75bcc7e9-63b4-4500-b49b-bd8242dde983",
    "workspace_id": "13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030",
    "work_id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "expected_revision": 11,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "89c70965-7d61-4872-8328-2975772e2098",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:41:10.170671Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-01/scenario/workspace",
    "request_sha256": "0a31251bc86f0a2fbd6b52fd2da83f789a5ce9ad61f3cb095ba689b9ddcbb30c"
  },
  "fingerprint": "3c4b785601ce545121d18dd663a5c16227cab1ee655c50b85d2dd6e12af49d61",
  "before": {
    "id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "revision": 11,
    "created_at": "2026-09-10T08:41:09.942224Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "revision": 12,
    "created_at": "2026-09-10T08:41:09.942224Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "0746043d-40a1-4658-9de3-8e4ecb941115",
  "state_revision": 13,
  "recorded_at": "2026-09-10T08:41:10.238430Z",
  "product_version": "0.10.1",
  "request": {
    "version": 2,
    "operation_id": "2fdc8068-55b8-445a-b613-c07fd3e746de",
    "workspace_id": "13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030",
    "work_id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "expected_revision": 12,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "89c70965-7d61-4872-8328-2975772e2098",
    "artifact_revision": 1,
    "content_sha256": "0a88c782503024ac3e5215ee2753a37916971d318146fa46878cc561314e68c9",
    "content_size": 146,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:41:10.220159Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-01/scenario/workspace",
    "request_sha256": "06d83a319df45dda23871d1e6e55989d820bcd48c65c943215e364bf1d9080fb"
  },
  "fingerprint": "4536847fc5bc5a9067b19854317eabce17df280ab559b5705c5fe6d4d99be165",
  "before": {
    "id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "revision": 12,
    "created_at": "2026-09-10T08:41:09.942224Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "revision": 13,
    "created_at": "2026-09-10T08:41:09.942224Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "89c70965-7d61-4872-8328-2975772e2098",
    "revision": 1,
    "created_at": "2026-09-10T08:41:09.942224Z",
    "kind": "artifact",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "work_id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "title": "KITE disposition",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "89c70965-7d61-4872-8328-2975772e2098",
    "revision": 2,
    "created_at": "2026-09-10T08:41:09.942224Z",
    "kind": "artifact",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "work_id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "title": "KITE disposition",
    "status": "registered",
    "active_version": "2fdc8068-55b8-445a-b613-c07fd3e746de"
  },
  "artifact_version": {
    "id": "2fdc8068-55b8-445a-b613-c07fd3e746de",
    "artifact_id": "89c70965-7d61-4872-8328-2975772e2098",
    "work_id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "artifact_revision": 2,
    "sha256": "0a88c782503024ac3e5215ee2753a37916971d318146fa46878cc561314e68c9",
    "size": 146,
    "created_at": "2026-09-10T08:41:10.238430Z",
    "state_revision": 13
  }
}
```

```json
{
  "id": "e92ee33f-b2cd-4421-b254-5c03e1251134",
  "state_revision": 14,
  "recorded_at": "2026-09-10T08:41:10.300328Z",
  "product_version": "0.10.1",
  "request": {
    "version": 3,
    "operation_id": "fff95649-83bb-4751-84c7-e93f0f28ca9b",
    "workspace_id": "13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030",
    "work_id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "expected_revision": 13,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "89c70965-7d61-4872-8328-2975772e2098",
        "version_id": "2fdc8068-55b8-445a-b613-c07fd3e746de",
        "sha256": "0a88c782503024ac3e5215ee2753a37916971d318146fa46878cc561314e68c9"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "fff95649-83bb-4751-84c7-e93f0f28ca9b",
      "workspace_id": "13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030",
      "process": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
      "related_work": "aaae5c3e-f218-452e-927d-a9d87356b5be",
      "intent": "accepted_result",
      "source_revision": 13,
      "result": {
        "artifact_id": "89c70965-7d61-4872-8328-2975772e2098",
        "version_id": "2fdc8068-55b8-445a-b613-c07fd3e746de",
        "sha256": "0a88c782503024ac3e5215ee2753a37916971d318146fa46878cc561314e68c9"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "8224c57cb322b40e71a818382c8a7b8ebfbb9dae386de69ddc0f8168b63b5591"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:41:10.282244Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-01/scenario/workspace",
    "request_sha256": "2fb444bdede1919726c37e54ae9f71d46fdee443857e778126969882a2e55506"
  },
  "fingerprint": "b9f3aea46b6b01557254b34906bc7c824f4350b5066e6aa89727166e6e1e7b2f",
  "before": {
    "id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "revision": 13,
    "created_at": "2026-09-10T08:41:09.942224Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "revision": 14,
    "created_at": "2026-09-10T08:41:09.942224Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "4047f2bd-489c-4a85-ab05-0972303341a7",
  "state_revision": 15,
  "recorded_at": "2026-09-10T08:41:10.397273Z",
  "product_version": "0.10.1",
  "request": {
    "version": 2,
    "operation_id": "a173992b-f227-476d-8d3b-d13deacc1b9a",
    "workspace_id": "13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030",
    "work_id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "expected_revision": 14,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "89c70965-7d61-4872-8328-2975772e2098",
    "artifact_revision": 2,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:41:10.378930Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-01/scenario/workspace",
    "request_sha256": "b342fd7aeb0f1e1865aab2a1ae439d4284d193eebff8c0c8e41bfccc2a8c73e4"
  },
  "fingerprint": "037be2998e244d633a6bc90a1f37572d6e81a269cbf61c022e0649a53318b7e1",
  "before": {
    "id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "revision": 14,
    "created_at": "2026-09-10T08:41:09.942224Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "revision": 15,
    "created_at": "2026-09-10T08:41:09.942224Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "de697685-1d7c-4d5c-a823-b9bf937601f3",
  "state_revision": 16,
  "recorded_at": "2026-09-10T08:41:10.451875Z",
  "product_version": "0.10.1",
  "request": {
    "version": 2,
    "operation_id": "1f3750d4-7a4a-43bc-a99e-f5a0a91aa0ba",
    "workspace_id": "13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030",
    "work_id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "expected_revision": 15,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "89c70965-7d61-4872-8328-2975772e2098",
    "artifact_revision": 2,
    "content_sha256": "baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb",
    "content_size": 146,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:41:10.433235Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-01/scenario/workspace",
    "request_sha256": "022e560072349ac892f8258e694ddd7db58276d6b586dce0adbddfc973d593a6"
  },
  "fingerprint": "6183f6a469359079de5faeb7d3d939184901ef3577f58b3787b6a3f93ec7d0ad",
  "before": {
    "id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "revision": 15,
    "created_at": "2026-09-10T08:41:09.942224Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "revision": 16,
    "created_at": "2026-09-10T08:41:09.942224Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "89c70965-7d61-4872-8328-2975772e2098",
    "revision": 2,
    "created_at": "2026-09-10T08:41:09.942224Z",
    "kind": "artifact",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "work_id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "title": "KITE disposition",
    "status": "registered",
    "active_version": "2fdc8068-55b8-445a-b613-c07fd3e746de"
  },
  "artifact_after": {
    "id": "89c70965-7d61-4872-8328-2975772e2098",
    "revision": 3,
    "created_at": "2026-09-10T08:41:09.942224Z",
    "kind": "artifact",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "work_id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "title": "KITE disposition",
    "status": "registered",
    "active_version": "1f3750d4-7a4a-43bc-a99e-f5a0a91aa0ba"
  },
  "artifact_version": {
    "id": "1f3750d4-7a4a-43bc-a99e-f5a0a91aa0ba",
    "artifact_id": "89c70965-7d61-4872-8328-2975772e2098",
    "work_id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "artifact_revision": 3,
    "sha256": "baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb",
    "size": 146,
    "created_at": "2026-09-10T08:41:10.451875Z",
    "state_revision": 16
  }
}
```

```json
{
  "id": "2489b510-35bd-4b15-ab32-281197480bf7",
  "state_revision": 17,
  "recorded_at": "2026-09-10T08:41:10.518448Z",
  "product_version": "0.10.1",
  "request": {
    "version": 3,
    "operation_id": "5b190050-df6a-4963-8265-e459d5b9c844",
    "workspace_id": "13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030",
    "work_id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "expected_revision": 16,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "89c70965-7d61-4872-8328-2975772e2098",
        "version_id": "1f3750d4-7a4a-43bc-a99e-f5a0a91aa0ba",
        "sha256": "baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "5b190050-df6a-4963-8265-e459d5b9c844",
      "workspace_id": "13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030",
      "process": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
      "related_work": "aaae5c3e-f218-452e-927d-a9d87356b5be",
      "intent": "accepted_result",
      "source_revision": 16,
      "result": {
        "artifact_id": "89c70965-7d61-4872-8328-2975772e2098",
        "version_id": "1f3750d4-7a4a-43bc-a99e-f5a0a91aa0ba",
        "sha256": "baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "491e9a1493d63657c7c2bdaa5884e41e857928dd440475b489ced550330402b7"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:41:10.497813Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-01/scenario/workspace",
    "request_sha256": "7c4f42c2c0b4f0a7dba1a95d7eb36838a535b25cbde9ee02fe812204aa6817cb"
  },
  "fingerprint": "be8e907bd54c4888a2b847809980a556d5ea3bb253b023bcc981a75e1f030918",
  "before": {
    "id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "revision": 16,
    "created_at": "2026-09-10T08:41:09.942224Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "revision": 17,
    "created_at": "2026-09-10T08:41:09.942224Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "a3523479-5a4f-4a7b-8c67-511c3819a287",
  "state_revision": 18,
  "recorded_at": "2026-09-10T08:41:10.745572Z",
  "product_version": "0.10.1",
  "request": {
    "version": 4,
    "operation_id": "2ef6a919-ad4b-45ed-b531-11a81aae3055",
    "workspace_id": "13bcdef2-9ee7-4c3f-9c6c-514e3ee4d030",
    "work_id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "expected_revision": 17,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.lot\",\"pack_version\":\"1.0.0\",\"process_type\":\"fictional.lot-release\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "89c70965-7d61-4872-8328-2975772e2098",
        "version_id": "1f3750d4-7a4a-43bc-a99e-f5a0a91aa0ba",
        "sha256": "baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 17,
      "result": {
        "artifact_id": "89c70965-7d61-4872-8328-2975772e2098",
        "version_id": "1f3750d4-7a4a-43bc-a99e-f5a0a91aa0ba",
        "sha256": "baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb"
      },
      "acceptance_ids": [
        "fff95649-83bb-4751-84c7-e93f0f28ca9b",
        "5b190050-df6a-4963-8265-e459d5b9c844"
      ],
      "next_work": {
        "work_id": "c1346774-1960-49ca-bd3e-cd964eccc068",
        "artifact_id": "6622013e-721e-4501-94b2-1e8656a5091c",
        "goal": "Fictional KITE release; cancel unused continuation",
        "expected_result": "No further package work; trusted host explicitly cancels this Work",
        "acceptance": [
          "No further package work; trusted host explicitly cancels this Work"
        ],
        "boundaries": [
          "Fictional local evidence only; no real release or external action"
        ],
        "budget": "One finite fictional lot",
        "executor_requirements": [
          "fictional.lot/v1:closed",
          "release"
        ],
        "artifact_title": "Unused closed continuation (no Result claimed)",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:41:10.737893Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-01/scenario/events/disposition-restored",
    "request_sha256": "c9541a772e60ce3d7b194992e16c3074cc932723a1f5089f3e2435dad7a4089d"
  },
  "fingerprint": "d908f2abc6f51bff8219f7e362d716a5caa334e88a63655fcd7de696d2daccda",
  "before": {
    "id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "revision": 17,
    "created_at": "2026-09-10T08:41:09.942224Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "revision": 18,
    "created_at": "2026-09-10T08:41:09.942224Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "completion_id": "2ef6a919-ad4b-45ed-b531-11a81aae3055",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "c1346774-1960-49ca-bd3e-cd964eccc068",
    "revision": 18,
    "created_at": "2026-09-10T08:41:10.745572Z",
    "kind": "work",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "goal": "Fictional KITE release; cancel unused continuation",
    "expected_result": "No further package work; trusted host explicitly cancels this Work",
    "acceptance": [
      "No further package work; trusted host explicitly cancels this Work"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:closed",
      "release"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "6622013e-721e-4501-94b2-1e8656a5091c",
    "revision": 1,
    "created_at": "2026-09-10T08:41:10.745572Z",
    "kind": "artifact",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "work_id": "c1346774-1960-49ca-bd3e-cd964eccc068",
    "title": "Unused closed continuation (no Result claimed)",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "89c70965-7d61-4872-8328-2975772e2098",
    "revision": 3,
    "created_at": "2026-09-10T08:41:09.942224Z",
    "kind": "artifact",
    "process_id": "dc83fef9-c6a0-4b36-8261-93bc6b52189a",
    "work_id": "aaae5c3e-f218-452e-927d-a9d87356b5be",
    "title": "KITE disposition",
    "status": "registered",
    "active_version": "1f3750d4-7a4a-43bc-a99e-f5a0a91aa0ba"
  },
  "result_references": [
    {
      "artifact_id": "89c70965-7d61-4872-8328-2975772e2098",
      "version_id": "1f3750d4-7a4a-43bc-a99e-f5a0a91aa0ba",
      "sha256": "baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb"
    },
    {
      "artifact_id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
      "version_id": "92a75f69-08a6-448b-a9a5-3f3f12fae297",
      "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    },
    {
      "artifact_id": "0a96504a-a3ed-45a6-a31e-21f7d59158ee",
      "version_id": "878b9479-af67-4682-a06d-4d5d1cff3837",
      "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
    },
    {
      "artifact_id": "89c70965-7d61-4872-8328-2975772e2098",
      "version_id": "2fdc8068-55b8-445a-b613-c07fd3e746de",
      "sha256": "0a88c782503024ac3e5215ee2753a37916971d318146fa46878cc561314e68c9"
    }
  ]
}
```

