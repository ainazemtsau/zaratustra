# Zaratustra — generated overview

generated_from_revision: 19
generated_at: 2026-09-10T08:50:15.356298+00:00
workspace_id: 55065915-2296-4c00-b344-19c8e2b963c3

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
  "revision": 3,
  "created_at": "2026-09-10T08:50:14.387458Z",
  "kind": "artifact",
  "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
  "work_id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
  "title": "KITE disposition",
  "status": "registered",
  "active_version": "c88e9ddc-f616-4ef0-bbf9-6d508a556c63"
}
```

## artifact

```json
{
  "id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
  "revision": 3,
  "created_at": "2026-09-10T08:50:13.854963Z",
  "kind": "artifact",
  "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
  "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
  "title": "KITE inspection",
  "status": "registered",
  "active_version": "0cb2ed13-8841-452c-8f57-41bb89b427ea"
}
```

## artifact

```json
{
  "id": "bbff9de1-a8d1-4e79-91b4-af1d0b290a5a",
  "revision": 1,
  "created_at": "2026-09-10T08:50:15.107494Z",
  "kind": "artifact",
  "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
  "work_id": "845a5f9d-3349-428c-a120-e7dbdb221636",
  "title": "Unused closed continuation (no Result claimed)",
  "status": "declared",
  "active_version": null
}
```

## event

```json
{
  "id": "39e82e67-a2e0-4f80-9745-096a6d8ba938",
  "revision": 1,
  "created_at": "2026-09-10T08:50:13.854963Z",
  "kind": "event",
  "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
  "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.1",
  "state_revision": 1,
  "affected_ids": [
    "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "a4a00b68-9f93-4042-9f47-2ef3ca290f6f"
  ]
}
```

## process

```json
{
  "id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
  "revision": 4,
  "created_at": "2026-09-10T08:50:13.854963Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "845a5f9d-3349-428c-a120-e7dbdb221636",
  "revision": 19,
  "created_at": "2026-09-10T08:50:15.107494Z",
  "kind": "work",
  "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
  "goal": "Fictional KITE release; cancel unused continuation",
  "expected_result": "No further package work; trusted host explicitly cancels this Work",
  "acceptance": [
    "No further package work; trusted host explicitly cancels this Work"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "cancelled",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:closed",
    "release"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
  "revision": 11,
  "created_at": "2026-09-10T08:50:13.854963Z",
  "kind": "work",
  "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "completion_id": "559083bf-338b-43d8-bfab-f312e259985a",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
  "revision": 18,
  "created_at": "2026-09-10T08:50:14.387458Z",
  "kind": "work",
  "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
  "goal": "Choose release or discard for inspected fictional KITE",
  "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
  "acceptance": [
    "Explicit disposition naming the exact accepted inspection SHA256"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:decide",
    "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
  ],
  "completion_id": "b2ddba32-1cca-4e44-bc41-5fa924a0f928",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 8cf5c4d1-c032-44ce-93f7-67f51de35238; Artifact revision: 2
  SHA-256: 79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f; bytes: 148
  File: artifacts/a4a00b68-9f93-4042-9f47-2ef3ca290f6f/8cf5c4d1-c032-44ce-93f7-67f51de35238.blob

- Version: 8e387f96-8acd-46c0-9200-36fce9c3044c; Artifact revision: 2
  SHA-256: 0a88c782503024ac3e5215ee2753a37916971d318146fa46878cc561314e68c9; bytes: 146
  File: artifacts/a3bdaeda-2637-4809-bf5f-f7c3f0288e4a/8e387f96-8acd-46c0-9200-36fce9c3044c.blob

- Version: 0cb2ed13-8841-452c-8f57-41bb89b427ea; Artifact revision: 3
  SHA-256: e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312; bytes: 147
  File: artifacts/a4a00b68-9f93-4042-9f47-2ef3ca290f6f/0cb2ed13-8841-452c-8f57-41bb89b427ea.blob

- Version: c88e9ddc-f616-4ef0-bbf9-6d508a556c63; Artifact revision: 3
  SHA-256: baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb; bytes: 146
  File: artifacts/a3bdaeda-2637-4809-bf5f-f7c3f0288e4a/c88e9ddc-f616-4ef0-bbf9-6d508a556c63.blob

## Mutation provenance

```json
{
  "id": "de6692f4-0e37-48aa-97e5-d5d6d50bfc9c",
  "state_revision": 2,
  "recorded_at": "2026-09-10T08:50:13.881843Z",
  "product_version": "0.10.1",
  "request": {
    "version": 1,
    "operation_id": "18762781-0e7d-4fce-b9c5-03a80f90ccf7",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:13.868049Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "c48ccaca5b7dc6488be7f446a97bc306378764d818a775b2fb7a2e65fc35e54b"
  },
  "fingerprint": "ec343df98c9df065fb2cefb90bcd1707741973c85d3457d9163c4be94c844a5b",
  "before": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 1,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 2,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "71f809ca-dc93-420d-a6af-bf6567db1e31",
  "state_revision": 3,
  "recorded_at": "2026-09-10T08:50:13.916310Z",
  "product_version": "0.10.1",
  "request": {
    "version": 1,
    "operation_id": "75ce8345-a9a7-467d-9e50-5c5ea8831195",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:13.903873Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "d8104b24257c7c117d49953147ba3ba346a8872c1c59931ee942b1d6142fba6f"
  },
  "fingerprint": "1ae055eae7ed0ddfe012be39546f7e5cc2a642a0a4f54800555bb8c18c0fe85e",
  "before": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 2,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 3,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "0bf9d8c6-5fb7-4d6b-a974-e9a62d363a0e",
  "state_revision": 4,
  "recorded_at": "2026-09-10T08:50:13.952931Z",
  "product_version": "0.10.1",
  "request": {
    "version": 5,
    "operation_id": "77cfcb9b-b2c2-4cae-89f8-ea574e2d5aa7",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional lot binding under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:13.940921Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "48a199ddbd1b961f62aa8c8ce6d78ec809f016c9e9e5cd4fe82af5ff8e8a8c85"
  },
  "fingerprint": "993dd9cc9a7d310d44e1dae9d32e79aab3b8bb2b7eb9b001308540095d6c0386",
  "before": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 3,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 4,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "revision": 1,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "revision": 4,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "6ad31860-f5db-46c2-a006-38a5701cf976",
  "state_revision": 5,
  "recorded_at": "2026-09-10T08:50:14.012242Z",
  "product_version": "0.10.1",
  "request": {
    "version": 2,
    "operation_id": "98c1d503-6dd8-4829-ab53-f6f4ee22ff50",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:13.999717Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "3d145f90b2234284549473b456e80e40784c8c63055886ed79eb7770f1e43418"
  },
  "fingerprint": "d06e52307748fe3598165e01d93a7ee8b79e4b73be6e8607b1af4078484435e8",
  "before": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 4,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 5,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "ffb72739-6ec6-4e7f-bb26-ec33e0d9c393",
  "state_revision": 6,
  "recorded_at": "2026-09-10T08:50:14.051763Z",
  "product_version": "0.10.1",
  "request": {
    "version": 2,
    "operation_id": "8cf5c4d1-c032-44ce-93f7-67f51de35238",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "artifact_revision": 1,
    "content_sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f",
    "content_size": 148,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:14.038247Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "dcd0412523e007d297cdd34c862095201835afdf569c18c576ee6f6f5a5dea61"
  },
  "fingerprint": "2c0018bd0c2340d8e7e6d0b68d26c1ca8c67dcf62e0b678b3a7dbb195bbe8102",
  "before": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 5,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 6,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "revision": 1,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "artifact",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "title": "KITE inspection",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "revision": 2,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "artifact",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "8cf5c4d1-c032-44ce-93f7-67f51de35238"
  },
  "artifact_version": {
    "id": "8cf5c4d1-c032-44ce-93f7-67f51de35238",
    "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "artifact_revision": 2,
    "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f",
    "size": 148,
    "created_at": "2026-09-10T08:50:14.051763Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "8478d1a9-70d0-476e-98ae-3bf74dfca30b",
  "state_revision": 7,
  "recorded_at": "2026-09-10T08:50:14.101979Z",
  "product_version": "0.10.1",
  "request": {
    "version": 3,
    "operation_id": "942f70cd-718a-400f-b7c6-e65204ff184a",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
        "version_id": "8cf5c4d1-c032-44ce-93f7-67f51de35238",
        "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "942f70cd-718a-400f-b7c6-e65204ff184a",
      "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
      "process": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
      "related_work": "8acf0f77-094c-4848-87cb-748f7628dbfd",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
        "version_id": "8cf5c4d1-c032-44ce-93f7-67f51de35238",
        "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "43a98aaf52764a6a4f621848b03d8441fa03238bfc3a4376269d70bc1d71a635"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:14.086567Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "28db1340be23f39af2459e2ddbf88f6ef6610cd5861ac6c073d624dfa8545ebc"
  },
  "fingerprint": "e674850d547e5e164ea777270a0668c8ab29adfbaf7d4d8b7013f640e90011fe",
  "before": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 6,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 7,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "312d13cb-78ca-4c1c-aa47-596f6779ef57",
  "state_revision": 8,
  "recorded_at": "2026-09-10T08:50:14.169089Z",
  "product_version": "0.10.1",
  "request": {
    "version": 2,
    "operation_id": "17772044-48f5-4f90-a266-00b9c546b775",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "expected_revision": 7,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "artifact_revision": 2,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:14.153206Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "2a77505c4ff5bd0136acba904deb0ee23a01950263979446d68ea4643aa82cb5"
  },
  "fingerprint": "f4b9705391d80bddeb03280bb4560bfff8038fcdce2d0d11905b181f2ece85c3",
  "before": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 7,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 8,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "2e6e9e3e-cb30-4896-ac12-e785f1dd3fd5",
  "state_revision": 9,
  "recorded_at": "2026-09-10T08:50:14.213250Z",
  "product_version": "0.10.1",
  "request": {
    "version": 2,
    "operation_id": "0cb2ed13-8841-452c-8f57-41bb89b427ea",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "expected_revision": 8,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "artifact_revision": 2,
    "content_sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312",
    "content_size": 147,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:14.198766Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "02dd72c8eb2008070e4d9892474716181e3caaa5f1424a02635333cb85660555"
  },
  "fingerprint": "4c12180ea9f738237b064ec5e24ec2a600d4f3cc13da101bb299cf3b1630b77a",
  "before": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 8,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 9,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "revision": 2,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "artifact",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "8cf5c4d1-c032-44ce-93f7-67f51de35238"
  },
  "artifact_after": {
    "id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "revision": 3,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "artifact",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "0cb2ed13-8841-452c-8f57-41bb89b427ea"
  },
  "artifact_version": {
    "id": "0cb2ed13-8841-452c-8f57-41bb89b427ea",
    "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "artifact_revision": 3,
    "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312",
    "size": 147,
    "created_at": "2026-09-10T08:50:14.213250Z",
    "state_revision": 9
  }
}
```

```json
{
  "id": "7c44c3ec-5a5e-4ce8-a641-2835e4db35ef",
  "state_revision": 10,
  "recorded_at": "2026-09-10T08:50:14.267287Z",
  "product_version": "0.10.1",
  "request": {
    "version": 3,
    "operation_id": "6500e0c9-b9e0-420d-8706-5a5e0d49e72b",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "expected_revision": 9,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
        "version_id": "0cb2ed13-8841-452c-8f57-41bb89b427ea",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "6500e0c9-b9e0-420d-8706-5a5e0d49e72b",
      "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
      "process": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
      "related_work": "8acf0f77-094c-4848-87cb-748f7628dbfd",
      "intent": "accepted_result",
      "source_revision": 9,
      "result": {
        "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
        "version_id": "0cb2ed13-8841-452c-8f57-41bb89b427ea",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "9b52a0d81875349239cc1e5184f6b833f8fc24589d800fdc4921b3f26931b29f"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:14.250823Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "c89a192ee2f96c7c352e48aa3485caa4e5eb93da24bcfed443157ea7d3062578"
  },
  "fingerprint": "b6d497a4683fee5cde48d805c8185fa5a374b3977b12581930cad6a3bd0af66a",
  "before": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 9,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 10,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "a3c207ba-ce0a-4f78-8597-a45bfcacb9ec",
  "state_revision": 11,
  "recorded_at": "2026-09-10T08:50:14.387458Z",
  "product_version": "0.10.1",
  "request": {
    "version": 4,
    "operation_id": "559083bf-338b-43d8-bfab-f312e259985a",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "expected_revision": 10,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.lot\",\"pack_version\":\"1.0.0\",\"process_type\":\"fictional.lot-release\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
        "version_id": "0cb2ed13-8841-452c-8f57-41bb89b427ea",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 10,
      "result": {
        "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
        "version_id": "0cb2ed13-8841-452c-8f57-41bb89b427ea",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      },
      "acceptance_ids": [
        "942f70cd-718a-400f-b7c6-e65204ff184a",
        "6500e0c9-b9e0-420d-8706-5a5e0d49e72b"
      ],
      "next_work": {
        "work_id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
        "artifact_id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
        "goal": "Choose release or discard for inspected fictional KITE",
        "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
        "acceptance": [
          "Explicit disposition naming the exact accepted inspection SHA256"
        ],
        "boundaries": [
          "Fictional local evidence only; no real release or external action"
        ],
        "budget": "One finite fictional lot",
        "executor_requirements": [
          "fictional.lot/v1:decide",
          "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
        ],
        "artifact_title": "KITE disposition",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:14.370777Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "36657ebd15f0a335ad9d6b1134fe5d6fba1658b08242a450f508d701c13aaeb5"
  },
  "fingerprint": "20f97ecbec15710c33dcf3f21e735fe60635ba1aeaf7cc27bb78991b7ad4dd12",
  "before": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 10,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 11,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "completion_id": "559083bf-338b-43d8-bfab-f312e259985a",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "revision": 11,
    "created_at": "2026-09-10T08:50:14.387458Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
    "revision": 1,
    "created_at": "2026-09-10T08:50:14.387458Z",
    "kind": "artifact",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "work_id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "title": "KITE disposition",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "revision": 3,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "artifact",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "0cb2ed13-8841-452c-8f57-41bb89b427ea"
  },
  "result_references": [
    {
      "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
      "version_id": "0cb2ed13-8841-452c-8f57-41bb89b427ea",
      "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    },
    {
      "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
      "version_id": "8cf5c4d1-c032-44ce-93f7-67f51de35238",
      "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
    }
  ]
}
```

```json
{
  "id": "771bcde9-bb0c-46fc-bcdf-8f48482dc7cc",
  "state_revision": 12,
  "recorded_at": "2026-09-10T08:50:14.638305Z",
  "product_version": "0.10.1",
  "request": {
    "version": 2,
    "operation_id": "1808e454-14d2-4462-ae13-1a500ef02411",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "expected_revision": 11,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:14.618301Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "e758ba7a8d4902358909f7196ac99d8e7f8b192be2635fb46c91216f64cf508c"
  },
  "fingerprint": "319cd92e5ce7df7c1e1b065530326a9d98677c8bf4403311e72b9f48707199a3",
  "before": {
    "id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "revision": 11,
    "created_at": "2026-09-10T08:50:14.387458Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "revision": 12,
    "created_at": "2026-09-10T08:50:14.387458Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "67703c54-8467-465d-b6d8-bc21a426706f",
  "state_revision": 13,
  "recorded_at": "2026-09-10T08:50:14.690114Z",
  "product_version": "0.10.1",
  "request": {
    "version": 2,
    "operation_id": "8e387f96-8acd-46c0-9200-36fce9c3044c",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "expected_revision": 12,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
    "artifact_revision": 1,
    "content_sha256": "0a88c782503024ac3e5215ee2753a37916971d318146fa46878cc561314e68c9",
    "content_size": 146,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:14.672026Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "85ca50968dac7da5afaeec882298061d5218a8412211f1c7edbec05ee4f96f38"
  },
  "fingerprint": "a3d4c22bb792db717598f3a65a30a79541222a84c07fab66957cf865d56df67d",
  "before": {
    "id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "revision": 12,
    "created_at": "2026-09-10T08:50:14.387458Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "revision": 13,
    "created_at": "2026-09-10T08:50:14.387458Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
    "revision": 1,
    "created_at": "2026-09-10T08:50:14.387458Z",
    "kind": "artifact",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "work_id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "title": "KITE disposition",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
    "revision": 2,
    "created_at": "2026-09-10T08:50:14.387458Z",
    "kind": "artifact",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "work_id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "title": "KITE disposition",
    "status": "registered",
    "active_version": "8e387f96-8acd-46c0-9200-36fce9c3044c"
  },
  "artifact_version": {
    "id": "8e387f96-8acd-46c0-9200-36fce9c3044c",
    "artifact_id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
    "work_id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "artifact_revision": 2,
    "sha256": "0a88c782503024ac3e5215ee2753a37916971d318146fa46878cc561314e68c9",
    "size": 146,
    "created_at": "2026-09-10T08:50:14.690114Z",
    "state_revision": 13
  }
}
```

```json
{
  "id": "45ea8feb-6699-4b50-b535-709216438c59",
  "state_revision": 14,
  "recorded_at": "2026-09-10T08:50:14.752863Z",
  "product_version": "0.10.1",
  "request": {
    "version": 3,
    "operation_id": "9e335244-4839-48e8-84eb-d9fce231b025",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "expected_revision": 13,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
        "version_id": "8e387f96-8acd-46c0-9200-36fce9c3044c",
        "sha256": "0a88c782503024ac3e5215ee2753a37916971d318146fa46878cc561314e68c9"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "9e335244-4839-48e8-84eb-d9fce231b025",
      "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
      "process": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
      "related_work": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
      "intent": "accepted_result",
      "source_revision": 13,
      "result": {
        "artifact_id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
        "version_id": "8e387f96-8acd-46c0-9200-36fce9c3044c",
        "sha256": "0a88c782503024ac3e5215ee2753a37916971d318146fa46878cc561314e68c9"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "ecc6a1bc479a7d6e9857a29b0589511b72ffd94c581cb58092966d85f58880a1"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:14.733769Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "cc6221234592a3853d10b09212b2dcb6bbb2f62cbc03746aa4612624c1f18630"
  },
  "fingerprint": "34cd001ad0ad3cd8a2e414776530d0f9f883de925eca278beb6d4f2b01bed2c2",
  "before": {
    "id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "revision": 13,
    "created_at": "2026-09-10T08:50:14.387458Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "revision": 14,
    "created_at": "2026-09-10T08:50:14.387458Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "c2ebf772-ae85-4640-82ff-3d3617edbee5",
  "state_revision": 15,
  "recorded_at": "2026-09-10T08:50:14.853368Z",
  "product_version": "0.10.1",
  "request": {
    "version": 2,
    "operation_id": "51ed6f5f-62a3-4a75-8847-faa652e464b5",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "expected_revision": 14,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
    "artifact_revision": 2,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:14.834037Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "ec42bc4e237902f1cf80af13ff14ab34d7bf385527c9d04c52b4fd37812add1c"
  },
  "fingerprint": "970ce53775868118db7611d4d613415bb79f9918d796f9e02c0389d779ad0f75",
  "before": {
    "id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "revision": 14,
    "created_at": "2026-09-10T08:50:14.387458Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "revision": 15,
    "created_at": "2026-09-10T08:50:14.387458Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "22cf2ca5-a213-4484-abae-f838324cb9ff",
  "state_revision": 16,
  "recorded_at": "2026-09-10T08:50:14.908927Z",
  "product_version": "0.10.1",
  "request": {
    "version": 2,
    "operation_id": "c88e9ddc-f616-4ef0-bbf9-6d508a556c63",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "expected_revision": 15,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
    "artifact_revision": 2,
    "content_sha256": "baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb",
    "content_size": 146,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:14.889193Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "0dad3f973309c9305dd724a568a2704c2606a18244fccf41d134f5c59d75b34c"
  },
  "fingerprint": "0b53eb0f1e8259c2016607a5c8efbf717ca193d4cbabc09bb8d5fbccc7999cdb",
  "before": {
    "id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "revision": 15,
    "created_at": "2026-09-10T08:50:14.387458Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "revision": 16,
    "created_at": "2026-09-10T08:50:14.387458Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
    "revision": 2,
    "created_at": "2026-09-10T08:50:14.387458Z",
    "kind": "artifact",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "work_id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "title": "KITE disposition",
    "status": "registered",
    "active_version": "8e387f96-8acd-46c0-9200-36fce9c3044c"
  },
  "artifact_after": {
    "id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
    "revision": 3,
    "created_at": "2026-09-10T08:50:14.387458Z",
    "kind": "artifact",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "work_id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "title": "KITE disposition",
    "status": "registered",
    "active_version": "c88e9ddc-f616-4ef0-bbf9-6d508a556c63"
  },
  "artifact_version": {
    "id": "c88e9ddc-f616-4ef0-bbf9-6d508a556c63",
    "artifact_id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
    "work_id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "artifact_revision": 3,
    "sha256": "baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb",
    "size": 146,
    "created_at": "2026-09-10T08:50:14.908927Z",
    "state_revision": 16
  }
}
```

```json
{
  "id": "44446410-f43c-49f3-a074-6f3950821860",
  "state_revision": 17,
  "recorded_at": "2026-09-10T08:50:14.980132Z",
  "product_version": "0.10.1",
  "request": {
    "version": 3,
    "operation_id": "40de3461-33c6-41cb-8d7d-e79c8c742ba7",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "expected_revision": 16,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
        "version_id": "c88e9ddc-f616-4ef0-bbf9-6d508a556c63",
        "sha256": "baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "40de3461-33c6-41cb-8d7d-e79c8c742ba7",
      "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
      "process": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
      "related_work": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
      "intent": "accepted_result",
      "source_revision": 16,
      "result": {
        "artifact_id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
        "version_id": "c88e9ddc-f616-4ef0-bbf9-6d508a556c63",
        "sha256": "baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "ed8c8ee0ebce2fc41faeb8a6f39717d4040cd273582a605d0af3c081032a7fb0"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:14.957851Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "3bf613390a464dc53a3cf9f17ac3bb8ab23236e7b2fe8edc4afc713d81256276"
  },
  "fingerprint": "7789e2f86779be102ed51ef7930c400c722642e2f1d1a560be8e9d7b9b9b5266",
  "before": {
    "id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "revision": 16,
    "created_at": "2026-09-10T08:50:14.387458Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "revision": 17,
    "created_at": "2026-09-10T08:50:14.387458Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "0523a4e2-d331-4a74-8ed5-a90064f92218",
  "state_revision": 18,
  "recorded_at": "2026-09-10T08:50:15.107494Z",
  "product_version": "0.10.1",
  "request": {
    "version": 4,
    "operation_id": "b2ddba32-1cca-4e44-bc41-5fa924a0f928",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "expected_revision": 17,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.lot\",\"pack_version\":\"1.0.0\",\"process_type\":\"fictional.lot-release\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
        "version_id": "c88e9ddc-f616-4ef0-bbf9-6d508a556c63",
        "sha256": "baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 17,
      "result": {
        "artifact_id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
        "version_id": "c88e9ddc-f616-4ef0-bbf9-6d508a556c63",
        "sha256": "baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb"
      },
      "acceptance_ids": [
        "9e335244-4839-48e8-84eb-d9fce231b025",
        "40de3461-33c6-41cb-8d7d-e79c8c742ba7"
      ],
      "next_work": {
        "work_id": "845a5f9d-3349-428c-a120-e7dbdb221636",
        "artifact_id": "bbff9de1-a8d1-4e79-91b4-af1d0b290a5a",
        "goal": "Fictional KITE release; cancel unused continuation",
        "expected_result": "No further package work; trusted host explicitly cancels this Work",
        "acceptance": [
          "No further package work; trusted host explicitly cancels this Work"
        ],
        "boundaries": [
          "Fictional local evidence only; no real release or external action"
        ],
        "budget": "One finite fictional lot",
        "executor_requirements": [
          "fictional.lot/v1:closed",
          "release"
        ],
        "artifact_title": "Unused closed continuation (no Result claimed)",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:15.085069Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "026b973b91b6a1b85529a6eda81a77bc020074446ebf7e9de043186cb847c261"
  },
  "fingerprint": "119d4988755c3b3309f08c2b171bcf7e2bf21ad38a1c1c25c1e9b12129b82156",
  "before": {
    "id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "revision": 17,
    "created_at": "2026-09-10T08:50:14.387458Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "revision": 18,
    "created_at": "2026-09-10T08:50:14.387458Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "completion_id": "b2ddba32-1cca-4e44-bc41-5fa924a0f928",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "845a5f9d-3349-428c-a120-e7dbdb221636",
    "revision": 18,
    "created_at": "2026-09-10T08:50:15.107494Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Fictional KITE release; cancel unused continuation",
    "expected_result": "No further package work; trusted host explicitly cancels this Work",
    "acceptance": [
      "No further package work; trusted host explicitly cancels this Work"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:closed",
      "release"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "bbff9de1-a8d1-4e79-91b4-af1d0b290a5a",
    "revision": 1,
    "created_at": "2026-09-10T08:50:15.107494Z",
    "kind": "artifact",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "work_id": "845a5f9d-3349-428c-a120-e7dbdb221636",
    "title": "Unused closed continuation (no Result claimed)",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
    "revision": 3,
    "created_at": "2026-09-10T08:50:14.387458Z",
    "kind": "artifact",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "work_id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "title": "KITE disposition",
    "status": "registered",
    "active_version": "c88e9ddc-f616-4ef0-bbf9-6d508a556c63"
  },
  "result_references": [
    {
      "artifact_id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
      "version_id": "c88e9ddc-f616-4ef0-bbf9-6d508a556c63",
      "sha256": "baa2a2877997bf1a3567eb17c279053873c4b5f35d7656a73089e28a593a10cb"
    },
    {
      "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
      "version_id": "0cb2ed13-8841-452c-8f57-41bb89b427ea",
      "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    },
    {
      "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
      "version_id": "8cf5c4d1-c032-44ce-93f7-67f51de35238",
      "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
    },
    {
      "artifact_id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
      "version_id": "8e387f96-8acd-46c0-9200-36fce9c3044c",
      "sha256": "0a88c782503024ac3e5215ee2753a37916971d318146fa46878cc561314e68c9"
    }
  ]
}
```

```json
{
  "id": "3ff50afd-aa13-4ae4-b6d9-d1f21c5cc97d",
  "state_revision": 19,
  "recorded_at": "2026-09-10T08:50:15.356298Z",
  "product_version": "0.10.1",
  "request": {
    "version": 1,
    "operation_id": "8de07124-e78c-476b-bf84-5bdd93b16671",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "845a5f9d-3349-428c-a120-e7dbdb221636",
    "expected_revision": 18,
    "operation": "cancel_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:15.335425Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "ae548c67662bf7e6ed1117f3fad57e840daebba5e56cda98cc67fecf00e0aba9"
  },
  "fingerprint": "efeb3d0047a90302720ddd0de62374bce2fa40a3dadd1413b5dab2acde848eb1",
  "before": {
    "id": "845a5f9d-3349-428c-a120-e7dbdb221636",
    "revision": 18,
    "created_at": "2026-09-10T08:50:15.107494Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Fictional KITE release; cancel unused continuation",
    "expected_result": "No further package work; trusted host explicitly cancels this Work",
    "acceptance": [
      "No further package work; trusted host explicitly cancels this Work"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:closed",
      "release"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "845a5f9d-3349-428c-a120-e7dbdb221636",
    "revision": 19,
    "created_at": "2026-09-10T08:50:15.107494Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Fictional KITE release; cancel unused continuation",
    "expected_result": "No further package work; trusted host explicitly cancels this Work",
    "acceptance": [
      "No further package work; trusted host explicitly cancels this Work"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "cancelled",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:closed",
      "release"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

