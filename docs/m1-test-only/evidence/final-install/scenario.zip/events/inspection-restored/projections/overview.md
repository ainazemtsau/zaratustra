# Zaratustra — generated overview

generated_from_revision: 11
generated_at: 2026-09-10T08:50:14.469342+00:00
workspace_id: 55065915-2296-4c00-b344-19c8e2b963c3

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
  "revision": 1,
  "created_at": "2026-09-10T08:50:14.469342Z",
  "kind": "artifact",
  "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
  "work_id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
  "title": "KITE disposition",
  "status": "declared",
  "active_version": null
}
```

## artifact

```json
{
  "id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
  "revision": 3,
  "created_at": "2026-09-10T08:50:13.854963Z",
  "kind": "artifact",
  "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
  "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
  "title": "KITE inspection",
  "status": "registered",
  "active_version": "0cb2ed13-8841-452c-8f57-41bb89b427ea"
}
```

## event

```json
{
  "id": "39e82e67-a2e0-4f80-9745-096a6d8ba938",
  "revision": 1,
  "created_at": "2026-09-10T08:50:13.854963Z",
  "kind": "event",
  "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
  "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.10.1",
  "state_revision": 1,
  "affected_ids": [
    "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "a4a00b68-9f93-4042-9f47-2ef3ca290f6f"
  ]
}
```

## process

```json
{
  "id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
  "revision": 4,
  "created_at": "2026-09-10T08:50:13.854963Z",
  "kind": "process",
  "title": "Fictional KITE lot release",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
  "revision": 11,
  "created_at": "2026-09-10T08:50:13.854963Z",
  "kind": "work",
  "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
  "goal": "Inspect casing and label of fictional lot KITE",
  "expected_result": "Exact inspection bytes with both marks for both named checks",
  "acceptance": [
    "Every required check is observed and recorded"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:inspect"
  ],
  "completion_id": "559083bf-338b-43d8-bfab-f312e259985a",
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
  "revision": 11,
  "created_at": "2026-09-10T08:50:14.469342Z",
  "kind": "work",
  "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
  "goal": "Choose release or discard for inspected fictional KITE",
  "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
  "acceptance": [
    "Explicit disposition naming the exact accepted inspection SHA256"
  ],
  "boundaries": [
    "Fictional local evidence only; no real release or external action"
  ],
  "budget": "One finite fictional lot",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "fictional.lot/v1:decide",
    "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
  ],
  "pack_binding": {
    "pack_id": "fictional.lot",
    "pack_version": "1.0.0",
    "process_type": "fictional.lot-release",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 8cf5c4d1-c032-44ce-93f7-67f51de35238; Artifact revision: 2
  SHA-256: 79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f; bytes: 148
  File: artifacts/a4a00b68-9f93-4042-9f47-2ef3ca290f6f/8cf5c4d1-c032-44ce-93f7-67f51de35238.blob

- Version: 0cb2ed13-8841-452c-8f57-41bb89b427ea; Artifact revision: 3
  SHA-256: e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312; bytes: 147
  File: artifacts/a4a00b68-9f93-4042-9f47-2ef3ca290f6f/0cb2ed13-8841-452c-8f57-41bb89b427ea.blob

## Mutation provenance

```json
{
  "id": "de6692f4-0e37-48aa-97e5-d5d6d50bfc9c",
  "state_revision": 2,
  "recorded_at": "2026-09-10T08:50:13.881843Z",
  "product_version": "0.10.1",
  "request": {
    "version": 1,
    "operation_id": "18762781-0e7d-4fce-b9c5-03a80f90ccf7",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:13.868049Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "c48ccaca5b7dc6488be7f446a97bc306378764d818a775b2fb7a2e65fc35e54b"
  },
  "fingerprint": "ec343df98c9df065fb2cefb90bcd1707741973c85d3457d9163c4be94c844a5b",
  "before": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 1,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 2,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "71f809ca-dc93-420d-a6af-bf6567db1e31",
  "state_revision": 3,
  "recorded_at": "2026-09-10T08:50:13.916310Z",
  "product_version": "0.10.1",
  "request": {
    "version": 1,
    "operation_id": "75ce8345-a9a7-467d-9e50-5c5ea8831195",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "fictional.lot/v1:inspect"
    ],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:13.903873Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "d8104b24257c7c117d49953147ba3ba346a8872c1c59931ee942b1d6142fba6f"
  },
  "fingerprint": "1ae055eae7ed0ddfe012be39546f7e5cc2a642a0a4f54800555bb8c18c0fe85e",
  "before": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 2,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 3,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "0bf9d8c6-5fb7-4d6b-a974-e9a62d363a0e",
  "state_revision": 4,
  "recorded_at": "2026-09-10T08:50:13.952931Z",
  "product_version": "0.10.1",
  "request": {
    "version": 5,
    "operation_id": "77cfcb9b-b2c2-4cae-89f8-ea574e2d5aa7",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional lot binding under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:13.940921Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "48a199ddbd1b961f62aa8c8ce6d78ec809f016c9e9e5cd4fe82af5ff8e8a8c85"
  },
  "fingerprint": "993dd9cc9a7d310d44e1dae9d32e79aab3b8bb2b7eb9b001308540095d6c0386",
  "before": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 3,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ]
  },
  "after": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 4,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "revision": 1,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "process",
    "title": "Fictional KITE lot release"
  },
  "process_after": {
    "id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "revision": 4,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "process",
    "title": "Fictional KITE lot release",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "6ad31860-f5db-46c2-a006-38a5701cf976",
  "state_revision": 5,
  "recorded_at": "2026-09-10T08:50:14.012242Z",
  "product_version": "0.10.1",
  "request": {
    "version": 2,
    "operation_id": "98c1d503-6dd8-4829-ab53-f6f4ee22ff50",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:13.999717Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "3d145f90b2234284549473b456e80e40784c8c63055886ed79eb7770f1e43418"
  },
  "fingerprint": "d06e52307748fe3598165e01d93a7ee8b79e4b73be6e8607b1af4078484435e8",
  "before": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 4,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 5,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "ffb72739-6ec6-4e7f-bb26-ec33e0d9c393",
  "state_revision": 6,
  "recorded_at": "2026-09-10T08:50:14.051763Z",
  "product_version": "0.10.1",
  "request": {
    "version": 2,
    "operation_id": "8cf5c4d1-c032-44ce-93f7-67f51de35238",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "artifact_revision": 1,
    "content_sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f",
    "content_size": 148,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:14.038247Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "dcd0412523e007d297cdd34c862095201835afdf569c18c576ee6f6f5a5dea61"
  },
  "fingerprint": "2c0018bd0c2340d8e7e6d0b68d26c1ca8c67dcf62e0b678b3a7dbb195bbe8102",
  "before": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 5,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 6,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "revision": 1,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "artifact",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "title": "KITE inspection",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "revision": 2,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "artifact",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "8cf5c4d1-c032-44ce-93f7-67f51de35238"
  },
  "artifact_version": {
    "id": "8cf5c4d1-c032-44ce-93f7-67f51de35238",
    "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "artifact_revision": 2,
    "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f",
    "size": 148,
    "created_at": "2026-09-10T08:50:14.051763Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "8478d1a9-70d0-476e-98ae-3bf74dfca30b",
  "state_revision": 7,
  "recorded_at": "2026-09-10T08:50:14.101979Z",
  "product_version": "0.10.1",
  "request": {
    "version": 3,
    "operation_id": "942f70cd-718a-400f-b7c6-e65204ff184a",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
        "version_id": "8cf5c4d1-c032-44ce-93f7-67f51de35238",
        "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "942f70cd-718a-400f-b7c6-e65204ff184a",
      "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
      "process": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
      "related_work": "8acf0f77-094c-4848-87cb-748f7628dbfd",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
        "version_id": "8cf5c4d1-c032-44ce-93f7-67f51de35238",
        "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "43a98aaf52764a6a4f621848b03d8441fa03238bfc3a4376269d70bc1d71a635"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:14.086567Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "28db1340be23f39af2459e2ddbf88f6ef6610cd5861ac6c073d624dfa8545ebc"
  },
  "fingerprint": "e674850d547e5e164ea777270a0668c8ab29adfbaf7d4d8b7013f640e90011fe",
  "before": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 6,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 7,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "312d13cb-78ca-4c1c-aa47-596f6779ef57",
  "state_revision": 8,
  "recorded_at": "2026-09-10T08:50:14.169089Z",
  "product_version": "0.10.1",
  "request": {
    "version": 2,
    "operation_id": "17772044-48f5-4f90-a266-00b9c546b775",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "expected_revision": 7,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "artifact_revision": 2,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:14.153206Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "2a77505c4ff5bd0136acba904deb0ee23a01950263979446d68ea4643aa82cb5"
  },
  "fingerprint": "f4b9705391d80bddeb03280bb4560bfff8038fcdce2d0d11905b181f2ece85c3",
  "before": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 7,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 8,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "2e6e9e3e-cb30-4896-ac12-e785f1dd3fd5",
  "state_revision": 9,
  "recorded_at": "2026-09-10T08:50:14.213250Z",
  "product_version": "0.10.1",
  "request": {
    "version": 2,
    "operation_id": "0cb2ed13-8841-452c-8f57-41bb89b427ea",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "expected_revision": 8,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Selected fictional T4 under RUN c-solmax-zaratustra-m1-first-process-20260910-exec",
    "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "artifact_revision": 2,
    "content_sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312",
    "content_size": 147,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:14.198766Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "02dd72c8eb2008070e4d9892474716181e3caaa5f1424a02635333cb85660555"
  },
  "fingerprint": "4c12180ea9f738237b064ec5e24ec2a600d4f3cc13da101bb299cf3b1630b77a",
  "before": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 8,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 9,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "revision": 2,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "artifact",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "8cf5c4d1-c032-44ce-93f7-67f51de35238"
  },
  "artifact_after": {
    "id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "revision": 3,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "artifact",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "0cb2ed13-8841-452c-8f57-41bb89b427ea"
  },
  "artifact_version": {
    "id": "0cb2ed13-8841-452c-8f57-41bb89b427ea",
    "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "artifact_revision": 3,
    "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312",
    "size": 147,
    "created_at": "2026-09-10T08:50:14.213250Z",
    "state_revision": 9
  }
}
```

```json
{
  "id": "7c44c3ec-5a5e-4ce8-a641-2835e4db35ef",
  "state_revision": 10,
  "recorded_at": "2026-09-10T08:50:14.267287Z",
  "product_version": "0.10.1",
  "request": {
    "version": 3,
    "operation_id": "6500e0c9-b9e0-420d-8706-5a5e0d49e72b",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "expected_revision": 9,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation/disposition; no real owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
        "version_id": "0cb2ed13-8841-452c-8f57-41bb89b427ea",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "6500e0c9-b9e0-420d-8706-5a5e0d49e72b",
      "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
      "process": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
      "related_work": "8acf0f77-094c-4848-87cb-748f7628dbfd",
      "intent": "accepted_result",
      "source_revision": 9,
      "result": {
        "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
        "version_id": "0cb2ed13-8841-452c-8f57-41bb89b427ea",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      },
      "basis": [],
      "provenance": "Fictional observation/disposition; no real owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T4 fictional host"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-first-process-20260910-exec",
      "input_sha256": "9b52a0d81875349239cc1e5184f6b833f8fc24589d800fdc4921b3f26931b29f"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:14.250823Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/workspace",
    "request_sha256": "c89a192ee2f96c7c352e48aa3485caa4e5eb93da24bcfed443157ea7d3062578"
  },
  "fingerprint": "b6d497a4683fee5cde48d805c8185fa5a374b3977b12581930cad6a3bd0af66a",
  "before": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 9,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 10,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "e3bfde1c-94d6-4f41-93c6-33fd4c9690b4",
  "state_revision": 11,
  "recorded_at": "2026-09-10T08:50:14.469342Z",
  "product_version": "0.10.1",
  "request": {
    "version": 4,
    "operation_id": "559083bf-338b-43d8-bfab-f312e259985a",
    "workspace_id": "55065915-2296-4c00-b344-19c8e2b963c3",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "expected_revision": 10,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.lot\",\"pack_version\":\"1.0.0\",\"process_type\":\"fictional.lot-release\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
        "version_id": "0cb2ed13-8841-452c-8f57-41bb89b427ea",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 10,
      "result": {
        "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
        "version_id": "0cb2ed13-8841-452c-8f57-41bb89b427ea",
        "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
      },
      "acceptance_ids": [
        "942f70cd-718a-400f-b7c6-e65204ff184a",
        "6500e0c9-b9e0-420d-8706-5a5e0d49e72b"
      ],
      "next_work": {
        "work_id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
        "artifact_id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
        "goal": "Choose release or discard for inspected fictional KITE",
        "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
        "acceptance": [
          "Explicit disposition naming the exact accepted inspection SHA256"
        ],
        "boundaries": [
          "Fictional local evidence only; no real release or external action"
        ],
        "budget": "One finite fictional lot",
        "executor_requirements": [
          "fictional.lot/v1:decide",
          "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
        ],
        "artifact_title": "KITE disposition",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T4-fictional-host",
    "source_ref": "RUN c-solmax-zaratustra-m1-first-process-20260910-exec; selected fictional workspace only; not T4 owner acceptance",
    "confirmed_at": "2026-09-10T08:50:14.464339Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-test-only-processes-20260910/_scratch/install-02/scenario/events/inspection-restored",
    "request_sha256": "5e99fee918d8f2c5cc9f213829489abb60cf42c010956e07993b1af3e94b8e96"
  },
  "fingerprint": "20f97ecbec15710c33dcf3f21e735fe60635ba1aeaf7cc27bb78991b7ad4dd12",
  "before": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 10,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "revision": 11,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Inspect casing and label of fictional lot KITE",
    "expected_result": "Exact inspection bytes with both marks for both named checks",
    "acceptance": [
      "Every required check is observed and recorded"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:inspect"
    ],
    "completion_id": "559083bf-338b-43d8-bfab-f312e259985a",
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "revision": 11,
    "created_at": "2026-09-10T08:50:14.469342Z",
    "kind": "work",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "goal": "Choose release or discard for inspected fictional KITE",
    "expected_result": "Explicit disposition naming the exact accepted inspection SHA256",
    "acceptance": [
      "Explicit disposition naming the exact accepted inspection SHA256"
    ],
    "boundaries": [
      "Fictional local evidence only; no real release or external action"
    ],
    "budget": "One finite fictional lot",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "fictional.lot/v1:decide",
      "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    ],
    "pack_binding": {
      "pack_id": "fictional.lot",
      "pack_version": "1.0.0",
      "process_type": "fictional.lot-release",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "a3bdaeda-2637-4809-bf5f-f7c3f0288e4a",
    "revision": 1,
    "created_at": "2026-09-10T08:50:14.469342Z",
    "kind": "artifact",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "work_id": "d07cf23e-3aca-4f20-aed5-7dfe9974ae66",
    "title": "KITE disposition",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
    "revision": 3,
    "created_at": "2026-09-10T08:50:13.854963Z",
    "kind": "artifact",
    "process_id": "7cf2f8f1-876d-48d0-9bce-1ccac2e65b6d",
    "work_id": "8acf0f77-094c-4848-87cb-748f7628dbfd",
    "title": "KITE inspection",
    "status": "registered",
    "active_version": "0cb2ed13-8841-452c-8f57-41bb89b427ea"
  },
  "result_references": [
    {
      "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
      "version_id": "0cb2ed13-8841-452c-8f57-41bb89b427ea",
      "sha256": "e9713526f4c6a5be58f911d6bba578bcbe4384fad7f077bdc9d843e11c1e0312"
    },
    {
      "artifact_id": "a4a00b68-9f93-4042-9f47-2ef3ca290f6f",
      "version_id": "8cf5c4d1-c032-44ce-93f7-67f51de35238",
      "sha256": "79bc0d143895c68975d7b44a492910b85c6ce66c832ab1959450543a2e48305f"
    }
  ]
}
```

