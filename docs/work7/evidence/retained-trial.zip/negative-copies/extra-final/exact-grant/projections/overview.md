# Zaratustra — generated overview

generated_from_revision: 14
generated_at: 2026-09-08T16:53:42.293509+00:00
workspace_id: 4846e59f-b3f8-4ed1-9bb3-fea22f713b88

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "7f72c737-0ed3-420d-bc82-dfe69996cdb2",
  "revision": 1,
  "created_at": "2026-09-08T16:53:42.293509Z",
  "kind": "artifact",
  "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
  "work_id": "09154bbb-34e0-4917-ad85-74cbaee0824d",
  "title": "Краткое сравнение",
  "status": "declared",
  "active_version": null
}
```

## artifact

```json
{
  "id": "ae7eca56-fd16-41ad-b262-2981468b922e",
  "revision": 5,
  "created_at": "2026-09-08T04:03:30.216247Z",
  "kind": "artifact",
  "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
  "work_id": "56785bef-c147-4236-b12a-cad24845567a",
  "title": "Observation draft",
  "status": "registered",
  "active_version": "cf7cabdd-cfc0-42e1-8e20-feb6d3cdd261"
}
```

## event

```json
{
  "id": "b0257ea3-6179-4ac2-95a2-de033bf98078",
  "revision": 1,
  "created_at": "2026-09-08T04:03:30.216247Z",
  "kind": "event",
  "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
  "work_id": "56785bef-c147-4236-b12a-cad24845567a",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.2.0",
  "state_revision": 1,
  "affected_ids": [
    "bae978a9-a181-4368-be55-b1837fd47747",
    "56785bef-c147-4236-b12a-cad24845567a",
    "ae7eca56-fd16-41ad-b262-2981468b922e"
  ]
}
```

## process

```json
{
  "id": "bae978a9-a181-4368-be55-b1837fd47747",
  "revision": 1,
  "created_at": "2026-09-08T04:03:30.216247Z",
  "kind": "process",
  "title": "Fictional observatory"
}
```

## work

```json
{
  "id": "09154bbb-34e0-4917-ad85-74cbaee0824d",
  "revision": 14,
  "created_at": "2026-09-08T16:53:42.293509Z",
  "kind": "work",
  "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
  "goal": "Сравнить два сохранённых описания вымышленной луны",
  "expected_result": "Краткое сравнение",
  "acceptance": [
    "Указать, что серебряный край виден на закате, и сослаться на обе сохранённые версии"
  ],
  "boundaries": [
    "Только Fictional observatory, без внешних действий"
  ],
  "budget": "One short local session",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": []
}
```

## work

```json
{
  "id": "56785bef-c147-4236-b12a-cad24845567a",
  "revision": 14,
  "created_at": "2026-09-08T04:03:30.216247Z",
  "kind": "work",
  "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
  "goal": "Describe an imaginary moon",
  "expected_result": "A short fictional observation",
  "acceptance": [
    "The observation is saved"
  ],
  "boundaries": [
    "Fictional data only"
  ],
  "budget": "One short local session",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "reasoning",
    "coding"
  ],
  "completion_id": "9179d4f8-d868-49c0-8ec8-3df7078bffc8"
}
```

## Registered versions

- Version: 258ea271-3f06-4c29-9caa-09cf2613d2d4; Artifact revision: 2
  SHA-256: de22a67833d4525f95d460d75890f8a046a08d51e19bd086e380df104afd1214; bytes: 59
  File: artifacts/ae7eca56-fd16-41ad-b262-2981468b922e/258ea271-3f06-4c29-9caa-09cf2613d2d4.blob

- Version: 75a8c7b3-3f17-4a50-a777-c70f3515bfd8; Artifact revision: 3
  SHA-256: 6fd73651c03ddf966703c5b96f6b7a7da79a6d3482b82342f191dd4ea9299b45; bytes: 68
  File: artifacts/ae7eca56-fd16-41ad-b262-2981468b922e/75a8c7b3-3f17-4a50-a777-c70f3515bfd8.blob

- Version: b1e86f3a-095b-44f0-ad18-b19d84830607; Artifact revision: 4
  SHA-256: 6fd73651c03ddf966703c5b96f6b7a7da79a6d3482b82342f191dd4ea9299b45; bytes: 68
  File: artifacts/ae7eca56-fd16-41ad-b262-2981468b922e/b1e86f3a-095b-44f0-ad18-b19d84830607.blob

- Version: cf7cabdd-cfc0-42e1-8e20-feb6d3cdd261; Artifact revision: 5
  SHA-256: 6fd73651c03ddf966703c5b96f6b7a7da79a6d3482b82342f191dd4ea9299b45; bytes: 68
  File: artifacts/ae7eca56-fd16-41ad-b262-2981468b922e/cf7cabdd-cfc0-42e1-8e20-feb6d3cdd261.blob

## Mutation provenance

```json
{
  "id": "58fa841d-fc00-4fe7-9e74-17889480acc0",
  "state_revision": 2,
  "recorded_at": "2026-09-08T05:40:13.179497Z",
  "product_version": "0.3.0",
  "request": {
    "version": 1,
    "operation_id": "bcc646b2-4f74-4838-852f-43202acd5264",
    "workspace_id": "4846e59f-b3f8-4ed1-9bb3-fea22f713b88",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional Work 3 executor trial under the development CALL"
  },
  "confirmation": {
    "channel": "local-console",
    "actor": "local-console-operator",
    "source_ref": "console-confirmation:1ad2d6ce-3497-4b78-9660-8199847e9e00",
    "confirmed_at": "2026-09-08T05:40:13.176376Z",
    "workspace_path": "C:/Users/Anton/AppData/Local/Temp/zaratustra-work3-gnt5ksg0/workspace",
    "request_sha256": "3c9e924d8f162977e00cd9cb54c5ee77ee0b3778022fd6213ef677b622b696ba"
  },
  "fingerprint": "4c67f57bb3309cea3ae0e162a9692539723bd4df70c2a6490ef9b153c6c28577",
  "before": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 1,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 2,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "4f345190-bf96-43b1-b749-26514d15c27c",
  "state_revision": 3,
  "recorded_at": "2026-09-08T05:40:45.906973Z",
  "product_version": "0.3.0",
  "request": {
    "version": 1,
    "operation_id": "86020eab-07db-4744-b4bb-b7af933df9b0",
    "workspace_id": "4846e59f-b3f8-4ed1-9bb3-fea22f713b88",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "reasoning",
      "coding"
    ],
    "artifact_references": [],
    "provenance": "Fictional Work 3 executor trial under the development CALL"
  },
  "confirmation": {
    "channel": "local-console",
    "actor": "local-console-operator",
    "source_ref": "console-confirmation:99b14551-f563-4af8-bbef-dbf6a1944aff",
    "confirmed_at": "2026-09-08T05:40:45.904180Z",
    "workspace_path": "C:/Users/Anton/AppData/Local/Temp/zaratustra-work3-gnt5ksg0/workspace",
    "request_sha256": "c1a1f13cd646acd5efe981cd5919383f66ba51da7e6960b5171997cb128b3f08"
  },
  "fingerprint": "827e6b1556a41d5827c375ee1c099bd1c4739a3ce3b16bdf00a6928857bb6dc7",
  "before": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 2,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 3,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "affected_projections": [],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "cf4a8317-b1a6-4071-8760-2a83128aa83e",
  "state_revision": 4,
  "recorded_at": "2026-09-08T05:40:49.245767Z",
  "product_version": "0.3.0",
  "request": {
    "version": 1,
    "operation_id": "377b862e-6889-462f-a1e4-c7120a1ce574",
    "workspace_id": "4846e59f-b3f8-4ed1-9bb3-fea22f713b88",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "expected_revision": 3,
    "operation": "revoke_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional Work 3 executor trial under the development CALL"
  },
  "confirmation": {
    "channel": "local-console",
    "actor": "local-console-operator",
    "source_ref": "console-confirmation:4ebe086c-9d8f-4265-ba63-7135ffb3eb9b",
    "confirmed_at": "2026-09-08T05:40:49.241412Z",
    "workspace_path": "C:/Users/Anton/AppData/Local/Temp/zaratustra-work3-gnt5ksg0/workspace",
    "request_sha256": "3592296e9b496d95aec4efc19a9aa23f3f4da195c45695090dfadffc6491a109"
  },
  "fingerprint": "77faf730b2af7d71c16435a2cf9fe492761b3098291c5d8c183dc68d6e49a3c0",
  "before": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 3,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "after": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 4,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "affected_projections": [],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "e64623ab-dd89-49ee-a6e2-687f59ae8985",
  "state_revision": 5,
  "recorded_at": "2026-09-08T07:36:56.758518Z",
  "product_version": "0.4.0",
  "request": {
    "version": 2,
    "operation_id": "d046b21b-e0ad-45f1-81a3-182228e55542",
    "workspace_id": "4846e59f-b3f8-4ed1-9bb3-fea22f713b88",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "expected_revision": 4,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional installed Work 4 trial under the development CALL",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-console",
    "actor": "local-console-operator",
    "source_ref": "console-confirmation:6a07d224-dbcc-4be4-a3f6-461e26d262b2",
    "confirmed_at": "2026-09-08T07:36:56.755369Z",
    "workspace_path": "C:/Users/Anton/AppData/Local/Temp/zaratustra-work4-viai92mt/workspace",
    "request_sha256": "575759c612b0f132f78b7f82a4f90473a5d8132aadcdd17fb442f4f9019795ab"
  },
  "fingerprint": "d5e49afeb4fe9f3240c57a2da707a9361c78bbcb89963d78f89cd4130d47945b",
  "before": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 4,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "after": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 5,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "d830012f-9c6d-491b-aff4-947d1efabbf8",
  "state_revision": 6,
  "recorded_at": "2026-09-08T07:37:05.164345Z",
  "product_version": "0.4.0",
  "request": {
    "version": 2,
    "operation_id": "ced01bc2-04df-4b90-b3e5-b868438fb7dd",
    "workspace_id": "4846e59f-b3f8-4ed1-9bb3-fea22f713b88",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "expected_revision": 5,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional installed Work 4 trial under the development CALL",
    "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-console",
    "actor": "local-console-operator",
    "source_ref": "console-confirmation:2b5497a7-a85c-41e3-8c72-a4d5d55b0acb",
    "confirmed_at": "2026-09-08T07:37:05.160323Z",
    "workspace_path": "C:/Users/Anton/AppData/Local/Temp/zaratustra-work4-viai92mt/workspace",
    "request_sha256": "901fce02349d7f692d893581ec1737d22a9a433c8667ac91f3d24892855f1272"
  },
  "fingerprint": "1a10f525ada4b545524c0b9fc5c75a285ae75d6d38295b76189d1a6255d8d717",
  "before": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 5,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "after": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 6,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "ab042f0e-7aa9-45c2-b7d1-e0b5fceb8493",
  "state_revision": 7,
  "recorded_at": "2026-09-08T07:37:13.726233Z",
  "product_version": "0.4.0",
  "request": {
    "version": 2,
    "operation_id": "258ea271-3f06-4c29-9caa-09cf2613d2d4",
    "workspace_id": "4846e59f-b3f8-4ed1-9bb3-fea22f713b88",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "expected_revision": 6,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional installed Work 4 trial under the development CALL",
    "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
    "artifact_revision": 1,
    "content_sha256": "de22a67833d4525f95d460d75890f8a046a08d51e19bd086e380df104afd1214",
    "content_size": 59,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-console",
    "actor": "local-console-operator",
    "source_ref": "console-confirmation:b554fb20-e50c-4ff0-ae50-b44e972769e0",
    "confirmed_at": "2026-09-08T07:37:13.718097Z",
    "workspace_path": "C:/Users/Anton/AppData/Local/Temp/zaratustra-work4-viai92mt/workspace",
    "request_sha256": "8b51fa7fee4fcb0cab10b4372a22f0b74ee6074d02f5b814a7117fc588053561"
  },
  "fingerprint": "3e2b9a11473d0602de4c459d374a5bc62dfd6d420b91093f9b29209839db5ad7",
  "before": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 6,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "after": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 7,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "ae7eca56-fd16-41ad-b262-2981468b922e",
    "revision": 1,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "artifact",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "title": "Observation draft",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "ae7eca56-fd16-41ad-b262-2981468b922e",
    "revision": 2,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "artifact",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "title": "Observation draft",
    "status": "registered",
    "active_version": "258ea271-3f06-4c29-9caa-09cf2613d2d4"
  },
  "artifact_version": {
    "id": "258ea271-3f06-4c29-9caa-09cf2613d2d4",
    "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "artifact_revision": 2,
    "sha256": "de22a67833d4525f95d460d75890f8a046a08d51e19bd086e380df104afd1214",
    "size": 59,
    "created_at": "2026-09-08T07:37:13.726233Z",
    "state_revision": 7
  }
}
```

```json
{
  "id": "5519b7cc-95ae-4246-9ecf-3187dbf5969f",
  "state_revision": 8,
  "recorded_at": "2026-09-08T07:37:23.595872Z",
  "product_version": "0.4.0",
  "request": {
    "version": 2,
    "operation_id": "75a8c7b3-3f17-4a50-a777-c70f3515bfd8",
    "workspace_id": "4846e59f-b3f8-4ed1-9bb3-fea22f713b88",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "expected_revision": 7,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional installed Work 4 trial under the development CALL",
    "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
    "artifact_revision": 2,
    "content_sha256": "6fd73651c03ddf966703c5b96f6b7a7da79a6d3482b82342f191dd4ea9299b45",
    "content_size": 68,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-console",
    "actor": "local-console-operator",
    "source_ref": "console-confirmation:385cb4d1-0c88-4218-a2df-6989cca626da",
    "confirmed_at": "2026-09-08T07:37:23.586571Z",
    "workspace_path": "C:/Users/Anton/AppData/Local/Temp/zaratustra-work4-viai92mt/workspace",
    "request_sha256": "998404f717c7498ed6ba41eafd3cfa71fb25d8f78804e53f4a721f00b6b2c66f"
  },
  "fingerprint": "3e707a737ccd1d5dfa44670dfa2f97239bb6d636838d17180aad105422994369",
  "before": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 7,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "after": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 8,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "ae7eca56-fd16-41ad-b262-2981468b922e",
    "revision": 2,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "artifact",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "title": "Observation draft",
    "status": "registered",
    "active_version": "258ea271-3f06-4c29-9caa-09cf2613d2d4"
  },
  "artifact_after": {
    "id": "ae7eca56-fd16-41ad-b262-2981468b922e",
    "revision": 3,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "artifact",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "title": "Observation draft",
    "status": "registered",
    "active_version": "75a8c7b3-3f17-4a50-a777-c70f3515bfd8"
  },
  "artifact_version": {
    "id": "75a8c7b3-3f17-4a50-a777-c70f3515bfd8",
    "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "artifact_revision": 3,
    "sha256": "6fd73651c03ddf966703c5b96f6b7a7da79a6d3482b82342f191dd4ea9299b45",
    "size": 68,
    "created_at": "2026-09-08T07:37:23.595872Z",
    "state_revision": 8
  }
}
```

```json
{
  "id": "a488c867-6880-4479-8b94-71af64943b0c",
  "state_revision": 9,
  "recorded_at": "2026-09-08T07:37:48.631916Z",
  "product_version": "0.4.0",
  "request": {
    "version": 2,
    "operation_id": "b4e35da8-b5e5-4bfc-9b2b-b9a1891b482a",
    "workspace_id": "4846e59f-b3f8-4ed1-9bb3-fea22f713b88",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "expected_revision": 8,
    "operation": "restore_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional installed Work 4 trial under the development CALL",
    "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
    "artifact_revision": 3,
    "content_sha256": "6fd73651c03ddf966703c5b96f6b7a7da79a6d3482b82342f191dd4ea9299b45",
    "content_size": 68,
    "restore_version": "75a8c7b3-3f17-4a50-a777-c70f3515bfd8",
    "references": []
  },
  "confirmation": {
    "channel": "local-console",
    "actor": "local-console-operator",
    "source_ref": "console-confirmation:08bc6832-2e1e-4339-bcbb-be3c221fb3e3",
    "confirmed_at": "2026-09-08T07:37:48.627873Z",
    "workspace_path": "C:/Users/Anton/AppData/Local/Temp/zaratustra-work4-viai92mt/workspace",
    "request_sha256": "bb9e6f656869ea18e5e4973f201ce5963bd5c806b29202d69d0e9cee3284ea33"
  },
  "fingerprint": "6e631b9537a6cdac6ef268d3e0edadbc9a59c0bd2f617c5ca5fbfe92bf1d6dad",
  "before": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 8,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "after": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 9,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "72885554-1023-4b45-9b1a-332273dd45ba",
  "state_revision": 10,
  "recorded_at": "2026-09-08T09:21:38.773140Z",
  "product_version": "0.5.0",
  "request": {
    "version": 3,
    "operation_id": "d0032728-4bb3-41b7-b8ee-b3996c872dc8",
    "workspace_id": "4846e59f-b3f8-4ed1-9bb3-fea22f713b88",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "expected_revision": 9,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation accepted because the silver rim is visible.",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
        "version_id": "75a8c7b3-3f17-4a50-a777-c70f3515bfd8",
        "sha256": "6fd73651c03ddf966703c5b96f6b7a7da79a6d3482b82342f191dd4ea9299b45"
      },
      {
        "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
        "version_id": "258ea271-3f06-4c29-9caa-09cf2613d2d4",
        "sha256": "de22a67833d4525f95d460d75890f8a046a08d51e19bd086e380df104afd1214"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "d0032728-4bb3-41b7-b8ee-b3996c872dc8",
      "workspace_id": "4846e59f-b3f8-4ed1-9bb3-fea22f713b88",
      "process": "bae978a9-a181-4368-be55-b1837fd47747",
      "related_work": "56785bef-c147-4236-b12a-cad24845567a",
      "intent": "accepted_result",
      "source_revision": 9,
      "result": {
        "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
        "version_id": "75a8c7b3-3f17-4a50-a777-c70f3515bfd8",
        "sha256": "6fd73651c03ddf966703c5b96f6b7a7da79a6d3482b82342f191dd4ea9299b45"
      },
      "basis": [
        {
          "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
          "version_id": "258ea271-3f06-4c29-9caa-09cf2613d2d4",
          "sha256": "de22a67833d4525f95d460d75890f8a046a08d51e19bd086e380df104afd1214"
        }
      ],
      "provenance": "Fictional observation accepted because the silver rim is visible.",
      "owner_instruction": "  Fictional quoted decision: retain this observation.  ",
      "constraints": [
        "Only the fictional observatory"
      ],
      "open_questions": [
        "Continuation belongs to a later admitted Work"
      ],
      "created_by": "executor-fictional-file"
    },
    "delivery": {
      "source_ref": "C:/Users/Anton/AppData/Local/Temp/zaratustra-work5-96nw94ii/handoff-file.json",
      "input_sha256": "64ea7acfd4bdc41d93599b3450f9f75b33034fde71cbec726995b55b1f2a58e3"
    }
  },
  "confirmation": {
    "channel": "local-console",
    "actor": "local-console-operator",
    "source_ref": "console-confirmation:46ba43ff-ae00-440f-b185-6f0f4571a54b",
    "confirmed_at": "2026-09-08T09:21:38.764716Z",
    "workspace_path": "C:/Users/Anton/AppData/Local/Temp/zaratustra-work5-96nw94ii/workspace",
    "request_sha256": "2634d4af15e277153c25562d19e745031153c37c9a5f29721e85162e1e80daeb"
  },
  "fingerprint": "7a7ae19c94a485eed09e71d3ab23b9b8e660fb665a752bc0681be7cf67372aea",
  "before": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 9,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "after": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 10,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "22ece12d-198b-4730-88c0-1c7f8c18ac8f",
  "state_revision": 11,
  "recorded_at": "2026-09-08T09:21:50.602174Z",
  "product_version": "0.5.0",
  "request": {
    "version": 3,
    "operation_id": "9530e3d4-0ccb-4a93-845f-bfcd724dd771",
    "workspace_id": "4846e59f-b3f8-4ed1-9bb3-fea22f713b88",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "expected_revision": 10,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional observation accepted because the silver rim is visible.",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
        "version_id": "75a8c7b3-3f17-4a50-a777-c70f3515bfd8",
        "sha256": "6fd73651c03ddf966703c5b96f6b7a7da79a6d3482b82342f191dd4ea9299b45"
      },
      {
        "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
        "version_id": "258ea271-3f06-4c29-9caa-09cf2613d2d4",
        "sha256": "de22a67833d4525f95d460d75890f8a046a08d51e19bd086e380df104afd1214"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "9530e3d4-0ccb-4a93-845f-bfcd724dd771",
      "workspace_id": "4846e59f-b3f8-4ed1-9bb3-fea22f713b88",
      "process": "bae978a9-a181-4368-be55-b1837fd47747",
      "related_work": "56785bef-c147-4236-b12a-cad24845567a",
      "intent": "accepted_result",
      "source_revision": 10,
      "result": {
        "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
        "version_id": "75a8c7b3-3f17-4a50-a777-c70f3515bfd8",
        "sha256": "6fd73651c03ddf966703c5b96f6b7a7da79a6d3482b82342f191dd4ea9299b45"
      },
      "basis": [
        {
          "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
          "version_id": "258ea271-3f06-4c29-9caa-09cf2613d2d4",
          "sha256": "de22a67833d4525f95d460d75890f8a046a08d51e19bd086e380df104afd1214"
        }
      ],
      "provenance": "Fictional observation accepted because the silver rim is visible.",
      "owner_instruction": "  Fictional quoted decision: retain this observation.  ",
      "constraints": [
        "Only the fictional observatory"
      ],
      "open_questions": [
        "Continuation belongs to a later admitted Work"
      ],
      "created_by": "executor-fictional-stdin"
    },
    "delivery": {
      "source_ref": "stdin",
      "input_sha256": "376a8514fc9ad46687f163dc9b1c96622e40476bde137b5c9ef460d59451eb00"
    }
  },
  "confirmation": {
    "channel": "local-console",
    "actor": "local-console-operator",
    "source_ref": "console-confirmation:6de229a3-ab83-4aa4-bb2f-ad47e7de0ded",
    "confirmed_at": "2026-09-08T09:21:50.596000Z",
    "workspace_path": "C:/Users/Anton/AppData/Local/Temp/zaratustra-work5-96nw94ii/workspace",
    "request_sha256": "d3dd497a5e58dbf7481e4e47c92cf3ea2443688bfbeb67d9ba9a76448daf28a7"
  },
  "fingerprint": "8baf57ef5f0a2ee23e630a168cadd11ad600416486f6d0becab2070fd7a73e50",
  "before": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 10,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "after": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 11,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "37b1d3f4-042c-4806-832f-59874cec7fd9",
  "state_revision": 12,
  "recorded_at": "2026-09-08T16:53:42.212016Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "b1e86f3a-095b-44f0-ad18-b19d84830607",
    "workspace_id": "4846e59f-b3f8-4ed1-9bb3-fea22f713b88",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "expected_revision": 11,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Same accepted fictional bytes; scope diagnostic",
    "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
    "artifact_revision": 3,
    "content_sha256": "6fd73651c03ddf966703c5b96f6b7a7da79a6d3482b82342f191dd4ea9299b45",
    "content_size": 68,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "executor-fictional-adapter",
    "source_ref": "Work7:simulated-prior-permission",
    "confirmed_at": "2026-09-08T16:53:42.208811Z",
    "workspace_path": "C:/Users/Anton/AppData/Local/Temp/zaratustra-work7-m8i5i307/negative-copies/extra-final/exact-grant",
    "request_sha256": "5a5343dfb3daf6bcc06d308129b915e53d7d836997e28c6b7e9d129b38fa9721"
  },
  "fingerprint": "feefc4b50f09a20f915e9820181de2f79670da519786df260147ea0f33308a4b",
  "before": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 11,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "after": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 12,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "ae7eca56-fd16-41ad-b262-2981468b922e",
    "revision": 3,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "artifact",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "title": "Observation draft",
    "status": "registered",
    "active_version": "75a8c7b3-3f17-4a50-a777-c70f3515bfd8"
  },
  "artifact_after": {
    "id": "ae7eca56-fd16-41ad-b262-2981468b922e",
    "revision": 4,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "artifact",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "title": "Observation draft",
    "status": "registered",
    "active_version": "b1e86f3a-095b-44f0-ad18-b19d84830607"
  },
  "artifact_version": {
    "id": "b1e86f3a-095b-44f0-ad18-b19d84830607",
    "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "artifact_revision": 4,
    "sha256": "6fd73651c03ddf966703c5b96f6b7a7da79a6d3482b82342f191dd4ea9299b45",
    "size": 68,
    "created_at": "2026-09-08T16:53:42.212016Z",
    "state_revision": 12
  }
}
```

```json
{
  "id": "733ebf90-abc9-44ed-b618-eb8a01c39abc",
  "state_revision": 13,
  "recorded_at": "2026-09-08T16:53:42.250312Z",
  "product_version": "0.7.0",
  "request": {
    "version": 2,
    "operation_id": "cf7cabdd-cfc0-42e1-8e20-feb6d3cdd261",
    "workspace_id": "4846e59f-b3f8-4ed1-9bb3-fea22f713b88",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "expected_revision": 12,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Same accepted fictional bytes; scope diagnostic",
    "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
    "artifact_revision": 4,
    "content_sha256": "6fd73651c03ddf966703c5b96f6b7a7da79a6d3482b82342f191dd4ea9299b45",
    "content_size": 68,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "executor-fictional-adapter",
    "source_ref": "Work7:simulated-prior-permission",
    "confirmed_at": "2026-09-08T16:53:42.247224Z",
    "workspace_path": "C:/Users/Anton/AppData/Local/Temp/zaratustra-work7-m8i5i307/negative-copies/extra-final/exact-grant",
    "request_sha256": "554b3b4ff46da98e8b406041d8e98f6aef7da892d8100bd163f6facbe9609be5"
  },
  "fingerprint": "eefddb5621cd23ccfc8eae89a67c010c0aed57debcbe9bbb5bade691a1a5c1a7",
  "before": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 12,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "after": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 13,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "ae7eca56-fd16-41ad-b262-2981468b922e",
    "revision": 4,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "artifact",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "title": "Observation draft",
    "status": "registered",
    "active_version": "b1e86f3a-095b-44f0-ad18-b19d84830607"
  },
  "artifact_after": {
    "id": "ae7eca56-fd16-41ad-b262-2981468b922e",
    "revision": 5,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "artifact",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "title": "Observation draft",
    "status": "registered",
    "active_version": "cf7cabdd-cfc0-42e1-8e20-feb6d3cdd261"
  },
  "artifact_version": {
    "id": "cf7cabdd-cfc0-42e1-8e20-feb6d3cdd261",
    "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "artifact_revision": 5,
    "sha256": "6fd73651c03ddf966703c5b96f6b7a7da79a6d3482b82342f191dd4ea9299b45",
    "size": 68,
    "created_at": "2026-09-08T16:53:42.250312Z",
    "state_revision": 13
  }
}
```

```json
{
  "id": "60f805fa-f51e-4ca0-88fd-70d767531160",
  "state_revision": 14,
  "recorded_at": "2026-09-08T16:53:42.293509Z",
  "product_version": "0.7.0",
  "request": {
    "version": 4,
    "operation_id": "9179d4f8-d868-49c0-8ec8-3df7078bffc8",
    "workspace_id": "4846e59f-b3f8-4ed1-9bb3-fea22f713b88",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "expected_revision": 13,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Work7 fictional trial; exact fixture confirmed by owner",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
        "version_id": "75a8c7b3-3f17-4a50-a777-c70f3515bfd8",
        "sha256": "6fd73651c03ddf966703c5b96f6b7a7da79a6d3482b82342f191dd4ea9299b45"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 13,
      "result": {
        "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
        "version_id": "75a8c7b3-3f17-4a50-a777-c70f3515bfd8",
        "sha256": "6fd73651c03ddf966703c5b96f6b7a7da79a6d3482b82342f191dd4ea9299b45"
      },
      "acceptance_ids": [
        "d0032728-4bb3-41b7-b8ee-b3996c872dc8",
        "9530e3d4-0ccb-4a93-845f-bfcd724dd771"
      ],
      "next_work": {
        "work_id": "09154bbb-34e0-4917-ad85-74cbaee0824d",
        "artifact_id": "7f72c737-0ed3-420d-bc82-dfe69996cdb2",
        "goal": "Сравнить два сохранённых описания вымышленной луны",
        "expected_result": "Краткое сравнение",
        "acceptance": [
          "Указать, что серебряный край виден на закате, и сослаться на обе сохранённые версии"
        ],
        "boundaries": [
          "Только Fictional observatory, без внешних действий"
        ],
        "budget": "One short local session",
        "executor_requirements": [],
        "artifact_title": "Краткое сравнение",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "executor-fictional-adapter",
    "source_ref": "Work7:simulated-prior-permission",
    "confirmed_at": "2026-09-08T16:53:42.286983Z",
    "workspace_path": "C:/Users/Anton/AppData/Local/Temp/zaratustra-work7-m8i5i307/negative-copies/extra-final/exact-grant",
    "request_sha256": "6da9399724d74048d36668070b071d29720914ce18b7968f1fa272cd1f712926"
  },
  "fingerprint": "45edd7aa1898dd1e2f41342ea37f94ec03446276a2a8543bc64dac91c58c7bd0",
  "before": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 13,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ]
  },
  "after": {
    "id": "56785bef-c147-4236-b12a-cad24845567a",
    "revision": 14,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Describe an imaginary moon",
    "expected_result": "A short fictional observation",
    "acceptance": [
      "The observation is saved"
    ],
    "boundaries": [
      "Fictional data only"
    ],
    "budget": "One short local session",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "reasoning",
      "coding"
    ],
    "completion_id": "9179d4f8-d868-49c0-8ec8-3df7078bffc8"
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "09154bbb-34e0-4917-ad85-74cbaee0824d",
    "revision": 14,
    "created_at": "2026-09-08T16:53:42.293509Z",
    "kind": "work",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "goal": "Сравнить два сохранённых описания вымышленной луны",
    "expected_result": "Краткое сравнение",
    "acceptance": [
      "Указать, что серебряный край виден на закате, и сослаться на обе сохранённые версии"
    ],
    "boundaries": [
      "Только Fictional observatory, без внешних действий"
    ],
    "budget": "One short local session",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "next_artifact": {
    "id": "7f72c737-0ed3-420d-bc82-dfe69996cdb2",
    "revision": 1,
    "created_at": "2026-09-08T16:53:42.293509Z",
    "kind": "artifact",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "work_id": "09154bbb-34e0-4917-ad85-74cbaee0824d",
    "title": "Краткое сравнение",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "ae7eca56-fd16-41ad-b262-2981468b922e",
    "revision": 5,
    "created_at": "2026-09-08T04:03:30.216247Z",
    "kind": "artifact",
    "process_id": "bae978a9-a181-4368-be55-b1837fd47747",
    "work_id": "56785bef-c147-4236-b12a-cad24845567a",
    "title": "Observation draft",
    "status": "registered",
    "active_version": "cf7cabdd-cfc0-42e1-8e20-feb6d3cdd261"
  },
  "result_references": [
    {
      "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
      "version_id": "75a8c7b3-3f17-4a50-a777-c70f3515bfd8",
      "sha256": "6fd73651c03ddf966703c5b96f6b7a7da79a6d3482b82342f191dd4ea9299b45"
    },
    {
      "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
      "version_id": "258ea271-3f06-4c29-9caa-09cf2613d2d4",
      "sha256": "de22a67833d4525f95d460d75890f8a046a08d51e19bd086e380df104afd1214"
    },
    {
      "artifact_id": "ae7eca56-fd16-41ad-b262-2981468b922e",
      "version_id": "cf7cabdd-cfc0-42e1-8e20-feb6d3cdd261",
      "sha256": "6fd73651c03ddf966703c5b96f6b7a7da79a6d3482b82342f191dd4ea9299b45"
    }
  ]
}
```

