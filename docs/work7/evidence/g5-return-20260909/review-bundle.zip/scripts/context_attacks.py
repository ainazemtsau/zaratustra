"""Installed byte/grant/final-snapshot attacks on retained fictional copies."""
from pathlib import Path
import importlib.util
import base64
import json
import sqlite3
import uuid
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('g5_runtime', Path(__file__).with_name('runtime.py'))
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
c = r.c
RESULTS = {}

def case(name, fn, after=True):
    RESULTS[name] = r.case(name, fn, after)

def artifact(path, work_id=None):
    return next(a for a in c.read_records(path).records if isinstance(a, c.Artifact)
                and a.work_id == (work_id or r.read_request().work_id))

def publish_request(path, content, work_id=None, refs=()):
    a = artifact(path, work_id)
    return r.simple(path, 'publish_artifact', work_id, version=2, artifact_id=a.id,
        artifact_revision=a.revision, content_sha256=r.sha(content), content_size=len(content), references=refs)

def original_content(path):
    ref = r.read_request().submission.result
    return c.read_artifact(path, ref.artifact_id, ref.version_id)

def repair_request(path, content):
    a = artifact(path)
    return r.simple(path, 'restore_artifact', version=2, artifact_id=a.id, artifact_revision=a.revision,
        content_sha256=content.version.sha256, content_size=content.version.size, restore_version=content.version.id)

def late_bytes(path, flavor):
    q = r.query(path)
    saved = r.discover(path)
    all_refs = saved.event.result_references
    ref = all_refs[1] if flavor.endswith('basis') else all_refs[0]
    content = c.read_artifact(path, ref.artifact_id, ref.version_id)
    target = path / content.version.relative_path
    existing_quarantine = set(target.parent.glob('quarantine-*.blob'))
    before = r.dbhash(path)
    if flavor.startswith('missing'):
        target.unlink()
    else:
        target.write_bytes(bytes([content.content[0] ^ 1]) + content.content[1:])
    r.refused(flavor, lambda: r.open_at(path, q), 'content_unavailable' if flavor.startswith('missing') else 'content_changed')
    assert r.discover(path) == saved and r.dbhash(path) == before
    r.log('metadata-remains-historical', unchanged_result=True, db_unchanged=True)
    req = repair_request(path, content)
    r.refused('wrong-repair-bytes', lambda: r.apply(path, req, b'incorrect'), 'content_changed')
    r.apply(path, req, content.content)
    assert r.discover(path) == saved
    assert r.source(path).status == 'done'
    assert artifact(path).active_version == r.read_request().submission.result.version_id
    r.refused('repair-invalidates-old-query', lambda: r.open_at(path, q), 'conflict')
    r.open_at(path)
    if not flavor.startswith('missing'):
        quarantined = list(set(target.parent.glob('quarantine-*.blob')) - existing_quarantine)
        assert len(quarantined) == 1
        assert quarantined[0].read_bytes() == bytes([content.content[0] ^ 1]) + content.content[1:]
        r.log('exact-quarantine', name=quarantined[0].name, sha256=r.sha(quarantined[0].read_bytes()))

def before_result_bytes(path, flavor):
    request = r.make_request(path)
    refs = [request.submission.result]
    refs.extend(h.handoff.result for h in c.read_handoffs(path))
    refs.extend(ref for h in c.read_handoffs(path) for ref in h.handoff.basis)
    ref = next(v for v in refs if v.version_id != request.submission.result.version_id) if flavor.endswith('basis') else refs[0]
    content = c.read_artifact(path, ref.artifact_id, ref.version_id)
    target = path / content.version.relative_path
    before = r.dbhash(path)
    if flavor.startswith('missing'):
        target.unlink()
    else:
        target.write_bytes(bytes([content.content[0] ^ 1]) + content.content[1:])
    r.refused(flavor, lambda: r.submit(path, request), 'content_unavailable' if flavor.startswith('missing') else 'content_changed')
    assert r.dbhash(path) == before
    r.effect(path, 0)

def final_bytes(path, corrupt=False):
    q = r.query(path)
    content = original_content(path)
    permission = r.auth(path, q)
    before = r.dbhash(path)
    original = r.ctx._compile
    def interleave(collected, query):
        result = original(collected, query)
        target = path / content.version.relative_path
        if corrupt:
            target.write_bytes(bytes([content.content[0] ^ 1]) + content.content[1:])
        else:
            target.unlink()
        r.log('between-collection-and-final', injection='corrupt bytes' if corrupt else 'remove bytes')
        return result
    with patch.object(r.ctx, '_compile', interleave):
        r.refused('full-final-bytes', lambda: c.open_work(path, q, permission),
                  'content_changed' if corrupt else 'content_unavailable')
    assert r.dbhash(path) == before

def final_managed(path, operation):
    q = r.query(path)
    permission = r.auth(path, q)
    original = r.ctx._compile
    def interleave(collected, query):
        out = original(collected, query)
        target = r.read_request().work_id if operation == 'source-revoke' else q.work_id
        op = 'revoke_work' if operation == 'source-revoke' else operation
        fields = {'requirements': ('G5 changed requirement',)} if op == 'set_work_requirements' else {}
        r.apply(path, r.simple(path, op, target, **fields))
        return out
    with patch.object(r.ctx, '_compile', interleave):
        r.refused('managed-change-before-return', lambda: c.open_work(path, q, permission),
            'permission_denied' if operation in ('revoke_work', 'cancel_work') else 'conflict')
    if operation == 'source-revoke':
        r.refused('revoked-source-discovery', lambda: r.discover(path), 'permission_denied')
        new = r.open_at(path).output
        envelope = json.loads(new)['context']['envelope']
        assert envelope['state_revision'] == 13 and envelope['dependencies']['work_revision'] == 12
        r.log('finite-grant-survives-source-revoke', new_global=13, next_work_revision=12)

def final_tamper(path, target):
    q = r.query(path)
    permission = r.auth(path, q)
    original = r.ctx._compile
    def interleave(collected, query):
        out = original(collected, query)
        with sqlite3.connect(r.db(path)) as con:
            if target == 'process-title':
                con.execute("UPDATE core_records SET body=json_set(body,'$.title','G5 changed') WHERE kind='process'")
            elif target == 'membership':
                con.execute("UPDATE core_records SET body=json_set(body,'$.process_id',?) WHERE kind='artifact' AND json_extract(body,'$.work_id')=?",
                    (str(uuid.uuid4()), str(q.work_id)))
            elif target == 'source-current-work':
                con.execute("UPDATE core_records SET body=json_set(body,'$.goal','G5 changed') WHERE id=?", (str(r.read_request().work_id),))
            elif target == 'journal':
                con.execute('DELETE FROM mutation_events WHERE state_revision=2')
            elif target == 'acceptance':
                con.execute("UPDATE accepted_handoffs SET body=json_set(body,'$.handoff.owner_instruction','G5 changed')")
            elif target == 'descriptor':
                con.execute("UPDATE artifact_versions SET body=json_set(body,'$.size',12345) WHERE id=?",
                    (str(r.read_request().submission.result.version_id),))
            elif target == 'result':
                con.execute('DELETE FROM work_results')
            elif target == 'receipt':
                con.execute('DELETE FROM mutation_receipts WHERE operation_id=?', (str(r.read_request().operation_id),))
            else:
                raise AssertionError(target)
        r.log('diagnostic-only-SQL-damage', table_or_field=target, global_revision_unchanged=12)
        return out
    with patch.object(r.ctx, '_compile', interleave):
        r.refused('full-final-' + target, lambda: c.open_work(path, q, permission))

def budget(path):
    before = r.dbhash(path)
    wire = r.open_at(path).output
    obj = json.loads(wire)
    assert wire == r.jsonbytes(obj) + bytes([10])
    assert len(wire) == obj['manifest']['budget']['used']
    assert obj['manifest']['context_sha256'] == r.sha(r.jsonbytes(obj['context']))
    assert len(obj['manifest']['sources']) == len(obj['context']['sources']) == 8
    for source, item in zip(obj['context']['sources'], obj['manifest']['sources'], strict=True):
        encoded = r.jsonbytes(source['data'])
        assert item['locator'] == source['locator'] and item['revision'] == source['revision']
        assert item['value_sha256'] == r.sha(encoded) and item['value_bytes'] == len(encoded)
        if 'content_base64' in source['data']:
            raw = base64.b64decode(source['data']['content_base64'], validate=True)
            assert len(raw) == item['content_bytes'] and r.sha(raw) == item['content_sha256']
    exact = r.open_at(path, r.query(path, max_bytes=len(wire))).output
    assert len(exact) == len(wire)
    for size in (len(wire) - 1, len(r.jsonbytes(obj['context'])), 5000):
        r.refused('full-budget-' + str(size), lambda n=size: r.open_at(path, r.query(path, max_bytes=n)), 'budget_exceeded')
    assert r.dbhash(path) == before
    r.log('full-wire-verification', bytes=len(wire), max_bytes=65536, sha256=r.sha(wire), source_count=8,
        exact_boundary=len(exact), mandatory_context_only_bytes=len(r.jsonbytes(obj['context'])), final_LF=True)

def finite_grants(path):
    content = original_content(path).content
    middle = publish_request(path, content)
    r.apply(path, middle, content)
    last = publish_request(path, content)
    r.apply(path, last, content)
    final_content = c.read_artifact(path, artifact(path).id)
    final_ref = c.ArtifactReference(artifact_id=artifact(path).id, version_id=last.operation_id, sha256=final_content.version.sha256)
    data = r.make_request(path).model_dump()
    data['submission']['result'] = final_ref.model_dump()
    data['references'] = (final_ref,)
    request = c.MutationRequest.model_validate(data)
    r.submit(path, request)
    saved = r.discover(path)
    granted = {ref.version_id for ref in saved.event.result_references}
    assert last.operation_id in granted and middle.operation_id not in granted
    denied = c.ArtifactReference(artifact_id=artifact(path).id, version_id=middle.operation_id, sha256=r.sha(content))
    permission = r.auth(path, r.query(path, references=(denied,)))
    watched = []
    real = r.ctx.verified_content
    def read_spy(root, descriptor):
        watched.append(str(descriptor.id))
        return real(root, descriptor)
    with patch.object(r.ctx, 'verified_content', read_spy):
        r.refused('registered-but-ungranted', lambda: c.open_work(path, r.query(path, references=(denied,)), permission), 'scope')
    assert str(middle.operation_id) not in watched
    r.log('finite-historical-grants', granted=list(map(str, granted)), denied=str(middle.operation_id), read_calls=watched)
    r.open_at(path)

def foreign(path):
    q = r.query(path)
    for key in ('work_id', 'workspace_id', 'process_id'):
        value = q.model_copy(update={key: uuid.uuid4()})
        r.refused('foreign-' + key, lambda v=value: r.open_at(path, v))
    original = r.read_request().submission.result
    for ref in (original.model_copy(update={'artifact_id': uuid.uuid4()}),
                original.model_copy(update={'sha256': '0' * 64}),
                original.model_copy(update={'version_id': uuid.uuid4()})):
        r.refused('altered-exact-grant', lambda v=ref: r.open_at(path, r.query(path, references=(v,))), 'scope')
    own = artifact(path, q.work_id)
    r.refused('disguise-source-as-own', lambda: r.open_at(path, r.query(path,
        references=(original.model_copy(update={'artifact_id': own.id}),))), 'invalid_artifact')
    other = r.receipt_query(work_id=q.work_id)
    r.refused('next-rights-do-not-read-source-result', lambda: c.read_result(path, other, r.auth(path, other)), 'not_found')

def current_acceptances(path):
    work = r.query(path).work_id
    a = artifact(path, work)
    content = original_content(path).content
    denied = publish_request(path, content, work)
    r.refused('next-has-no-publication-authority', lambda: r.apply(path, denied, content), 'permission_denied')
    r.apply(path, r.simple(path, 'authorize_artifact', work, version=2, artifact_id=a.id, artifact_revision=a.revision))
    pub = publish_request(path, content, work)
    r.apply(path, pub, content)
    ref = c.ArtifactReference(artifact_id=a.id, version_id=pub.operation_id, sha256=r.sha(content))
    template = c.read_handoffs(path)[0].handoff
    new_ids = []
    for i in range(2):
        handoff = template.model_copy(update=dict(handoff_id=uuid.uuid4(), related_work=work,
             source_revision=c.read_records(path).state_revision, result=ref, basis=(),
             provenance='G5 synthetic acceptance on diagnostic copy ' + str(i)))
        req = c.handoff_request(handoff.model_dump_json().encode(), source_ref='G5 synthetic diagnostic data')
        r.apply(path, req)
        new_ids.append(handoff.handoff_id)
    obj = json.loads(r.open_at(path).output)
    actual = [s['data']['handoff']['handoff_id'] for s in obj['context']['sources'] if s['locator'].startswith('acceptance:')]
    expected = [*map(str, r.read_request().submission.acceptance_ids), *map(str, new_ids)]
    assert actual == expected
    r.log('all-committed-acceptances-no-latest-wins', expected=expected, actual=actual)

if __name__ == '__main__':
    r.guard()
    for flavor in ('missing-result', 'corrupt-result', 'missing-basis', 'corrupt-basis'):
        case('before-submit-' + flavor, lambda p, f=flavor: before_result_bytes(p, f), False)
        case('late-loss-repair-' + flavor, lambda p, f=flavor: late_bytes(p, f))
    case('final-byte-loss', final_bytes)
    case('final-byte-corruption', lambda p: final_bytes(p, True))
    for op in ('set_work_requirements', 'revoke_work', 'cancel_work', 'source-revoke'):
        case('final-managed-' + op, lambda p, o=op: final_managed(p, o))
    for target in ('process-title', 'membership', 'source-current-work', 'journal', 'acceptance', 'descriptor', 'result', 'receipt'):
        case('final-full-' + target, lambda p, t=target: final_tamper(p, t))
    case('canonical-wire-budget', budget)
    case('finite-registered-historical-grants', finite_grants, False)
    case('foreign-query-and-grants', foreign)
    case('all-current-and-inherited-acceptances', current_acceptances)
    r.write('context-summary.json', RESULTS)
