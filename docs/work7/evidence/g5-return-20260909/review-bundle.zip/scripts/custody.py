"""Independent G5 custody, native gate and isolated runtime setup (not product code)."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[4]
OUT = ROOT / 'docs/g5/work7-20260909'
TRIAL = ROOT / '_scratch/g5-work7-20260909'
CANDIDATE = '05047e38acc7386484223a5feacc510b015b2a85'
BASE = '2fa3111666139eef3ae699319444809fce563ead'
SOURCE = '5866a48c5f9d0f492ad55723120366ffe8f08921'

def guard():
    if (ROOT / 'STOP').exists():
        raise RuntimeError('STOP: ' + (ROOT / 'STOP').read_text(encoding='utf-8'))
    if (ROOT / 'STEER.md').exists():
        raise RuntimeError('New STEER requires owner-intent resolution')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(path, value):
    target = OUT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(value, ensure_ascii=True, indent=2) + '\n', encoding='utf-8', newline='\n')

def run(name, args, cwd=ROOT, check=True, env=None):
    guard()
    start = datetime.datetime.now(datetime.UTC).isoformat()
    p = subprocess.run([str(a) for a in args], cwd=cwd, capture_output=True, env=env)
    (OUT / f'raw/{name}.stdout').write_bytes(p.stdout)
    (OUT / f'raw/{name}.stderr').write_bytes(p.stderr)
    save(f'raw/{name}.json', dict(command=[str(a) for a in args], cwd=str(cwd), start=start,
         end=datetime.datetime.now(datetime.UTC).isoformat(), exit=p.returncode,
         stdout_sha256=sha(p.stdout), stderr_sha256=sha(p.stderr)))
    print(name, p.returncode, flush=True)
    if check and p.returncode:
        raise RuntimeError(f'{name}: exit {p.returncode}; see raw stdout/stderr')
    return p

def inventory(path, exclude=()):
    files, directories = {}, []
    if not path.is_dir():
        return {'path': str(path), 'available': False}
    for parent, dirs, names in os.walk(path):
        dirs[:] = sorted(d for d in dirs if d not in exclude)
        for d in dirs:
            directories.append((Path(parent) / d).relative_to(path).as_posix())
        for n in sorted(names):
            p = Path(parent) / n
            files[p.relative_to(path).as_posix()] = {'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size}
    return dict(path=str(path), available=True, files=files, directories=sorted(directories))

def preservation(label):
    paths = [Path(ROOT.anchor) / 'projects/zaratustra/_scratch' / name
             for name in ('work5-handoff', 'work6-context', 'work7-result')]
    records = {}
    for idx, path in enumerate(paths):
        head = run(f'{label}-checkout-{idx}-head', ['git', '-C', path, 'rev-parse', 'HEAD']).stdout.decode().strip()
        tracked = run(f'{label}-checkout-{idx}-files', ['git', '-C', path, 'ls-files', '-z']).stdout.decode().split('\0')
        records[str(path)] = dict(head=head, files={p: sha((path / p).read_bytes()) for p in tracked if p})
    for path in [Path(os.environ['LOCALAPPDATA']) / 'Temp' / name for name in (
        'zaratustra-work5-96nw94ii', 'zaratustra-work6-_0caf231',
        'zaratustra-work7-m8i5i307', 'zaratustra-work7-restore-0dy2qb3o')]:
        records[str(path)] = inventory(path, ('venv', '.venv', '__pycache__'))
    save(f'preservation-{label}.json', records)
    if label == 'after':
        before = json.loads((OUT / 'preservation-before.json').read_text())
        save('preservation-comparison.json', {'unchanged': before == records})
        assert before == records

def initial():
    assert run('initial-head', ['git', 'rev-parse', 'HEAD']).stdout.decode().strip() == CANDIDATE
    run('initial-status', ['git', '--no-optional-locks', '-c', 'core.excludesFile=', 'status', '--porcelain=v1'])
    run('initial-worktrees', ['git', 'worktree', 'list', '--porcelain'])
    run('base-diff', ['git', 'diff', '--binary', BASE, CANDIDATE])
    run('source-diff', ['git', 'diff', '--binary', BASE, SOURCE])
    run('delivery-diff', ['git', 'diff', '--stat', SOURCE, CANDIDATE])
    run('product-diff', ['git', 'diff', BASE, CANDIDATE, '--', 'src', 'tests', 'tools', 'pyproject.toml', 'uv.lock'])
    tracked = run('candidate-files', ['git', 'ls-tree', '-r', '--name-only', CANDIDATE]).stdout.decode().splitlines()
    save('candidate-identity.json', dict(candidate=CANDIDATE, source=SOURCE, accepted_base=BASE,
        physical_task_id=os.environ.get('CODEX_THREAD_ID'), cwd=str(ROOT), mode='PROBA', home='solmax',
        stop=False, steer=False, files={p: sha((ROOT / p).read_bytes()) for p in tracked}))
    preservation('before')

def gate():
    attempt = 1
    while (OUT / f'raw/native-deliver-{attempt}.json').exists():
        attempt += 1
    run(f'native-deliver-{attempt}', ['uv', 'run', '--locked', 'python', '-m', 'tools.check', '--deliver'])

def prepare():
    info = {}
    for work, expected in [(6, '1657d3a559ba1275ea010b5d83ff0cb818ba26fa74ab195cc86f8218ac57d539'),
                           (7, '90acb543e44959949ea90a94a004528598fcc75b70bb58a6f2f6f21079bcdd2f')]:
        archive = ROOT / f'docs/work{work}/evidence/retained-trial.zip'
        assert sha(archive.read_bytes()) == expected
        target = TRIAL / f'accepted-work{work}-restore'
        assert not target.exists()
        target.mkdir()
        with zipfile.ZipFile(archive) as z:
            for item in z.infolist():
                resolved = (target / item.filename).resolve()
                assert resolved.is_relative_to(target.resolve())
            z.extractall(target)
            fi = {i.filename: sha(z.read(i)) for i in z.infolist() if not i.is_dir()}
            di = sorted(i.filename.rstrip('/') for i in z.infolist() if i.is_dir())
        inv = inventory(target)
        assert fi == {p: v['sha256'] for p, v in inv['files'].items()}
        assert di == inv['directories']
        info[str(work)] = dict(archive_sha256=expected, file_count=len(fi), directory_count=len(di), inventory=inv)
    save('archive-restoration.json', info)
    shutil.copytree(TRIAL / 'accepted-work6-restore/workspace', TRIAL / 'main')
    (TRIAL / 'unrelated-cwd').mkdir()
    run('runtime-venv', ['uv', 'venv', '--python', '3.13.7', TRIAL / 'venv'])
    py = TRIAL / 'venv/Scripts/python.exe'
    wheel = ROOT / 'dist/zaratustra-0.7.0-py3-none-any.whl'
    savedwheel = TRIAL / 'accepted-work7-restore/zaratustra-0.7.0-py3-none-any.whl'
    assert sha(wheel.read_bytes()) == sha(savedwheel.read_bytes()) == 'dada5424fdf899c7d78d62b97f7acbd9edece35bc2c322e65e877b3bb6db8b84'
    run('runtime-install', ['uv', 'pip', 'install', '--offline', '--python', py, '-r',
        ROOT / 'docs/work7/evidence/runtime-requirements.txt', wheel])
    run('runtime-pip-check', ['uv', 'pip', 'check', '--python', py])
    entries = {}
    with zipfile.ZipFile(wheel) as z:
        for name in z.namelist():
            if name.startswith('zaratustra/') and name.endswith('.py'):
                sources = {'source': sha((ROOT / 'src' / name).read_bytes()), 'wheel': sha(z.read(name)),
                           'installed': sha((TRIAL / 'venv/Lib/site-packages' / name).read_bytes())}
                assert len(set(sources.values())) == 1
                entries[name] = sources
    shutil.copy2(wheel, OUT / wheel.name)
    save('installed-identity.json', dict(candidate=CANDIDATE, wheel_sha256=sha(wheel.read_bytes()), sources=entries))

if __name__ == '__main__':
    guard()
    {'initial': initial, 'gate': gate, 'prepare': prepare,
     'preserve-after': lambda: preservation('after')}[sys.argv[1]]()
