"""Read-only reproduction of the author's explicitly retained locale sibling."""
from pathlib import Path
import importlib.util
import os

spec = importlib.util.spec_from_file_location('custody', Path(__file__).with_name('custody.py'))
k = importlib.util.module_from_spec(spec)
spec.loader.exec_module(k)
k.guard()
workspace = k.TRIAL / 'main'
before = k.sha((workspace / '.zara/state.sqlite3').read_bytes())
environment = {**os.environ, 'PYTHONIOENCODING': 'ascii'}
p = k.run('known-legacy-records-ascii', [k.TRIAL / 'venv/Scripts/zara.exe', 'records', 'read', workspace],
          cwd=k.TRIAL / 'unrelated-cwd', check=False, env=environment)
assert p.returncode == 1 and p.stdout == b'' and b'UnicodeEncodeError' in p.stderr
assert k.sha((workspace / '.zara/state.sqlite3').read_bytes()) == before
k.save('known-locale.json', dict(status='REPRODUCED_NONBLOCKING_KNOWN_RESIDUAL',
    source='docs/work7/OUTPUT-REPAIR.md HOME:work7-locale-output-audit', code=1, stdout_bytes=0, db_unchanged=True))
