"""Only rerun the four harness-error cases on new copies; retain failed originals."""
from pathlib import Path
import importlib.util

spec = importlib.util.spec_from_file_location('context_attacks', Path(__file__).with_name('context_attacks.py'))
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
a.r.guard()
for flavor in ('corrupt-result', 'corrupt-basis'):
    a.case('recheck-late-loss-repair-' + flavor, lambda p, f=flavor: a.late_bytes(p, f))
for flavor in ('missing-basis', 'corrupt-basis'):
    a.case('recheck-before-submit-' + flavor, lambda p, f=flavor: a.before_result_bytes(p, f), False)
a.r.write('context-recheck-summary.json', a.RESULTS)
