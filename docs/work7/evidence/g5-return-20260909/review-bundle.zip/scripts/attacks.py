"""Independently selected attacks against the installed candidate; no product edits."""
from pathlib import Path
import importlib.util
import contextlib
import json
import os
import sqlite3
import sys
import uuid
from concurrent.futures import ThreadPoolExecutor
from threading import Barrier
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('g5_runtime', Path(__file__).with_name('runtime.py'))
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
c = r.c
RESULTS = {}

def case(name, fn, after=False):
    RESULTS[name] = r.case(name, fn, after)

def revised(req, **changes):
    return c.MutationRequest.model_validate({**req.model_dump(), **changes})

def reqchange(req, field, value):
    data = req.model_dump()
    data['submission'][field] = value
    return c.MutationRequest.model_validate(data)

def atomic_fault(path, stage):
    request = r.make_request(path)
    permission = r.auth(path, request)
    before = r.dbhash(path)
    real = sqlite3.connect
    seen = []
    class Fault(sqlite3.Connection):
        writes = False
        inserts = 0
        def execute(self, sql, parameters=(), /):
            if sql == 'BEGIN IMMEDIATE':
                self.writes = True
            if self.writes:
                point = None
                if sql.startswith('INSERT INTO core_records'):
                    self.inserts += 1
                    point = 'next-work' if self.inserts == 1 else 'next-artifact'
                for prefix, name in (
                    ('UPDATE core_records', 'source-completion'), ('UPDATE core_state', 'global-revision'),
                    ('INSERT INTO mutation_events', 'event'), ('INSERT INTO mutation_receipts', 'receipt'),
                    ('INSERT INTO work_results', 'result'), ('COMMIT', 'commit')):
                    if sql.startswith(prefix):
                        point = name
                if point:
                    seen.append(point)
                if point == stage:
                    raise sqlite3.OperationalError('G5 injected rejection at ' + stage)
            return super().execute(sql, parameters)
    with patch.object(r.ws.sqlite3, 'connect', lambda *a, **kw: real(*a, factory=Fault, **kw)):
        r.refused('sqlite-' + stage, lambda: c.submit_result(path, request, permission))
    r.log('injection-trace', seen=seen, stage=stage, db_unchanged=r.dbhash(path) == before)
    assert stage in seen and r.dbhash(path) == before
    r.effect(path, 0)
    r.refused('original-id-discovery-before-retry', lambda: r.discover(path), 'not_found')
    accepted = r.submit(path, request)
    assert accepted.new_revision == 12
    r.effect(path, 1)

def order(path, flavor):
    req = r.make_request(path)
    if flavor == 'invalid-input-first':
        malformed = req.model_copy(update={'expected_revision': 0})
        r.refused(flavor, lambda: c.submit_result(path, malformed))
    elif flavor == 'no-auth-before-stale':
        req = revised(req, expected_revision=10)
        r.refused(flavor, lambda: c.submit_result(path, req), 'permission_denied')
    elif flavor in ('cancel-before-stale', 'revoke-before-stale'):
        r.apply(path, r.simple(path, 'cancel_work' if flavor.startswith('cancel') else 'revoke_work'))
        r.refused(flavor, lambda: r.submit(path, req), 'permission_denied')
    elif flavor in ('stale-before-collision', 'collision-before-bytes'):
        req = revised(req, operation_id=c.read_history(path).receipts[-1].operation_id,
                      expected_revision=10 if flavor.startswith('stale') else 11)
        content = c.read_artifact(path, req.submission.result.artifact_id, req.submission.result.version_id)
        (path / content.version.relative_path).unlink()
        r.refused(flavor, lambda: r.submit(path, req), 'conflict' if flavor.startswith('stale') else 'collision')
    elif flavor == 'refs-before-db':
        content = c.read_artifact(path, req.submission.result.artifact_id, req.submission.result.version_id)
        (path / content.version.relative_path).unlink()
        r.refused(flavor, lambda: r.submit(path, req), 'content_unavailable')
    r.effect(path, 0)

def terminals(path):
    req = r.read_request()
    before = r.dbhash(path)
    for value in (req, revised(req, expected_revision=12), revised(req, expected_revision=12, operation_id=uuid.uuid4())):
        r.refused('terminal-submission', lambda v=value: r.submit(path, v), 'permission_denied')
    for operation in ('authorize_work', 'set_work_requirements', 'cancel_work'):
        r.refused('done-' + operation, lambda op=operation: r.apply(path, r.simple(path, op)), 'permission_denied')
    r.refused('source-open', lambda: r.open_at(path, r.query(path, req.work_id)), 'permission_denied')
    assert r.dbhash(path) == before
    r.effect(path, 1)

def request_binding(path):
    req = r.make_request(path)
    permission = r.auth(path, req)
    changes = {'goal': 'Different fictional goal', 'acceptance': ('Different criterion',),
               'boundaries': ('Different boundary',), 'budget': 'Different budget',
               'executor_requirements': ('unconfirmed',), 'work_id': uuid.uuid4(),
               'artifact_id': uuid.uuid4(), 'expected_result': 'Different result', 'artifact_title': 'Different title'}
    for key, value in changes.items():
        payload = req.model_dump()
        payload['submission']['next_work'][key] = value
        altered = c.MutationRequest.model_validate(payload)
        r.refused('altered-next-' + key, lambda: c.submit_result(path, altered, permission), 'permission_denied')
    other = r.TRIAL / 'diagnostics/binding-other-path'
    r.shutil.copytree(path, other)
    r.refused('other-path', lambda: c.submit_result(other, req, permission), 'permission_denied')
    for value in ({'approved': True}, permission.confirmation, permission.confirmation.model_dump()):
        r.refused('non-authority-object', lambda v=value: c.submit_result(path, req, v), 'permission_denied')
    r.effect(path, 0)

def acceptance_integrity(path, flavor):
    req = r.make_request(path)
    ids = req.submission.acceptance_ids
    if flavor == 'omit-old':
        req = reqchange(req, 'acceptance_ids', ids[1:])
    elif flavor == 'reverse-order':
        req = reqchange(req, 'acceptance_ids', tuple(reversed(ids)))
    elif flavor == 'foreign-id':
        req = reqchange(req, 'acceptance_ids', (uuid.uuid4(), ids[1]))
    elif flavor == 'occupied-next':
        data = req.submission.next_work.model_dump()
        data['artifact_id'] = req.submission.result.artifact_id
        req = reqchange(req, 'next_work', data)
    elif flavor == 'stale-source':
        req = reqchange(req, 'source_revision', 10)
    r.refused(flavor, lambda: r.submit(path, req), 'conflict' if flavor == 'stale-source' else 'invalid_result')
    r.effect(path, 0)

def handoff_replay(path):
    event = next(e for e in c.read_history(path).events if e.request.handoff is not None)
    original = event.request
    before = r.dbhash(path)
    r.refused('work5-original-stale', lambda: r.apply(path, original), 'conflict')
    delivered = c.handoff_request(original.handoff.model_dump_json().encode(), source_ref='stdin:G5 new transport', expected_revision=11)
    assert delivered.handoff.source_revision == original.handoff.source_revision
    returned = r.apply(path, delivered)
    assert returned == c.read_history(path).receipts[event.state_revision - 2]
    content = c.read_artifact(path, delivered.handoff.result.artifact_id, delivered.handoff.result.version_id)
    (path / content.version.relative_path).unlink()
    assert r.apply(path, delivered) == returned
    modified = delivered.handoff.model_copy(update={'owner_instruction': 'different meaning'})
    changed = c.handoff_request(modified.model_dump_json().encode(), source_ref='stdin:changed', expected_revision=11)
    r.refused('work5-collision-before-absent-bytes', lambda: r.apply(path, changed), 'collision')
    modified = delivered.handoff.model_copy(update={'handoff_id': uuid.uuid4()})
    new = c.handoff_request(modified.model_dump_json().encode(), source_ref='stdin:new-id-old-revision', expected_revision=11)
    r.refused('new-id-cannot-refresh-historical-decision', lambda: r.apply(path, new), 'conflict')
    assert r.dbhash(path) == before
    r.apply(path, r.simple(path, 'revoke_work'))
    delivered = revised(delivered, expected_revision=12)
    r.refused('revoked-before-duplicate', lambda: r.apply(path, delivered), 'permission_denied')

def projection(path):
    req = r.make_request(path)
    with patch.object(r.mut, 'write_projection', side_effect=OSError('G5 projection output unavailable')):
        e = r.refused('post-commit-projection', lambda: r.submit(path, req), 'rebuild_required')
        assert isinstance(e, c.ProjectionRebuildError) and e.receipt.operation_id == req.operation_id
    before = r.dbhash(path)
    assert r.discover(path).receipt == e.receipt
    r.effect(path, 1)
    c.rebuild_projections(path)
    first = (path / 'projections/overview.md').read_bytes()
    c.rebuild_projections(path)
    assert (path / 'projections/overview.md').read_bytes() == first
    assert r.dbhash(path) == before
    r.log('deterministic-rebuild', sha256=r.sha(first), db_unchanged=True)

def lost_reply(path):
    p = r.run_child('lost-reply-child', ['exit-after-commit', path])
    assert p.returncode == 79 and p.stdout == b''
    p = r.run_child('lost-reply-independent-restart', ['restart', path, 'lost-reply-restart'])
    assert p.returncode == 0
    r.effect(path, 1)
    r.refused('lost-reply-terminal-original-id', lambda: r.submit(path, r.read_request()), 'permission_denied')

def concurrency(path):
    request = r.make_request(path)
    barrier = Barrier(2)
    def contender(index):
        req = request if index == 0 else revised(request, operation_id=uuid.uuid4())
        permission = r.auth(path, req)
        barrier.wait(timeout=10)
        try:
            return c.submit_result(path, req, permission).model_dump(mode='json')
        except c.WorkspaceError as e:
            return {'refused': str(e), 'code': getattr(e, 'code', None)}
    with ThreadPoolExecutor(2) as pool:
        values = list(pool.map(contender, range(2)))
    r.log('concurrent-independent-ids', outcomes=values)
    assert sum('operation_id' in v for v in values) == 1
    assert sum(v.get('code') == 'permission_denied' for v in values) == 1
    snap = c.read_records(path)
    assert snap.state_revision == 12 and len([w for w in snap.records if isinstance(w, c.Work)]) == 2

def run_effects():
    for stage in ('next-work', 'next-artifact', 'source-completion', 'global-revision', 'event', 'receipt', 'result', 'commit'):
        case('atomic-' + stage, lambda p, s=stage: atomic_fault(p, s))
    for flavor in ('invalid-input-first', 'no-auth-before-stale', 'cancel-before-stale', 'revoke-before-stale',
                   'stale-before-collision', 'collision-before-bytes', 'refs-before-db'):
        case('order-' + flavor, lambda p, f=flavor: order(p, f))
    case('terminal-no-reopen', terminals, True)
    case('exact-authorization-binding', request_binding)
    for flavor in ('omit-old', 'reverse-order', 'foreign-id', 'occupied-next', 'stale-source'):
        case('result-' + flavor, lambda p, f=flavor: acceptance_integrity(p, f))
    case('work5-identity-replay', handoff_replay)
    case('projection-committed-receipt', projection)
    case('lost-reply-restart', lost_reply)
    case('concurrent-submit', concurrency)

if __name__ == '__main__':
    r.guard()
    run_effects()
    r.write('effects-summary.json', RESULTS)
