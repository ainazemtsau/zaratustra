"""Fresh G5 installed-runtime reproductions; fictional diagnostics, never Work8.

Run with the isolated wheel Python -I from unrelated-cwd. Main submission uses
the actual interactive console. Fault groups simulate the prior-permission seam
on explicitly selected new copies. SQL/file damage is diagnostic only.
"""
from pathlib import Path
import base64
import contextlib
import hashlib
import importlib.metadata
import io
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import traceback
import uuid
from unittest.mock import patch

from zaratustra import cli
from zaratustra import core as c
from zaratustra.core import context as ctx
from zaratustra.core import mutations as mut
from zaratustra.core import workspace as ws

ROOT = Path(__file__).resolve().parents[4]
OUT = ROOT / 'docs/g5/work7-20260909'
TRIAL = ROOT / '_scratch/g5-work7-20260909'
MAIN = TRIAL / 'main'
ACTIVE_LOG = []

def guard():
    if (ROOT / 'STOP').exists() or (ROOT / 'STEER.md').exists():
        raise RuntimeError('STOP/STEER must be resolved before commands/mutation')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def jsonbytes(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode()

def write(name, value):
    p = OUT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=True, indent=2, default=str) + '\n', encoding='utf-8', newline='\n')

def db(path):
    return path / '.zara/state.sqlite3'

def dbhash(path):
    return sha(db(path).read_bytes())

def log(kind, **value):
    ACTIVE_LOG.append(dict(kind=kind, **value))

def auth(path, request):
    log('exact-simulated-prior-permission', path=str(path), request=request.model_dump(mode='json'))
    return c.authorize_local(c.prepare_authorization(path, request), channel='local-chat',
        actor='G5 fictional diagnostic adapter', source_ref='G5 explicit fixture test permission; not owner runtime acceptance')

def submit(path, request):
    guard()
    return c.submit_result(path, request, auth(path, request))

def apply(path, request, content=None):
    guard()
    return c.apply_mutation(path, request, auth(path, request), content=content)

def read_request():
    return c.MutationRequest.model_validate_json((OUT / 'input/request.json').read_bytes())

def source(path):
    req = read_request()
    return next(r for r in c.read_records(path).records if isinstance(r, c.Work) and r.id == req.work_id)

def make_request(path, **updates):
    req = read_request().model_dump()
    rev = c.read_records(path).state_revision
    req['expected_revision'] = rev
    req['submission']['source_revision'] = rev
    req.update(updates)
    return c.MutationRequest.model_validate(req)

def simple(path, operation, work_id=None, **fields):
    snap = c.read_records(path)
    return c.MutationRequest(operation_id=uuid.uuid4(), workspace_id=snap.workspace_id,
        work_id=work_id or read_request().work_id, expected_revision=snap.state_revision,
        operation=operation, provenance='G5 controlled fictional diagnostic', **fields)

def query(path, work_id=None, max_bytes=65536, **changes):
    snap = c.read_records(path)
    work = next(r for r in snap.records if isinstance(r, c.Work) and
                r.id == (work_id or read_request().submission.next_work.work_id))
    data = dict(workspace_id=snap.workspace_id, work_id=work.id, process_id=work.process_id,
                expected_revision=snap.state_revision, max_bytes=max_bytes)
    data.update(changes)
    return c.ContextQuery(**data)

def open_at(path, q=None):
    q = q or query(path)
    return c.open_work(path, q, auth(path, q))

def receipt_query(req=None, **updates):
    req = req or read_request()
    return c.ReceiptQuery(workspace_id=req.workspace_id, work_id=updates.get('work_id', req.work_id),
        operation_id=updates.get('operation_id', req.operation_id))

def discover(path, req=None):
    q = receipt_query(req)
    return c.read_result(path, q, auth(path, q))

def refused(label, fn, expected=None):
    try:
        value = fn()
    except Exception as e:
        code = getattr(e, 'code', None)
        log('refusal', label=label, type=type(e).__name__, code=code, detail=str(e))
        if expected is not None:
            assert code in expected if isinstance(expected, tuple) else code == expected, (label, code, expected)
        assert isinstance(e, (c.WorkspaceError, ValueError)), (label, type(e))
        return e
    log('UNEXPECTED_SUCCESS', label=label, value=str(value))
    raise AssertionError(f'{label}: expected refusal, got success')

def effect(path, accepted):
    snap, history = c.read_records(path), c.read_history(path)
    with sqlite3.connect(db(path).as_uri() + '?mode=ro', uri=True) as con:
        counts = {t: con.execute('SELECT count(*) FROM ' + t).fetchone()[0]
                  for t in ('core_records', 'mutation_events', 'mutation_receipts', 'work_results')}
    works = [r for r in snap.records if isinstance(r, c.Work)]
    log('authoritative-state', revision=snap.state_revision, counts=counts,
        works=[w.model_dump(mode='json') for w in works])
    assert counts['work_results'] == accepted
    assert len(works) == 1 + accepted
    assert len(history.events) == len(history.receipts) == snap.state_revision - 1
    if accepted:
        saved = discover(path)
        done = next(w for w in works if w.id == saved.event.before.id)
        nxt = next(w for w in works if w.id == saved.next_work_id)
        assert done.status == 'done' and done.completion_id == saved.receipt.operation_id
        assert nxt.status == 'ready' and nxt.authority_scope == 'work_metadata'
        assert saved.event.request == read_request() or saved.event.request.submission.next_work == read_request().submission.next_work
    return snap

def prepare_main():
    assert sys.flags.isolated and str(ROOT / 'src') not in sys.path
    write('runtime-environment.json', dict(executable=sys.executable, cwd=str(Path.cwd()), isolated=sys.flags.isolated,
          sys_path=sys.path, package_file=c.__file__, version=importlib.metadata.version('zaratustra'),
          python=sys.version, sqlite=sqlite3.sqlite_version, pydantic=importlib.metadata.version('pydantic')))
    assert c.read_workspace(MAIN).schema_version == 5
    q6 = c.ContextQuery.model_validate_json((ROOT / 'docs/work6/evidence/query.json').read_bytes())
    before = dbhash(MAIN)
    out6 = c.open_work(MAIN, q6, auth(MAIN, q6)).output
    (OUT / 'raw/work6-compatibility.stdout').write_bytes(out6)
    assert out6 == (ROOT / 'docs/work6/evidence/context-library.json').read_bytes()
    assert dbhash(MAIN) == before
    req = json.loads((ROOT / 'docs/work7/evidence/request.json').read_bytes())
    req['operation_id'] = str(uuid.uuid4())
    req['submission']['next_work']['work_id'] = str(uuid.uuid4())
    req['submission']['next_work']['artifact_id'] = str(uuid.uuid4())
    req['provenance'] = 'Fresh physical G5 Work7; exact owner-confirmed fictional fixture'
    request = c.MutationRequest.model_validate(req)
    write('input/request.json', request.model_dump(mode='json'))
    refused('schema5-requires-explicit6', lambda: submit(MAIN, request), 'schema')
    assert dbhash(MAIN) == before
    refused('default-migrate-refuses-downgrade', lambda: c.migrate_workspace(MAIN))
    assert dbhash(MAIN) == before
    c.migrate_workspace(MAIN, target_version=6)
    assert c.read_records(MAIN).state_revision == 11
    shutil.copytree(MAIN, TRIAL / 'ready-base')
    write('input/receipt-query.json', receipt_query().model_dump(mode='json'))
    fresh = TRIAL / 'empty-init'
    fresh.mkdir()
    assert c.init_workspace(fresh).schema_version == 1
    assert c.migrate_workspace(fresh).schema_version == 4
    write('raw/prepare-main.json', dict(log=ACTIVE_LOG, old_context_sha256=sha(out6), old_context_bytes=len(out6),
          new_request_sha256=sha((OUT / 'input/request.json').read_bytes()), init_schema=1, default_migrate_schema=4))

class Tee:
    def __init__(self, original, file):
        self.original, self.file = original, file
    def write(self, value):
        self.file.write(value)
        self.file.flush()
        return self.original.write(value)
    def flush(self):
        self.file.flush()
        self.original.flush()
    def isatty(self):
        return self.original.isatty()

def cli_args(action, path=MAIN):
    if action in ('submit', 'replay'):
        return ['result', 'submit', str(path), str(OUT / 'input/request.json')]
    if action == 'discover':
        return ['result', 'read', str(path), receipt_query().model_dump_json()]
    q = query(path, max_bytes=5000 if action == 'budget' else 65536,
              **({'expected_revision': 11} if action == 'stale' else {}))
    write(f'input/{action}-query.json', q.model_dump(mode='json'))
    return ['work', 'open', str(q.work_id), '--workspace', str(path), '--workspace-id', str(q.workspace_id),
            '--process', str(q.process_id), '--expected-revision', str(q.expected_revision), '--max-bytes', str(q.max_bytes)]

def console(action):
    args = cli_args(action)
    before = dbhash(MAIN)
    original_err, original_out = sys.stderr, sys.stdout
    write(f'raw/console-{action}-command.json', dict(argv=args, stdin_isatty=sys.stdin.isatty(),
           stderr_isatty=sys.stderr.isatty(), permission='executor actual console on selected fictional copy'))
    with (OUT / f'raw/console-{action}.stderr').open('w', encoding='utf-8', newline='\n') as err:
        with (OUT / f'raw/console-{action}.stdout').open('w', encoding='ascii', newline='\n') as out:
            try:
                sys.stderr = Tee(original_err, err)
                sys.stdout = out
                code = cli.main(args)
            finally:
                sys.stderr, sys.stdout = original_err, original_out
    write(f'raw/console-{action}.json', dict(exit=code, before_db=before, after_db=dbhash(MAIN)))
    print(f'CLI {action}: exit {code}', flush=True)
    return code

def main_check():
    before = dbhash(MAIN)
    effect(MAIN, 1)
    result = discover(MAIN)
    context = open_at(MAIN).output
    assert json.loads((OUT / 'raw/console-submit.stdout').read_bytes()) == result.receipt.model_dump(mode='json')
    assert json.loads((OUT / 'raw/console-discover.stdout').read_bytes()) == result.model_dump(mode='json')
    assert context == (OUT / 'raw/console-next.stdout').read_bytes()
    assert context == open_at(MAIN).output
    assert dbhash(MAIN) == before
    (OUT / 'raw/main-context.stdout').write_bytes(context)
    write('raw/main-result.json', result.model_dump(mode='json'))
    write('raw/main-check.json', dict(log=ACTIVE_LOG, context_sha256=sha(context), bytes=len(context)))

def restart(path, prefix):
    before = dbhash(path)
    saved = discover(path)
    wire = open_at(path).output
    q = receipt_query()
    receipt = c.read_receipt(path, q, auth(path, q))
    assert receipt == saved.receipt
    assert dbhash(path) == before
    (OUT / f'raw/{prefix}-context.stdout').write_bytes(wire)
    write(f'raw/{prefix}-result.json', saved.model_dump(mode='json'))
    write(f'raw/{prefix}.json', dict(pid=os.getpid(), executable=sys.executable, cwd=str(Path.cwd()),
          db_sha256=before, source_status=source(path).status, operation_id=str(receipt.operation_id),
          next_work_id=str(saved.next_work_id), context_sha256=sha(wire), bytes=len(wire), log=ACTIVE_LOG))

def case(name, body, after=False):
    global ACTIVE_LOG
    ACTIVE_LOG = []
    path = TRIAL / 'diagnostics' / name
    path.parent.mkdir(exist_ok=True)
    assert not path.exists(), name
    shutil.copytree(MAIN if after else TRIAL / 'ready-base', path)
    before = dbhash(path)
    try:
        body(path)
        status = 'PASS'
        error = None
    except Exception:
        status, error = 'FAIL', traceback.format_exc()
    write(f'cases/{name}.json', dict(status=status, error=error, base='main-completed' if after else 'new-work6-main-migrated6',
          path=str(path), before_db=before, after_db=dbhash(path), log=ACTIVE_LOG))
    print(name, status, flush=True)
    return status

def run_child(name, args):
    p = subprocess.run([sys.executable, '-I', str(Path(__file__).resolve()), *map(str, args)],
                       cwd=TRIAL / 'unrelated-cwd', capture_output=True)
    (OUT / f'raw/{name}.stdout').write_bytes(p.stdout)
    (OUT / f'raw/{name}.stderr').write_bytes(p.stderr)
    write(f'raw/{name}-process.json', dict(args=list(map(str, args)), exit=p.returncode, pid_parent=os.getpid()))
    return p

if __name__ == '__main__':
    guard()
    mode = sys.argv[1]
    if mode == 'prepare-main':
        prepare_main()
    elif mode == 'console':
        sys.exit(console(sys.argv[2]))
    elif mode == 'main-check':
        main_check()
    elif mode == 'restart':
        restart(Path(sys.argv[2]), sys.argv[3])
    elif mode == 'exit-after-commit':
        def lose_reply(path):
            os._exit(79)
        with patch.object(mut, 'rebuild_projections', lose_reply):
            submit(Path(sys.argv[2]), read_request())
