"""Read original Work7 archive using fresh installed candidate; no author driver."""
from pathlib import Path
import hashlib
import json
import sys
from zaratustra import core as c

ROOT = Path(__file__).resolve().parents[4]
OUT = ROOT / 'docs/g5/work7-20260909'
if (ROOT / 'STOP').exists() or (ROOT / 'STEER.md').exists():
    raise RuntimeError('STOP/STEER')
trial = Path(sys.argv[1])
path = trial / 'workspace'
def auth(query):
    return c.authorize_local(c.prepare_authorization(path, query), channel='local-chat',
        actor='G5 fictional restored-read adapter', source_ref='G5 fixture permission; simulated adapter')
q = c.ReceiptQuery.model_validate_json((trial / 'receipt-query.json').read_bytes())
saved = c.read_result(path, q, auth(q))
assert saved.model_dump(mode='json') == json.loads((ROOT / 'docs/work7/evidence/result.json').read_bytes())
query = c.ContextQuery.model_validate_json((trial / 'query.json').read_bytes())
wire = c.open_work(path, query, auth(query)).output
assert wire == (ROOT / 'docs/work7/evidence/context-library.json').read_bytes()
assert hashlib.sha256(wire).hexdigest() == 'f9549bbbfd83eed752dae510c2f91db06217ff130673558c0643af5744fe1894'
(OUT / 'raw/author-restored-context.stdout').write_bytes(wire)
(OUT / 'raw/author-restored-result.json').write_text(saved.model_dump_json(indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(dict(bytes=len(wire), sha256=hashlib.sha256(wire).hexdigest(), installed=c.__file__, isolated=sys.flags.isolated)))
