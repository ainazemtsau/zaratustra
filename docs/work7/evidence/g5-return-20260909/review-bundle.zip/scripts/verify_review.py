"""Read-only review hygiene, raw-output reconciliation and bundle verification."""
from pathlib import Path
import importlib.util
import ast
import json
import sys
import zipfile

spec = importlib.util.spec_from_file_location('custody', Path(__file__).with_name('custody.py'))
k = importlib.util.module_from_spec(spec)
spec.loader.exec_module(k)
k.guard()

if sys.argv[1] == 'before-bundle':
    # Native repo hygiene only: not product behavioral evidence.
    k.run('review-hygiene', ['uv', 'run', '--locked', 'python', '-c',
        'from tools.check import ROOT,hygiene; errors=hygiene(ROOT); print(errors); raise SystemExit(bool(errors))'])
    for script in (k.OUT / 'scripts').glob('*.py'):
        ast.parse(script.read_text(encoding='utf-8'))
    sessions = json.loads((k.OUT / 'terminal-session.json').read_bytes())
    for session in sessions['sessions']:
        prefix = session['raw_prefix']
        meta = json.loads((k.OUT / (prefix + '.json')).read_bytes())
        command = json.loads((k.OUT / (prefix + '-command.json')).read_bytes())
        prompt = (k.OUT / (prefix + '.stderr')).read_text(encoding='utf-8')
        assert meta['exit'] == session['observed_exit']
        assert session['input'].strip() in prompt
        assert command['stdin_isatty'] and command['stderr_isatty']
        if session['action'] in ('replay', 'budget', 'stale'):
            assert not (k.OUT / (prefix + '.stdout')).read_bytes()
            assert meta['before_db'] == meta['after_db']
    cases = {p.stem: json.loads(p.read_bytes()) for p in (k.OUT / 'cases').glob('*.json')}
    failed = [name for name, item in cases.items() if item['status'] == 'FAIL']
    assert set(failed) == {'late-loss-repair-corrupt-result', 'late-loss-repair-corrupt-basis',
                           'before-submit-missing-basis', 'before-submit-corrupt-basis'}
    assert all(cases['recheck-' + name]['status'] == 'PASS' for name in failed)
    assert len(cases) == 62
    k.save('review-validation.json', dict(case_runs=62, semantic_groups=58, harness_failures_retained=failed,
        all_four_targeted_rechecks_pass=True, console_sessions=6, console_raw_metadata_reconciled=True,
        review_script_syntax_and_native_hygiene_pass=True))
else:
    manifest = json.loads((k.OUT / 'review-manifest.json').read_bytes())
    archive = k.OUT / 'review-bundle.zip'
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for name, info in manifest['files'].items():
            assert k.sha(z.read(name)) == info['sha256'] == k.sha((k.OUT / name).read_bytes())
        for name in manifest['directories']:
            assert z.getinfo(name + '/').is_dir()
        assert z.read('review-manifest.json') == (k.OUT / 'review-manifest.json').read_bytes()
    print(json.dumps(dict(review_bundle_sha256=k.sha(archive.read_bytes()), file_count=len(manifest['files']) + 1,
                         directory_count=len(manifest['directories']), all_hashed_entries_verified=True)))
