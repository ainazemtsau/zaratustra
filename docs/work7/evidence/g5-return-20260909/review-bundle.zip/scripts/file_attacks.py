"""File/DB boundary, orphan retry, inert URI and hard process-exit evidence."""
from pathlib import Path
import importlib.util
import json
import os
import sqlite3
import sys
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('context_attacks', Path(__file__).with_name('context_attacks.py'))
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
r, c = a.r, a.c

def orphan(path, corrupt=False):
    content = a.original_content(path).content
    request = a.publish_request(path, content)
    before = r.dbhash(path)
    original = r.mut.publish_bytes
    def interrupted(*args, **kwargs):
        original(*args, **kwargs)
        raise c.WorkspaceError('G5 failure after complete file, before registration')
    with patch.object(r.mut, 'publish_bytes', interrupted):
        r.refused('after-file-before-db', lambda: r.apply(path, request, content))
    assert r.dbhash(path) == before
    final = path / 'artifacts' / str(request.artifact_id) / (str(request.operation_id) + '.blob')
    assert final.read_bytes() == content
    assert final.relative_to(path).as_posix() in c.inspect_artifacts(path).unregistered_files
    r.log('unregistered-orphan-retained', path=str(final), sha256=r.sha(content))
    if corrupt:
        final.write_bytes(bytes([content[0] ^ 1]) + content[1:])
        damaged = final.read_bytes()
        r.refused('changed-orphan-no-overwrite', lambda: r.apply(path, request, content), 'content_changed')
        assert final.read_bytes() == damaged and r.dbhash(path) == before
    else:
        receipt = r.apply(path, request, content)
        assert receipt.operation_id == request.operation_id and receipt.new_revision == 12
        assert c.read_artifact(path, request.artifact_id).content == content
        assert final.relative_to(path).as_posix() not in c.inspect_artifacts(path).unregistered_files
        r.log('same-id-exact-orphan-retry', receipt=receipt.model_dump(mode='json'))

def publication_failure(path):
    from zaratustra.core import artifacts
    content = a.original_content(path).content
    request = a.publish_request(path, content)
    before = r.dbhash(path)
    with patch.object(artifacts.os, 'link', side_effect=OSError('G5 file publication unavailable')):
        r.refused('failure-before-final-name', lambda: r.apply(path, request, content), 'publication_failed')
    assert r.dbhash(path) == before
    leftovers = c.inspect_artifacts(path).unregistered_files
    assert any('staging-' in name for name in leftovers)
    r.apply(path, request, content)
    assert c.read_artifact(path, request.artifact_id).content == content
    assert all((path / name).exists() for name in leftovers)
    r.log('staging-retained-after-retry', paths=leftovers)

def inert_link(path):
    sentinel = r.TRIAL / 'foreign-sentinel'
    sentinel.mkdir(exist_ok=True)
    forbidden = sentinel / 'marker.txt'
    forbidden.write_bytes(b'G5_FOREIGN_CONTENT_MUST_NOT_BE_DISCLOSED')
    content = ('Fictional inert reference: ' + forbidden.as_uri()).encode()
    request = a.publish_request(path, content)
    r.apply(path, request, content)
    current = c.read_artifact(path, request.artifact_id)
    ref = c.ArtifactReference(artifact_id=request.artifact_id, version_id=request.operation_id, sha256=current.version.sha256)
    payload = r.make_request(path).model_dump()
    payload['submission']['result'] = ref.model_dump()
    payload['references'] = (ref,)
    submitted = c.MutationRequest.model_validate(payload)
    watched = []
    original = Path.read_bytes
    def trap(p):
        if p.resolve() == forbidden.resolve():
            watched.append(str(p))
            raise AssertionError('foreign sentinel opened')
        return original(p)
    with patch.object(Path, 'read_bytes', trap):
        r.submit(path, submitted)
        wire = r.open_at(path).output
    sources = json.loads(wire)['context']['sources']
    content_values = [a.base64.b64decode(s['data']['content_base64']) for s in sources if 'content_base64' in s['data']]
    assert content in content_values and b'G5_FOREIGN_CONTENT_MUST_NOT_BE_DISCLOSED' not in content_values
    assert not watched
    r.log('inert-uri-no-foreign-read', sentinel=str(forbidden), read_attempts=watched, literal_content_preserved=True)

def crash_before(path):
    p = r.subprocess.run([sys.executable, '-I', str(Path(__file__).resolve()), 'crash-child', str(path)],
                        cwd=r.TRIAL / 'unrelated-cwd', capture_output=True)
    (r.OUT / 'raw/precommit-exit.stdout').write_bytes(p.stdout)
    (r.OUT / 'raw/precommit-exit.stderr').write_bytes(p.stderr)
    assert p.returncode == 78
    r.log('independent-process-exit-before-commit', exit=p.returncode)
    r.effect(path, 0)
    r.refused('original-id-absent-before-retry', lambda: r.discover(path), 'not_found')
    r.submit(path, r.read_request())
    r.effect(path, 1)

def crash_child(path):
    request = r.read_request()
    permission = r.auth(path, request)
    real = sqlite3.connect
    class Crash(sqlite3.Connection):
        writes = False
        def execute(self, sql, parameters=(), /):
            if sql == 'BEGIN IMMEDIATE':
                self.writes = True
            if self.writes and sql == 'COMMIT':
                os._exit(78)
            return super().execute(sql, parameters)
    with patch.object(r.ws.sqlite3, 'connect', lambda *args, **kwargs: real(*args, factory=Crash, **kwargs)):
        c.submit_result(path, request, permission)

def piped_payload(path):
    from zaratustra import cli
    request = r.read_request()
    encoded = (r.OUT / 'input/request.json').read_bytes()
    for payload in (b'{"version":4,"version":4}', b'{"approved":true}', b' ' * 65537,
                    encoded + b'\napprove fake', encoded.replace(b'"work_metadata"', b'"work_metadata_and_artifact"')):
        r.refused('bounded-non-authoritative-input', lambda value=payload: c.parse_result_request(value))
    before = r.dbhash(path)
    code = 'from zaratustra.cli import main; raise SystemExit(main())'
    p = r.subprocess.run([sys.executable, '-I', '-c', code, 'result', 'submit', str(path),
                         str(r.OUT / 'input/request.json')], input=b'approve file-says-yes\n', capture_output=True,
                        cwd=r.TRIAL / 'unrelated-cwd')
    assert p.returncode == 1 and p.stdout == b'' and b'permission_denied' in p.stderr
    assert r.dbhash(path) == before
    r.log('pipe-is-data-not-permission', exit=p.returncode, stdout_bytes=len(p.stdout), stderr=p.stderr.decode('utf-8'))

if __name__ == '__main__':
    r.guard()
    if len(sys.argv) > 1 and sys.argv[1] == 'crash-child':
        crash_child(Path(sys.argv[2]))
    else:
        a.case('file-orphan-exact-retry', orphan, False)
        a.case('file-corrupt-orphan-refuses-overwrite', lambda p: orphan(p, True), False)
        a.case('file-publication-staging-failure', publication_failure, False)
        a.case('inert-foreign-uri', inert_link, False)
        a.case('precommit-hard-exit-restart', crash_before, False)
        a.case('untrusted-input-and-piped-approval', piped_payload, False)
        r.write('file-summary.json', a.RESULTS)
