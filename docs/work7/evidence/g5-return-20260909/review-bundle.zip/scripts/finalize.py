"""G5 retained-byte custody and independent restore verification."""
from pathlib import Path
import importlib.util
import base64
import json
import os
import re
import shutil
import sys
import tarfile
import zipfile

spec = importlib.util.spec_from_file_location('custody', Path(__file__).with_name('custody.py'))
k = importlib.util.module_from_spec(spec)
spec.loader.exec_module(k)
ROOT, OUT, TRIAL = k.ROOT, k.OUT, k.TRIAL

def authority():
    base = Path(ROOT.anchor) / 'my_global_workflow/207a/solmax/live/solmax'
    paths = ('work/zaratustra-architecture-plan-2026-09-05.md',
             'work/converge-g-zara-m0-continuity.md', 'work/converge-g-zara-m0-continuity-arch.md',
             'knowledge/zaratustra-plan-conforming-approval-2026-09-07.md')
    sources = {}
    (OUT / 'authority').mkdir(exist_ok=True)
    for p in paths:
        raw = (base / p).read_bytes()
        normalized = raw.replace(bytes([13, 10]), bytes([10]))
        sources[p] = dict(path=str(base / p), sha256=k.sha(raw), lf_sha256=k.sha(normalized))
        (OUT / 'authority' / Path(p).name).write_bytes(raw)
    assert sources[paths[0]]['lf_sha256'] == '4f90d19fc742ab616301b6b4121880f76c75faaeb1f606c8190a84853d8b3e0e'
    k.save('authority-sources.json', sources)
    compiled = json.loads((OUT / 'raw/main-context.stdout').read_bytes())
    # Mechanical extraction from only the delivered package; interpretation is manual.
    material = dict(package_sha256=k.sha((OUT / 'raw/main-context.stdout').read_bytes()),
                    envelope=compiled['context']['envelope'], sources=[])
    for source in compiled['context']['sources']:
        copied = json.loads(json.dumps(source))
        if 'content_base64' in copied['data']:
            raw = base64.b64decode(copied['data']['content_base64'])
            copied['decoded_utf8'] = raw.decode('utf-8')
            copied['decoded_sha256'] = k.sha(raw)
        material['sources'].append(copied)
    k.save('package-only-material.json', material)
    exact_diff = k.run('implementation-patch-full-recomputed', ['git', 'diff', k.BASE, k.SOURCE]).stdout
    supplied = (ROOT / 'docs/work7/evidence/implementation.patch').read_bytes()
    unchanged = k.run('released-and-old-contracts-diff', ['git', 'diff', '--name-only', k.BASE, k.CANDIDATE,
        '--', 'src/zaratustra/core/migrations.py', *[f'src/zaratustra/core/migration_v{i}.py' for i in range(2, 6)],
        'validation.config', 'docs/work1', 'docs/work2', 'docs/work3', 'docs/work4', 'docs/work5', 'docs/work6']).stdout
    assert not unchanged
    # The author's patch is the complete base-to-source diff, including plan/docs.
    assert exact_diff == supplied
    k.save('diff-verification.json', dict(source_diff_sha256=k.sha(exact_diff), supplied_patch_sha256=k.sha(supplied),
        source_patch_equal=exact_diff == supplied, released_and_old_contracts_unchanged=True))
    for work in (6, 7):
        archived = ROOT / f'docs/work{work}/evidence/retained-trial.zip'
        manifest = json.loads((ROOT / f'docs/work{work}/evidence/retained-trial-manifest.json').read_bytes())
        with zipfile.ZipFile(archived) as z:
            actual_files = {i.filename: k.sha(z.read(i)) for i in z.infolist() if not i.is_dir()}
            actual_dirs = sorted(i.filename for i in z.infolist() if i.is_dir())
        assert actual_files == manifest['files']
        assert actual_dirs == sorted(manifest['directories'])
        k.save(f'author-work{work}-manifest-verification.json', dict(files=len(actual_files),
               directories=len(actual_dirs), exact_manifest_match=True, archive_sha256=k.sha(archived.read_bytes())))
    with tarfile.open(ROOT / 'dist/zaratustra-0.7.0.tar.gz') as archive:
        checked = []
        for m in archive.getmembers():
            if '/src/zaratustra/' in m.name and m.name.endswith('.py'):
                relative = m.name.split('/src/', 1)[1]
                assert archive.extractfile(m).read() == (ROOT / 'src' / relative).read_bytes()
                checked.append(relative)
    k.save('build-artifacts.json', dict(wheel=k.sha((ROOT / 'dist/zaratustra-0.7.0-py3-none-any.whl').read_bytes()),
        sdist=k.sha((ROOT / 'dist/zaratustra-0.7.0.tar.gz').read_bytes()), sdist_source_files=checked))

def author_restore():
    py = TRIAL / 'venv/Scripts/python.exe'
    zara = TRIAL / 'venv/Scripts/zara.exe'
    base = TRIAL / 'accepted-work7-restore'
    before = k.inventory(base)
    for label, args in [('version', ['--version']), ('status', ['status', base / 'workspace']),
                        ('init-read', ['init', base / 'workspace']), ('projections', ['projections', 'status', base / 'workspace'])]:
        k.run('author-restore-' + label, [zara, *args], cwd=TRIAL / 'unrelated-cwd')
    k.run('author-restore-read', [py, '-I', Path(__file__).with_name('restore_reader.py'), base], cwd=TRIAL / 'unrelated-cwd')
    after = k.inventory(base)
    assert before == after
    k.save('author-restore-verification.json', dict(all_files_and_directories_unchanged=True,
          files=len(before['files']), directories=len(before['directories']),
          exact_context_sha256=k.sha((OUT / 'raw/author-restored-context.stdout').read_bytes())))

def retain_restore():
    inventory = k.inventory(TRIAL, ('venv', '.venv', '__pycache__'))
    archive = OUT / 'runtime-bundle.zip'
    assert not archive.exists()
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
        for d in inventory['directories']:
            z.writestr(d + '/', b'')
        for p in inventory['files']:
            z.write(TRIAL / p, p)
    k.save('runtime-manifest.json', dict(archive=archive.name, sha256=k.sha(archive.read_bytes()),
        exclusions=['venv', '.venv', '__pycache__'], **inventory))
    restore = ROOT / '_scratch/g5-work7-restore-20260909'
    assert not restore.exists()
    # Exercise the documented Windows extraction mechanism; preserve directory entries.
    ps = "Expand-Archive -LiteralPath '" + str(archive).replace("'", "''") + "' -DestinationPath '" + str(restore).replace("'", "''") + "'"
    k.run('own-restore-expand', ['pwsh', '-NoProfile', '-Command', ps])
    def compare():
        actual = k.inventory(restore, ('venv', '.venv', '__pycache__'))
        assert actual['files'] == inventory['files']
        assert actual['directories'] == inventory['directories']
    compare()
    k.run('own-restore-venv', ['uv', 'venv', '--python', '3.13.7', restore / 'venv'])
    py = restore / 'venv/Scripts/python.exe'
    k.run('own-restore-install', ['uv', 'pip', 'install', '--offline', '--python', py,
          '-r', restore / 'accepted-work7-restore/runtime-requirements.txt',
          restore / 'accepted-work7-restore/zaratustra-0.7.0-py3-none-any.whl'])
    k.run('own-restore-pip-check', ['uv', 'pip', 'check', '--python', py])
    k.run('own-restore-restart', [py, '-I', Path(__file__).with_name('runtime.py'), 'restart',
          restore / 'main', 'own-restored'], cwd=restore / 'unrelated-cwd')
    assert (OUT / 'raw/own-restored-context.stdout').read_bytes() == (OUT / 'raw/main-context.stdout').read_bytes()
    compare()
    installed = {}
    for p in (ROOT / 'src/zaratustra').rglob('*.py'):
        relative = p.relative_to(ROOT / 'src')
        value = k.sha((restore / 'venv/Lib/site-packages' / relative).read_bytes())
        assert value == k.sha(p.read_bytes())
        installed[relative.as_posix()] = value
    k.save('own-restore-verification.json', dict(path=str(restore), file_count=len(inventory['files']),
        directory_count=len(inventory['directories']), all_bytes_and_dirs_equal_before_and_after=True,
        source_installed_equal=installed, context_sha256=k.sha((OUT / 'raw/own-restored-context.stdout').read_bytes()),
        restore_data_inventory=k.inventory(restore, ('venv', '.venv', '__pycache__'))))

def finish():
    identity = json.loads((OUT / 'candidate-identity.json').read_bytes())
    changed = [p for p, digest in identity['files'].items() if k.sha((ROOT / p).read_bytes()) != digest]
    assert not changed
    k.save('candidate-preservation.json', dict(candidate=k.CANDIDATE, unchanged_tracked_file_count=len(identity['files']), changed=changed))
    k.preservation('after')
    # Read-only inventory of retained data and of this entire review; excludes itself.
    content = k.inventory(OUT, ('__pycache__',))
    for name in ('review-manifest.json', 'review-bundle.zip'):
        content['files'].pop(name, None)
    k.save('review-manifest.json', dict(candidate=k.CANDIDATE, task_id=identity['physical_task_id'], home='solmax', **content))
    archive = OUT / 'review-bundle.zip'
    assert not archive.exists()
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
        for d in content['directories']:
            z.writestr(d + '/', b'')
        for f in content['files']:
            z.write(OUT / f, f)
        z.write(OUT / 'review-manifest.json', 'review-manifest.json')
    print('review-bundle sha256', k.sha(archive.read_bytes()), flush=True)

if __name__ == '__main__':
    k.guard()
    {'authority': authority, 'author-restore': author_restore, 'retain-restore': retain_restore, 'finish': finish}[sys.argv[1]]()
