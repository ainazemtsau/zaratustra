# M0 Zaratustra — основание WHAT, 2026-09-07

session: s-solmax-zaratustra-m0-converge-20260907
call: c-solmax-zaratustra-m0-converge-20260907
node: g-zara-m0-continuity
base: e19ae953268db95c30364e278d80a1b75dc0a0aa
triage: heavy — converge ON — because ошибочный контракт mutation/authority/context меняет достоверность всего первого сценария; после накопления состояния его замена затрагивает записи, migrations и evidence, безопасный stub не доказан.
imported: [plan-20260905, s-solmax-zaratustra-plan-frame-20260907, s-solmax-zaratustra-plan-map-20260907, owner-ack:solmax-charter-20260907-accepted, owner-ack:solmax-plan-conforming-20260907]
open_rows: 9
owner_open_rows: 0
canon_proposed: [G1, G2, G3, G4, G5, G6, G7, G8, G9]

Это основание для следующего converge-arch. Исполнимость и product done не доказаны; node остаётся parked, bet/tasks/tracks отсутствуют. Технический review и оба помощника дают рекомендации; собственные выводы этой ноги не являются внешним evidence.

## Источники и импорт уже решённого

Все пути ниже от корня Direction OS. P/C/M и owner receipts существовали до этой ноги.

| Ключ | Точный источник | Импорт и предел authority |
|---|---|---|
| P / plan-20260905 | live/solmax/work/zaratustra-architecture-plan-2026-09-05.md; SHA-256 4f90d19fc742ab616301b6b4121880f76c75faaeb1f606c8190a84853d8b3e0e | План §§0–44 сохраняется дословно. Основание принятия: live/solmax/knowledge/zaratustra-plan-2026-09-05-authority.md — «надо вот проект делаем точно по этому плану, который тебе ниже». |
| C / frame | live/solmax/CHARTER.md; SHA-256 6fb467b8ef2e510c846edf7a453b4739a8f042b8fe37f08972b562cb260bd9f6; live/solmax/history/2026-09-07-s-solmax-zaratustra-plan-frame-20260907.md | Весь устав и root приняты «принимаю»: live/solmax/work/zaratustra-charter-approval-2026-09-07.md, owner-ack:solmax-charter-20260907-accepted. |
| M / map | live/solmax/work/zaratustra-plan-map-2026-09-07.md; live/solmax/history/2026-09-07-s-solmax-zaratustra-plan-map-20260907.md | Каркас «согласен»; M0 и дальнейшие цели приняты после сверки по делегации. Критерии M0 — M:40–45 и live/solmax/cards/g-zara-m0-continuity.md, done_when. |
| A / delegation | live/solmax/knowledge/zaratustra-plan-conforming-approval-2026-09-07.md; live/solmax/work/zaratustra-map-owner-approval-2026-09-07.md; SHA-256 receipt 6e1e6002e15d9e70ec5b9cfeca8e4bbfacda3023ada209c7a5b612798baa634b | owner-ack:solmax-plan-conforming-20260907. «Если нет каких-то расхождений с планом, то я как бы подтверждаю, да, ты можешь идти.»; «В принципе все вот эти моменты авто подтверждать, если не идет какое-то рассогласование плана». При расхождении: «если какие-то есть с ним расхождения, ты отдельно посвяти». |
| R / review | live/solmax/work/zaratustra-plan-transition-review-2026-09-05.md:63–131 | Технические замечания и предложенные проверки; не самостоятельная authority алгоритма, нового acceptance или факта выполнения M0. |
| H / evidence limits | live/solmax/knowledge/selftest-must-poison-the-suspected-axis.md; live/solmax/knowledge/first-process-creator-live-proof-boundary.md | Самопроверка доказывает только проверяемую ось; единичный показ не доказывает recurring reliability или независимость процессов. Эти знания не добавляют будущие результаты к M0. |

Все импортированные ответы born-closed: выбранные SQLite/CLI/стек, M0-first, Work 1–8, реальный показ, чистый чат, границы M1+ не возвращаются владельцу на повторный выбор. Старое blanket CORE.md/converge OFF и текстовая Wave 0 не применяются: P§44, A:32–35, M «Ближайшее продолжение». Triage выше — собственная классификация стоимости ошибки, не слова владельца и не результат проверки продукта.

## §GLOSSARY

Термины извлечены из done_when и линз. Включены только обнаруженные вторые чтения; ссылки на термин разрешены лишь для названных свойств.

| Term | meaning-here | load-bearing properties | competing-readings |
|---|---|---|---|
| G1 Work | Ограниченная единица работы, открываемая по свежему состоянию. source: P§§1.4,3.2,7 | scope: отдельный исполнительный контекст; fresh: актуальный open; terminal: выполненная/неактуальная Work не запускается снова | Пользовательский разговор может быть длиннее одной Work; replay операции не равен новому запуску Work. |
| G2 чистый чат | Отдельный новый чат продолжает по актуальному пакету. source: C SC1; P§§28,42 | input: только актуальный пакет; behavior: правильно называет решение/основание/revision/результат/следующий шаг без пересказа | Наличие пяти полей или новый subprocess не доказывает понимание новым чатом. |
| G3 повтор Handoff | Повторное предъявление той же операции не создаёт второй эффект. source: P§5:357, §28:1186; C SC1 | effect: один эффект | Возврат прежней квитанции, тип ответа и payload collision не определены этим свойством; W19 open. |
| G4 revision | Проверяемая версия состояния, а не timestamp текста. source: P§§4.1,5,7,10.2 | stale: устаревшее изменение не применяется молча, conflict; context: manifest называет переданные revisions | Старый pasted Next Call не является текущей истиной; точная гранулярность revision — W22/W24 open. |
| G5 согласованность при сбое | Authoritative состояние остаётся согласованным, projections восстанавливаются. source: P§§4–5,28; C Pre-mortem 3 | db: mutation/event/receipt одной DB-транзакцией; files: отдельная публикация; projection: пересоздаваемое представление | Git commit не транзакция Core; мгновенная атомарность DB+всех файлов не объявлена. Recovery/видимость — W20 open. |
| G6 квитанция результата | Свидетельство принятой mutation с revision и происхождением. source: P§5, §41 Work 7; C Pre-mortem 3 | evidence: связана с результатом/изменением; persistence: в DB-транзакции | Не равна разрешению владельца; исторический receipt не выдаёт новых прав. |
| G7 owner-mediated receipt | Доверенное получение Handoff от владельца для безопасного внутреннего изменения. source: P§6.1; C Constraints «Власть» | channel: trust приходит от канала; external: отдельное точное разрешение external/spend/irreversible | `approved: true` и owner_instruction внутри JSON сами не дают authority. Механизм — W21 open. |
| G8 Process | Один вымышленный процесс для M0; предметные исключения Core запрещены. source: P§§2,8,28–30,41 | fictional: тестовые данные; isolation: чужой контекст исключён; generic: общая семантика Core | Реальный показ владельцу не равен первому реальному Process M2; isolation test не требует полноценного M1. |
| G9 projections/context | Производный read-only вид и ограниченный актуальный пакет конкретной Work. source: P§§4.4,7,10 | derived: не вторая истина; fresh: revisions; scope: допустимые namespace/authority/budget и manifest | Загрузка всей истории или доверие старой projection не заменяют work open. |

## §WHAT

`answered` означает, что требование уже принято внешним источником, а не выполнено продуктом. W01–W06 содержат точный текст шести принятых критериев, без добавления HOW. Shape переносит acceptance дословно. W07–W18 — уже принятые границы. W19–W27 — вопросы этой ноги, ни один не объявлен новым acceptance.

| ID | Статус / тег | Требование или вопрос | Основание / ответчик |
|---|---|---|---|
| W01 | answered; acceptance | В выбранной пустой папке создаются workspace, один вымышленный Process и Work. Состояние сохраняется между запусками. | source: M M0.1; C SC1; P§§4.1,26,28,41 Work 1–2. |
| W02 | answered; acceptance | Владелец проходит цепочку: обсуждение в ChatGPT → принятый результат через Handoff → импорт в Codex → записанный результат с квитанцией → следующая Work. Импорт поддерживает file/stdin. | source: M M0.2; C SC1; P§§6,28,41 Work 5/7/8,42. |
| W03 | answered; acceptance | Отдельный чистый чат получает только актуальный пакет контекста и правильно называет решение, его основание, действовавшую revision, полученный результат и следующий шаг. | source: M M0.3; C SC1; P§§28,42; →G2[input,behavior]. |
| W04 | answered; acceptance | Проверки подтверждают: повтор Handoff даёт один эффект; устаревшая revision вызывает conflict; сбой сохраняет согласованность; операция без прав отклоняется; чужой контекст не попадает в Work. | source: M M0.4; C SC1; P§28; →G3[effect], →G4[stale], →G5[db,files,projection], →G8[isolation]. |
| W05 | answered; acceptance | Журнал позволяет восстановить, кто, на каком основании и что изменил. Производные представления пересоздаются из сохранённого состояния; сценарий проходит без ручной правки DB/state Markdown, предметных исключений в Core и доверия устаревшему контексту. | source: M M0.5; C SC1/Constraints; P§§4.4,28–29,42. |
| W06 | answered; acceptance | После Work 8 владельцу предъявлен работающий сценарий, выполнение остановлено перед M1. | source: M M0.6; C SC1; P§41:1563–1567. |
| W07 | answered; boundary | SQLite — operational truth; versioned/immutable artifacts с SHA-256, transactional active revision; Git optional; projections пересоздаются. | source: P§4; C Constraints «Единое состояние». |
| W08 | answered; boundary | Единый Mutation API проверяет управляемые изменения; mutation/event/receipt фиксируются одной DB-транзакцией, публикация файлов отдельна. | source: P§§3.3,5; C Pre-mortem 3:192–194. |
| W09 | answered; boundary | Handoff не выдаёт себе authority; безопасные внутренние изменения имеют trusted owner-mediated receipt; external/spend/irreversible требуют точного отдельного разрешения. | source: P§6.1; C Constraints «Власть»; →G7[channel,external]. |
| W10 | answered; boundary | work open сверяет текущее состояние; выполненная/неактуальная Work не запускается повторно. | source: P§7; →G1[fresh,terminal]. |
| W11 | answered; boundary | Context ограничен разрешёнными источниками, актуальными revisions и budget; manifest называет реально переданное, включая skills/tools/memory при наличии. | source: P§10; C Constraints «Одна ограниченная Work»; →G9[fresh,scope]. Полная personalization этим не добавлена. |
| W12 | answered; boundary | Work 1–8 идут строго последовательно: foundation → records → mutation → artifacts/projections → handoff → context → result → end-to-end; предел заканчивается показом и остановкой. | source: P§41; C Constraints «Первый предел»; M «Порядок». Это продуктовый порядок, не восемь заведённых Direction задач. |
| W13 | answered; boundary | M1+, автоматическая интеграция Proof B, внешний установщик и полный переезд не prerequisite M0; CLI доказывается до MCP, после Work 8 интеграция сама не запускается. | source: C SC1–4; P§§25,28–41; M «Порядок», transport-proof/independent-install/full-migration boundaries. |
| W14 | answered; boundary | Стек: Python 3.13, uv, sqlite3, Pydantic v2, pytest, ruff, SHA-256, явные migrations; перечисленная в §27 тяжёлая инфраструктура не нужна первой реализации. | source: P§27; C Canonical repos. Доступность/версии инструментов здесь не проверялись и не замораживаются как runtime fact. |
| W15 | answered; boundary | Один публичный продукт без личного содержимого; пользователь сам выбирает отдельную workspace; один пользователь на workspace. | source: P§26; C Constraints «Один пользователь», «Один публичный продукт». |
| W16 | answered; boundary | До переезда Direction OS остаётся рабочим местом; Zaratustra не пишет в его live state. Product implementation начинается лишь после законного перехода состояния. | source: P§44; C Mission/Constraints «Граница Direction OS». |
| W17 | answered; boundary | Personalization/router/frontend/autonomy вне M0; fine-tuning и оптимизация одобрения запрещены. Примеры будущих процессов/инструментов не становятся текущими требованиями. | source: P§§1,14–16,28,32–39,43; C Constraints; M. |
| W18 | answered; boundary | Делегация не задаёт appetite, deadline, WIP, новый денежный бюджет/приоритет, первый реальный Process или внешние права. Недостающие owner-owned choices решает владелец в соответствующем этапе. | source: A:25–30; C Constraints «Деньги», «Приоритет», Risk posture; M M2/independent-install/full-migration. |
| W19 | open; architecture | Как связаны ответ на duplicate, stale revision, завершённая Work, изменённый payload под тем же id и доступ к прежнему receipt? | answerer: PLAN; следующий converge-arch готовит сравнение. Источник вопроса P§§5,7,28 vs рекомендация R:65–73. rewrites: изменение принятого replay-контракта после реализации затронет importer, receipts, failure tests и, возможно, migrations; стоимость ≤1 дня не доказана. Буквальный порядок §5 не переставлен; такой выбор требует показать расхождение владельцу. |
| W20 | open; architecture | Где граница commit/видимости результата при сбое записи artifact, DB commit и rebuild; как восстанавливается согласованный результат без второго эффекта? | answerer: PLAN; converge-arch готовит сравнение. Источник вопроса P§§4–5,28, C Pre-mortem 3, R:75–98. rewrites: durable references/recovery/evidence, потенциально дорого после накопления state; дешёвым stub не названо. |
| W21 | open; architecture | Как trusted caller подтверждает получение и связывает authority с Work/содержимым/scope; кто вправе читать прежний receipt? | answerer: PLAN; converge-arch готовит сравнение. Источник вопроса P§6.1, R:100–108. rewrites: trust boundary/import paths и permissions tests; ошибка затрагивает все mutations, стоимость ≤1 дня не доказана. Новых полномочий нет. |
| W22 | open; architecture | Как work open/context manifest связываются с согласованным свежим состоянием, в том числе после сбоя rebuild и при нехватке context budget? | answerer: PLAN; converge-arch готовит сравнение. Источник вопроса P§§4.4,7,10, R:93–98. rewrites: snapshot/context contract и его проверки; свойства freshness/scope/budget нельзя вырезать как формат. |
| W23 | open; → PLAN | Какими сохранёнными входом и ответом предъявить поведение действительно отдельного чистого чата по пяти принятым фактам? | answerer: PLAN; source вопроса C SC1, P§§28,42, R:110–114. rewrites: протокол демонстрации и повтор Work 8 без изменения продукта, предварительная оценка ≤1 рабочего дня при доступной поверхности; при недоказуемой чистоте вернуть blocker, не подменять acceptance. Конкретный способ и данные ещё не приняты. |
| W24 | open; → PLAN | Какие локальные форматы и параметры реализуют закрытые свойства: schema/CLI flags, transaction mode/BUSY handling, id/fingerprint, timestamps, layout и cleanup? | answerer: PLAN. Источник параметров P§§4–7,10,27; рекомендации R:65–108. rewrites: ограниченный прототип и его тесты в соответствующей Work, оценка ≤1 дня до зависимости внешних потребителей; изменения семантики/storage migration возвращаются W19–W22. Ни BEGIN IMMEDIATE, ни конкретная strict-schema политика не стали owner verdict. |
| W25 | open; → PLAN | Какие минимальные fictional fixtures и отрицательный чужой контекст проверяют M0, не добавляя второй полноценный Process? | answerer: PLAN; source вопроса P§§28,30,41; R:128–129 предлагает sentinel. rewrites: тестовые данные и повтор проверки, оценка ≤1 дня; реальный Process/продуктовые требования не выбираются. |
| W26 | open; → PLAN | Какое доступное имя/место нового product repo и установочный layout использовать при bootstrap? | answerer: PLAN/bootstrap; source вопроса C Canonical repos, P§26, R «Основание и граница». rewrites: scaffold/metadata/docs до публикации, оценка ≤1 дня; после внешних зависимостей пересмотреть. Факт существования repo/доступность имени не заявлены; внешние права не добавлены. |
| W27 | open; architecture | Какие только уже требуемые M0 выходы/внутренние границы понадобятся следующим потребителям и что ещё нельзя заморозить без их основания? | answerer: PLAN; converge-arch ведёт TREE-проверку по E1–E12 ниже. rewrites: расширение публичного Core contract до consumer evidence может затронуть следующие milestones; дешёвым не названо. Новые future prerequisites запрещены W13. |

## Node-on-paper и покрытие

Установленный продукт сохраняет решение и продолжает ограниченную Work через Handoff и актуальный контекст другого чата →W01–W03, W10–W11. Достоверность поддерживают управляемые изменения, права, revisions, восстанавливаемые artifacts/projections и audit →W04–W05, W07–W09. Первый предел заканчивается реальным показом после последовательных Work 1–8 →W06,W12; последующие этапы не входят в этот допуск →W13,W17–W18. Конкретные replay/recovery/trust/snapshot контракты пока open →W19–W22, answerer PLAN; протокол демонстрации open →W23, answerer PLAN.

converge_coverage:

| Критерий / линза | covered_by |
|---|---|
| Node done_when 1/2/3/4/5/6 | W01 / W02 / W03 / W04 / W05 / W06 — тексты дословны; вопросы HOW отдельно W19–W26 |
| Continuity | W02–W05,W10–W11; G2/G9; open W22–W23 |
| Extensibility | W05,W13,W15; G8; open W25,W27; M1 не закрывается M0 |
| Agent-buildability | W12,W14; open W19–W26; реальные права/свежесть не safe-to-stub |
| Actual use | W02–W03,W06; реальный показ на fictional данных; M2/полный переезд отделены W13,W18 |
| Privacy / authority / integrity | W04–W05,W07–W11,W15–W17; open W19–W22 |
| Cost discipline | W14,W18; расход/скорость/экономия не заявлены; open W26 |

Следующие связи — импорт границ из M/P/C для следующего DECLARE, а не подписанные новые §CONTRACTS. Входящего build prerequisite от M1+ у M0 нет. E1–E12 покрывают всех остальных детей принятой карты; конкретные интерфейсы остаются W27 open, answerer PLAN. Для каждой строки source: M, точная карточка того же id; обозначенный P/C уточняет основание.

| Edge | Узел / направление и условие | covered_by |
|---|---|---|
| E1 | M0 → g-zara-m1-modularity: foundation для Process contract после отдельного допуска M1; P§30 | W05,W12–W13,W27 |
| E2 | M0 → g-zara-m2-real-use: Work/context/results для выбранного настоящего потока после M0/M1; P§31 | W01–W03,W13,W18,W27 |
| E3 | M0 → g-zara-m3-memory: сохранённые решения/события/происхождение при допуске памяти, не полный memory engine в M0; P§32 | W05,W07–W08,W17,W27 |
| E4 | g-zara-m4-personal-evals: реальные случаи появляются позднее; M0 не поставляет готовый personal eval suite; P§33 | W13,W17,W27 |
| E5 | g-zara-m5-routing: позднее использует evidence evals, не условие Work M0; P§34 | W13–W14,W17–W18,W27 |
| E6 | g-zara-m6-assistant: status/context Core для будущего общего обзора, план дня не M0; P§35 | W05,W11,W13,W27 |
| E7 | g-zara-m7-consolidation: накопленные события/материал позднего использования, без reflection сейчас; P§36 | W05,W13,W17,W27 |
| E8 | M0 → g-zara-m8-frontend: тот же Core/Mutation API для будущих views, UI позже; P§§1.6,37 | W07–W08,W13,W17,W27 |
| E9 | g-zara-m9-autonomy: Work/context/permissions позже дополняются verification/routing и отдельной делегацией; P§38 | W09–W13,W17–W18,W27 |
| E10 | M0 → g-zara-transport-proof: Handoff/Core семантика после доказанного CLI и до масштабирования; P§§25,40 Proof B | W02,W08–W10,W13,W19,W21,W27 |
| E11 | M0 → g-zara-independent-install: установленный сценарий готовит отдельную внешнюю установку/обновление; C SC4 | W01,W13–W15,W26–W27 |
| E12 | g-zara-full-migration: готовые процессы/план дня и отдельный допуск, тридцатидневное окно не M0; C SC3 | W13,W16,W18,W27 |

## Исследовательские дети — свидетельства этой ноги

По converge steps 2/3 исполнены два read-only child: `/root/m0_miner` (explorer) и `/root/m0_strategic_search` (researcher), роли `.codex/agents/explorer.toml` и `.codex/agents/researcher.toml`. Это in-session source mining/research, не внешнее свидетельство и не binding G5. Miner проверил шесть критериев, шесть линз, вторые чтения и границы будущих результатов; источники сведены в таблицы выше.

Strategic_search рассмотрел буквальный порядок, duplicate fast path, отдельное чтение receipt, reopen завершённой Work, общую атомарность DB/files, publish→commit→rebuild, Git transaction, trust из JSON/caller, криптографию, тест вместо чата и реальный чистый чат. После refutation оставлены четыре совместимые группы кандидатов (могут сочетаться; не четыре новых owner verdict):

| Кандидат / статус | Почему сохранён / цена |
|---|---|
| Буквальный §5 + отдельно определяемый replay response; INFERRED, W19 open | P:347–357, §28 требуют один эффект и stale conflict, а не обязательно прежний receipt. Потеря первого ответа оставляет неопределённость для клиента. Отдельное разрешённое receipt-read — кандидат, не добавленное требование. |
| Разделить authoritative commit и восстанавливаемые projections; INFERRED, W20 open | P§4, C Pre-mortem 3 уже разделяют обязанности. Prepublish/cleanup/recovery — рекомендации R:75–98; остаются orphan/видимость результата/freshness риски. |
| Trust от caller отдельно от Handoff; INFERRED, W21 open | P§6.1 задаёт принятую границу. Точный carrier/binding не выбран; сам факт запуска executable не доказывает слово владельца. |
| Сохранить пакет и фактический ответ отдельного чистого чата; INFERRED, W23 open | C SC1, P§§28,42 требуют реального поведения. Нужно доказать чистоту входа; наличие manifest или теста этого не заменяет. |

Отвергнуты как уже принятые решения: обязательный duplicate-first/old receipt (расходится с буквальным P§5 и M:423–428); restart terminal Work (P§7); Git как транзакция Core (P§4.3); trust из `approved: true` (P§6.1); технический тест вместо чистого чата (C Constraints); MCP/полный второй Process как prerequisite (W13). Криптографическая инфраструктура не объявлена обязательной или запрещённой: её необходимость не доказана для M0.

Точная обнаруженная разница — порядок §5 против предложения R:65–73. Непримиримое противоречие внутри принятого acceptance не доказано: ответ conflict без второго эффекта может сохранять буквальные гарантии. Это собственный вывод для постановки W19, не выбранная семантика реализации. Любая предложенная перестановка §5 или ослабление acceptance предъявляется владельцу как конкретное расхождение по A; сейчас ничего из этого не утверждено.

## §SIGNOFF

Define — G1–G9: accepted under owner delegation after plan check, 2026-09-07, owner-ack:solmax-plan-conforming-20260907. Сверены только перечисленные свойства с P/C/M; competing-readings показывают границы, не добавляют требования. Основание: «Если нет каких-то расхождений с планом, то я как бы подтверждаю, да, ты можешь идти.»; «В принципе все вот эти моменты авто подтверждать, если не идет какое-то рассогласование плана». Это применение существующих слов к точному §GLOSSARY, а не новая личная подпись владельца.

Resolve — W01–W18: accepted under owner delegation after plan check по той же квитанции; W01–W06 дословны принятому M0, W07–W18 импортированы из названных источников. W19–W27 приняты лишь как открытый список с ответчиком PLAN, без утверждения предложенных ответов. Новых owner-owned forks для закрытого WHAT не найдено. Если нужное решение отсутствует в плане или меняет его, ответчик обязан вернуть конкретный вопрос владельцу; его будущие слова не выдуманы. Первый реальный Process, внешняя установка, размеры будущих scopes и новые расходы остаются будущими owner choices, W18.

## Close / route

converge WHAT done: coverage полное в пределах прочитанных критериев/границ; acceptance answered на внешних источниках, остальные девять вопросов named open. Полнота продукта проверяется реализацией, не этим документом. G5 product PASS отсутствует; внутрисессионные помощники его не заменяют.

Единственный successor: c-solmax-zaratustra-m0-converge-arch-20260907, to session, play converge-arch, тот же parked node. Основание — heavy triage и W19–W22/W27; низкорисковые детали W23–W26 остаются PLAN. После архитектурной ноги нужен свежий converge-verify перед shape. Продуктовый executor CALL здесь не выдаётся.

## §CONTRACTS — converge-arch 2026-09-07

session: s-solmax-zaratustra-m0-converge-arch-20260907
base: 83fd8dc432cff80db40ebbb04575349fcb9d0358
contract_coverage: every TREE interaction → a §CONTRACTS entry
arch_open: 5 — W19,W20,W21,W22,W27
open_rows: 9 — W19–W27; answerer: PLAN (W26: PLAN/bootstrap)
owner_open_rows: 0
arch_in_context_only: PASS

Это дополнение завершает архитектурную подготовку, на которую выше ссылался исходный converge. Его прежний successor converge-arch уже возвращается этой ногой; актуальный единственный successor — c-solmax-zaratustra-m0-converge-verify-20260907. Исходные §GLOSSARY/§WHAT и их signoff сохранены. «Следующий converge-arch готовит сравнение» в W19–W22 теперь разрешается в work/converge-g-zara-m0-continuity-arch.md, одноимённые разделы; ответы этих строк остаются open.

Статус source-backed у контракта означает импорт уже принятого поведения из P/C/M, не факт реализации. Источники P/C/M/A определены выше; R — только технический input. Для внутренних seams read_by — обе названные стороны при проектировании M0 и изменении общей границы; для внешних E — M0 и точный будущий node при его converge. Это proposal двухстороннего canon для review, без записи в knowledge. Ни один новый consumer не получает заранее выбранный формат или механизм.

### Внутренние seams — поведение первого сценария

| ID | Потребитель ← производитель; событие | Требуемый поток / ограничение | Основание и открытая часть |
|---|---|---|---|
| C01 | Mutation ← import/исполнитель; подача Handoff или результата | Намерение изменения, связанная Work, основание и ожидаемое состояние проходят общую проверку управляемых изменений; текст входа сам себе прав не выдаёт. | source: P§§3.3,5–6,24–25; W02,W08–W09. Trust и replay open W19/W21. |
| C02 | Mutation и Context ← Work/authority; попытка записи или чтения | Действующая область разрешений ограничивает доступные действия и сведения; возможность исполнителя и ссылка на объект не являются выдачей прав. | source: P§§1.5,3.4,6.1,10.1,22; W09,W11. Binding caller/проверки связей open W21/W22. |
| C03 | Audit/исполнитель ← Mutation/state; принятие изменения, конфликт или отказ | Принятый результат, его действовавшая revision и происхождение восстанавливаются из сохранённой истории; повтор не повторяет эффект, stale не применяется молча, отказ без прав не даёт разрешённого изменения. | source: P§§5,28,42; C SC1/Pre-mortem 3; W04–W05,W08. Единица эффекта, ответы replay/terminal, commit/recovery open W19/W20. |
| C04 | Mutation/Context ← Artifact; регистрация или использование содержимого | Изменение ссылается на определённую версию содержимого с проверяемой целостностью и происхождением; обновление действующей ссылки сохраняет согласованность. | source: P§§4.2,5,10; W05,W07. Недоступность/подмена bytes и восстановление open W20/W22. |
| C05 | Читающая поверхность ← State/projection; чтение представления после изменения или восстановления | Представление показывает происхождение по revision и воспроизводится из сохранённого состояния; само не становится authority изменения. | source: P§§1.6,4.4,5,7; W05,W07,W10. Публикация/свежесть и время генерации open W20/W22/W24. |
| C06 | Исполнитель ← Context/Work; открытие Work | Ограниченный актуальный контекст с разрешёнными основаниями и manifest переданного; выполненная или неактуальная карточка не запускает старую Work снова. | source: P§§1.4,7,10,28–29; W03,W10–W11. Снимок, зависимости revisions, бюджет и фактическая передача open W22/W23. |
| C07 | Продолжение ← Result/Work; принятие результата и открытие следующей работы | Сохранённый результат связан со следующим шагом так, чтобы отдельный чистый чат восстановил решение, основание, revision, результат и продолжение без пересказа. | source: P§§7,28,41 Work 7–8,42; C SC1; W02–W03. Создание/связь следующей Work в границе эффекта open W19/W20; evidence чата W23. |
| C08 | Первая Work ← workspace/Process; запуск в выбранной пустой папке | Созданные исходные записи сохраняются между запусками; один fictional Process использует общую семантику Core и ограничивает свой контекст. | source: P§§2–4,26,28–29,41 Work 1–2; W01,W05,W15. Исходная authority до первой Work open W21; fixtures W25; bootstrap metadata W26. |

Механизмы каждого seam → PLAN через указанные W-id. rewrites: W19–W22 затрагивают state/receipts/permissions/context и потенциальные migrations; W23–W26 имеют отдельную цену в §WHAT; новая будущая зависимость → W27. Способ вызова, схемы, размещение, transaction mode и cadence сюда не включены.

### TREE: все 12 остальных детей карты

Сверены M «Карточки», §§16–25 порядка, P§§30–40 и текущие node payloads. На вход M0 не требуется выход ни одного будущего узла. Непостроенного обязательного producer у M0 нет. Направление стрелки ниже — будущее использование уже требуемого результата или явное отсутствие прямого M0-контракта; оно не означает запуск будущего этапа сейчас.

| Edge / consumer | Поток и событие будущего использования | Диспозиция сейчас / source |
|---|---|---|
| E1 g-zara-m1-modularity | M0 → M1: общие записи Process/Work, состояние, контекст и управляемые изменения при отдельном допуске второго отличающегося Process. | source: M M1; P§§8,30; C SC2; C01–C08. Минимум M0 source-backed; полнота Process contract и общий обзор обоих — M1, open W27. |
| E2 g-zara-m2-real-use | M0 → M2: продолжение Work/результата/контекста при переходе к выбранному настоящему потоку после M0/M1. | source: M M2; P§31; C SC3; C06–C07. Настоящий Process выбирается на своём этапе; никаких данных M2 для M0, open W27. |
| E3 g-zara-m3-memory | M0 → M3: сохранённые решения, события и происхождение как основания будущей памяти при её допуске. | source: M M3; P§§11–12,32; C03–C04. Кандидаты, supersession и полный memory engine не поставляются M0; будущая детализация open W27. |
| E4 g-zara-m4-personal-evals | Прямого необходимого контракта от M0 не установлено: M4 требует реальные повторяющиеся ошибки позднего использования. | source: M M4; P§33. Core failure evidence M0 не объявлен private personal suite; будущий ответчик PLAN/M4, open W27. |
| E5 g-zara-m5-routing | Прямого необходимого контракта от M0 не установлено: сравнение исполнителей потребляет eval evidence при допуске routing. | source: M M5; P§§20–21,34. Registry/router и обещанная экономия в M0 отсутствуют; PLAN/M5, open W27. |
| E6 g-zara-m6-assistant | M0 → M6: достоверное состояние Work/Process как часть будущих status capsules после отдельного допуска assistant. | source: M M6; P§§8,35; C05–C06. Полные capsules, общий user context, план дня и cross-process reasoning не M0; open W27. |
| E7 g-zara-m7-consolidation | Прямого необходимого контракта от M0 не установлено: консолидация получает накопленный реальный материал поздних этапов. | source: M M7; P§36. История M0 остаётся C03, но retention/консолидация/reflector заранее не заморожены; PLAN/M7, open W27. |
| E8 g-zara-m8-frontend | M0 → M8: отображаемое состояние и общие управляемые операции при появлении views; действие UI использует ту же семантику Core. | source: M M8; P§§1.6,3.3,25,37; C01–C06. UI и его API schema позже; open W27. |
| E9 g-zara-m9-autonomy | M0 → M9: Work, context, permissions и результаты как часть будущего основания после доказательства также verification/routing. | source: M M9; P§§22–23,38; C02,C06–C07. Это не поставка всей автономности и не выдача delegation/external rights в M0; open W27. |
| E10 g-zara-transport-proof | M0 → Proof B: Handoff и Core-семантика переноса при проверке автоматического пути после доказанного CLI и до масштабирования. | source: M transport-proof; P§§6,25,40B; C01–C03. Семантика source-backed, transport adapter позже; replay/trust open W19/W21, внешний seam W27. |
| E11 g-zara-independent-install | M0 → внешняя проверка: устанавливаемый сценарий и сохранённое состояние, когда закреплённая версия, инструкция и независимый участник готовы. | source: M independent-install; C SC4; P§§4.1,26–27; C08. Отчёт участника и upgrade proof не M0; bootstrap metadata W26, будущая детализация W27. |
| E12 g-zara-full-migration | Прямого нового M0-контракта нет: готовые реальные процессы/план дня получают отдельный допуск полного переезда. | source: M full-migration; C SC3. Тридцатидневное окно и выключение Direction OS не prerequisite M0; PLAN/full-migration, open W27. |

Каждая E-строка: → PLAN для неустановленного HOW, answerer: PLAN; rewrites: изменение публичного Core contract/данных после появления потребителя может потребовать согласованной миграции обеих сторон, цена ≤1 дня не доказана. Будущие владельцы вопросов названы рядом с узлом, их работа не блокирует Work 1–8. Дельт ADDED/MODIFIED/REMOVED к контракту уже построенного sibling нет: построенного sibling-потребителя этих новых контрактов данная карта не утверждает.

### §SIGNOFF — Declare и Decompose

Declare: accepted under owner delegation after plan check — owner-ack:solmax-plan-conforming-20260907. Предмет: только source-backed поведение C01–C08 и диспозиции E1–E12, сопоставленные с указанными P/C/M. Основание A: «Если нет каких-то расхождений с планом, то я как бы подтверждаю, да, ты можешь идти.»; «В принципе все вот эти моменты авто подтверждать, если не идет какое-то рассогласование плана». Это применение существующей делегации, не новая личная подпись документа. Открытые уточнения не объявлены утверждёнными ответами.

Decompose: import/transport, Work/authority, Mutation/state/history, artifacts/projections, Context и Result/continuation — внутренние обязанности одного M0. Новые sub-nodes не требуются принятым первым сценарием и не создаются; Work 1–8 сохраняют исходный последовательный порядок. source: P§§3–10,41,43; M M0; A. Это схема ответственности, не новый список продуктовых задач.

### §SIGNOFF — Architect и актуальный маршрут

Architect: принятые ограничения импортированы из P/C/M под тем же owner-ack; выбранных новых high-risk механизмов нет. W19,W20,W21,W22,W27 остаются open, answerer PLAN; сравнения, опровержения, технические рекомендации и цена переделки — work/converge-g-zara-m0-continuity-arch.md. W23–W26 остаются открытой PLAN agenda. Любая необходимая перестановка §5, ослабление гарантии или owner-owned выбор без основания в плане возвращается владельцу конкретным расхождением; никакого нового согласия не записано.

Сопоставление вариантов и miner — in-session input evidence, не внешние ответы и не binding G5. Architecture-on-paper передаётся будущему PLAN только в context; PLAN записывает binding ADR и возвращает несоответствие, если вариант не выдерживает реализации. Acceptance W01–W06 не изменён.

Единственный successor: c-solmax-zaratustra-m0-converge-verify-20260907, to session, play converge-verify, verify_target build; отдельный свежий физический чат. Для него проверяемый предмет — §GLOSSARY/§WHAT/§CONTRACTS/§SIGNOFF и источники; deciding-session research reasoning не является входом проверки. Узел остаётся parked, NOW.bet=null, tasks/tracks отсутствуют; готовность к реализации и product done не заявлены.

END_OF_FILE: live/solmax/work/converge-g-zara-m0-continuity.md
