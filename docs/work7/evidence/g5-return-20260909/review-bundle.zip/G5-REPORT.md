# Binding G5 — Work 7 / HOME solmax

Date: 2026-09-09. Fresh physical task: `01a0837c-d088-7eb3-bd31-973ac5d9654e`.
Candidate: **`05047e38acc7386484223a5feacc510b015b2a85`**.
Source candidate: `5866a48c5f9d0f492ad55723120366ffe8f08921`.
Accepted Work6 base: `2fa3111666139eef3ae699319444809fce563ead`.
Review checkout: `C:/my_global_workflow/9111/zaratustra`, initially clean detached HEAD at candidate.
Review commit is the Git commit containing this report and its manifest, returned explicitly in the final handback; it is not the product candidate.

## outcome

**PASS / PASS / PASS for the three original CALL done_when. No blocking findings.**
One previously disclosed, nonblocking legacy CLI encoding defect was independently reproduced (N1 below). No product defect was repaired in G5.

| Original criterion | Verdict | Independent basis |
|---|---|---|
| 1. After Work6, submit_result retains accepted Result, mutation, receipt and next Work link; authoritative recovery | **PASS** | Actual console submit on a NEW restored Work6 main copy advances 11→12 once. Core/CLI/event/receipt/Result/current records agree. Separate process and separately installed restored runtime recover the same operation and next Work. |
| 2. PLAN W19/W20 defines the effect; replay, failure and unknown outcome produce neither second effect nor lost accepted continuation | **PASS** | Eight transaction rejection points roll back; same-id retry succeeds. Competing operations yield one effect. Hard process exit before commit leaves no effect; after commit leaves one discoverable effect. Terminal/revoked/stale/collision ordering, Work5 replay, projection failure, exact file recovery and immutable links were attacked independently. |
| 3. Next package carries recoverable decision, basis, effective revision, result and next step, with exact commit/input/output; clean-chat understanding belongs to T7 | **PASS for the Work7 obligation** | The delivered bytes themselves contain all five facts, both committed decisions and both historical content versions. Full canonical budget, individual hashes, reference grants and final revalidation passed. This review did **not** perform the T7 clean-chat/owner demonstration. |

This is the separately launched G5, not an author self-review or a subagent verdict. The only subagent performed the bounded read-only setup smoke required by AGENTS §10; it did no behavioral review, build or runtime work. No author-task conversation/history was read. The reviewer independently read the full CALL and candidate contracts and chose the attacks below.

## evidence

### Authority, scope and exact source

Authority is the original `c-solmax-zaratustra-m0-result-20260908-work7`, engineering_contract36, PROBA, HOME solmax. Read at candidate: root AGENTS/validation.config; all requested Work7 documents including original CALL, PLAN, fixture permission, output repair, INSTALL, DELIVERY, HOME and root RESULT; prior Work1–6 contracts, Work3 W21 exact owner decision and setup exclusion. The requested architectural sections and C01–C08/E1–E12 were compared read-only. Copies/hashes of referenced design and conforming-HOW authority are in [authority-sources.json](authority-sources.json) and [authority/](authority/). The architecture checkout has CRLF bytes; its LF hash is the CALL-pinned `4f90d19fc742ab616301b6b4121880f76c75faaeb1f606c8190a84853d8b3e0e`.

The confirmed fictional next-content was retained exactly apart from new operation/Work/Artifact identities and reviewer provenance. All submissions start from a NEW copy of accepted Work6 **main**; negative copies are diagnostics only. No real Process, new external authority or second complete Process was introduced. The sole additional foreign sentinel is inert diagnostic content.

Complete actual base→candidate diff: [raw/base-diff.stdout](raw/base-diff.stdout). Base→source diff: [raw/source-diff.stdout](raw/source-diff.stdout). Source→candidate changes are only report/docs/evidence: [raw/delivery-diff.stdout](raw/delivery-diff.stdout). The full base→source diff equals the author's implementation.patch, SHA256 `4a460fb49e6c8ff7d254464e242c9f43cd8c7a7d9aeafc4450a42ebbc900ea46`; [diff-verification.json](diff-verification.json). Released migrations1–5, validation.config, docs/work1–6 and old tests remain unchanged. A scoped first comparison excluded plan/docs and therefore differed; its original result is retained in raw/scoped-diff-comparison-first.json, not treated as a product finding.

### Native and installed identity

Native command, exact candidate checkout: `uv run --locked python -m tools.check --deliver`.
**Exit 0, 140 tests passed in 29.29s**, formatting/lint, types, two import boundaries, hygiene, wheel/sdist build and report structure passed. Full raw: [raw/native-deliver-1.json](raw/native-deliver-1.json), [stdout](raw/native-deliver-1.stdout), [stderr](raw/native-deliver-1.stderr). The report gate checks presence, not truth. An earlier run stopped on nonportable literals in the reviewer's own custody script; [raw/native-deliver.stdout](raw/native-deliver.stdout) retains that failure. Only the review script was corrected before the successful full gate.

Python3.13.7 / SQLite3.50.4 / Pydantic2.13.5 / product0.7.0. Installed runs use `-I` and unrelated-cwd, with no checkout source on sys.path: [runtime-environment.json](runtime-environment.json). Actual packaged `zara.exe` also passed version/status/init-read/projection checks on restored data. All **19** Python files match source, rebuilt wheel and installed runtime; restored installation was checked again: [installed-identity.json](installed-identity.json), [build-artifacts.json](build-artifacts.json), [own-restore-verification.json](own-restore-verification.json).

Final wheel exists both independently built and retained in this review: `zaratustra-0.7.0-py3-none-any.whl`, SHA256 **`dada5424fdf899c7d78d62b97f7acbd9edece35bc2c322e65e877b3bb6db8b84`**. Sdist exists and its 19 source files match. This review's runtime checks execute the final candidate. The author's initial `90f35f6` manifest/console checks were not relabeled as final; the final Result-read ASCII encoding repair was exercised by our actual console discovery with ASCII-encoded stdout.

### Actual accepted effect and exact delivery

| Identity | New G5 main trial |
|---|---|
| Selected workspace | `_scratch/g5-work7-20260909/main` in this checkout |
| workspace / Process | `4846e59f-b3f8-4ed1-9bb3-fea22f713b88` / `bae978a9-a181-4368-be55-b1837fd47747` |
| Source Work | `56785bef-c147-4236-b12a-cad24845567a`, done |
| Operation / completion id | `e32cbdaf-90f6-4b78-9786-d6c08a5af103` |
| Next Work | `83919d84-913e-4089-97d5-94d248206c70`, ready, work_metadata |
| Next declared Artifact | `b3cd633a-a093-4c1a-8c22-02ff70bddfe5` |
| Global revision | 11→12; source and next Work revision12; declared Artifact revision1 |

Exact inputs: [input/request.json](input/request.json), [input/receipt-query.json](input/receipt-query.json), [input/next-query.json](input/next-query.json). Actual console: `raw/console-{submit,discover,next,replay,budget,stale}.{json,stdout,stderr}` and their command records. The console prompts use genuine TTY stdin/stderr; the tee records the prompt without creating permission. The six exact confirmations were **executor** actions on the authorized fictional copy, not owner runtime acceptance. [terminal-session.json](terminal-session.json) records the issued tool inputs and outcomes.

Main receipt and SavedResult agree with authoritative history and current records: [raw/main-check.json](raw/main-check.json), [raw/main-result.json](raw/main-result.json). Public CLI next output equals library/repeated-read/restored output: **20,882/65,536 bytes, eight sources**, SHA256 **`9734dbedeccf8c68342d6dbdb665d758d02cc7edba7e66530b0c565dd6d89cb9`**. Raw [main-context.stdout](raw/main-context.stdout). New identities/provenance/path give this run its own bytes; no budget was raised to obtain them.

### Atomic promise coverage and attacks

Each case file contains its selected copy, exact requests, injected condition, observed refusal/result and before/after DB hashes. Scripts are independent G5 code under [scripts/](scripts/); they are not product changes. Summary indexes: [effects-summary.json](effects-summary.json), [context-summary.json](context-summary.json), [context-recheck-summary.json](context-recheck-summary.json), [file-summary.json](file-summary.json). There are **58 distinct semantic groups**, plus four narrowly repeated harness-error groups. Corrected groups passed; original harness failures remain visible.

| Promise / adversarial attempt | Independent evidence (under cases/) | Outcome / source locus reviewed |
|---|---|---|
| Input before authority; no serialized approval | order-invalid-input-first; untrusted-input-and-piped-approval | Malformed/duplicate/oversize input rejected; pipe cannot grant permission; zero stdout/DB change. handoffs.py:68, cli/__init__.py:131, mutations.py:579. |
| Exact caller/path/complete next content | exact-authorization-binding | Changed goal, acceptance, boundary, budget, requirements, output title/result and IDs or path rejected under old permission. mut:101,153; protocol:247. |
| Current Work/authority before stale/duplicate | order-no-auth-before-stale; order-cancel-before-stale; order-revoke-before-stale; terminal-no-reopen | Current-status/permission refusal wins; cancelled/done cannot reopen; no second Result even with a new id. mut:421; protocol:263. |
| Revision before duplicate; duplicate before bytes | order-stale-before-collision; order-collision-before-bytes; order-refs-before-db | Stale returns conflict; current reused id returns collision even with missing bytes; a fresh request checks bytes before writing. mut:434–459. |
| Keep Work5 acceptance identity/replay/source revision | work5-identity-replay | Stale original refused; explicit transport refresh returns exact original receipt even after loss of bytes; new delivery does not change identity; changed intent collides; new id cannot freshen historical source; revocation wins. protocol:222,240; mut:437. |
| One complete effect at every SQL point | atomic-next-work, atomic-next-artifact, atomic-source-completion, atomic-global-revision, atomic-event, atomic-receipt, atomic-result, atomic-commit | Every injected rejection leaves exact pre-operation DB and zero Result/next; original-id discovery says not_found; same-id exact retry produces one effect. mut:502–575; workspace.py:138. |
| Distinct concurrent operation IDs | concurrent-submit | One accepted receipt and one terminal refusal; global12, exactly two Works. No concurrent second effect. |
| Unknown outcome before commit | precommit-hard-exit-restart; atomic-commit | Child exits78 before COMMIT; coherent zero-effect state and not_found by original id; same request later commits once. No reopen. |
| Unknown outcome after commit and fresh discovery | lost-reply-restart; raw/lost-reply-*.json | Child exits79 after commit before projection/response, stdout empty. A separate new OS process discovers original id, exact next Work and package; terminal retry refuses. mut:579,655. |
| Projection failure does not undo acceptance | projection-committed-receipt | rebuild_required carries committed receipt; Result/next persist. Repeated deterministic rebuild produces identical overview and unchanged DB. mut:591,636. |
| Every acceptance/identity retained in Result | result-omit-old; result-reverse-order; result-foreign-id; result-occupied-next; result-stale-source | Omitted/reordered/foreign decision or occupied identity rejected; stale source cannot be reinterpreted. results.py:27–85. |
| No missing/corrupt result or historical basis accepted | before-submit-missing-result, before-submit-corrupt-result; recheck-before-submit-missing-basis, recheck-before-submit-corrupt-basis | Refused before Result/next effect, unchanged DB. mut:460–473. |
| File-before-DB, retained orphan and exact retry | file-orphan-exact-retry; file-corrupt-orphan-refuses-overwrite; file-publication-staging-failure | Complete unregistered bytes survive failure and are reusable only exactly; damaged orphan is not overwritten; staging retained. No fabricated registration. artifacts.py:100. |
| Late loss separate from historical discovery; exact done-state repair | late-loss-repair-missing-result/basis; recheck-late-loss-repair-corrupt-result/basis | open refuses without a DB revision change; metadata discovery remains exact. Wrong bytes refused; exact audited repair preserves completion/link/active version, adds one revision and retains new quarantine bytes. Old query becomes stale. protocol:263; artifacts.py:100. |
| Whole final snapshot, including non-disclosed state | final-full-process-title; final-full-source-current-work; final-full-membership | Same-revision damage between collect and return refused; no stale package escapes. context.py:224,278; records.py:123; mut:172. |
| Whole final journal/acceptance/descriptor/Result/receipt | final-full-journal, final-full-acceptance, final-full-descriptor, final-full-result, final-full-receipt | Missing/changed authoritative components during assembly refused, independent of manifest presence. |
| Final physical byte validation | final-byte-loss; final-byte-corruption | Included bytes removed/changed after first collect cause full refusal; DB remains unchanged. context.py:173,278. |
| Global invalidation even if selected Work did not change | final-managed-set_work_requirements; final-managed-source-revoke; late-loss repair groups | Any managed change invalidates old query. Source revoke advances global13 while next Work remains revision12; a fresh authorized next query succeeds with the recorded grant. |
| Current consumer revoked/cancelled | final-managed-revoke_work; final-managed-cancel_work | Final validation refuses permission; historical acceptance does not provide current consumer authority. |
| Finite exact historical grants, not ancestor namespace | finite-registered-historical-grants; foreign-query-and-grants | A registered intermediate version that was never granted is refused before its bytes are read. Changed artifact/version/hash, foreign Process/workspace/Work and disguised own ref refuse. Next Work query cannot disclose source Result under next Work identity. |
| All committed acceptances, no latest-wins | all-current-and-inherited-acceptances | In a diagnostic copy, two additional current-Work acceptances coexist with both inherited ones; all four delivered in journal order. Next has no publication rights until an explicit exact grant. context.py:85–147. |
| Every publication reference edge and full closure | missing historical basis groups; finite-grants; full native context tests | Both physical historical versions required; transitive publication metadata retained. Static review also checked scope/hash before the seen-version shortcut (context.py:149–173, results.py:69–84), so a visited target is not an authority shortcut. Source inspection alone is not the behavioral basis. |
| URI/text/projection/receipt never authority | inert-foreign-uri; exact-authorization-binding; untrusted-input-and-piped-approval | Literal foreign file URI is retained as content; sentinel read trap sees no access and sentinel contents are absent. No permission arises from payload/confirmation-shaped data. |
| Complete canonical wire, envelope/manifest/LF, no hidden budget | canonical-wire-budget; actual console budget/stale | Each canonical value/hash/size and raw base64/hash matches; exact whole-output limit succeeds, one byte below and context-only allowance refuse. Console overflow/stale give exit1 with empty stdout. context.py:236. |
| Old schemas and no automatic upgrade | raw/prepare-main.json; raw/work6-compatibility.stdout; native old tests | Original schema5 context still exactly 12,320 bytes/hash; Result requires explicit6, init stays1, default migrate stays4. Released migration bytes unchanged. |
| Durable recovery includes directory layout | archive-restoration.json; author-restore-verification.json; own-restore-verification.json | Full archive manifest comparison, normal extraction and installed reads preserve files **and** dirs, including empty required dirs. No hand-built layout/DB repairs. |

### Five facts recovered from the package itself

The reviewer used [raw/main-context.stdout](raw/main-context.stdout), with only base64 decoding/JSON extraction in [package-only-material.json](package-only-material.json). The following is manual interpretation of those exact bytes, not a test that freezes owner-facing prose and not a separate clean-chat demonstration.

| Fact | Recoverable content and locator |
|---|---|
| Decision | Both acceptance sources carry the fictional instruction `Fictional quoted decision: retain this observation.` The exact leading/trailing spaces are retained in the JSON. IDs `d0032728-…` and `9530e3d4-…` are both present; neither is erased by the other. |
| Basis | Both provenance fields say the observation was accepted because the silver rim is visible. Exact historical basis version `258ea271-…`, hash `de22a678…`, decodes to “Fictional observation: the imaginary moon has a silver rim.” |
| Effective revision | Handoff source revisions **9 and 10**; their committed acceptance revisions **10 and 11**. Result source revision **11**, Result commit revision **12**. Current state/Work/authority **12**, Process **1**, new Artifact **1**. Incoming Result source-before/source-after and receipts preserve these distinctions. A later diagnostic global13/Work12 query confirmed they are not collapsed into one revision. |
| Result | Exact submitted version `75a8c7b3-…`, hash `6fd73651…`, decodes to “Fictional observation, revision two: the silver rim appears at dusk.” Incoming Result connects it to source completion and the receipt by `e32cbdaf-…`. |
| Next step | Current Work and incoming Result's next creation/request specify: compare the two saved descriptions of the fictional moon; produce a short comparison; mention the rim at dusk and reference both versions. Scope is only Fictional observatory, no external action; budget One short local session; metadata plus explicitly inherited grounds, no publication rights. |

The historical decisions do not assert acceptance of the new comparison task. The next Work has its own explicit criteria. Source revocation and current consumer revocation remain distinct, as declared in PLAN. No model selection or executor launch is inferred from the package.

### Retention, restore and preservation

Author Work6 archive: `1657d3a559ba1275ea010b5d83ff0cb818ba26fa74ab195cc86f8218ac57d539`, **75 files/72 dirs**. Author Work7 archive: `90acb543e44959949ea90a94a004528598fcc75b70bb58a6f2f6f21079bcdd2f`, **149 files/136 dirs**. Both original manifests were compared to exact ZIP entries and hashes. Independent read of restored Work7 with final wheel reproduces exactly **20,873 bytes**, SHA256 `f9549bbbfd83eed752dae510c2f91db06217ff130673558c0643af5744fe1894`; no resubmit of that terminal trial.

Our [runtime-bundle.zip](runtime-bundle.zip), SHA256 **`167e432e738ffedb6cc61d1d3e1e19e42aa6d883da07e26649714e823f07c571`**, retains **556 files/675 dirs**, including new main, migrated ready base, all diagnostic copies, original archive restorations, exact dependencies/wheels and minimal sentinel. Its [runtime-manifest.json](runtime-manifest.json) enumerates every retained file and directory. Disposable venv/pycache are excluded, reconstructed from retained exact wheel/pins.

PowerShell Expand-Archive restored the complete bundle into `_scratch/g5-work7-restore-20260909`. Offline installation into a NEW venv and `-I` restart recovered our exact Result/context. All 556 retained file hashes and 675 directories matched before and after reads. The restore inventory is retained separately in own-restore-verification.json. Diagnostic copies remain diagnostic and never become main.

[preservation-before.json](preservation-before.json), [preservation-after.json](preservation-after.json) and [preservation-comparison.json](preservation-comparison.json) verify old Work5/6/7 checkout tracked bytes, branch heads and existing retained runtime files/dirs unchanged. [candidate-preservation.json](candidate-preservation.json) verifies every candidate-tracked file unchanged. Only `docs/g5/work7-20260909/` is committed by this task. [review-manifest.json](review-manifest.json) indexes the review artifacts; [review-bundle.zip](review-bundle.zip) is the complete portable report/raw/script bundle with runtime-bundle inside.

## Findings

### N1 — P2, known nonblocking legacy inspection encoding defect

**Locus:** `src/zaratustra/cli/__init__.py:238` serializes records with literal non-ASCII text; `:260` prints under the current stdout codec. This is the pre-existing class explicitly routed HOME by `docs/work7/OUTPUT-REPAIR.md:27`; not a newly discovered Work7 Result/context defect.

**Repro:** on the new completed fictional G5 main, set `PYTHONIOENCODING=ascii` and run installed `zara records read <main>`. Exact runnable script: [scripts/known_locale.py](scripts/known_locale.py). Raw command/exit/stdout/stderr: [raw/known-legacy-records-ascii.json](raw/known-legacy-records-ascii.json), [stderr](raw/known-legacy-records-ascii.stderr).

**Expected:** owner-local JSON inspection handles retained Unicode fields without an uncaught encoding error. **Observed:** exit1, zero stdout, `UnicodeEncodeError` at final print; DB unchanged. The new Result-read command and exact next-context carrier succeed under the tested ASCII output conditions, so this does not refute the three Work7 criteria. **Disposition:** keep `HOME:work7-locale-output-audit` open for its owner; G5 makes no repair or successor CALL.

No unresolved required-tool or evidence blocker remains. Local sandbox could not initially open uv cache/managed Python; approved execution with the existing local runtime completed the required commands. No external installation or network proof is claimed.

## assumptions

The owner's exact fixture permission and W21 local trust boundary apply to these new fictional copies. Diagnostic local-chat permissions simulate a trusted adapter after permission; actual console tests exercise the accepted console path. They are not proof of a shipped chat transport or owner identity. SQLite's admitted local failure model applies; no power/disk/controller-loss or hostile same-OS-user protection is claimed. A returned package is current at final validation, not a lease for later execution.

## cuts

No original done_when or mandatory boundary was removed. Work8/T7 actual clean-chat understanding and owner demonstration are **NOT VERIFIED here and remain later work by contract**, rather than an implementation failure being hidden by a manifest. No OPORA/frozen pair/provider-diversity/CI gates were added. No Work8, M1+, external service, remote publication, spend, live Direction or archive write occurred. Root Product RESULT, product source/tests/contracts and old runtime data were not edited.

## cost

One fresh local G5 task; one bounded setup-only evaluator; native full gate plus independent installed attacks, six executor console confirmations, two restoration routes and byte custody. 58 semantic groups with four corrected harness reruns; all original failed logs preserved. No external spend. Token/currency cost not measured. No owner deadline or new engineering scope was promised.

## manual-acceptance

Fixture permission exists. Owner runtime acceptance and T7 clean-chat demonstration do not. G5 PASS is a technical verdict on the exact candidate and three Work7 obligations. It does not itself close Direction T6/CALL/M0, issue a Direction successor or admit Work8.

## next

next: solmax

Return this exact candidate verdict, review commit and complete bundle to HOME. Direction owns further disposition and the known N1 follow-up. Product bytes remain frozen throughout this G5.

END_OF_FILE: docs/g5/work7-20260909/G5-REPORT.md
