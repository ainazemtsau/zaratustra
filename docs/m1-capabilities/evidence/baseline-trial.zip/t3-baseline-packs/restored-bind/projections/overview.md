# Zaratustra — generated overview

generated_from_revision: 4
generated_at: 2026-09-09T15:35:14.671923+00:00
workspace_id: c4f6cfc9-7943-435f-b7b0-3373c4bae118

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "acac8629-11ca-4b85-b483-f89f9ab7571e",
  "revision": 1,
  "created_at": "2026-09-09T15:35:13.501059Z",
  "kind": "artifact",
  "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
  "work_id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
  "title": "Fictional batch observation",
  "status": "declared",
  "active_version": null
}
```

## event

```json
{
  "id": "471abca7-da23-4936-8651-f1ea157260a4",
  "revision": 1,
  "created_at": "2026-09-09T15:35:13.501059Z",
  "kind": "event",
  "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
  "work_id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.8.0",
  "state_revision": 1,
  "affected_ids": [
    "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "acac8629-11ca-4b85-b483-f89f9ab7571e"
  ]
}
```

## process

```json
{
  "id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
  "revision": 4,
  "created_at": "2026-09-09T15:35:13.501059Z",
  "kind": "process",
  "title": "Fictional pack lifecycle",
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "1.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
  "revision": 4,
  "created_at": "2026-09-09T15:35:13.501059Z",
  "kind": "work",
  "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
  "goal": "Continue a fictional batch with an exact retained pack version",
  "expected_result": "Recorded observation and continuation",
  "acceptance": [
    "Both fictional marks"
  ],
  "boundaries": [
    "Local fictional data only"
  ],
  "budget": "One T2 lifecycle example",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ],
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "1.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

## Mutation provenance

```json
{
  "id": "1cc8edbc-80c2-4cb2-8efa-7e78325998f1",
  "state_revision": 2,
  "recorded_at": "2026-09-09T15:35:13.581229Z",
  "product_version": "0.8.0",
  "request": {
    "version": 1,
    "operation_id": "cca4e090-3f23-44e2-ab2f-a4ade5728ba7",
    "workspace_id": "c4f6cfc9-7943-435f-b7b0-3373c4bae118",
    "work_id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T2 fixture authorized by RUN c-solmax-zaratustra-m1-packs-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T15:35:13.541029Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-baseline-packs/workspace",
    "request_sha256": "702cbd794a4dc68e15c8cf182e3592951514903cc2d979104fa25e166cf2fd36"
  },
  "fingerprint": "2a3e2cf18c3368e14389e6c6cff49fe6c78b7b0254351610a126499c9c60f29c",
  "before": {
    "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "revision": 1,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "work",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "revision": 2,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "work",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "1a3b37b7-a016-4638-851f-c4e7bb7f4c8a",
  "state_revision": 3,
  "recorded_at": "2026-09-09T15:35:13.779262Z",
  "product_version": "0.8.0",
  "request": {
    "version": 1,
    "operation_id": "3c3e523a-1867-49fc-9653-6a9bf7224578",
    "workspace_id": "c4f6cfc9-7943-435f-b7b0-3373c4bae118",
    "work_id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "probe.batch/v1"
    ],
    "artifact_references": [],
    "provenance": "Fictional T2 fixture authorized by RUN c-solmax-zaratustra-m1-packs-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T15:35:13.776315Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-baseline-packs/workspace",
    "request_sha256": "6ad965e7bfb75e46d0b67f0d99cc6e402917a0e4da92c0fcef61740061fd1ded"
  },
  "fingerprint": "ab41f749e55f15e128125ce03878614e004ec7018cdcacacc2d71831007795b1",
  "before": {
    "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "revision": 2,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "work",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "revision": 3,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "work",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "506b97c5-03d7-49ac-a645-5046a35a4d9d",
  "state_revision": 4,
  "recorded_at": "2026-09-09T15:35:14.671923Z",
  "product_version": "0.8.0",
  "request": {
    "version": 5,
    "operation_id": "6e882a69-319d-4c5f-84a9-c50fd8d88c9d",
    "workspace_id": "c4f6cfc9-7943-435f-b7b0-3373c4bae118",
    "work_id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional Process/Work binding under RUN c-solmax-zaratustra-m1-packs-20260909-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T15:35:14.669508Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-baseline-packs/restored-bind",
    "request_sha256": "1f8965b98d8d76bd83932ef2b3b03ddc7de0f211243c251d3ecf9ae4017dad31"
  },
  "fingerprint": "460dee7396b781c8afa94b15285a93a0ef74ac7fb0804d6a82a6e018dd6c387d",
  "before": {
    "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "revision": 3,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "work",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "revision": 4,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "work",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "revision": 1,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "process",
    "title": "Fictional pack lifecycle"
  },
  "process_after": {
    "id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "revision": 4,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "process",
    "title": "Fictional pack lifecycle",
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

