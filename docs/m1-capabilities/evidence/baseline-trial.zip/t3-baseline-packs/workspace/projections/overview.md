# Zaratustra — generated overview

generated_from_revision: 8
generated_at: 2026-09-09T15:35:14.511256+00:00
workspace_id: c4f6cfc9-7943-435f-b7b0-3373c4bae118

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "acac8629-11ca-4b85-b483-f89f9ab7571e",
  "revision": 2,
  "created_at": "2026-09-09T15:35:13.501059Z",
  "kind": "artifact",
  "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
  "work_id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
  "title": "Fictional batch observation",
  "status": "registered",
  "active_version": "313cb3dd-6bd5-44b3-bee0-92073d092984"
}
```

## artifact

```json
{
  "id": "d5dd7b24-d806-46e9-8660-5895de7eb7e4",
  "revision": 1,
  "created_at": "2026-09-09T15:35:14.511256Z",
  "kind": "artifact",
  "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
  "work_id": "966972bc-a0ea-4786-babe-dfebc2ffa79a",
  "title": "Next fictional batch observation",
  "status": "declared",
  "active_version": null
}
```

## event

```json
{
  "id": "471abca7-da23-4936-8651-f1ea157260a4",
  "revision": 1,
  "created_at": "2026-09-09T15:35:13.501059Z",
  "kind": "event",
  "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
  "work_id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.8.0",
  "state_revision": 1,
  "affected_ids": [
    "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "acac8629-11ca-4b85-b483-f89f9ab7571e"
  ]
}
```

## process

```json
{
  "id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
  "revision": 4,
  "created_at": "2026-09-09T15:35:13.501059Z",
  "kind": "process",
  "title": "Fictional pack lifecycle",
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "1.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
  "revision": 8,
  "created_at": "2026-09-09T15:35:13.501059Z",
  "kind": "work",
  "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
  "goal": "Continue a fictional batch with an exact retained pack version",
  "expected_result": "Recorded observation and continuation",
  "acceptance": [
    "Both fictional marks"
  ],
  "boundaries": [
    "Local fictional data only"
  ],
  "budget": "One T2 lifecycle example",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ],
  "completion_id": "d9cbb991-560d-4d29-a9f5-35736c65dc88",
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "1.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "966972bc-a0ea-4786-babe-dfebc2ffa79a",
  "revision": 8,
  "created_at": "2026-09-09T15:35:14.511256Z",
  "kind": "work",
  "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
  "goal": "Inspect the next fictional batch",
  "expected_result": "Both independent marks",
  "acceptance": [
    "Observation and recording marks are both present"
  ],
  "boundaries": [
    "Local fictional data only"
  ],
  "budget": "One T2 lifecycle example",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ],
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "1.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 313cb3dd-6bd5-44b3-bee0-92073d092984; Artifact revision: 2
  SHA-256: 9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38; bytes: 36
  File: artifacts/acac8629-11ca-4b85-b483-f89f9ab7571e/313cb3dd-6bd5-44b3-bee0-92073d092984.blob

## Mutation provenance

```json
{
  "id": "1cc8edbc-80c2-4cb2-8efa-7e78325998f1",
  "state_revision": 2,
  "recorded_at": "2026-09-09T15:35:13.581229Z",
  "product_version": "0.8.0",
  "request": {
    "version": 1,
    "operation_id": "cca4e090-3f23-44e2-ab2f-a4ade5728ba7",
    "workspace_id": "c4f6cfc9-7943-435f-b7b0-3373c4bae118",
    "work_id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T2 fixture authorized by RUN c-solmax-zaratustra-m1-packs-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T15:35:13.541029Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-baseline-packs/workspace",
    "request_sha256": "702cbd794a4dc68e15c8cf182e3592951514903cc2d979104fa25e166cf2fd36"
  },
  "fingerprint": "2a3e2cf18c3368e14389e6c6cff49fe6c78b7b0254351610a126499c9c60f29c",
  "before": {
    "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "revision": 1,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "work",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "revision": 2,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "work",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "1a3b37b7-a016-4638-851f-c4e7bb7f4c8a",
  "state_revision": 3,
  "recorded_at": "2026-09-09T15:35:13.779262Z",
  "product_version": "0.8.0",
  "request": {
    "version": 1,
    "operation_id": "3c3e523a-1867-49fc-9653-6a9bf7224578",
    "workspace_id": "c4f6cfc9-7943-435f-b7b0-3373c4bae118",
    "work_id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "probe.batch/v1"
    ],
    "artifact_references": [],
    "provenance": "Fictional T2 fixture authorized by RUN c-solmax-zaratustra-m1-packs-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T15:35:13.776315Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-baseline-packs/workspace",
    "request_sha256": "6ad965e7bfb75e46d0b67f0d99cc6e402917a0e4da92c0fcef61740061fd1ded"
  },
  "fingerprint": "ab41f749e55f15e128125ce03878614e004ec7018cdcacacc2d71831007795b1",
  "before": {
    "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "revision": 2,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "work",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "revision": 3,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "work",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "89c7d43c-fe5a-4536-9142-8cb800d219d3",
  "state_revision": 4,
  "recorded_at": "2026-09-09T15:35:14.141664Z",
  "product_version": "0.8.0",
  "request": {
    "version": 5,
    "operation_id": "6e882a69-319d-4c5f-84a9-c50fd8d88c9d",
    "workspace_id": "c4f6cfc9-7943-435f-b7b0-3373c4bae118",
    "work_id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional Process/Work binding under RUN c-solmax-zaratustra-m1-packs-20260909-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T15:35:14.138771Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-baseline-packs/workspace",
    "request_sha256": "840f0454e84b159b5094c2cdf67eba11aa907b6044e995514a41bc426ccf737e"
  },
  "fingerprint": "460dee7396b781c8afa94b15285a93a0ef74ac7fb0804d6a82a6e018dd6c387d",
  "before": {
    "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "revision": 3,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "work",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "revision": 4,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "work",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "revision": 1,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "process",
    "title": "Fictional pack lifecycle"
  },
  "process_after": {
    "id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "revision": 4,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "process",
    "title": "Fictional pack lifecycle",
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "237818a2-328c-4d6b-9485-683fedd01cd7",
  "state_revision": 5,
  "recorded_at": "2026-09-09T15:35:14.244609Z",
  "product_version": "0.8.0",
  "request": {
    "version": 2,
    "operation_id": "0a1c0a55-9821-42f9-b4f3-ca9de3237de3",
    "workspace_id": "c4f6cfc9-7943-435f-b7b0-3373c4bae118",
    "work_id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T2 fixture authorized by RUN c-solmax-zaratustra-m1-packs-20260909-exec",
    "artifact_id": "acac8629-11ca-4b85-b483-f89f9ab7571e",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T15:35:14.241942Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-baseline-packs/workspace",
    "request_sha256": "caf165e111f5e2eb61309b1ec401674a3395d781ed10e61353239c4c77eddbbb"
  },
  "fingerprint": "6c36c8e833e1073ff8da8320d670645b40f4a33f2b757ab90a581274164fb0cb",
  "before": {
    "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "revision": 4,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "work",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "revision": 5,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "work",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "e08d90f1-8b81-4c09-b44d-dccb56182ad9",
  "state_revision": 6,
  "recorded_at": "2026-09-09T15:35:14.278852Z",
  "product_version": "0.8.0",
  "request": {
    "version": 2,
    "operation_id": "313cb3dd-6bd5-44b3-bee0-92073d092984",
    "workspace_id": "c4f6cfc9-7943-435f-b7b0-3373c4bae118",
    "work_id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T2 fixture authorized by RUN c-solmax-zaratustra-m1-packs-20260909-exec",
    "artifact_id": "acac8629-11ca-4b85-b483-f89f9ab7571e",
    "artifact_revision": 1,
    "content_sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38",
    "content_size": 36,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T15:35:14.275276Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-baseline-packs/workspace",
    "request_sha256": "230455a3aa65ae8c3dc6283fe2bae594e2dc4b5c5900cc5ace50ce9afcbac5f1"
  },
  "fingerprint": "309a031c0a1c8d86917628ed2376c1e92108a3428b4e469f590ed2a339da342f",
  "before": {
    "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "revision": 5,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "work",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "revision": 6,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "work",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "acac8629-11ca-4b85-b483-f89f9ab7571e",
    "revision": 1,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "artifact",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "work_id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "title": "Fictional batch observation",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "acac8629-11ca-4b85-b483-f89f9ab7571e",
    "revision": 2,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "artifact",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "work_id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "title": "Fictional batch observation",
    "status": "registered",
    "active_version": "313cb3dd-6bd5-44b3-bee0-92073d092984"
  },
  "artifact_version": {
    "id": "313cb3dd-6bd5-44b3-bee0-92073d092984",
    "artifact_id": "acac8629-11ca-4b85-b483-f89f9ab7571e",
    "work_id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "artifact_revision": 2,
    "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38",
    "size": 36,
    "created_at": "2026-09-09T15:35:14.278852Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "ec741b03-554c-4c46-9cd6-b1c59aba1de4",
  "state_revision": 7,
  "recorded_at": "2026-09-09T15:35:14.326755Z",
  "product_version": "0.8.0",
  "request": {
    "version": 3,
    "operation_id": "7d2ad078-02e0-4ceb-800d-b7e05f006f18",
    "workspace_id": "c4f6cfc9-7943-435f-b7b0-3373c4bae118",
    "work_id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T2 observation; no owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "acac8629-11ca-4b85-b483-f89f9ab7571e",
        "version_id": "313cb3dd-6bd5-44b3-bee0-92073d092984",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "7d2ad078-02e0-4ceb-800d-b7e05f006f18",
      "workspace_id": "c4f6cfc9-7943-435f-b7b0-3373c4bae118",
      "process": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
      "related_work": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "acac8629-11ca-4b85-b483-f89f9ab7571e",
        "version_id": "313cb3dd-6bd5-44b3-bee0-92073d092984",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      },
      "basis": [],
      "provenance": "Fictional T2 observation; no owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T2 fictional adapter"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-packs-20260909-exec",
      "input_sha256": "ba8bd014b53f05dcfb41aae1cf2b17f1ee95130e3355701582b14bbfa3f1d104"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T15:35:14.322920Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-baseline-packs/workspace",
    "request_sha256": "bd63ca94ebf3f93e9c5efd57441e7f59c5c23d2f28a53c90e91787520aaae7ad"
  },
  "fingerprint": "253fb4a4cdff89505a9c5946040a938f9482d45eaa6180e72f9aaa7150f1e520",
  "before": {
    "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "revision": 6,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "work",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "revision": 7,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "work",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "242c12ea-37ca-4120-a408-4ce6028e2838",
  "state_revision": 8,
  "recorded_at": "2026-09-09T15:35:14.511256Z",
  "product_version": "0.8.0",
  "request": {
    "version": 4,
    "operation_id": "d9cbb991-560d-4d29-a9f5-35736c65dc88",
    "workspace_id": "c4f6cfc9-7943-435f-b7b0-3373c4bae118",
    "work_id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "expected_revision": 7,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.batch\",\"pack_version\":\"1.0.0\",\"process_type\":\"fictional.batch-check\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "acac8629-11ca-4b85-b483-f89f9ab7571e",
        "version_id": "313cb3dd-6bd5-44b3-bee0-92073d092984",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 7,
      "result": {
        "artifact_id": "acac8629-11ca-4b85-b483-f89f9ab7571e",
        "version_id": "313cb3dd-6bd5-44b3-bee0-92073d092984",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      },
      "acceptance_ids": [
        "7d2ad078-02e0-4ceb-800d-b7e05f006f18"
      ],
      "next_work": {
        "work_id": "966972bc-a0ea-4786-babe-dfebc2ffa79a",
        "artifact_id": "d5dd7b24-d806-46e9-8660-5895de7eb7e4",
        "goal": "Inspect the next fictional batch",
        "expected_result": "Both independent marks",
        "acceptance": [
          "Observation and recording marks are both present"
        ],
        "boundaries": [
          "Local fictional data only"
        ],
        "budget": "One T2 lifecycle example",
        "executor_requirements": [
          "probe.batch/v1"
        ],
        "artifact_title": "Next fictional batch observation",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T15:35:14.505065Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-baseline-packs/workspace",
    "request_sha256": "2b6f552586d42a5976b97412401348789240af2b2c15f5e214046d173d2ac612"
  },
  "fingerprint": "afa81614056666a10ee67f73187e4d05ce9e846cb3e302ef1091b38d161dca37",
  "before": {
    "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "revision": 7,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "work",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "revision": 8,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "work",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "completion_id": "d9cbb991-560d-4d29-a9f5-35736c65dc88",
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "966972bc-a0ea-4786-babe-dfebc2ffa79a",
    "revision": 8,
    "created_at": "2026-09-09T15:35:14.511256Z",
    "kind": "work",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "goal": "Inspect the next fictional batch",
    "expected_result": "Both independent marks",
    "acceptance": [
      "Observation and recording marks are both present"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "1.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "d5dd7b24-d806-46e9-8660-5895de7eb7e4",
    "revision": 1,
    "created_at": "2026-09-09T15:35:14.511256Z",
    "kind": "artifact",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "work_id": "966972bc-a0ea-4786-babe-dfebc2ffa79a",
    "title": "Next fictional batch observation",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "acac8629-11ca-4b85-b483-f89f9ab7571e",
    "revision": 2,
    "created_at": "2026-09-09T15:35:13.501059Z",
    "kind": "artifact",
    "process_id": "026d993e-f2e4-48f4-8547-e0c08ab41e18",
    "work_id": "0b2a6c7f-07d0-4e5c-83ac-e80743cbcfe5",
    "title": "Fictional batch observation",
    "status": "registered",
    "active_version": "313cb3dd-6bd5-44b3-bee0-92073d092984"
  },
  "result_references": [
    {
      "artifact_id": "acac8629-11ca-4b85-b483-f89f9ab7571e",
      "version_id": "313cb3dd-6bd5-44b3-bee0-92073d092984",
      "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
    }
  ]
}
```

