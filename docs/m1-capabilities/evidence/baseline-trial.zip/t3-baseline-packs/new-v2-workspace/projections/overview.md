# Zaratustra — generated overview

generated_from_revision: 8
generated_at: 2026-09-09T15:35:15.041091+00:00
workspace_id: 583af450-e51a-474b-af9f-c52efc666bf2

Read-only projection. Rebuild from saved state; edits do not change Zaratustra.
Version metadata records publication. Use artifact read to verify current bytes.
This owner-local overview is not a Work context package.

## artifact

```json
{
  "id": "09f2861d-f484-434e-9077-b4c5eb309fc3",
  "revision": 1,
  "created_at": "2026-09-09T15:35:15.041091Z",
  "kind": "artifact",
  "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
  "work_id": "e29d54f4-e3c7-41b0-b60a-bf98b4a518be",
  "title": "Next fictional batch observation",
  "status": "declared",
  "active_version": null
}
```

## artifact

```json
{
  "id": "0e04f2b0-a05d-44e1-819b-183907b530a5",
  "revision": 2,
  "created_at": "2026-09-09T15:35:14.765862Z",
  "kind": "artifact",
  "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
  "work_id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
  "title": "Fictional batch observation",
  "status": "registered",
  "active_version": "107a1ef9-4ec9-4fbf-82e4-b0ee3d3f30bc"
}
```

## event

```json
{
  "id": "5b2056c8-4d62-49b7-926f-130f297e4b90",
  "revision": 1,
  "created_at": "2026-09-09T15:35:14.765862Z",
  "kind": "event",
  "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
  "work_id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
  "action": "initial_records_created",
  "actor": "local-invocation",
  "basis": "explicit-workspace-bootstrap",
  "product_version": "0.8.0",
  "state_revision": 1,
  "affected_ids": [
    "24887db7-7bd2-4429-af19-819e0920ea87",
    "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "0e04f2b0-a05d-44e1-819b-183907b530a5"
  ]
}
```

## process

```json
{
  "id": "24887db7-7bd2-4429-af19-819e0920ea87",
  "revision": 4,
  "created_at": "2026-09-09T15:35:14.765862Z",
  "kind": "process",
  "title": "Fictional pack lifecycle",
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "2.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
  "revision": 8,
  "created_at": "2026-09-09T15:35:14.765862Z",
  "kind": "work",
  "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
  "goal": "Continue a fictional batch with an exact retained pack version",
  "expected_result": "Recorded observation and continuation",
  "acceptance": [
    "Both fictional marks"
  ],
  "boundaries": [
    "Local fictional data only"
  ],
  "budget": "One T2 lifecycle example",
  "status": "done",
  "authority_scope": "work_metadata_and_artifact",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ],
  "completion_id": "a2614576-23dd-4abf-ab28-125979c67f5e",
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "2.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## work

```json
{
  "id": "e29d54f4-e3c7-41b0-b60a-bf98b4a518be",
  "revision": 8,
  "created_at": "2026-09-09T15:35:15.041091Z",
  "kind": "work",
  "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
  "goal": "Inspect the next fictional batch",
  "expected_result": "Both independent marks",
  "acceptance": [
    "Observation and recording marks are both present"
  ],
  "boundaries": [
    "Local fictional data only"
  ],
  "budget": "One T2 lifecycle example",
  "status": "ready",
  "authority_scope": "work_metadata",
  "context_handles": [],
  "dependencies": [],
  "executor_requirements": [
    "probe.batch/v1"
  ],
  "pack_binding": {
    "pack_id": "fictional.batch",
    "pack_version": "2.0.0",
    "process_type": "fictional.batch-check",
    "contract_version": 1,
    "state_version": 1
  }
}
```

## Registered versions

- Version: 107a1ef9-4ec9-4fbf-82e4-b0ee3d3f30bc; Artifact revision: 2
  SHA-256: 9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38; bytes: 36
  File: artifacts/0e04f2b0-a05d-44e1-819b-183907b530a5/107a1ef9-4ec9-4fbf-82e4-b0ee3d3f30bc.blob

## Mutation provenance

```json
{
  "id": "44998dcd-0d2f-4176-bc29-db5bd47f5e4c",
  "state_revision": 2,
  "recorded_at": "2026-09-09T15:35:14.787155Z",
  "product_version": "0.8.0",
  "request": {
    "version": 1,
    "operation_id": "34ae9acf-9a8e-4cc3-9de7-246cc4878c17",
    "workspace_id": "583af450-e51a-474b-af9f-c52efc666bf2",
    "work_id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "expected_revision": 1,
    "operation": "authorize_work",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T2 fixture authorized by RUN c-solmax-zaratustra-m1-packs-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T15:35:14.784116Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-baseline-packs/new-v2-workspace",
    "request_sha256": "0169dc696242783d5538002380f2e78cea0abe464c5dbca54f5f961d37c52b97"
  },
  "fingerprint": "132dacc4ed12731ddd21e72856330df231e6e75613f63a2f55db98bfd4600516",
  "before": {
    "id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "revision": 1,
    "created_at": "2026-09-09T15:35:14.765862Z",
    "kind": "work",
    "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "draft",
    "authority_scope": "none",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "revision": 2,
    "created_at": "2026-09-09T15:35:14.765862Z",
    "kind": "work",
    "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "2d02e50b-f274-491e-8f36-8f284d2e7c92",
  "state_revision": 3,
  "recorded_at": "2026-09-09T15:35:14.826852Z",
  "product_version": "0.8.0",
  "request": {
    "version": 1,
    "operation_id": "20959136-2bda-4643-9b58-f94732b304ab",
    "workspace_id": "583af450-e51a-474b-af9f-c52efc666bf2",
    "work_id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "expected_revision": 2,
    "operation": "set_work_requirements",
    "requirements": [
      "probe.batch/v1"
    ],
    "artifact_references": [],
    "provenance": "Fictional T2 fixture authorized by RUN c-solmax-zaratustra-m1-packs-20260909-exec"
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T15:35:14.824242Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-baseline-packs/new-v2-workspace",
    "request_sha256": "c4e17d9d9947b9f115d7ab4d68cf966b70234f19cbe6d6af10d2d62ae69fd059"
  },
  "fingerprint": "1975f592a8c393d04f202e4d7400794a10303c46a4e7b4c7ab67c535bf2e119e",
  "before": {
    "id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "revision": 2,
    "created_at": "2026-09-09T15:35:14.765862Z",
    "kind": "work",
    "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": []
  },
  "after": {
    "id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "revision": 3,
    "created_at": "2026-09-09T15:35:14.765862Z",
    "kind": "work",
    "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "69e39855-70f7-4d01-98fa-a51f9eaae731",
  "state_revision": 4,
  "recorded_at": "2026-09-09T15:35:14.875109Z",
  "product_version": "0.8.0",
  "request": {
    "version": 5,
    "operation_id": "868c8a60-63f6-4ee1-8793-1354c04dcf0b",
    "workspace_id": "583af450-e51a-474b-af9f-c52efc666bf2",
    "work_id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "expected_revision": 3,
    "operation": "bind_pack",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Explicit fictional Process/Work binding under RUN c-solmax-zaratustra-m1-packs-20260909-exec",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [],
    "handoff": null,
    "delivery": null,
    "submission": null,
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T15:35:14.872377Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-baseline-packs/new-v2-workspace",
    "request_sha256": "5713da74b4198af3e25e8b92e12dd4bdb4fdb3ac99a24ff009430a46bf50f41b"
  },
  "fingerprint": "98a1c2c603165331d60b39e511028a01d7d5255d3c86e347c61b081e5513b41c",
  "before": {
    "id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "revision": 3,
    "created_at": "2026-09-09T15:35:14.765862Z",
    "kind": "work",
    "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ]
  },
  "after": {
    "id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "revision": 4,
    "created_at": "2026-09-09T15:35:14.765862Z",
    "kind": "work",
    "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": null,
  "next_artifact": null,
  "result_artifact": null,
  "result_references": [],
  "process_before": {
    "id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "revision": 1,
    "created_at": "2026-09-09T15:35:14.765862Z",
    "kind": "process",
    "title": "Fictional pack lifecycle"
  },
  "process_after": {
    "id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "revision": 4,
    "created_at": "2026-09-09T15:35:14.765862Z",
    "kind": "process",
    "title": "Fictional pack lifecycle",
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  }
}
```

```json
{
  "id": "aff101a0-64f3-4cf8-a5fc-bc21c45df904",
  "state_revision": 5,
  "recorded_at": "2026-09-09T15:35:14.908530Z",
  "product_version": "0.8.0",
  "request": {
    "version": 2,
    "operation_id": "1daa5195-5d3d-402e-b931-d31c898f051d",
    "workspace_id": "583af450-e51a-474b-af9f-c52efc666bf2",
    "work_id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "expected_revision": 4,
    "operation": "authorize_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T2 fixture authorized by RUN c-solmax-zaratustra-m1-packs-20260909-exec",
    "artifact_id": "0e04f2b0-a05d-44e1-819b-183907b530a5",
    "artifact_revision": 1,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T15:35:14.905208Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-baseline-packs/new-v2-workspace",
    "request_sha256": "6ef19a1fe5e9bd382b0e769d1c31eceb6443a667ac28406c89bb5626457b04fb"
  },
  "fingerprint": "76a01976d8fcefdcb769fb4c05d1357d9b385dda9bdd5eaa47c970f8373d6ef0",
  "before": {
    "id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "revision": 4,
    "created_at": "2026-09-09T15:35:14.765862Z",
    "kind": "work",
    "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "revision": 5,
    "created_at": "2026-09-09T15:35:14.765862Z",
    "kind": "work",
    "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "fbc4f091-251e-4a64-9ce1-7c7a2639738b",
  "state_revision": 6,
  "recorded_at": "2026-09-09T15:35:14.943573Z",
  "product_version": "0.8.0",
  "request": {
    "version": 2,
    "operation_id": "107a1ef9-4ec9-4fbf-82e4-b0ee3d3f30bc",
    "workspace_id": "583af450-e51a-474b-af9f-c52efc666bf2",
    "work_id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "expected_revision": 5,
    "operation": "publish_artifact",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T2 fixture authorized by RUN c-solmax-zaratustra-m1-packs-20260909-exec",
    "artifact_id": "0e04f2b0-a05d-44e1-819b-183907b530a5",
    "artifact_revision": 1,
    "content_sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38",
    "content_size": 36,
    "restore_version": null,
    "references": []
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T15:35:14.940128Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-baseline-packs/new-v2-workspace",
    "request_sha256": "6424f492142450663373d0930f3780c8f9e5550798f7fdd0b0618c2cf9dc0bb0"
  },
  "fingerprint": "231d7ff3d06427c15883b7006e2e49dd3fab9a2c4fae248cb5243ae83d96e201",
  "before": {
    "id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "revision": 5,
    "created_at": "2026-09-09T15:35:14.765862Z",
    "kind": "work",
    "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "revision": 6,
    "created_at": "2026-09-09T15:35:14.765862Z",
    "kind": "work",
    "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": {
    "id": "0e04f2b0-a05d-44e1-819b-183907b530a5",
    "revision": 1,
    "created_at": "2026-09-09T15:35:14.765862Z",
    "kind": "artifact",
    "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "work_id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "title": "Fictional batch observation",
    "status": "declared",
    "active_version": null
  },
  "artifact_after": {
    "id": "0e04f2b0-a05d-44e1-819b-183907b530a5",
    "revision": 2,
    "created_at": "2026-09-09T15:35:14.765862Z",
    "kind": "artifact",
    "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "work_id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "title": "Fictional batch observation",
    "status": "registered",
    "active_version": "107a1ef9-4ec9-4fbf-82e4-b0ee3d3f30bc"
  },
  "artifact_version": {
    "id": "107a1ef9-4ec9-4fbf-82e4-b0ee3d3f30bc",
    "artifact_id": "0e04f2b0-a05d-44e1-819b-183907b530a5",
    "work_id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "artifact_revision": 2,
    "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38",
    "size": 36,
    "created_at": "2026-09-09T15:35:14.943573Z",
    "state_revision": 6
  }
}
```

```json
{
  "id": "7e10fc07-15bd-4d58-bbd2-b45d3a328bb7",
  "state_revision": 7,
  "recorded_at": "2026-09-09T15:35:14.992773Z",
  "product_version": "0.8.0",
  "request": {
    "version": 3,
    "operation_id": "2ab20377-bf22-4df3-bc63-25c9db4a10d9",
    "workspace_id": "583af450-e51a-474b-af9f-c52efc666bf2",
    "work_id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "expected_revision": 6,
    "operation": "accept_handoff",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Fictional T2 observation; no owner acceptance claim",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "0e04f2b0-a05d-44e1-819b-183907b530a5",
        "version_id": "107a1ef9-4ec9-4fbf-82e4-b0ee3d3f30bc",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      }
    ],
    "handoff": {
      "kind": "handoff",
      "version": 1,
      "handoff_id": "2ab20377-bf22-4df3-bc63-25c9db4a10d9",
      "workspace_id": "583af450-e51a-474b-af9f-c52efc666bf2",
      "process": "24887db7-7bd2-4429-af19-819e0920ea87",
      "related_work": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
      "intent": "accepted_result",
      "source_revision": 6,
      "result": {
        "artifact_id": "0e04f2b0-a05d-44e1-819b-183907b530a5",
        "version_id": "107a1ef9-4ec9-4fbf-82e4-b0ee3d3f30bc",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      },
      "basis": [],
      "provenance": "Fictional T2 observation; no owner acceptance claim",
      "owner_instruction": null,
      "constraints": [],
      "open_questions": [],
      "created_by": "T2 fictional adapter"
    },
    "delivery": {
      "source_ref": "c-solmax-zaratustra-m1-packs-20260909-exec",
      "input_sha256": "e44d2dfc019ad0f048c294b1bfbf4ffbefe6019847ce3b9bb7ac61fba9b4be2b"
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T15:35:14.988755Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-baseline-packs/new-v2-workspace",
    "request_sha256": "3dda07e7540294e2628639a3ce3ec91be05f4877e9b45239a102242599e43d46"
  },
  "fingerprint": "6213916e1ab835d1550691422507869faabff8e22233c498a9ad994d2f848f87",
  "before": {
    "id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "revision": 6,
    "created_at": "2026-09-09T15:35:14.765862Z",
    "kind": "work",
    "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "revision": 7,
    "created_at": "2026-09-09T15:35:14.765862Z",
    "kind": "work",
    "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null
}
```

```json
{
  "id": "29cfc6ec-df15-4655-8a40-06808ed6bfae",
  "state_revision": 8,
  "recorded_at": "2026-09-09T15:35:15.041091Z",
  "product_version": "0.8.0",
  "request": {
    "version": 4,
    "operation_id": "a2614576-23dd-4abf-ab28-125979c67f5e",
    "workspace_id": "583af450-e51a-474b-af9f-c52efc666bf2",
    "work_id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "expected_revision": 7,
    "operation": "submit_result",
    "requirements": [],
    "artifact_references": [],
    "provenance": "Exact pack proposal: {\"pack_id\":\"fictional.batch\",\"pack_version\":\"2.0.0\",\"process_type\":\"fictional.batch-check\",\"contract_version\":1,\"state_version\":1}; no authority granted",
    "artifact_id": null,
    "artifact_revision": null,
    "content_sha256": null,
    "content_size": null,
    "restore_version": null,
    "references": [
      {
        "artifact_id": "0e04f2b0-a05d-44e1-819b-183907b530a5",
        "version_id": "107a1ef9-4ec9-4fbf-82e4-b0ee3d3f30bc",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      }
    ],
    "handoff": null,
    "delivery": null,
    "submission": {
      "source_revision": 7,
      "result": {
        "artifact_id": "0e04f2b0-a05d-44e1-819b-183907b530a5",
        "version_id": "107a1ef9-4ec9-4fbf-82e4-b0ee3d3f30bc",
        "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
      },
      "acceptance_ids": [
        "2ab20377-bf22-4df3-bc63-25c9db4a10d9"
      ],
      "next_work": {
        "work_id": "e29d54f4-e3c7-41b0-b60a-bf98b4a518be",
        "artifact_id": "09f2861d-f484-434e-9077-b4c5eb309fc3",
        "goal": "Inspect the next fictional batch",
        "expected_result": "Both independent marks",
        "acceptance": [
          "Observation and recording marks are both present"
        ],
        "boundaries": [
          "Local fictional data only"
        ],
        "budget": "One T2 lifecycle example",
        "executor_requirements": [
          "probe.batch/v1"
        ],
        "artifact_title": "Next fictional batch observation",
        "authority_scope": "work_metadata"
      }
    }
  },
  "confirmation": {
    "channel": "local-chat",
    "actor": "T2-fictional-lifecycle-adapter",
    "source_ref": "RUN c-solmax-zaratustra-m1-packs-20260909-exec; exact local fictional fixture only; acceptance pending",
    "confirmed_at": "2026-09-09T15:35:15.036068Z",
    "workspace_path": "C:/projects/zaratustra/_scratch/m1-capabilities-20260909/_scratch/t3-baseline-packs/new-v2-workspace",
    "request_sha256": "c176904abe7b83425404d32bdced388b474d72adb4b4268f3b78af254118ae17"
  },
  "fingerprint": "e376f4064dc99136a248113b2acb9a5576f7cd3496990d75fe5ef808ac818e75",
  "before": {
    "id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "revision": 7,
    "created_at": "2026-09-09T15:35:14.765862Z",
    "kind": "work",
    "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "after": {
    "id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "revision": 8,
    "created_at": "2026-09-09T15:35:14.765862Z",
    "kind": "work",
    "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "goal": "Continue a fictional batch with an exact retained pack version",
    "expected_result": "Recorded observation and continuation",
    "acceptance": [
      "Both fictional marks"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "done",
    "authority_scope": "work_metadata_and_artifact",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "completion_id": "a2614576-23dd-4abf-ab28-125979c67f5e",
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "affected_projections": [
    "overview.md"
  ],
  "artifact_before": null,
  "artifact_after": null,
  "artifact_version": null,
  "next_work": {
    "id": "e29d54f4-e3c7-41b0-b60a-bf98b4a518be",
    "revision": 8,
    "created_at": "2026-09-09T15:35:15.041091Z",
    "kind": "work",
    "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "goal": "Inspect the next fictional batch",
    "expected_result": "Both independent marks",
    "acceptance": [
      "Observation and recording marks are both present"
    ],
    "boundaries": [
      "Local fictional data only"
    ],
    "budget": "One T2 lifecycle example",
    "status": "ready",
    "authority_scope": "work_metadata",
    "context_handles": [],
    "dependencies": [],
    "executor_requirements": [
      "probe.batch/v1"
    ],
    "pack_binding": {
      "pack_id": "fictional.batch",
      "pack_version": "2.0.0",
      "process_type": "fictional.batch-check",
      "contract_version": 1,
      "state_version": 1
    }
  },
  "next_artifact": {
    "id": "09f2861d-f484-434e-9077-b4c5eb309fc3",
    "revision": 1,
    "created_at": "2026-09-09T15:35:15.041091Z",
    "kind": "artifact",
    "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "work_id": "e29d54f4-e3c7-41b0-b60a-bf98b4a518be",
    "title": "Next fictional batch observation",
    "status": "declared",
    "active_version": null
  },
  "result_artifact": {
    "id": "0e04f2b0-a05d-44e1-819b-183907b530a5",
    "revision": 2,
    "created_at": "2026-09-09T15:35:14.765862Z",
    "kind": "artifact",
    "process_id": "24887db7-7bd2-4429-af19-819e0920ea87",
    "work_id": "95df6cca-2984-4c26-8b94-fff3dea4ab05",
    "title": "Fictional batch observation",
    "status": "registered",
    "active_version": "107a1ef9-4ec9-4fbf-82e4-b0ee3d3f30bc"
  },
  "result_references": [
    {
      "artifact_id": "0e04f2b0-a05d-44e1-819b-183907b530a5",
      "version_id": "107a1ef9-4ec9-4fbf-82e4-b0ee3d3f30bc",
      "sha256": "9bd4f2518d0531c2e0fe596e668e67a59b380143203dc53d05c28fb5f8576e38"
    }
  ]
}
```

